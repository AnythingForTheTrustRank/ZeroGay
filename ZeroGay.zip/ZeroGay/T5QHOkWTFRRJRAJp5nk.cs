using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using Il2CppSystem.IO;
using System;

internal delegate void T5QHOkWTFRRJRAJp5nk(object object_0, Stream stream_0, Il2CppSystem.Object object_1);