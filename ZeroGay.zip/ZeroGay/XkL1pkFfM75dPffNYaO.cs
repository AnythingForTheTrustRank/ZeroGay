using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate bool XkL1pkFfM75dPffNYaO(string , ref Color );