using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate RuntimeTypeHandle c1gR20k3GQnkXYSbeun(object object_0);