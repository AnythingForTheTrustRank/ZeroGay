using AksgHVKH9UOXlBDvRpO;
using Blaze.API.Wings;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements;
using X7IetPATbOXxq4U7Vmy;

namespace tj5E7kTcTdevpjQ41CC
{
	internal static class x5iKdsT53msph4ugL7v
	{
		private static QuickMenu VrXTT3VGiT;

		private static GameObject cGkT7GSyZl;

		private static GameObject dluTegwA5e;

		private static GameObject ITMTCH2Dra;

		private static GameObject VYkTqs1Do3;

		private static GameObject i85ThCIsnV;

		private static GameObject kd2THHam1R;

		private static GameObject pXnTsH8yKp;

		private static Sprite mwcTRvy1m6;

		private static Sprite JXLTtwcOf2;

		private static System.Random yxiTKBCfbV;

		internal static BaseWing TWUTl2Y4qm;

		internal static BaseWing MpJTAcdAnA;

		internal static Action<BaseWing> Pq6TGACSdE;

		internal static Action xJxTdPrXiC;

		internal static Action gBgTvS515b;

		private static x5iKdsT53msph4ugL7v qZx5jDgFuXf4fikxNhw;

		static x5iKdsT53msph4ugL7v()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			x5iKdsT53msph4ugL7v.yxiTKBCfbV = new System.Random();
			x5iKdsT53msph4ugL7v.TWUTl2Y4qm = new BaseWing();
			x5iKdsT53msph4ugL7v.MpJTAcdAnA = new BaseWing();
			x5iKdsT53msph4ugL7v.Pq6TGACSdE = (BaseWing _) => {
			};
			x5iKdsT53msph4ugL7v.xJxTdPrXiC = () => {
				x5iKdsT53msph4ugL7v.xJxTdPrXiC = () => {
				};
				x5iKdsT53msph4ugL7v.Pq6TGACSdE(x5iKdsT53msph4ugL7v.TWUTl2Y4qm);
			};
			x5iKdsT53msph4ugL7v.gBgTvS515b = () => {
				x5iKdsT53msph4ugL7v.gBgTvS515b = () => {
				};
				x5iKdsT53msph4ugL7v.Pq6TGACSdE(x5iKdsT53msph4ugL7v.MpJTAcdAnA);
			};
		}

		internal static int accTMUKvyj()
		{
			return x5iKdsT53msph4ugL7v.yxiTKBCfbV.Next(10000, 99999);
		}

		internal static GameObject adPTIt3N6U()
		{
			if (x5iKdsT53msph4ugL7v.dluTegwA5e == null)
			{
				x5iKdsT53msph4ugL7v.dluTegwA5e = GameObject.Find("UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard").get_gameObject();
			}
			return x5iKdsT53msph4ugL7v.dluTegwA5e;
		}

		internal static GameObject AKkT6ZQe76()
		{
			if (x5iKdsT53msph4ugL7v.VYkTqs1Do3 == null)
			{
				x5iKdsT53msph4ugL7v.VYkTqs1Do3 = GameObject.Find("UserInterface").get_transform().Find("MenuContent/Screens/Settings/AudioDevicePanel/VolumeSlider").get_gameObject();
			}
			return x5iKdsT53msph4ugL7v.VYkTqs1Do3;
		}

		internal static GameObject C0kTQASGMO()
		{
			if (x5iKdsT53msph4ugL7v.kd2THHam1R == null)
			{
				x5iKdsT53msph4ugL7v.kd2THHam1R = GameObject.Find("UserInterface/MenuContent/Screens");
			}
			return x5iKdsT53msph4ugL7v.kd2THHam1R;
		}

		public static Sprite dZgTrfwTya()
		{
			if (x5iKdsT53msph4ugL7v.mwcTRvy1m6 == null)
			{
				x5iKdsT53msph4ugL7v.mwcTRvy1m6 = GameObject.Find("UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Notifications/Panel_NoNotifications_Message/Icon").GetComponent<Image>().get_sprite();
			}
			return x5iKdsT53msph4ugL7v.mwcTRvy1m6;
		}

		internal static void eAFTapGNgO(this object object_0)
		{
			object_0.RAfTynoTZM(null);
		}

		internal static GameObject F8fTogOgTD()
		{
			if (x5iKdsT53msph4ugL7v.ITMTCH2Dra == null)
			{
				x5iKdsT53msph4ugL7v.ITMTCH2Dra = GameObject.Find("UserInterface").get_transform().Find("MenuContent/Popups/PerformanceSettingsPopup/Popup/Pages/Page_LimitAvatarPerformance/Tooltip_Details").get_gameObject();
			}
			return x5iKdsT53msph4ugL7v.ITMTCH2Dra;
		}

		public static Sprite Kl0T2DM75U()
		{
			if (x5iKdsT53msph4ugL7v.JXLTtwcOf2 == null)
			{
				x5iKdsT53msph4ugL7v.JXLTtwcOf2 = GameObject.Find("UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Settings/Panel_QM_ScrollRect/Viewport/VerticalLayoutGroup/Buttons_UI_Elements_Row_1/Button_ToggleQMInfo/Icon_Off").GetComponent<Image>().get_sprite();
			}
			return x5iKdsT53msph4ugL7v.JXLTtwcOf2;
		}

		internal static GameObject KZmTOk2LMU()
		{
			if (x5iKdsT53msph4ugL7v.cGkT7GSyZl == null)
			{
				foreach (Button componentsInChild in x5iKdsT53msph4ugL7v.lcQTnhPaXn().GetComponentsInChildren<Button>(true))
				{
					if (componentsInChild.get_name() != "Button_Screenshot")
					{
						continue;
					}
					x5iKdsT53msph4ugL7v.cGkT7GSyZl = componentsInChild.get_gameObject();
				}
			}
			return x5iKdsT53msph4ugL7v.cGkT7GSyZl;
		}

		internal static QuickMenu lcQTnhPaXn()
		{
			if (x5iKdsT53msph4ugL7v.VrXTT3VGiT == null)
			{
				x5iKdsT53msph4ugL7v.VrXTT3VGiT = Resources.FindObjectsOfTypeAll<QuickMenu>().get_Item(0);
			}
			return x5iKdsT53msph4ugL7v.VrXTT3VGiT;
		}

		internal static GameObject msqTBPPH7Q()
		{
			if (x5iKdsT53msph4ugL7v.pXnTsH8yKp == null)
			{
				x5iKdsT53msph4ugL7v.pXnTsH8yKp = GameObject.Find("UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase");
			}
			return x5iKdsT53msph4ugL7v.pXnTsH8yKp;
		}

		internal static x5iKdsT53msph4ugL7v OkeByygZDrpdwpGiyre()
		{
			return x5iKdsT53msph4ugL7v.qZx5jDgFuXf4fikxNhw;
		}

		internal static void RAfTynoTZM(this object object_0, Func<Transform, bool> func_0)
		{
			for (int i = object_0.get_childCount() - 1; i >= 0; i--)
			{
				if ((func_0 == null ? true : func_0(object_0.GetChild(i))))
				{
					UnityEngine.Object.DestroyImmediate(object_0.GetChild(i).get_gameObject());
				}
			}
		}

		internal static bool vmLfQxgXGd2gpiAtVOB()
		{
			return x5iKdsT53msph4ugL7v.qZx5jDgFuXf4fikxNhw == null;
		}

		internal static GameObject ztFTYNTouX()
		{
			if (x5iKdsT53msph4ugL7v.i85ThCIsnV == null)
			{
				x5iKdsT53msph4ugL7v.i85ThCIsnV = GameObject.Find("UserInterface").get_transform().Find("MenuContent/Screens/Settings/AudioDevicePanel/LevelText").get_gameObject();
			}
			return x5iKdsT53msph4ugL7v.i85ThCIsnV;
		}

		public enum MifxmhtwP8rVW59du8e
		{
			Worlds,
			Avatars,
			Social,
			Settings,
			Safety,
			UserInfo
		}
	}
}