using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.Management;

internal delegate ModerationManager kGOsRnRkxXY3KbKlX64();