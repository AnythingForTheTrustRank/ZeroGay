using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection.Emit;

internal delegate void cIB825kAnJ4142ZJvZ3(object object_0, OpCode opCode_0, LocalBuilder localBuilder_0);