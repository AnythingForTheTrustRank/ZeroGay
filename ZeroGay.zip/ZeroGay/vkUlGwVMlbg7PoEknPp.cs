using AksgHVKH9UOXlBDvRpO;
using ExitGames.Client.Photon;
using System;

internal delegate SendOptions vkUlGwVMlbg7PoEknPp();