using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object ii8qRuLq97ioP7iGRdO(Type , ushort );