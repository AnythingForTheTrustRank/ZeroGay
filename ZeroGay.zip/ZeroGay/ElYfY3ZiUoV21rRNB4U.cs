using b3eD5DgJPcASx0xfHYB;
using System;
using System.Collections;

internal delegate object ElYfY3ZiUoV21rRNB4U(IEnumerator );