using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.SDKBase;

internal delegate VRCPlayerApi kF3gKCFGx4HwjGpuahA(object );