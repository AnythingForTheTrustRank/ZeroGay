using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection.Emit;

internal delegate ILGenerator gEkGlGJ79umL5XQt9J6(object );