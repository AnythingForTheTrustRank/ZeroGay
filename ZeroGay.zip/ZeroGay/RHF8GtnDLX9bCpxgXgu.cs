using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void RHF8GtnDLX9bCpxgXgu(string , string );