using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string Nni9MynyImaw2aSloQO(string );