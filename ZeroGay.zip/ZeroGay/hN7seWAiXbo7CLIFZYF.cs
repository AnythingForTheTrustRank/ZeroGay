using b3eD5DgJPcASx0xfHYB;
using System;
using System.Diagnostics;

internal delegate Process hN7seWAiXbo7CLIFZYF(string );