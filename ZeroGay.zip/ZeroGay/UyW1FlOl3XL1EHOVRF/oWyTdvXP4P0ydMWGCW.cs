using b3eD5DgJPcASx0xfHYB;
using Eviction;
using Harmony;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using Skq89h9RZgXKFTIx1Mo;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDKBase;

namespace UyW1FlOl3XL1EHOVRF
{
	internal static class oWyTdvXP4P0ydMWGCW
	{
		public static HarmonyInstance aQEAZ3sal;

		private static Sprite meiVB177q;

		private static AssetBundle AOlLdIgGF;

		private static Material FkHJZQcHo;

		private static Sprite GOi5Bvwug;

		public static Color hgjdxS6AH;

		public static Color Ak9oZXRQW;

		public static Color M7qmIXSh2;

		public static Color l3DDbHMy8;

		public static Color BnecDnyPR;

		public static Color AJnyH5SG8;

		public static Color aEwEEXwOE;

		public static Color wpvzmNXFd;

		public static Color q5ukqdIPBe;

		private static System.Collections.Generic.List<string> pgkkkaDoZg;

		public static Texture2D fi6k85grOg;

		public static System.Collections.Generic.List<string> rcFkHfSeWH;

		public static System.Collections.Generic.List<GameObject> bYXkGPJXxW;

		private static byte Gjak3XEojv;

		private static byte sIbk93E8K0;

		private static int nZBks1ev7H;

		private static oWyTdvXP4P0ydMWGCW CDpibGJDMR7m4YbShCw;

		static oWyTdvXP4P0ydMWGCW()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			oWyTdvXP4P0ydMWGCW.hgjdxS6AH = new Color(H0Z2a890qe6bfIwSnp8.tKNM4WD3NI(), H0Z2a890qe6bfIwSnp8.BTLMtNukIa(), H0Z2a890qe6bfIwSnp8.E6SMN6sMmm());
			oWyTdvXP4P0ydMWGCW.Ak9oZXRQW = new Color(0.3f, 1f, 1f);
			oWyTdvXP4P0ydMWGCW.M7qmIXSh2 = new Color(H0Z2a890qe6bfIwSnp8.xyKMk94lkO(), H0Z2a890qe6bfIwSnp8.lC6MGOGGEx(), H0Z2a890qe6bfIwSnp8.MTJMsuAR1b());
			oWyTdvXP4P0ydMWGCW.l3DDbHMy8 = new Color(H0Z2a890qe6bfIwSnp8.FFpMF3B5cv(), H0Z2a890qe6bfIwSnp8.D61MRFAkXs(), H0Z2a890qe6bfIwSnp8.PpvMnlgaIA());
			oWyTdvXP4P0ydMWGCW.BnecDnyPR = new Color(H0Z2a890qe6bfIwSnp8.iRvMbZgXQk(), H0Z2a890qe6bfIwSnp8.SuVMTJZn6t(), H0Z2a890qe6bfIwSnp8.iNyMgGv7w4());
			oWyTdvXP4P0ydMWGCW.AJnyH5SG8 = new Color(H0Z2a890qe6bfIwSnp8.Cb8MSQKZTL(), H0Z2a890qe6bfIwSnp8.d2SMOrLICn(), H0Z2a890qe6bfIwSnp8.H7mMlX4LNO());
			oWyTdvXP4P0ydMWGCW.aEwEEXwOE = new Color(H0Z2a890qe6bfIwSnp8.RMssdZLXGo(), H0Z2a890qe6bfIwSnp8.EPOsDAugEb(), H0Z2a890qe6bfIwSnp8.YBPsEUJYFB());
			oWyTdvXP4P0ydMWGCW.wpvzmNXFd = new Color(H0Z2a890qe6bfIwSnp8.gn7suNF8j6(), H0Z2a890qe6bfIwSnp8.LeNsX1GhmW(), 0f);
			oWyTdvXP4P0ydMWGCW.q5ukqdIPBe = new Color(0.9f, 0f, 0.75f);
			oWyTdvXP4P0ydMWGCW.pgkkkaDoZg = new System.Collections.Generic.List<string>();
			oWyTdvXP4P0ydMWGCW.rcFkHfSeWH = new System.Collections.Generic.List<string>()
			{
				"Admin",
				"VIP",
				"Standard"
			};
			oWyTdvXP4P0ydMWGCW.bYXkGPJXxW = new System.Collections.Generic.List<GameObject>();
			oWyTdvXP4P0ydMWGCW.nZBks1ev7H = 0;
		}

		public static int bVtRJDioK(this object u0020)
		{
			int num;
			num = (u0020.Method_Public_get_PlayerNet_0().Method_Public_get_Byte_0() == 0 ? 0 : (int)(1000f / (float)u0020.Method_Public_get_PlayerNet_0().Method_Public_get_Byte_0()));
			return num;
		}

		public static void cw6B0Lkp3()
		{
			// 
			// Current member / type: System.Void UyW1FlOl3XL1EHOVRF.oWyTdvXP4P0ydMWGCW::cw6B0Lkp3()
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void cw6B0Lkp3()
			// 
			// Index was out of range. Must be non-negative and less than the size of the collection.
			// Parameter name: index
			//    at System.ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument argument, ExceptionResource resource)
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 184
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 118
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 56
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public static string FJpPiaW7b(this object u0020)
		{
			return u0020.Method_Internal_get_APIUser_0().get_id();
		}

		internal static Transform fKRroQl2x(object u0020, int u0020)
		{
			Transform transform = UnityEngine.Object.Instantiate<Transform>(u0020, u0020.get_parent(), false);
			transform.set_name(string.Format("EvolveTags:{0}", u0020));
			transform.set_localPosition(new Vector3(0f, 33f, 0f));
			transform.get_gameObject().set_active(true);
			Transform transform1 = null;
			for (int i = transform.get_childCount(); i > 0; i--)
			{
				Transform child = transform.GetChild(i - 1);
				if (child.get_name() != "Trust Text")
				{
					UnityEngine.Object.Destroy(child.get_gameObject());
				}
				else
				{
					transform1 = child;
				}
			}
			return transform1;
		}

		internal static void fPweSYolc(int u0020, object u0020, object u0020, Color u0020, object u0020)
		{
			Transform transform;
			Transform transform1 = u0020.Find(string.Format("EvolveTags:{0}", u0020));
			if (transform1 == null)
			{
				transform = oWyTdvXP4P0ydMWGCW.fKRroQl2x(u0020, u0020);
			}
			else
			{
				transform1.get_gameObject().SetActive(true);
				transform = transform1.Find("Trust Text");
			}
			TextMeshProUGUI component = transform.GetComponent<TextMeshProUGUI>();
			transform1.GetComponent<ImageThreeSlice>().set_color(u0020);
			component.set_color(u0020);
			component.set_richText(true);
			component.set_text(u0020);
		}

		private static void GQmxDom7i(object u0020, Color? u0020 = null, Color? u0020 = null, Color? u0020 = null, Color? u0020 = null, bool u0020 = false, bool u0020 = false)
		{
			Color color = new Color();
			if (u0020 != null)
			{
				if (u0020)
				{
					u0020.NameBackground.set_material(null);
					u0020.QuickStatsBackground.set_material(null);
					u0020.IconBackground.set_material(null);
				}
				else
				{
					u0020.NameBackground.set_material(oWyTdvXP4P0ydMWGCW.FkHJZQcHo);
					u0020.QuickStatsBackground.set_material(oWyTdvXP4P0ydMWGCW.FkHJZQcHo);
					u0020.IconBackground.set_material(oWyTdvXP4P0ydMWGCW.FkHJZQcHo);
				}
				Color _color = u0020.NameBackground.get_color();
				Color _color1 = u0020.IconBackground.get_color();
				Color color1 = u0020.QuickStatsBackground.get_color();
				Color _faceColor = u0020.Name.get_faceColor();
				if (u0020.HasValue)
				{
					Color value = u0020.Value;
					Color value1 = u0020.Value;
					value.a = _color.a;
					value1.a = color1.a;
					u0020.NameBackground.set_color(value / 2f);
					u0020.QuickStatsBackground.set_color(value1);
				}
				if (u0020.HasValue)
				{
					Color value2 = u0020.Value;
					value2.a = _color1.a;
					u0020.IconBackground.set_color(value2);
				}
				if (u0020.HasValue && !u0020.HasValue)
				{
					Color color2 = u0020.Value;
					color2.a = _faceColor.a;
					u0020.SNC(color2);
					u0020.ORbld();
				}
				if (u0020.HasValue && u0020.HasValue)
				{
					Color value3 = u0020.Value;
					Color color3 = u0020.Value;
					value3.a = _faceColor.a;
					color3.a = _faceColor.a;
				}
				if (u0020)
				{
					u0020.IsEvolved = true;
					ColorUtility.TryParseHtmlString("#ff0062", ref color);
					u0020.IconPulse.set_color(color);
					u0020.IconGlow.set_color(Color.get_black() * 2f);
					u0020.NamePulse.set_color(color);
					u0020.NameGlow.set_color(Color.get_black() * 2f);
				}
			}
		}

		private static void iGYKkuboF(object u0020, object u0020, object u0020, object u0020)
		{
			u0020.IconBackground.set_enabled(true);
			u0020.Icon.set_enabled(true);
			u0020.IconContainer.SetActive(true);
			u0020.Icon.set_texture(u0020);
		}

		public static string NiW0xN9aR(this object u0020)
		{
			string str;
			if (u0020.bVtRJDioK() < 80)
			{
				str = (u0020.bVtRJDioK() > 80 || u0020.bVtRJDioK() < 30 ? "<color=red>" : "<color=#FF7000>");
			}
			else
			{
				str = "<color=#59D365>";
			}
			string str1 = str;
			string str2 = string.Format("{0}{1}</color>", str1, u0020.bVtRJDioK());
			return str2;
		}

		public static string OwNFSv9R4(this object u0020)
		{
			string str;
			if (u0020.Method_Public_get_PlayerNet_0() <= 75)
			{
				str = "<color=#59D365>";
			}
			else
			{
				str = (u0020.Method_Public_get_PlayerNet_0() < 75 || u0020.Method_Public_get_PlayerNet_0() > 150 ? "<color=red>" : "<color=#FF7000>");
			}
			string str1 = str;
			string str2 = string.Format("{0}{1}</color>", str1, (short)u0020.Method_Public_get_PlayerNet_0());
			return str2;
		}

		internal static oWyTdvXP4P0ydMWGCW ptBYNKJyPcui8nqvXCL()
		{
			return oWyTdvXP4P0ydMWGCW.CDpibGJDMR7m4YbShCw;
		}

		internal static void RnW1MoSs7()
		{
			using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Evolve.Assets"))
			{
				using (MemoryStream memoryStream = new MemoryStream((int)manifestResourceStream.Length))
				{
					manifestResourceStream.CopyTo(memoryStream);
					oWyTdvXP4P0ydMWGCW.AOlLdIgGF = AssetBundle.LoadFromMemory_Internal(memoryStream.ToArray(), 0);
					AssetBundle aOlLdIgGF = oWyTdvXP4P0ydMWGCW.AOlLdIgGF;
					aOlLdIgGF.set_hideFlags(aOlLdIgGF.get_hideFlags() | 32);
				}
			}
			if (oWyTdvXP4P0ydMWGCW.AOlLdIgGF != null)
			{
				oWyTdvXP4P0ydMWGCW.FkHJZQcHo = oWyTdvXP4P0ydMWGCW.AOlLdIgGF.LoadAsset_Internal("NameplateMat", Il2CppType.Of<Material>()).Cast<Material>();
				Material fkHJZQcHo = oWyTdvXP4P0ydMWGCW.FkHJZQcHo;
				fkHJZQcHo.set_hideFlags(fkHJZQcHo.get_hideFlags() | 32);
				oWyTdvXP4P0ydMWGCW.GOi5Bvwug = oWyTdvXP4P0ydMWGCW.AOlLdIgGF.LoadAsset_Internal("NameplateOutline", Il2CppType.Of<Sprite>()).Cast<Sprite>();
				Sprite gOi5Bvwug = oWyTdvXP4P0ydMWGCW.GOi5Bvwug;
				gOi5Bvwug.set_hideFlags(gOi5Bvwug.get_hideFlags() | 32);
			}
		}

		public static void sZyfKxqj4(object u0020)
		{
			Nameplate component = u0020.get_gameObject().GetComponent<Nameplate>();
			if (component != null)
			{
				component.Reset();
			}
			if (oWyTdvXP4P0ydMWGCW.meiVB177q != null && component != null)
			{
				ImageThreeSlice imageThreeSlouse = component.NameBackground.GetComponent<ImageThreeSlice>();
				if (imageThreeSlouse != null)
				{
					imageThreeSlouse.set__sprite(oWyTdvXP4P0ydMWGCW.meiVB177q);
				}
			}
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			oWyTdvXP4P0ydMWGCW.GQmxDom7i(component, new Color?(Color.get_white()), new Color?(Color.get_white()), nullable1, nullable, true, false);
		}

		internal static void tsQnb6qNE(ref int u0020, object u0020, object u0020, Color u0020, object u0020)
		{
			Transform transform;
			Transform transform1 = u0020.Find(string.Format("EvolveTags:{0}", u0020));
			if (transform1 == null)
			{
				transform = oWyTdvXP4P0ydMWGCW.fKRroQl2x(u0020, u0020);
			}
			else
			{
				transform1.get_gameObject().SetActive(true);
				transform = transform1.Find("Trust Text");
			}
			TextMeshProUGUI component = transform.GetComponent<TextMeshProUGUI>();
			component.set_color(u0020);
			component.set_text(u0020);
			u0020++;
		}

		internal static bool Ub0iMKJcwBgHS8cnV5o()
		{
			return oWyTdvXP4P0ydMWGCW.CDpibGJDMR7m4YbShCw == null;
		}

		public static string uENjdoXKw(this object u0020)
		{
			string str;
			if (u0020.get_tags().Contains("Evolved"))
			{
				str = "Evolved";
			}
			else if (u0020.get_hasModerationPowers() || u0020.get_tags().Contains("admin_moderator"))
			{
				str = "Moderator";
			}
			else if (u0020.get_hasSuperPowers() || u0020.get_tags().Contains("admin_"))
			{
				str = "Admin";
			}
			else if (u0020.get_hasVIPAccess() || u0020.get_tags().Contains("system_legend") && u0020.get_tags().Contains("system_trust_legend") && u0020.get_tags().Contains("system_trust_trusted"))
			{
				str = "Legend";
			}
			else if (u0020.get_hasLegendTrustLevel() || u0020.get_tags().Contains("system_trust_legend") && u0020.get_tags().Contains("system_trust_trusted"))
			{
				str = "Veteran";
			}
			else if (u0020.get_hasVeteranTrustLevel())
			{
				str = "Trusted";
			}
			else if (u0020.get_hasTrustedTrustLevel())
			{
				str = "Known";
			}
			else if (u0020.get_hasKnownTrustLevel())
			{
				str = "User";
			}
			else if (u0020.get_hasBasicTrustLevel() || u0020.get_isNewUser())
			{
				str = "New User";
			}
			else if (u0020.get_hasNegativeTrustLevel())
			{
				str = "NegativeTrust";
			}
			else
			{
				str = (u0020.get_hasVeryNegativeTrustLevel() ? "VeryNegativeTrust" : "Visitor");
			}
			return str;
		}

		public static Il2CppSystem.Collections.Generic.List<Player> W0elhuS0P(this object u0020)
		{
			return u0020.get_field_Private_List_1_Player_0();
		}

		public static bool X0ppMu4vU(this object u0020)
		{
			return u0020.Method_Public_get_VRCPlayerApi_0().get_isMaster();
		}
	}
}