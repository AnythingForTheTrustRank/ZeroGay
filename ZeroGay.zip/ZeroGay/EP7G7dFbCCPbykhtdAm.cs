using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate bool EP7G7dFbCCPbykhtdAm(string , string );