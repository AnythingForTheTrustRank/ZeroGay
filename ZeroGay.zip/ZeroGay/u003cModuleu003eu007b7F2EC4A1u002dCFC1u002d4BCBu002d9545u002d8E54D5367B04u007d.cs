using System;

internal class <Module>{7F2EC4A1-CFC1-4BCB-9545-8E54D5367B04}
{

}