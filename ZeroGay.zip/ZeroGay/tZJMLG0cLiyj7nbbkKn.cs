using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;

internal delegate Delegate tZJMLG0cLiyj7nbbkKn(Type , object , MethodInfo );