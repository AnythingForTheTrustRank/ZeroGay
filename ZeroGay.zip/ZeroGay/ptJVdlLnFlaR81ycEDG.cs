using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void ptJVdlLnFlaR81ycEDG(object object_0, Component component_0);