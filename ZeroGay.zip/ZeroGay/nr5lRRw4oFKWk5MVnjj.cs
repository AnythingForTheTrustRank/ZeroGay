using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate Il2CppReferenceArray<GameObject> nr5lRRw4oFKWk5MVnjj(string string_0);