using System;

namespace Events
{
	public interface OnUpdateEvent
	{
		void OnUpdate();
	}
}