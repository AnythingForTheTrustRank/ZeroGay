using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;
using VRC;

internal delegate List<Player> rLEvrnZneMWMFkH8HKZ(object );