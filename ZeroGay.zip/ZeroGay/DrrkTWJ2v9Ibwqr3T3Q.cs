using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate GameObject DrrkTWJ2v9Ibwqr3T3Q(object object_0);