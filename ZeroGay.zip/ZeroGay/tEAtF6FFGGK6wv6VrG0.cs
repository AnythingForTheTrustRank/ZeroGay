using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Color tEAtF6FFGGK6wv6VrG0(object );