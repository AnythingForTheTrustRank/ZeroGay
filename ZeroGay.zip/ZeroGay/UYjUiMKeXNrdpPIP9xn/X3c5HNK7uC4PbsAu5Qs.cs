using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;
using X7IetPATbOXxq4U7Vmy;

namespace UYjUiMKeXNrdpPIP9xn
{
	internal class X3c5HNK7uC4PbsAu5Qs
	{
		internal static Module nduKCdK2kH;

		private static X3c5HNK7uC4PbsAu5Qs GHYMOGz43WwMHIjjNWw;

		static X3c5HNK7uC4PbsAu5Qs()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			X3c5HNK7uC4PbsAu5Qs.nduKCdK2kH = typeof(X3c5HNK7uC4PbsAu5Qs).Assembly.ManifestModule;
		}

		public X3c5HNK7uC4PbsAu5Qs()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static void ekTcn98Yxve(int typemdt)
		{
			Type type = X3c5HNK7uC4PbsAu5Qs.nduKCdK2kH.ResolveType(33554432 + typemdt);
			FieldInfo[] fields = type.GetFields();
			for (int i = 0; i < (int)fields.Length; i++)
			{
				FieldInfo fieldInfo = fields[i];
				MethodInfo methodInfo = (MethodInfo)X3c5HNK7uC4PbsAu5Qs.nduKCdK2kH.ResolveMethod(fieldInfo.MetadataToken + 100663296);
				fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, methodInfo));
			}
		}

		internal static X3c5HNK7uC4PbsAu5Qs L4bXjAzSVC9hOkQxCbV()
		{
			return X3c5HNK7uC4PbsAu5Qs.GHYMOGz43WwMHIjjNWw;
		}

		internal static bool UbcjtszjpLUVTmnOAPn()
		{
			return X3c5HNK7uC4PbsAu5Qs.GHYMOGz43WwMHIjjNWw == null;
		}

		internal delegate void Kl3LxbKqRIDAEbdE8wr(object o);
	}
}