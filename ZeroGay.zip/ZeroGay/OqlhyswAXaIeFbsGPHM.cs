using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Bounds OqlhyswAXaIeFbsGPHM(object object_0);