using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using tj5E7kTcTdevpjQ41CC;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace xLewLd7b9wDrreoOTAR
{
	internal class aJJj5I7S5WNQ76ULjw3
	{
		protected GameObject xwQeODQkuV;

		protected GameObject N8KeIWGteR;

		protected Slider MN9eoymkqP;

		protected Text gIKe6XUucn;

		protected float IE9eYfCnst;

		protected float tHNeBlleAt;

		protected float BsVerIED8m;

		internal static aJJj5I7S5WNQ76ULjw3 CR1wDU4trNPZoTHMA8p;

		public aJJj5I7S5WNQ76ULjw3(QMNestedButton qmnestedButton_0, float float_0, float float_1, string string_0, float float_2, float float_3, float float_4, Action<float> action_0, Color? nullable_0 = null)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.w397Nv01ct(qmnestedButton_0.GetMenuObject().get_transform(), float_0, float_1, string_0, float_2, float_3, float_4, action_0, nullable_0);
		}

		public aJJj5I7S5WNQ76ULjw3(Transform transform_0, float float_0, float float_1, string string_0, float float_2, float float_3, float float_4, Action<float> action_0, Color? nullable_0 = null)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.w397Nv01ct(transform_0, float_0, float_1, string_0, float_2, float_3, float_4, action_0, nullable_0);
		}

		internal static aJJj5I7S5WNQ76ULjw3 D7mxEv4lsO17ailo4JS()
		{
			return aJJj5I7S5WNQ76ULjw3.CR1wDU4trNPZoTHMA8p;
		}

		public void dDie5dIUGm(string string_0)
		{
			this.gIKe6XUucn.set_text(string_0);
		}

		public void E2X7zORbav(Vector2 vector2_0)
		{
			this.xwQeODQkuV.GetComponent<RectTransform>().set_anchoredPosition(vector2_0);
		}

		internal static bool G868d64K5xIjdMi3Wbh()
		{
			return aJJj5I7S5WNQ76ULjw3.CR1wDU4trNPZoTHMA8p == null;
		}

		public GameObject HYjeQTAYuG()
		{
			return this.xwQeODQkuV;
		}

		public void OjWec2Ub27(Color color_0)
		{
			this.gIKe6XUucn.set_color(color_0);
		}

		public void QeHeneIimZ(float float_0, float float_1, float float_2)
		{
			this.IE9eYfCnst = float_0;
			this.tHNeBlleAt = float_1;
			this.BsVerIED8m = float_2;
			this.MN9eoymkqP.set_minValue(this.IE9eYfCnst);
			this.MN9eoymkqP.set_maxValue(this.tHNeBlleAt);
			this.MN9eoymkqP.set_value(this.BsVerIED8m);
		}

		private void w397Nv01ct(Transform transform_0, float float_0, float float_1, string string_0, float float_2, float float_3, float float_4, Action<float> action_0, Color? nullable_0 = null)
		{
			this.xwQeODQkuV = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.AKkT6ZQe76(), transform_0);
			this.xwQeODQkuV.get_transform().set_localScale(new Vector3(1f, 1f, 1f));
			this.xwQeODQkuV.set_name(string.Format("{0}-QMSlider-{1}", "WTFBlaze", x5iKdsT53msph4ugL7v.accTMUKvyj()));
			this.N8KeIWGteR = UnityEngine.Object.Instantiate<GameObject>(GameObject.Find("UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/LevelText"), this.xwQeODQkuV.get_transform());
			this.N8KeIWGteR.set_name("QMSlider-Label");
			this.N8KeIWGteR.get_transform().set_localScale(new Vector3(1f, 1f, 1f));
			this.N8KeIWGteR.GetComponent<RectTransform>().set_sizeDelta(new Vector2(360f, 50f));
			this.N8KeIWGteR.GetComponent<RectTransform>().set_anchoredPosition(new Vector2(10.4f, 55f));
			this.N8KeIWGteR.AddComponent<Button>().get_onClick().AddListener(new Action(() => {
			}));
			this.MN9eoymkqP = this.xwQeODQkuV.GetComponent<Slider>();
			this.MN9eoymkqP.set_wholeNumbers(false);
			this.MN9eoymkqP.set_onValueChanged(new Slider.SliderEvent());
			this.MN9eoymkqP.get_onValueChanged().AddListener(action_0);
			this.MN9eoymkqP.get_onValueChanged().AddListener(new Action<float>((float f) => this.xwQeODQkuV.get_transform().Find("Fill Area/Label").GetComponent<Text>().set_text(string.Format("{0}%", this.MN9eoymkqP.get_value() / float_3 * 100f))));
			this.gIKe6XUucn = this.N8KeIWGteR.GetComponent<Text>();
			this.gIKe6XUucn.set_resizeTextForBestFit(false);
			if (nullable_0.HasValue)
			{
				this.OjWec2Ub27(nullable_0.Value);
			}
			this.E2X7zORbav(new Vector2(float_0, float_1));
			this.dDie5dIUGm(string_0);
			this.QeHeneIimZ(float_2, float_3, this.BsVerIED8m);
			UUyEqSykY4SKTrGkSI9.M6vyjPcRCq.Add(this);
		}
	}
}