using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.Events;

internal delegate UnityAction Dw2g5ePuvvEVifZIn7a(Action action_0);