using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void snE3Z2J8AsKTSZlGpUc(object object_0, Vector3 vector3_0);