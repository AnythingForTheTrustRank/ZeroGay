using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;

internal delegate List<VRCUiContentButton> M0qFxAJUnF1GVZAs1xh(object object_0);