using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Transform swxhcO81g70T1xgOLVa(object object_0, string string_0);