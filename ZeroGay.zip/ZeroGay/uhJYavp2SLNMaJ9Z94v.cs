using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string uhJYavp2SLNMaJ9Z94v();