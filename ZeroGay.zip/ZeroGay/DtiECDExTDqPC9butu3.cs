using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.SceneManagement;

internal delegate Scene DtiECDExTDqPC9butu3();