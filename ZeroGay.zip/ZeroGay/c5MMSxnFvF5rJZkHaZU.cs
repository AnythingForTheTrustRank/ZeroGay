using b3eD5DgJPcASx0xfHYB;
using System;
using System.Diagnostics;

internal delegate Process c5MMSxnFvF5rJZkHaZU();