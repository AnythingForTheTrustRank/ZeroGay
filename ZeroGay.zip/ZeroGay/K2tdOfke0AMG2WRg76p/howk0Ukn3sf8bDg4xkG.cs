using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using UnhollowerRuntimeLib;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using UnityEngine.UI;

namespace K2tdOfke0AMG2WRg76p
{
	internal class howk0Ukn3sf8bDg4xkG
	{
		public static howk0Ukn3sf8bDg4xkG.LO5Trc2TDhF4630kSDq KjnkLli4GN;

		internal static howk0Ukn3sf8bDg4xkG qjMYEV5sf216MtOJdIh;

		public howk0Ukn3sf8bDg4xkG()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static howk0Ukn3sf8bDg4xkG.LO5Trc2TDhF4630kSDq DftkAqOkft()
		{
			howk0Ukn3sf8bDg4xkG.LO5Trc2TDhF4630kSDq kjnkLli4GN;
			if (howk0Ukn3sf8bDg4xkG.KjnkLli4GN != null)
			{
				kjnkLli4GN = howk0Ukn3sf8bDg4xkG.KjnkLli4GN;
			}
			else
			{
				MethodInfo methodInfo = ((IEnumerable<MethodInfo>)typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public)).Single<MethodInfo>((MethodInfo m) => ((int)m.GetParameters().Length != 7 ? false : howk0Ukn3sf8bDg4xkG.hUJk1VKMTT(m, "Popups/StandardPopupV2")));
				howk0Ukn3sf8bDg4xkG.KjnkLli4GN = (howk0Ukn3sf8bDg4xkG.LO5Trc2TDhF4630kSDq)Delegate.CreateDelegate(typeof(howk0Ukn3sf8bDg4xkG.LO5Trc2TDhF4630kSDq), VRCUiPopupManager.get_field_Private_Static_VRCUiPopupManager_0(), methodInfo);
				kjnkLli4GN = howk0Ukn3sf8bDg4xkG.KjnkLli4GN;
			}
			return kjnkLli4GN;
		}

		internal static howk0Ukn3sf8bDg4xkG ecg5ei57wfljHouvNOG()
		{
			return howk0Ukn3sf8bDg4xkG.qjMYEV5sf216MtOJdIh;
		}

		public static void HR3kxjpRri()
		{
			GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Darkness").SetActive(false);
			GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Popup/BorderImage").GetComponent<Image>().set_color(new Color(0f, 0f, 0f, 0.1f));
			GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Panel").GetComponent<Image>().set_color(new Color(102f, 0f, 102f, 0.1f));
		}

		public static bool hUJk1VKMTT(object u0020, object u0020)
		{
			return XrefScanner.XrefScan(u0020).Any<XrefInstance>((XrefInstance xref) => {
				bool flag;
				if (xref.Type == 0)
				{
					Il2CppSystem.Object obj = xref.ReadAsObject();
					flag = (obj != null ? obj.ToString().IndexOf(u0020, StringComparison.OrdinalIgnoreCase) >= 0 : false);
				}
				else
				{
					flag = false;
				}
				return flag;
			});
		}

		public static void I7QkfZHxwK(object u0020, object u0020, object u0020, bool u0020, Action<string> u0020, System.Action u0020 = null)
		{
			VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Method_Public_Void_String_String_InputType_Boolean_String_Action_3_String_List_1_KeyCode_Text_Action_String_Boolean_Action_1_VRCUiPopup_Boolean_Int32_1(u0020, "", 0, u0020, u0020, DelegateSupport.ConvertDelegate<Il2CppSystem.Action<string, Il2CppSystem.Collections.Generic.List<KeyCode>, Text>>(new Action<string, Il2CppSystem.Collections.Generic.List<KeyCode>, Text>((string a, Il2CppSystem.Collections.Generic.List<KeyCode> b, Text c) => {
				Action<string> action = u0020;
				if (action != null)
				{
					action(a);
				}
				else
				{
				}
			})), DelegateSupport.ConvertDelegate<Il2CppSystem.Action>(u0020), u0020, true, null, false, 0);
		}

		internal static bool iG0oF75Mik1UOpq4hid()
		{
			return howk0Ukn3sf8bDg4xkG.qjMYEV5sf216MtOJdIh == null;
		}

		public static void xjckKV5Jww()
		{
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().HideScreen("POPUP");
		}

		public delegate void LO5Trc2TDhF4630kSDq(string title, string text, string leftButtonText, Il2CppSystem.Action leftButtonAction, string rightButtonText, Il2CppSystem.Action rightButtonAction, Il2CppSystem.Action<VRCUiPopup> additionalShit = null);
	}
}