using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.UI.Elements;

internal delegate void W6wVavXH4WPqucMUnyn(object object_0, MenuStateController menuStateController_0);