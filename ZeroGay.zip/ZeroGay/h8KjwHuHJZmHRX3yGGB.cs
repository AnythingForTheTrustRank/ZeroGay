using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void h8KjwHuHJZmHRX3yGGB(object object_0, VerticalWrapMode verticalWrapMode_0);