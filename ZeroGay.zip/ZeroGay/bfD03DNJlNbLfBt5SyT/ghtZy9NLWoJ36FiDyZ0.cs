using b3eD5DgJPcASx0xfHYB;
using iJ73DQwxRI3caDhkmDO;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using VRC.Core;

namespace bfD03DNJlNbLfBt5SyT
{
	internal class ghtZy9NLWoJ36FiDyZ0
	{
		protected GameObject SXTNyHsKER;

		protected UiVRCList yvcNEbXnsL;

		protected Text VIWNzfxCmC;

		private static GameObject yXACqk9lDP;

		internal static ghtZy9NLWoJ36FiDyZ0 Pj02TUDC9MqPhOsLNns;

		static ghtZy9NLWoJ36FiDyZ0()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			ghtZy9NLWoJ36FiDyZ0.yXACqk9lDP = GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport/Content/Public Avatar List");
		}

		public ghtZy9NLWoJ36FiDyZ0(Transform u0020, string u0020, int u0020 = 0)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.jCWN5ZZnsa(u0020, u0020, u0020);
		}

		internal static bool anNvgrD284XlU7oqmb0()
		{
			return ghtZy9NLWoJ36FiDyZ0.Pj02TUDC9MqPhOsLNns == null;
		}

		private void jCWN5ZZnsa(Transform u0020, string u0020, int u0020 = 0)
		{
			this.SXTNyHsKER = UnityEngine.Object.Instantiate<GameObject>(ghtZy9NLWoJ36FiDyZ0.yXACqk9lDP.get_gameObject(), u0020);
			this.SXTNyHsKER.GetComponent<UiAvatarList>().set_field_Public_Category_0(4);
			this.yvcNEbXnsL = this.SXTNyHsKER.GetComponent<UiVRCList>();
			this.VIWNzfxCmC = this.SXTNyHsKER.get_transform().Find("Button").GetComponentInChildren<Text>();
			this.SXTNyHsKER.get_transform().SetSiblingIndex(u0020);
			this.yvcNEbXnsL.set_clearUnseenListOnCollapse(false);
			this.yvcNEbXnsL.set_usePagination(false);
			this.yvcNEbXnsL.set_hideElementsWhenContracted(false);
			this.yvcNEbXnsL.set_hideWhenEmpty(false);
			this.yvcNEbXnsL.get_field_Protected_Dictionary_2_Int32_List_1_ApiModel_0().Clear();
			this.yvcNEbXnsL.get_pickerPrefab().get_transform().Find("TitleText").GetComponent<Text>().set_supportRichText(true);
			this.SXTNyHsKER.SetActive(true);
			this.SXTNyHsKER.set_name(u0020);
			this.VIWNzfxCmC.set_supportRichText(true);
			this.VIWNzfxCmC.set_text(u0020);
			vBMVdGwfepiujjMKYNt.vmpwdiYqFj.Add(this);
		}

		public GameObject JsBNoxcBBX()
		{
			return this.SXTNyHsKER;
		}

		public UiVRCList kcQNmOhnat()
		{
			return this.yvcNEbXnsL;
		}

		internal static ghtZy9NLWoJ36FiDyZ0 qScZArDbKm4rsFLgvQW()
		{
			return ghtZy9NLWoJ36FiDyZ0.Pj02TUDC9MqPhOsLNns;
		}

		public void sL6NddC2qZ(Il2CppSystem.Collections.Generic.List<ApiAvatar> u0020)
		{
			this.yvcNEbXnsL.Method_Protected_Void_List_1_T_Int32_Boolean_VRCUiContentButton_0<ApiAvatar>(u0020, 0, true, null);
		}

		public Text TWGND8MNpp()
		{
			return this.VIWNzfxCmC;
		}

		public void UFbNclPS0x()
		{
			try
			{
				UnityEngine.Object.Destroy(this.SXTNyHsKER);
			}
			catch
			{
			}
		}
	}
}