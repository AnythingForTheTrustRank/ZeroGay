using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void l8QP34egjqk9G2b6DZD(object , ParticleSystemTrailMode );