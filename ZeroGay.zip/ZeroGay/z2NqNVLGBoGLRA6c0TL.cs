using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object z2NqNVLGBoGLRA6c0TL(Type , sbyte );