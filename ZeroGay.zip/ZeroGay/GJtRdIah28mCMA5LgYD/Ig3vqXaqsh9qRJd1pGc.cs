using AksgHVKH9UOXlBDvRpO;
using onbPo2ICahPqKspsLXX;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.Networking;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;
using X7IetPATbOXxq4U7Vmy;

namespace GJtRdIah28mCMA5LgYD
{
	internal class Ig3vqXaqsh9qRJd1pGc
	{
		public static List<VRCSDK2.VRC_Pickup> lw6av6PWol;

		public static List<VRCSDK2.VRC_Trigger> avBaiGUGK7;

		public static VRC_EventHandler WNja94HPEI;

		public static string[] yLia0XdtYl;

		public static bool xfbaxybtE3;

		public static List<string> PcMaJZKsu0;

		public static bool UbEa8FdFBP;

		public static List<string> pcWaEhbo29;

		public static List<string> YTOawbwZCY;

		public static int jKQap28kgV;

		public static int UV4aW1Vh4C;

		public static float IoQaUumLtT;

		public static bool uHqaPbc2x8;

		public static bool kVxautFJjU;

		public static System.Random HQuaFucfMu;

		public static VRCPlayer hxnaXDtxF8;

		public static string NA0aZ3U6t5;

		private static Transform cQLaVm2GsH;

		private static VRC_AnimationController sg6aLlXINd;

		private static VRCVrIkController x3Ja1YNUug;

		public static bool GrZa3AaUZc;

		public static List<string> aBdak4qaU1;

		public static bool z0Vaffy95b;

		public static bool lfGameEg0A;

		public static bool UaWaDxf0FN;

		public static bool AaTagZA4LK;

		public static bool IT0a4a5Qpo;

		public static bool xZEaj2Huh5;

		public static bool Q2BaSvPxaS;

		public static bool RZbabyx2lN;

		public static bool uNsaN4Ytlo;

		private static Ig3vqXaqsh9qRJd1pGc lUxGlVmkvW0qXPREh8d;

		static Ig3vqXaqsh9qRJd1pGc()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			Ig3vqXaqsh9qRJd1pGc.lw6av6PWol = new List<VRCSDK2.VRC_Pickup>();
			Ig3vqXaqsh9qRJd1pGc.avBaiGUGK7 = new List<VRCSDK2.VRC_Trigger>();
			Ig3vqXaqsh9qRJd1pGc.xfbaxybtE3 = false;
			Ig3vqXaqsh9qRJd1pGc.UbEa8FdFBP = false;
			Ig3vqXaqsh9qRJd1pGc.pcWaEhbo29 = new List<string>();
			Ig3vqXaqsh9qRJd1pGc.YTOawbwZCY = new List<string>();
			Ig3vqXaqsh9qRJd1pGc.jKQap28kgV = 0;
			Ig3vqXaqsh9qRJd1pGc.UV4aW1Vh4C = 19;
			Ig3vqXaqsh9qRJd1pGc.IoQaUumLtT = 0f;
			Ig3vqXaqsh9qRJd1pGc.uHqaPbc2x8 = true;
			Ig3vqXaqsh9qRJd1pGc.kVxautFJjU = false;
			Ig3vqXaqsh9qRJd1pGc.HQuaFucfMu = new System.Random();
			Ig3vqXaqsh9qRJd1pGc.NA0aZ3U6t5 = "None";
			Ig3vqXaqsh9qRJd1pGc.GrZa3AaUZc = false;
			Ig3vqXaqsh9qRJd1pGc.aBdak4qaU1 = new List<string>()
			{
				"pen",
				"marker",
				"grip"
			};
			Ig3vqXaqsh9qRJd1pGc.z0Vaffy95b = false;
			Ig3vqXaqsh9qRJd1pGc.lfGameEg0A = false;
			Ig3vqXaqsh9qRJd1pGc.UaWaDxf0FN = false;
			Ig3vqXaqsh9qRJd1pGc.AaTagZA4LK = false;
			Ig3vqXaqsh9qRJd1pGc.IT0a4a5Qpo = false;
			Ig3vqXaqsh9qRJd1pGc.xZEaj2Huh5 = false;
			Ig3vqXaqsh9qRJd1pGc.Q2BaSvPxaS = false;
			Ig3vqXaqsh9qRJd1pGc.RZbabyx2lN = false;
			Ig3vqXaqsh9qRJd1pGc.uNsaN4Ytlo = false;
		}

		public Ig3vqXaqsh9qRJd1pGc()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool AyAh8CmfaK4H4EaIMDB()
		{
			return Ig3vqXaqsh9qRJd1pGc.lUxGlVmkvW0qXPREh8d == null;
		}

		public static IEnumerator B3daGaPk5D(bool bool_0)
		{
			return new Ig3vqXaqsh9qRJd1pGc.<keysorbittarget>d__38(0)
			{
				state = bool_0
			};
		}

		public static IEnumerator et7asF3KAT(bool bool_0)
		{
			while (true)
			{
				if (Ig3vqXaqsh9qRJd1pGc.IT0a4a5Qpo)
				{
					Vector3 _position = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position();
					GameObject gameObject = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key");
					GameObject gameObject1 = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key (1)");
					GameObject gameObject2 = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key (2)");
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					gameObject.GetComponent<UdonBehaviour>().Interact();
					yield return new WaitForSeconds(2f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject1.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject1.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject1.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					gameObject1.GetComponent<UdonBehaviour>().Interact();
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(_position);
					Ig3vqXaqsh9qRJd1pGc.IT0a4a5Qpo = false;
					_position = new Vector3();
					gameObject = null;
					gameObject1 = null;
					gameObject2 = null;
				}
				yield return new WaitForSeconds(1f);
			}
		}

		public static IEnumerator I3iaRdxWvF(bool bool_0)
		{
			while (true)
			{
				if (Ig3vqXaqsh9qRJd1pGc.Q2BaSvPxaS)
				{
					Vector3 _position = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position();
					GameObject gameObject = GameObject.Find("PoliceStation/Props/KeySpawn/Keys/Key");
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/KeySpawn/Keys/Key (1)");
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/KeySpawn/Keys/Key (2)");
					gameObject.GetComponent<UdonBehaviour>().Interact();
					gameObject1.GetComponent<UdonBehaviour>().Interact();
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(_position);
					Ig3vqXaqsh9qRJd1pGc.Q2BaSvPxaS = false;
					_position = new Vector3();
					gameObject = null;
					gameObject1 = null;
					gameObject2 = null;
				}
				yield return new WaitForSeconds(1f);
			}
		}

		public static IEnumerator laDad99FUS(bool bool_0)
		{
			return new Ig3vqXaqsh9qRJd1pGc.<folderorbitstarget>d__39(0)
			{
				state = bool_0
			};
		}

		public static IEnumerator rPOaKNDt5e(bool bool_0)
		{
			while (true)
			{
				if (Ig3vqXaqsh9qRJd1pGc.lfGameEg0A)
				{
					List<GameObject> gameObjects = new List<GameObject>()
					{
						GameObject.Find("PoliceStation").get_transform().Find("Props/KeySpawn/Keys/Key").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/KeySpawn/Keys/Key (1)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/KeySpawn/Keys/Key (2)").get_gameObject()
					};
					List<GameObject> gameObjects1 = gameObjects;
					GameObject gameObject = new GameObject();
					gameObject.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.35f, 0f));
					gameObject.get_transform().Rotate(new Vector3(0f, 360f, 0f));
					foreach (GameObject gameObject1 in gameObjects1)
					{
						QpoTfpIed0eCNGYhrQA.f8wIqsJwYK(gameObject1.get_gameObject());
						gameObject1.get_transform().set_position(gameObject.get_transform().get_position() + gameObject.get_transform().get_forward());
						gameObject1.get_transform().LookAt(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform());
						gameObject.get_transform().Rotate(new Vector3(0f, (float)(360 / gameObjects1.Count), 0f));
					}
					UnityEngine.Object.Destroy(gameObject);
					gameObject = null;
					gameObjects1 = null;
					gameObject = null;
				}
				yield return new WaitForSeconds(0.01f);
			}
		}

		internal static Ig3vqXaqsh9qRJd1pGc sKHumpmmYvAlW3LLisV()
		{
			return Ig3vqXaqsh9qRJd1pGc.lUxGlVmkvW0qXPREh8d;
		}

		public static IEnumerator u3gaAOpIDH(bool bool_0)
		{
			return new Ig3vqXaqsh9qRJd1pGc.<folderorbits>d__37(0)
			{
				state = bool_0
			};
		}

		public static IEnumerator VByalGOoOl(bool bool_0)
		{
			while (true)
			{
				if (Ig3vqXaqsh9qRJd1pGc.uNsaN4Ytlo)
				{
					UdonSync component = GameObject.Find("GameManager/PlayerObjectList/Ghosts/PlayerCharacterObject_Ghost (2)").GetComponent<UdonSync>();
					component.Method_Public_get_Player_0().Method_Private_set_Void_APIUser_0(APIUser.get_CurrentUser());
					yield return new WaitForSeconds(9f);
					component = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static void WIIaHSewvq()
		{
			GameObject gameObject = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "T4-M107" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static IEnumerator yhxatuVTIb(bool bool_0)
		{
			return new Ig3vqXaqsh9qRJd1pGc.<MurderPlayerBETA>d__33(0)
			{
				state = bool_0
			};
		}
	}
}