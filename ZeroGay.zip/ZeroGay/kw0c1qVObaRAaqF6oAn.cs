using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void kw0c1qVObaRAaqF6oAn(object , long );