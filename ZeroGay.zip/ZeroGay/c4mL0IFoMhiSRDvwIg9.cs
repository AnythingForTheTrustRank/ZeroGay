using b3eD5DgJPcASx0xfHYB;
using System;
using System.IO;

internal delegate void c4mL0IFoMhiSRDvwIg9(object , Stream );