using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;

internal delegate Il2CppStringArray XoIIvvwVCkJIU1y853s(string[] string_0);