using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.SceneManagement;

internal delegate Il2CppReferenceArray<GameObject> YV7MsbE87My4I8V8nmd(ref Scene scene_0);