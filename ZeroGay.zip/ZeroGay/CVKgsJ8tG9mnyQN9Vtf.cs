using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate PlayerNet CVKgsJ8tG9mnyQN9Vtf(object object_0);