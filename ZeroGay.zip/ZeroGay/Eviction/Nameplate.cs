using AksgHVKH9UOXlBDvRpO;
using System;
using TMPro;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace Eviction
{
	public class Nameplate : MonoBehaviour
	{
		public Graphic IconBackground;

		public RawImage Icon;

		public GameObject IconContainer;

		public static GameObject Content;

		public GameObject QuickStats;

		public ImageThreeSlice NameBackground;

		public ImageThreeSlice QuickStatsBackground;

		public TextMeshProUGUI Name;

		public ImageThreeSlice NamePulse;

		public Image IconPulse;

		public ImageThreeSlice NameGlow;

		public Image IconGlow;

		public TextMeshProUGUI IconText;

		private PlayerNameplate I7p21WNxnv;

		private Color Q9S23eZRoe;

		private Color lFy2kF0sKN;

		public bool IsEvolved;

		private bool uIC2fS6E1r;

		private bool Wj02mfbgR9;

		internal static Nameplate jYFPrWmvIooUUpiaSE6;

		public Nameplate(IntPtr ptr)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base(ptr);
		}

		internal static bool iHWI8xmigMKnBPhXjyT()
		{
			return Nameplate.jYFPrWmvIooUUpiaSE6 == null;
		}

		[HideFromIl2Cpp]
		public void ORbld()
		{
			if (this.I7p21WNxnv != null)
			{
				this.Name.set_color(this.Q9S23eZRoe);
			}
		}

		[HideFromIl2Cpp]
		public void Reset()
		{
			this.uIC2fS6E1r = false;
			this.Wj02mfbgR9 = false;
		}

		[HideFromIl2Cpp]
		public void SN(PlayerNameplate nameplate)
		{
			this.I7p21WNxnv = nameplate;
		}

		[HideFromIl2Cpp]
		public void SNC(Color color)
		{
			this.Q9S23eZRoe = color;
			this.uIC2fS6E1r = true;
		}

		public void Update()
		{
			this.Name.set_color(this.Q9S23eZRoe);
			if (this.IsEvolved)
			{
				this.IconBackground.set_enabled(true);
				this.Icon.set_enabled(true);
				this.Icon.get_gameObject().SetActive(true);
				this.IconContainer.SetActive(true);
				this.IconContainer.SetActive(true);
				this.IconText.get_gameObject().SetActive(false);
			}
		}

		internal static Nameplate Wju37Em9NaiaFkgKcEa()
		{
			return Nameplate.jYFPrWmvIooUUpiaSE6;
		}
	}
}