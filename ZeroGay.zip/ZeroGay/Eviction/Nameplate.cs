using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using TMPro;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

namespace Eviction
{
	public class Nameplate : MonoBehaviour
	{
		public Graphic IconBackground;

		public RawImage Icon;

		public GameObject IconContainer;

		public static GameObject Content;

		public GameObject QuickStats;

		public ImageThreeSlice NameBackground;

		public ImageThreeSlice QuickStatsBackground;

		public TextMeshProUGUI Name;

		public ImageThreeSlice NamePulse;

		public Image IconPulse;

		public ImageThreeSlice NameGlow;

		public Image IconGlow;

		public TextMeshProUGUI IconText;

		private PlayerNameplate XAb6q6AuEE;

		private Color E4C6k5gguv;

		private Color IfL68V8OYe;

		public bool IsEvolved;

		private bool Nxx6H7w57y;

		private bool drs6GMsfHd;

		internal static Nameplate B5TG38dBZOjVieBk6n0;

		public Nameplate(IntPtr ptr)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base(ptr);
		}

		[HideFromIl2Cpp]
		public void ORbld()
		{
			if (this.XAb6q6AuEE != null)
			{
				this.Name.set_color(this.E4C6k5gguv);
			}
		}

		[HideFromIl2Cpp]
		public void Reset()
		{
			this.Nxx6H7w57y = false;
			this.drs6GMsfHd = false;
		}

		[HideFromIl2Cpp]
		public void SN(PlayerNameplate nameplate)
		{
			this.XAb6q6AuEE = nameplate;
		}

		[HideFromIl2Cpp]
		public void SNC(Color color)
		{
			this.E4C6k5gguv = color;
			this.Nxx6H7w57y = true;
		}

		internal static bool TJ40C8dPlmkZOqAUItk()
		{
			return Nameplate.B5TG38dBZOjVieBk6n0 == null;
		}

		public void Update()
		{
			this.Name.set_color(this.E4C6k5gguv);
			if (this.IsEvolved)
			{
				this.IconBackground.set_enabled(true);
				this.Icon.set_enabled(true);
				this.Icon.get_gameObject().SetActive(true);
				this.IconContainer.SetActive(true);
				this.IconContainer.SetActive(true);
				this.IconText.get_gameObject().SetActive(false);
			}
		}

		internal static Nameplate YGKCo0dlEyFhMAElt98()
		{
			return Nameplate.B5TG38dBZOjVieBk6n0;
		}
	}
}