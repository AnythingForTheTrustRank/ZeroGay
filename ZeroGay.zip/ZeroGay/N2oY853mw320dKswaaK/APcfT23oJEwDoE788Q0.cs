using Apollo_Base.Modules;
using Area51.Events;
using b3eD5DgJPcASx0xfHYB;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using UnhollowerBaseLib;
using UnityEngine;
using ZeroDayAPI;

namespace N2oY853mw320dKswaaK
{
	internal class APcfT23oJEwDoE788Q0 : ModuleBase, OnAssetBundleLoadEvent
	{
		private string[] m1E3D3Dqhw;

		private string[] qSA3cRBMem;

		private int wOU3yZL31F;

		private int Y8K3ErapCx;

		private int YKT3zb4WNo;

		private int SQ49q2FjKt;

		private int LIL9kmcIyW;

		private int lus986u5Ce;

		private int rWv9HOuIYu;

		private Shader pvQ9GFOO8r;

		internal static APcfT23oJEwDoE788Q0 wQyYcL5xmRJmlUuxHqy;

		public APcfT23oJEwDoE788Q0()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.wOU3yZL31F = MainConfigSettings.Instance.MaxAudioSources;
			this.Y8K3ErapCx = MainConfigSettings.Instance.MaxLightSources;
			this.YKT3zb4WNo = MainConfigSettings.Instance.MaxDynBoneCollider;
			this.LIL9kmcIyW = MainConfigSettings.Instance.MaxMaterials;
			this.lus986u5Ce = MainConfigSettings.Instance.MaxCloth;
			this.rWv9HOuIYu = MainConfigSettings.Instance.MaxColliders;
			this.SQ49q2FjKt = MainConfigSettings.Instance.MaxPolys;
			this.pvQ9GFOO8r = Shader.Find("VRChat/PC/Toon Lit Cutout");
			this.m1E3D3Dqhw = MainConfigSettings.Instance.shaderList;
			this.qSA3cRBMem = MainConfigSettings.Instance.meshList;
		}

		internal static APcfT23oJEwDoE788Q0 H3l7rX5KexJSlaQC0i0()
		{
			return APcfT23oJEwDoE788Q0.wQyYcL5xmRJmlUuxHqy;
		}

		internal static bool kNlNMh51SFI2ltpScGC()
		{
			return APcfT23oJEwDoE788Q0.wQyYcL5xmRJmlUuxHqy == null;
		}

		public bool OnAvatarAssetBundleLoad(GameObject avatar, string avatarID)
		{
			int length;
			SkinnedMeshRenderer[] componentsInChildren = avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true);
			MeshFilter[] meshFilterArray = avatar.GetComponentsInChildren<MeshFilter>(true);
			SkinnedMeshRenderer[] skinnedMeshRendererArray = componentsInChildren;
			for (int i = 0; i < (int)skinnedMeshRendererArray.Length; i++)
			{
				SkinnedMeshRenderer skinnedMeshRenderer = skinnedMeshRendererArray[i];
				bool flag = false;
				if (!skinnedMeshRenderer.get_sharedMesh().get_isReadable())
				{
					UnityEngine.Object.DestroyImmediate(skinnedMeshRenderer, true);
					MelonLogger.Log("[AnitCrash] deleted unreadable Mesh");
				}
				else
				{
					int num = 0;
					while (num < (int)this.qSA3cRBMem.Length)
					{
						if (skinnedMeshRenderer.get_name().ToLower().Contains(this.qSA3cRBMem[num]))
						{
							MelonLogger.Log(string.Concat("[AnitCrash] deleted blackListed Mesh ", skinnedMeshRenderer.get_name()));
							UnityEngine.Object.DestroyImmediate(skinnedMeshRenderer, true);
							flag = true;
							break;
						}
						else
						{
							num++;
						}
					}
					if (!flag)
					{
						int length1 = 0;
						int num1 = 0;
						while (true)
						{
							if (num1 < skinnedMeshRenderer.get_sharedMesh().get_subMeshCount())
							{
								length1 = length1 + skinnedMeshRenderer.get_sharedMesh().GetTriangles(num1).get_Length() / 3;
								if (length1 >= this.SQ49q2FjKt)
								{
									UnityEngine.Object.DestroyImmediate(skinnedMeshRenderer, true);
									MelonLogger.Log("[AnitCrash] deleted Mesh with too many polys");
									flag = true;
									break;
								}
								else
								{
									num1++;
								}
							}
							else
							{
								break;
							}
						}
						if (!flag)
						{
							Material[] _materials = skinnedMeshRenderer.get_materials();
							if ((int)_materials.Length >= this.LIL9kmcIyW)
							{
								UnityEngine.Object.DestroyImmediate(skinnedMeshRenderer, true);
								length = (int)_materials.Length;
								MelonLogger.Log(string.Concat("[AnitCrash] deleted Mesh with ", length.ToString(), " materials"));
							}
							else
							{
								for (int j = 0; j < (int)_materials.Length; j++)
								{
									Shader _shader = _materials[j].get_shader();
									for (int k = 0; k < (int)this.m1E3D3Dqhw.Length; k++)
									{
										if (_shader.get_name().ToLower().Contains(this.m1E3D3Dqhw[k]))
										{
											MelonLogger.Log(string.Concat("[AnitCrash] replaced Shader ", _shader.get_name()));
											_shader = this.pvQ9GFOO8r;
										}
									}
								}
							}
						}
					}
				}
			}
			MeshFilter[] meshFilterArray1 = meshFilterArray;
			for (int l = 0; l < (int)meshFilterArray1.Length; l++)
			{
				MeshFilter meshFilter = meshFilterArray1[l];
				if (!meshFilter.get_sharedMesh().get_isReadable())
				{
					UnityEngine.Object.DestroyImmediate(meshFilter, true);
					MelonLogger.Log("[AnitCrash] deleted unreadable Mesh");
				}
				else
				{
					bool flag1 = false;
					int num2 = 0;
					while (num2 < (int)this.qSA3cRBMem.Length)
					{
						if (meshFilter.get_name().ToLower().Contains(this.qSA3cRBMem[num2]))
						{
							MelonLogger.Log(string.Concat("[AnitCrash] deleted blackListed Mesh ", meshFilter.get_name()));
							UnityEngine.Object.DestroyImmediate(meshFilter, true);
							flag1 = true;
							break;
						}
						else
						{
							num2++;
						}
					}
					if (!flag1)
					{
						int length2 = 0;
						int num3 = 0;
						while (true)
						{
							if (num3 < meshFilter.get_sharedMesh().get_subMeshCount())
							{
								length2 = length2 + meshFilter.get_sharedMesh().GetTriangles(num3).get_Length() / 3;
								if (length2 >= this.SQ49q2FjKt)
								{
									UnityEngine.Object.DestroyImmediate(meshFilter, true);
									MelonLogger.Log("[AnitCrash] deleted Mesh with too many polys");
									flag1 = true;
									break;
								}
								else
								{
									num3++;
								}
							}
							else
							{
								break;
							}
						}
						if (!flag1)
						{
							Material[] materialArray = meshFilter.get_gameObject().GetComponent<MeshRenderer>().get_materials();
							if ((int)materialArray.Length >= this.LIL9kmcIyW)
							{
								UnityEngine.Object.DestroyImmediate(meshFilter, true);
								length = (int)materialArray.Length;
								MelonLogger.Log(string.Concat("[AnitCrash] deleted Mesh with ", length.ToString(), " materials"));
							}
							else
							{
								for (int m = 0; m < (int)materialArray.Length; m++)
								{
									Shader shader = materialArray[m].get_shader();
									for (int n = 0; n < (int)this.m1E3D3Dqhw.Length; n++)
									{
										if (shader.get_name().ToLower().Contains(this.m1E3D3Dqhw[n]))
										{
											MelonLogger.Log(string.Concat("[AnitCrash] replaced Shader ", shader.get_name()));
											shader = this.pvQ9GFOO8r;
										}
									}
								}
							}
						}
					}
				}
			}
			AudioSource[] audioSourceArray = avatar.GetComponentsInChildren<AudioSource>();
			if ((int)audioSourceArray.Length >= this.wOU3yZL31F)
			{
				for (int o = 0; o < this.wOU3yZL31F; o++)
				{
					UnityEngine.Object.DestroyImmediate(audioSourceArray[o].get_gameObject(), true);
				}
				MelonLogger.Log(string.Concat("[AnitCrash] deleted ", this.wOU3yZL31F.ToString(), " AudioSources"));
			}
			Light[] lightArray = avatar.GetComponentsInChildren<Light>();
			if ((int)lightArray.Length >= this.Y8K3ErapCx)
			{
				for (int p = 0; p < this.Y8K3ErapCx; p++)
				{
					UnityEngine.Object.DestroyImmediate(lightArray[p].get_gameObject(), true);
				}
				MelonLogger.Log(string.Concat("[AnitCrash] deleted ", this.Y8K3ErapCx.ToString(), " Lights"));
			}
			Cloth[] clothArray = avatar.GetComponentsInChildren<Cloth>();
			if ((int)clothArray.Length >= this.lus986u5Ce)
			{
				for (int q = 0; q < this.lus986u5Ce; q++)
				{
					UnityEngine.Object.DestroyImmediate(clothArray[q].get_gameObject(), true);
				}
				MelonLogger.Log(string.Concat("[AnitCrash] deleted ", this.lus986u5Ce.ToString(), " Cloth"));
			}
			Collider[] colliderArray = avatar.GetComponentsInChildren<Collider>();
			if ((int)colliderArray.Length >= this.rWv9HOuIYu)
			{
				for (int r = 0; r < this.rWv9HOuIYu; r++)
				{
					UnityEngine.Object.DestroyImmediate(colliderArray[r].get_gameObject(), true);
				}
				MelonLogger.Log(string.Concat("[AnitCrash] deleted ", this.rWv9HOuIYu.ToString(), " Colliders"));
			}
			DynamicBoneCollider[] dynamicBoneColliderArray = avatar.GetComponentsInChildren<DynamicBoneCollider>();
			if ((int)dynamicBoneColliderArray.Length >= this.YKT3zb4WNo)
			{
				for (int s = 0; s < this.YKT3zb4WNo; s++)
				{
					UnityEngine.Object.DestroyImmediate(dynamicBoneColliderArray[s].get_gameObject(), true);
				}
				MelonLogger.Log(string.Concat("[AnitCrash] deleted ", this.YKT3zb4WNo.ToString(), " DynamicBoneColliders"));
			}
			return true;
		}

		public override void Start()
		{
		}
	}
}