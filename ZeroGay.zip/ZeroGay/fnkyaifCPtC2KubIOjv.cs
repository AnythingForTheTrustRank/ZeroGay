using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine.UI;

internal delegate float fnkyaifCPtC2KubIOjv(ref ColorBlock );