using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using VRC.UI.Elements;

internal delegate void kiXGjcXiMhZphcsUHnC(object object_0, Il2CppReferenceArray<UIPage> il2CppReferenceArray_0);