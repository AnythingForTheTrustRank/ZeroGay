using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate IntPtr lNH0CpRKnyhFuITFTge(object );