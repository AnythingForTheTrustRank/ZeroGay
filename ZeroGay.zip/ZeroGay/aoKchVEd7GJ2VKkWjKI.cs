using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using System;
using UnityEngine;

internal delegate UnityEngine.Object aoKchVEd7GJ2VKkWjKI(object object_0, string string_0, Il2CppSystem.Type type_0);