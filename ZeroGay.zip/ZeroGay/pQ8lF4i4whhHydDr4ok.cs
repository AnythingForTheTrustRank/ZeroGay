using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.SceneManagement;

internal delegate Il2CppReferenceArray<GameObject> pQ8lF4i4whhHydDr4ok(ref Scene );