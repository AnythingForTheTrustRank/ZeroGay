using b3eD5DgJPcASx0xfHYB;
using gpd3oZtw5qhYneWRlWY;
using HarmonyLib;
using HellTaker.mainshiet.patches.murder4;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using VRC.Networking;
using VRC.SDK3.Components;
using VRC.SDKBase;

namespace aH70sr9FBF3771T7Qxq
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class oDCyHD9ZaxudC5XAH0k
	{
		internal static oDCyHD9ZaxudC5XAH0k Q448JIdCwaJUkOpSljj;

		public oDCyHD9ZaxudC5XAH0k()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static bool uTG9iMgNKW(ref string u0020)
		{
			if (Murder4.PatreonEnforcer)
			{
				List<VRCPickup> vRCPickups = new List<VRCPickup>()
				{
					GameObject.Find("Game Logic/Weapons/Revolver").GetComponent<VRCPickup>()
				};
				GameObject.Find("Game Logic/Weapons/Revolver");
				GameObject gameObject = GameObject.Find("Game Logic/Weapons/Revolver/Patron skin sound");
				foreach (VRCPickup vRCPickup in vRCPickups)
				{
					if (!(u0020 == "SyncFire") || !Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup.get_gameObject()))
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Play", null, false);
				}
			}
			return true;
		}

		internal static oDCyHD9ZaxudC5XAH0k V4PYEmdb8H8xMaBaN2j()
		{
			return oDCyHD9ZaxudC5XAH0k.Q448JIdCwaJUkOpSljj;
		}

		internal static bool YuPhBfd24TUpYTL0krC()
		{
			return oDCyHD9ZaxudC5XAH0k.Q448JIdCwaJUkOpSljj == null;
		}
	}
}