using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string CMRmBKWG3X6LbOpO4m5(object object_0, string string_0, string string_1);