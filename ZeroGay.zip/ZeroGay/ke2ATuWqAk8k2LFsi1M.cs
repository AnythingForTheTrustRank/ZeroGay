using AksgHVKH9UOXlBDvRpO;
using System;
using System.IO;

internal delegate void ke2ATuWqAk8k2LFsi1M(object object_0, Stream stream_0, object object_1);