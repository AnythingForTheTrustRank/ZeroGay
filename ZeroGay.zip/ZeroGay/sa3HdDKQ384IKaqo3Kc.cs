using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate int sa3HdDKQ384IKaqo3Kc();