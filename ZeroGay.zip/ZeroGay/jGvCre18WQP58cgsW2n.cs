using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void jGvCre18WQP58cgsW2n(object , string , float );