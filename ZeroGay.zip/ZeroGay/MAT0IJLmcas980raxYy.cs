using AksgHVKH9UOXlBDvRpO;
using System;
using System.Threading.Tasks;

internal delegate Task MAT0IJLmcas980raxYy(int int_0);