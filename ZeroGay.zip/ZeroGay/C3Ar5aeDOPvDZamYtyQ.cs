using b3eD5DgJPcASx0xfHYB;
using System;
using TMPro;

internal delegate void C3Ar5aeDOPvDZamYtyQ(object , FontStyles );