using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.SDKBase;

internal delegate VRCPlayerApi rUJ6Lg8vXyrIn2DpR7E(object object_0);