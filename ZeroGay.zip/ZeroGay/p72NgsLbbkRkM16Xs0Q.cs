using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate void p72NgsLbbkRkM16Xs0Q(ref TaskAwaiter taskAwaiter_0);