using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.UI.Core;

internal delegate void EuFI3NXJBXA251jj8cN(object object_0, string string_0, UIContext uicontext_0, bool bool_0);