using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string QaQIeO3JkapHCMx9L0W(ref double double_0);