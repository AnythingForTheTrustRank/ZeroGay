using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate GameObject eun1D3Wp7NUfi9isOE1(PrimitiveType primitiveType_0);