using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;

namespace onbPo2ICahPqKspsLXX
{
	internal class QpoTfpIed0eCNGYhrQA
	{
		private static QpoTfpIed0eCNGYhrQA hloLCbfwdD47LsCRCI4;

		public QpoTfpIed0eCNGYhrQA()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static void b2xIHMFN4N(object object_0)
		{
			QpoTfpIed0eCNGYhrQA.b2xIHMFN4N(QpoTfpIed0eCNGYhrQA.Vp8IhNTTnx());
		}

		public static void f8wIqsJwYK(object object_0)
		{
			Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), object_0);
		}

		internal static QpoTfpIed0eCNGYhrQA FyuhPOfW7Oa7KPcdPql()
		{
			return QpoTfpIed0eCNGYhrQA.hloLCbfwdD47LsCRCI4;
		}

		internal static bool Ix2evSfp3CFLwlxV5tY()
		{
			return QpoTfpIed0eCNGYhrQA.hloLCbfwdD47LsCRCI4 == null;
		}

		public static VRCPlayer Vp8IhNTTnx()
		{
			return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
		}
	}
}