using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object FLNOvt3IVf0H0ASDv0X(Type type_0, short short_0);