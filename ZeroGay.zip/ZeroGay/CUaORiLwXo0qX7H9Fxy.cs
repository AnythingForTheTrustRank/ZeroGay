using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string CUaORiLwXo0qX7H9Fxy(ref ulong );