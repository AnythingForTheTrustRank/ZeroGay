using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate Type iEOALLi1l44QJNhksVG(object , string );