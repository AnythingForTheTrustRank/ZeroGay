using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using System;
using tYy2MDMXW3ILM6p88Dk;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace wdVshvIttB38g3stWhN
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class FnbxQIIRL38ImfJGr0C
	{
		private static FnbxQIIRL38ImfJGr0C hGRoIofUyjmlgQkNDv8;

		public FnbxQIIRL38ImfJGr0C()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static FnbxQIIRL38ImfJGr0C cICaC0fuGIZQrlCI0uM()
		{
			return FnbxQIIRL38ImfJGr0C.hGRoIofUyjmlgQkNDv8;
		}

		internal static bool Glos0kfPVLKLfNdjnKE()
		{
			return FnbxQIIRL38ImfJGr0C.hGRoIofUyjmlgQkNDv8 == null;
		}

		public static bool Vk3IKEZXnj(ref string string_0, object object_0)
		{
			bool flag;
			if (!YoFGyBMFcbpvHJfimuV.HuTMzt2oui)
			{
				flag = true;
			}
			else
			{
				flag = (string_0 != "SyncVotedOut" ? true : false);
			}
			return flag;
		}
	}
}