using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate QuickMenu wDo8SrZYOe9stmjMtHY();