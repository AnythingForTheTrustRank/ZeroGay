using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void AMCAxtpayY3kkxL3eKj();