using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void M5y4UNLln4EElwHFabF(object object_0, BitRate bitRate_0);