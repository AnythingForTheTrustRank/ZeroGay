using b3eD5DgJPcASx0xfHYB;
using Photon.Realtime;
using System;

internal delegate void BQHLpCKGEP4FjZM879a(object , EventCaching );