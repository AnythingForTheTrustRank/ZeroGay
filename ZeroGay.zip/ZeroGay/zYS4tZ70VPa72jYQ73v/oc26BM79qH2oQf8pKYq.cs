using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using Mono.WebBrowser;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;

namespace zYS4tZ70VPa72jYQ73v
{
	internal class oc26BM79qH2oQf8pKYq
	{
		public QMNestedButton k7M7uUVeku;

		public QMSingleButton bUY7FaUwlN;

		public QMSingleButton gnE7XYGLCU;

		public QMSingleButton kWk7Zix2Hj;

		public List<oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi> OnT7VZoFbj;

		private int M4W7LGYspZ;

		private int PlN71XVLq4;

		private int LH673wnSJ3;

		private Action<oc26BM79qH2oQf8pKYq> rlT7kQXfby;

		public int YAL7fOecsw;

		public bool RsK7m5EJyc;

		public bool Mmk7D9UUPA;

		public bool ioD7gcx6sl;

		private static oc26BM79qH2oQf8pKYq TJnuB34CsH7GqH611lK;

		public oc26BM79qH2oQf8pKYq(QMNestedButton qmnestedButton_0)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.OnT7VZoFbj = new List<oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi>();
			this.M4W7LGYspZ = 0;
			this.PlN71XVLq4 = 0;
			this.LH673wnSJ3 = 0;
			this.YAL7fOecsw = 0;
			this.RsK7m5EJyc = true;
			this.Mmk7D9UUPA = false;
			this.ioD7gcx6sl = false;
			base();
			this.k7M7uUVeku = qmnestedButton_0;
			QMNestedButton qMNestedButton = this.k7M7uUVeku;
			string str = (this.YAL7fOecsw + 1).ToString();
			int lH673wnSJ3 = this.LH673wnSJ3 + 1;
			string str1 = string.Concat("Page:\n", str, " of ", lH673wnSJ3.ToString());
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			this.kWk7Zix2Hj = new QMSingleButton(qMNestedButton, 4f, 1.65f, str1, () => {
			}, "", nullable1, nullable, false);
			this.kWk7Zix2Hj.GetGameObject().GetComponent<Button>().set_enabled(false);
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			this.gnE7XYGLCU = new QMSingleButton(this.k7M7uUVeku, 4f, 1.15f, "Back", () => this.STq7xO2Fmo(this.YAL7fOecsw - 1), "Go Back", nullable2, nullable, true);
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			this.bUY7FaUwlN = new QMSingleButton(this.k7M7uUVeku, 4f, 2.55f, "Next", () => this.STq7xO2Fmo(this.YAL7fOecsw + 1), "Go Next", nullable3, nullable, true);
		}

		public void DqI7E3yAaX()
		{
			foreach (oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi onT7VZoFbj in this.OnT7VZoFbj)
			{
				UnityEngine.Object.Destroy(onT7VZoFbj.i6Ntjl4P4E.GetGameObject());
			}
			this.OnT7VZoFbj.Clear();
			if (this.k7M7uUVeku.GetBackButton() != null)
			{
				UnityEngine.Object.Destroy(this.k7M7uUVeku.GetBackButton());
			}
			if (this.kWk7Zix2Hj != null)
			{
				this.kWk7Zix2Hj.DestroyMe();
			}
			if (this.gnE7XYGLCU != null)
			{
				this.gnE7XYGLCU.DestroyMe();
			}
			if (this.bUY7FaUwlN != null)
			{
				this.bUY7FaUwlN.DestroyMe();
			}
		}

		public void E0M7JXuQ6V(Action<oc26BM79qH2oQf8pKYq> action_0, bool bool_0 = true)
		{
			try
			{
				this.rlT7kQXfby = action_0;
				this.k7M7uUVeku.GetMainButton().SetAction(() => {
					if (bool_0)
					{
						this.xPQ7wBDCBE();
					}
					this.rlT7kQXfby(this);
					this.k7M7uUVeku.OpenMe();
					this.STq7xO2Fmo(0);
				});
			}
			catch (Mono.WebBrowser.Exception exception)
			{
				Console.WriteLine(exception);
			}
		}

		public void fb17pGVTke(QMButtonBase qmbuttonBase_0)
		{
			if (this.M4W7LGYspZ < 4)
			{
				this.M4W7LGYspZ++;
			}
			if (this.M4W7LGYspZ == 4)
			{
				this.M4W7LGYspZ = 1;
				this.PlN71XVLq4++;
			}
			if (this.PlN71XVLq4 == 4)
			{
				this.PlN71XVLq4 = 0;
				this.LH673wnSJ3++;
			}
			if (this.RsK7m5EJyc)
			{
				qmbuttonBase_0.SetLocation((float)this.M4W7LGYspZ, (float)this.PlN71XVLq4);
			}
			qmbuttonBase_0.SetActive(false);
			this.OnT7VZoFbj.Add(new oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi()
			{
				i6Ntjl4P4E = qmbuttonBase_0,
				YN9tSRk6pV = this.LH673wnSJ3
			});
		}

		public void qrX7WOlBnm(QMButtonBase qmbuttonBase_0, int int_0, float float_0 = 0f, float float_1 = 0f)
		{
			if (this.RsK7m5EJyc)
			{
				qmbuttonBase_0.SetLocation((float)this.M4W7LGYspZ, (float)this.PlN71XVLq4);
			}
			qmbuttonBase_0.SetActive(false);
			this.OnT7VZoFbj.Add(new oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi()
			{
				i6Ntjl4P4E = qmbuttonBase_0,
				YN9tSRk6pV = int_0
			});
			if (!this.ioD7gcx6sl && int_0 > this.LH673wnSJ3)
			{
				this.LH673wnSJ3 = int_0;
			}
		}

		public void QvY78axR7g()
		{
			this.xPQ7wBDCBE();
			Action<oc26BM79qH2oQf8pKYq> action = this.rlT7kQXfby;
			if (action == null)
			{
			}
			else
			{
				action(this);
			}
			this.k7M7uUVeku.OpenMe();
			this.STq7xO2Fmo(0);
		}

		internal static bool RsWjBF4qx7DuSG80r7E()
		{
			return oc26BM79qH2oQf8pKYq.TJnuB34CsH7GqH611lK == null;
		}

		public void STq7xO2Fmo(int int_0)
		{
			bool flag;
			if (!this.Mmk7D9UUPA)
			{
				flag = (int_0 < 0 ? true : int_0 > this.LH673wnSJ3);
			}
			else
			{
				flag = false;
			}
			if (!flag)
			{
				foreach (oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi onT7VZoFbj in this.OnT7VZoFbj)
				{
					if (onT7VZoFbj.YN9tSRk6pV == int_0)
					{
						QMButtonBase qMButtonBase = onT7VZoFbj.i6Ntjl4P4E;
						if (qMButtonBase != null)
						{
							qMButtonBase.SetActive(true);
						}
						else
						{
						}
					}
					else
					{
						QMButtonBase qMButtonBase1 = onT7VZoFbj.i6Ntjl4P4E;
						if (qMButtonBase1 != null)
						{
							qMButtonBase1.SetActive(false);
						}
						else
						{
						}
					}
				}
				this.YAL7fOecsw = int_0;
				QMSingleButton qMSingleButton = this.kWk7Zix2Hj;
				string str = (this.YAL7fOecsw + 1).ToString();
				int lH673wnSJ3 = this.LH673wnSJ3 + 1;
				qMSingleButton.SetButtonText(string.Concat("Page:\n", str, " of ", lH673wnSJ3.ToString()));
			}
		}

		public void xPQ7wBDCBE()
		{
			try
			{
				foreach (oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi onT7VZoFbj in this.OnT7VZoFbj)
				{
					UnityEngine.Object.Destroy(onT7VZoFbj.i6Ntjl4P4E.GetGameObject());
				}
				this.OnT7VZoFbj.Clear();
				this.M4W7LGYspZ = 0;
				this.PlN71XVLq4 = 0;
				this.LH673wnSJ3 = 0;
				this.YAL7fOecsw = 0;
			}
			catch
			{
			}
		}

		internal static oc26BM79qH2oQf8pKYq z0leoy4h5CFYiyRie2Y()
		{
			return oc26BM79qH2oQf8pKYq.TJnuB34CsH7GqH611lK;
		}

		public class YnTItyt4kAVP6NiLCbi
		{
			public QMButtonBase i6Ntjl4P4E;

			public int YN9tSRk6pV;

			internal static oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi EaGKjVzloo69No4fktC;

			public YnTItyt4kAVP6NiLCbi()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal static oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi JebNs6zGL79mLj2jGXM()
			{
				return oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi.EaGKjVzloo69No4fktC;
			}

			internal static bool RH8lMUzAgDtsiuo7PYH()
			{
				return oc26BM79qH2oQf8pKYq.YnTItyt4kAVP6NiLCbi.EaGKjVzloo69No4fktC == null;
			}
		}
	}
}