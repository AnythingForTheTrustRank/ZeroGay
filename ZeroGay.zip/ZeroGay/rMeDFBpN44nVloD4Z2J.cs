using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCVrCamera rMeDFBpN44nVloD4Z2J();