using AksgHVKH9UOXlBDvRpO;
using Photon.Realtime;
using System;

internal delegate LoadBalancingPeer rtBpcTVQvQVR1fr2RNj(object object_0);