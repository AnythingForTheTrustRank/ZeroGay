using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;
using X7IetPATbOXxq4U7Vmy;

namespace EagM04yuytpHm5EGSqN
{
	internal class ewoOruyP5ycGmhU6XIS : MonoBehaviour
	{
		public static bool CcMyXCCUHa;

		public static float XtDyZO3jCs;

		private static ewoOruyP5ycGmhU6XIS WdTkXwDuQajXqUifN2D;

		public ewoOruyP5ycGmhU6XIS(IntPtr intptr_0)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base(intptr_0);
		}

		internal static bool BYYOfPDFjEV96xKkFY5()
		{
			return ewoOruyP5ycGmhU6XIS.WdTkXwDuQajXqUifN2D == null;
		}

		internal static ewoOruyP5ycGmhU6XIS mmFMfcDXRkVoXTuBJ0C()
		{
			return ewoOruyP5ycGmhU6XIS.WdTkXwDuQajXqUifN2D;
		}

		private void OnCollisionEnter(Collision collision)
		{
			if (!collision.get_transform().get_name().Contains("VRCPlayer"))
			{
				foreach (ContactPoint contact in collision.get_contacts())
				{
					if (!ewoOruyP5ycGmhU6XIS.CcMyXCCUHa)
					{
						continue;
					}
					Vector3 vector3 = new Vector3(contact.get_point().x, contact.get_point().y, contact.get_point().z);
					ewoOruyP5ycGmhU6XIS.pkQyF4aBZT(vector3);
					UnityEngine.Object.Destroy(base.get_gameObject());
				}
			}
		}

		private void OnCollisionExit(Collision other)
		{
		}

		private void OnDestroy()
		{
			ewoOruyP5ycGmhU6XIS.CcMyXCCUHa = false;
		}

		public void OnDisable()
		{
			ewoOruyP5ycGmhU6XIS.CcMyXCCUHa = false;
		}

		public void OnEnable()
		{
			ewoOruyP5ycGmhU6XIS.CcMyXCCUHa = false;
		}

		internal static void pkQyF4aBZT(Vector3 vector3_0)
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array[i].get_gameObject());
					array[i].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					array[i].get_transform().set_position(vector3_0);
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(vRCPickupArray[j].get_gameObject());
					vRCPickupArray[j].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					vRCPickupArray[j].get_transform().set_position(vector3_0);
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array1[k].get_gameObject());
					array1[k].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					array1[k].get_transform().set_position(vector3_0);
				}
			}
		}

		public void Start()
		{
		}

		public void Update()
		{
			if (base.get_gameObject().GetComponent<VRCSDK2.VRC_Pickup>().get_IsHeld())
			{
				ewoOruyP5ycGmhU6XIS.CcMyXCCUHa = true;
			}
			if (ewoOruyP5ycGmhU6XIS.CcMyXCCUHa)
			{
				base.get_gameObject().GetComponent<Rigidbody>().set_useGravity(true);
				base.get_gameObject().GetComponent<BoxCollider>().set_isTrigger(false);
			}
			ewoOruyP5ycGmhU6XIS.XtDyZO3jCs = 0f;
		}
	}
}