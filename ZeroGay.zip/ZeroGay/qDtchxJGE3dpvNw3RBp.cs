using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string qDtchxJGE3dpvNw3RBp(string string_0, string string_1);