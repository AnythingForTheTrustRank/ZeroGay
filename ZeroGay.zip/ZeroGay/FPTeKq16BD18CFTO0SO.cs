using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void FPTeKq16BD18CFTO0SO(object , ParticleSystemTrailTextureMode );