using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine.Events;

internal delegate void maB3XlnYI3Pb6SZLILL(object , UnityAction );