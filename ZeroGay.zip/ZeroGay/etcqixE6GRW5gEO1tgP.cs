using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Color etcqixE6GRW5gEO1tgP(Color color_0, float float_0);