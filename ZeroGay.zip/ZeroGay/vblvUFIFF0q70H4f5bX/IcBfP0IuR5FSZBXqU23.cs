using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using N6nRU8MeL8DN1kbqbkv;
using System;
using UnityEngine;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace vblvUFIFF0q70H4f5bX
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class IcBfP0IuR5FSZBXqU23
	{
		public static string IESIVw3ETo;

		internal static IcBfP0IuR5FSZBXqU23 xKGepffbySKtl7oA1Eb;

		static IcBfP0IuR5FSZBXqU23()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			IcBfP0IuR5FSZBXqU23.IESIVw3ETo = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
		}

		public IcBfP0IuR5FSZBXqU23()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static bool MbXIXOyokH()
		{
			bool flag;
			flag = (!RoomManager.Method_Internal_Static_get_String_0().Contains(IcBfP0IuR5FSZBXqU23.IESIVw3ETo) ? false : true);
			return flag;
		}

		internal static bool opGqARfNpgGIkMGfyv9()
		{
			return IcBfP0IuR5FSZBXqU23.xKGepffbySKtl7oA1Eb == null;
		}

		internal static IcBfP0IuR5FSZBXqU23 tSW5VJfzvqy9EJvTFMb()
		{
			return IcBfP0IuR5FSZBXqU23.xKGepffbySKtl7oA1Eb;
		}

		public static bool UI0IZmZg8b(ref string string_0, object object_0)
		{
			if (IcBfP0IuR5FSZBXqU23.MbXIXOyokH())
			{
				if (nBcbMnM7C7ZvL3AISZB.O7hME59iH3)
				{
					GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(false);
					GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(false);
					GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(false);
				}
				else
				{
					GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(true);
					GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(true);
					GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(true);
				}
			}
			return true;
		}
	}
}