using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Type bOs27Qwo8uC7MbciptB(object object_0);