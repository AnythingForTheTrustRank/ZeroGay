using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void uO3QCbe92by34gAAw6J(object , FontStyle );