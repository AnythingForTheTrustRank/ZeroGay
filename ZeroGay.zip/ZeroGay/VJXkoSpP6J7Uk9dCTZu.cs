using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using System;
using System.Reflection;

internal delegate MethodInfo VJXkoSpP6J7Uk9dCTZu(object , MethodBase , HarmonyMethod , HarmonyMethod , HarmonyMethod , HarmonyMethod , HarmonyMethod );