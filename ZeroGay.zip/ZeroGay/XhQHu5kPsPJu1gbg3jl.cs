using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection.Emit;

internal delegate void XhQHu5kPsPJu1gbg3jl(object object_0, OpCode opCode_0, int int_0);