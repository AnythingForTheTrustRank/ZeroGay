using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.UI;

internal delegate ColorBlock kmefn5FepMQsgKhVXnr(object object_0);