using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using N6nRU8MeL8DN1kbqbkv;
using System;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace CusFldIUt1IyQRdHLSb
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class dWh3OkIWO0OKatQH9PE
	{
		internal static dWh3OkIWO0OKatQH9PE K0KwHhf4DgSdlAhFwGe;

		public dWh3OkIWO0OKatQH9PE()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool nC85bMfjOAAXqxQaKao()
		{
			return dWh3OkIWO0OKatQH9PE.K0KwHhf4DgSdlAhFwGe == null;
		}

		internal static dWh3OkIWO0OKatQH9PE QTlFJufSo0OoDTUBsfy()
		{
			return dWh3OkIWO0OKatQH9PE.K0KwHhf4DgSdlAhFwGe;
		}

		public static bool tJIIPh34OE(ref string string_0, object object_0)
		{
			bool flag;
			if (!nBcbMnM7C7ZvL3AISZB.O7hME59iH3)
			{
				flag = true;
			}
			else
			{
				flag = (string_0 == "SyncSnakeAttack" ? false : true);
			}
			return flag;
		}
	}
}