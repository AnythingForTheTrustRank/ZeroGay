using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using System;

internal delegate Il2CppSystem.Object OvHC2rwDV5ReghtCbtL(string string_0);