using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string omImDb8smmIsrvH4r3t(string string_0, object object_0, object object_1);