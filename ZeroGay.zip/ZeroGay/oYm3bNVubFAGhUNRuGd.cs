using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void oYm3bNVubFAGhUNRuGd(object , ref bool );