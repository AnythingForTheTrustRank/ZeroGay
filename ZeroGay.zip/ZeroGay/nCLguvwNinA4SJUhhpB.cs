using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCPlayer nCLguvwNinA4SJUhhpB();