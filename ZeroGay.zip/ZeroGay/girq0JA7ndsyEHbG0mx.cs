using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Diagnostics;
using System;

internal delegate Process girq0JA7ndsyEHbG0mx();