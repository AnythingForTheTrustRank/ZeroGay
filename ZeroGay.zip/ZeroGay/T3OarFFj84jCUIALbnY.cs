using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void T3OarFFj84jCUIALbnY(object , Material );