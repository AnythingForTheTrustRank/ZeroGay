using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate PlayerNameplate G6EFg21F9uSaJmiLBN9(object );