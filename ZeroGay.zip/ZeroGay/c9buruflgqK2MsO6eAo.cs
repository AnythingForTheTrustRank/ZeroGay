using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine.UI;

internal delegate void c9buruflgqK2MsO6eAo(object , ColorBlock );