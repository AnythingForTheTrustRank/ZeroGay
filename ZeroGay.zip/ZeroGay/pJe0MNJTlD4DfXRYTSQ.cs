using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;
using System.Reflection.Emit;

internal delegate void pJe0MNJTlD4DfXRYTSQ(object , OpCode , MethodInfo , Type[] );