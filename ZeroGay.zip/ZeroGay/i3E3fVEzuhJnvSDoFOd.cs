using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;
using UnhollowerRuntimeLib.XrefScans;

internal delegate MethodBase i3E3fVEzuhJnvSDoFOd(ref XrefInstance xrefInstance_0);