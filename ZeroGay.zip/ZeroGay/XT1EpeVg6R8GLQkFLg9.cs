using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCInput XT1EpeVg6R8GLQkFLg9(object object_0);