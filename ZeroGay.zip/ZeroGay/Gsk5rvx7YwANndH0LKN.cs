using b3eD5DgJPcASx0xfHYB;
using System;
using TMPro;

internal delegate void Gsk5rvx7YwANndH0LKN(object , TextAlignmentOptions );