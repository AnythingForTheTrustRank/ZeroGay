using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void TpVdoWWFZ5ssv5eFShg(object object_0, Quaternion quaternion_0);