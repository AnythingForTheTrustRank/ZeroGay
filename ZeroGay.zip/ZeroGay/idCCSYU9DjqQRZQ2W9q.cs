using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Core;

internal delegate APIUser idCCSYU9DjqQRZQ2W9q();