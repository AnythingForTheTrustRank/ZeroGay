using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void WHFDCRZIu776GbfsyoV(object object_0, string string_0, float float_0);