using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection.Emit;

internal delegate void vQOv26kWubvXegodUDE(object object_0, OpCode opCode_0, sbyte sbyte_0);