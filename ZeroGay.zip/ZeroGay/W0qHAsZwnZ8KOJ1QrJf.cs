using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;

internal delegate List<VRCUiContentButton> W0qHAsZwnZ8KOJ1QrJf(object );