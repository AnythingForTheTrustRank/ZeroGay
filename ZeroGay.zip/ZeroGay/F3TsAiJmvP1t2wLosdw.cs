using AksgHVKH9UOXlBDvRpO;
using System;
using VRC;

internal delegate PlayerManager F3TsAiJmvP1t2wLosdw();