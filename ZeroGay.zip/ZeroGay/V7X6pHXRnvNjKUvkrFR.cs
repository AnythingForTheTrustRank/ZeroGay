using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.UI.Elements;

internal delegate void V7X6pHXRnvNjKUvkrFR(object object_0, List<UIPage> list_0);