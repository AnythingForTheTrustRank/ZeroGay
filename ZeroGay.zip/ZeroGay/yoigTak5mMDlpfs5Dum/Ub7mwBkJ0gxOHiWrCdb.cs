using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using Il2CppSystem.IO;
using Il2CppSystem.Runtime.Serialization.Formatters.Binary;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnhollowerBaseLib;
using UnityEngine;

namespace yoigTak5mMDlpfs5Dum
{
	internal class Ub7mwBkJ0gxOHiWrCdb
	{
		internal static Ub7mwBkJ0gxOHiWrCdb zcVcdV5tICxD9myVAWX;

		public Ub7mwBkJ0gxOHiWrCdb()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static Ub7mwBkJ0gxOHiWrCdb cBTwbe5wyohL30g4oIK()
		{
			return Ub7mwBkJ0gxOHiWrCdb.zcVcdV5tICxD9myVAWX;
		}

		public static byte[] dSVkmlCavh(object u0020)
		{
			byte[] array;
			if (u0020 == null)
			{
				array = null;
			}
			else
			{
				Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				Il2CppSystem.IO.MemoryStream memoryStream = new Il2CppSystem.IO.MemoryStream();
				binaryFormatter.Serialize(memoryStream, u0020);
				array = memoryStream.ToArray();
			}
			return array;
		}

		public static A78fM98HaP7l9iYZSek l7188lYESg<A78fM98HaP7l9iYZSek>(object u0020)
		{
			return Ub7mwBkJ0gxOHiWrCdb.YZskEFXuSh<A78fM98HaP7l9iYZSek>(Ub7mwBkJ0gxOHiWrCdb.Ls5kD6TIcL(u0020));
		}

		public static byte[] Ls5kD6TIcL(object u0020)
		{
			byte[] array;
			if (u0020 != null)
			{
				System.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
				binaryFormatter.Serialize(memoryStream, u0020);
				array = memoryStream.ToArray();
			}
			else
			{
				array = null;
			}
			return array;
		}

		public static UnityEngine.Object pZUkojwpBM(object u0020)
		{
			Il2CppStructArray<byte> il2CppStructArray = new Il2CppStructArray<byte>((long)((int)u0020.Length));
			u0020.CopyTo(il2CppStructArray, 0);
			return new UnityEngine.Object((new Il2CppSystem.Object(il2CppStructArray.get_Pointer())).get_Pointer());
		}

		internal static bool uphMeb5QTiy46GJr6rr()
		{
			return Ub7mwBkJ0gxOHiWrCdb.zcVcdV5tICxD9myVAWX == null;
		}

		public static byte[] VFqkdccph4(int u0020)
		{
			System.Random random = new System.Random();
			byte[] numArray = new byte[u0020 * 1024];
			random.NextBytes(numArray);
			return numArray;
		}

		public static xyHvHB8kS12rV6BVRjH xHu8qboxFx<xyHvHB8kS12rV6BVRjH>(object u0020)
		{
			return Ub7mwBkJ0gxOHiWrCdb.z6Zkc5MN1Q<xyHvHB8kS12rV6BVRjH>(Ub7mwBkJ0gxOHiWrCdb.dSVkmlCavh(u0020));
		}

		public static Q28JpmkzNPSZOQtQet9 YZskEFXuSh<Q28JpmkzNPSZOQtQet9>(object u0020)
		{
			Q28JpmkzNPSZOQtQet9 q28JpmkzNPSZOQtQet9;
			if (u0020 != null)
			{
				Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				q28JpmkzNPSZOQtQet9 = (Q28JpmkzNPSZOQtQet9)binaryFormatter.Deserialize(new Il2CppSystem.IO.MemoryStream(u0020));
			}
			else
			{
				q28JpmkzNPSZOQtQet9 = default(Q28JpmkzNPSZOQtQet9);
			}
			return q28JpmkzNPSZOQtQet9;
		}

		public static PMcY4nkyO56YFpFtZPd z6Zkc5MN1Q<PMcY4nkyO56YFpFtZPd>(object u0020)
		{
			PMcY4nkyO56YFpFtZPd pMcY4nkyO56YFpFtZPd;
			if (u0020 != null)
			{
				System.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream(u0020))
				{
					pMcY4nkyO56YFpFtZPd = (PMcY4nkyO56YFpFtZPd)binaryFormatter.Deserialize(memoryStream);
				}
			}
			else
			{
				pMcY4nkyO56YFpFtZPd = default(PMcY4nkyO56YFpFtZPd);
			}
			return pMcY4nkyO56YFpFtZPd;
		}
	}
}