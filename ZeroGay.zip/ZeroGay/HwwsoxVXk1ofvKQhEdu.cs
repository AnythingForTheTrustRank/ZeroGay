using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;

internal delegate string HwwsoxVXk1ofvKQhEdu(string string_0, IEnumerable<string> ienumerable_0);