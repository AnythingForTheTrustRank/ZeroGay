using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using UnityEngine.UI;

internal delegate void neBP1ffvB2CNGmx24xj(ref ColorBlock , Color );