using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate Delegate dHdhCp1HjojP1HvodPV(Type type_0, MethodInfo methodInfo_0);