using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object No4tL93aRWNlQQ7iQth(Type type_0, long long_0);