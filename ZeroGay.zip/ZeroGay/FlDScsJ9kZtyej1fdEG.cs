using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void FlDScsJ9kZtyej1fdEG(object object_0, GameObject gameObject_0);