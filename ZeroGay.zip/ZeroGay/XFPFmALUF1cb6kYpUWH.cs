using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate int XFPFmALUF1cb6kYpUWH(ref IntPtr );