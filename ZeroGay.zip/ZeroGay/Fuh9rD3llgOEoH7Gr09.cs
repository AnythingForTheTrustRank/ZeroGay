using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate long Fuh9rD3llgOEoH7Gr09(ref IntPtr intptr_0);