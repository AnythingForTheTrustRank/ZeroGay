using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object mm3I7sLMZKsvsRwTqdH(Type , ulong );