using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using Il2CppSystem.IO;
using System;

internal delegate void TQGT61RLrIfqFossstZ(object , Stream , Il2CppSystem.Object );