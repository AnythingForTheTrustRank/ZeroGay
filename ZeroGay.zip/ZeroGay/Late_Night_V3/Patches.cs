using AksgHVKH9UOXlBDvRpO;
using ExitGames.Client.Photon;
using H265BlIi2sW2Qc3cqB8;
using HarmonyLib;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using N6nRU8MeL8DN1kbqbkv;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using UnityEngine.XR;
using VRC;
using VRC.Core;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace Late_Night_V3
{
	public static class Patches
	{
		public static string WORLDID;

		private static bool eDBITdmAPU;

		private static bool HoeI7k5WUp;

		public static byte KYS;

		public static object KYS2;

		public static RaiseEventOptions KYS3;

		internal static Patches LktW1GfJ8jXsIXujm8Y;

		static Patches()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			Patches.WORLDID = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
		}

		public static bool CheckMethod(MethodBase methodBase, string match)
		{
			bool flag;
			try
			{
				flag = (
					from instance in XrefScanner.XrefScan(methodBase)
					where false
					select instance).Any<XrefInstance>();
				return flag;
			}
			catch
			{
			}
			flag = false;
			return flag;
		}

		public static bool CheckUsed(MethodBase methodBase, string methodName)
		{
			bool flag;
			try
			{
				flag = (
					from instance in XrefScanner.UsedBy(methodBase)
					where (instance.TryResolve() != null ? instance.TryResolve().Name.Contains(methodName) : false)
					select instance).Any<XrefInstance>();
				return flag;
			}
			catch
			{
			}
			flag = false;
			return flag;
		}

		private static bool comfyMenu(object __instance, bool __0, bool __1)
		{
			bool flag;
			try
			{
				if (XRDevice.get_isPresent())
				{
					float single = (Utils.VRCTrackingManager == null ? 1f : Utils.VRCTrackingManager.get_transform().get_localScale().x);
					if (single <= 0f)
					{
						single = 1f;
					}
					Transform _transform = __instance.get_transform();
					Transform transform = __instance.get_transform().Find("UnscaledUI");
					_transform.set_position(Utils.GetWorldCameraPosition());
					Quaternion _rotation = GameObject.Find("Camera (eye)").get_transform().get_rotation();
					Vector3 _eulerAngles = _rotation.get_eulerAngles();
					Vector3 vector3 = new Vector3(_eulerAngles.x - 30f, _eulerAngles.y, 0f);
					if (Utils.CurrentUser == null)
					{
						float single1 = 0f;
						vector3.z = 0f;
						vector3.x = single1;
					}
					if (!__0)
					{
						_transform.set_rotation(Quaternion.Euler(vector3));
					}
					else
					{
						Quaternion quaternion = Quaternion.Euler(vector3);
						if (Quaternion.Angle(_transform.get_rotation(), quaternion) >= 15f)
						{
							if (Quaternion.Angle(_transform.get_rotation(), quaternion) < 25f)
							{
								_transform.set_rotation(Quaternion.RotateTowards(_transform.get_rotation(), quaternion, 1f));
							}
							else
							{
								_transform.set_rotation(Quaternion.RotateTowards(_transform.get_rotation(), quaternion, 5f));
							}
						}
					}
					if (single >= 0f)
					{
						_transform.set_localScale(single * Vector3.get_one());
					}
					else
					{
						_transform.set_localScale(Vector3.get_one());
					}
					if (single > 1.401298E-45f)
					{
						transform.set_localScale(1f / single * Vector3.get_one());
					}
					else
					{
						transform.set_localScale(Vector3.get_one());
					}
					flag = false;
					return flag;
				}
			}
			catch
			{
			}
			flag = true;
			return flag;
		}

		public static bool GetIsFriend(this APIUser Instance)
		{
			return (Instance.get_isFriend() || APIUser.IsFriendsWith(Instance.get_id()) ? true : APIUser.get_CurrentUser().get_friendIDs().Contains(Instance.get_id()));
		}

		public static HarmonyMethod GetLocalPatch(string name)
		{
			HarmonyMethod harmonyMethod = new HarmonyMethod(typeof(Patches).GetMethod(name, BindingFlags.Static | BindingFlags.NonPublic));
			return harmonyMethod;
		}

		public static bool Inworld()
		{
			bool flag;
			flag = (!RoomManager.Method_Internal_Static_get_String_0().Contains(Patches.WORLDID) ? false : true);
			return flag;
		}

		internal static Patches kEYnNOfED8vRuGJZeDn()
		{
			return Patches.LktW1GfJ8jXsIXujm8Y;
		}

		private static void onJoin(ref Player __0)
		{
			try
			{
				if (MainConfigSettings.Instance.joinleavelogger)
				{
					if (MainConfigSettings.Instance.PlayerESP)
					{
						Esp.ToggleESP(false);
						Esp.ToggleESP(true);
					}
					if (__0.get_field_Private_APIUser_0().GetIsFriend())
					{
						VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(string.Concat("<color=#e0cf16> ", __0.Method_Internal_get_APIUser_0().get_displayName(), " </color><color=#00e617> Joined</color>"));
						MainMenuLol.logjoin(string.Concat("<color=#e0cf16> FRIEND ", __0.Method_Internal_get_APIUser_0().get_displayName(), " </color><color=#00e617> Joined</color>"));
						MelonLogger.Log(string.Concat("FRIEND [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Joined"));
					}
					else
					{
						VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(string.Concat(__0.Method_Internal_get_APIUser_0().get_displayName(), "<color=green> Joined</color>"));
						MainMenuLol.logjoin(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Joined"));
						MelonLogger.Log(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Joined"));
					}
				}
			}
			catch
			{
			}
		}

		private static void onLeft(ref Player __0)
		{
			try
			{
				if (MainConfigSettings.Instance.joinleavelogger)
				{
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(string.Concat(__0.Method_Internal_get_APIUser_0().get_displayName(), "<color=#ad0000> Left</color>"));
					MainMenuLol.logleave(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Left"));
					MelonLogger.Log(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Left"));
				}
			}
			catch
			{
			}
		}

		private static bool photonevents(ref EventData __0)
		{
			bool flag;
			try
			{
				if (__0.get_Code() == 4 && MainConfigSettings.Instance.Event4blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 6 && MainConfigSettings.Instance.Event6blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 8 && MainConfigSettings.Instance.Event8blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 9 && MainConfigSettings.Instance.Event9blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 33 && MainConfigSettings.Instance.Event33blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 209 && MainConfigSettings.Instance.Event209blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() != 210 || !MainConfigSettings.Instance.Event210blockNonfriends)
				{
					flag = true;
					return flag;
				}
				else
				{
					flag = false;
				}
			}
			catch
			{
				flag = true;
				return flag;
			}
			return flag;
		}

		public static MethodInfo PlaceUI()
		{
			MethodInfo methodInfo;
			bool flag;
			foreach (XrefInstance xrefInstance in XrefScanner.XrefScan(typeof(VRCUiManager).GetMethod("LateUpdate")))
			{
				flag = ((xrefInstance.Type != 1 || !(xrefInstance.TryResolve() != null) ? true : (int)xrefInstance.TryResolve().GetParameters().Length != 2) ? false : ((IEnumerable<ParameterInfo>)xrefInstance.TryResolve().GetParameters()).All<ParameterInfo>((ParameterInfo a) => a.ParameterType == typeof(bool)));
				if (!flag)
				{
					continue;
				}
				methodInfo = (MethodInfo)xrefInstance.TryResolve();
				return methodInfo;
			}
			methodInfo = null;
			return methodInfo;
		}

		internal static bool S9fH7Nf8ta1l4RZZaOJ()
		{
			return Patches.LktW1GfJ8jXsIXujm8Y == null;
		}

		private static bool UdonLogShit(ref string __0, object __1)
		{
			bool flag;
			if (__0.Contains(""))
			{
				MelonLogger.Log(string.Concat(__0, " : From : ", __1.get_name()));
			}
			if (TRfUrNIv9gICnHInO1k.gPeI0EYTL8)
			{
				if (!Patches.HoeI7k5WUp)
				{
					MelonLogger.Log("Patched Stab Death");
					MelonLogger.Log("Patched Bullet Death");
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Stab Death", ConsoleColor.Red));
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Bullet Death", ConsoleColor.Red));
					Patches.HoeI7k5WUp = true;
				}
				if (__0 != "BackStabDamage")
				{
					if (!__0.Contains("HitDamage"))
					{
						goto Label1;
					}
					MelonLogger.Log("Prevented Death");
					flag = false;
					return flag;
				}
				else
				{
					MelonLogger.Log("Prevented Death");
					flag = false;
					return flag;
				}
			}
		Label1:
			if (!nBcbMnM7C7ZvL3AISZB.O7hME59iH3)
			{
				flag = true;
			}
			else
			{
				if (!Patches.eDBITdmAPU)
				{
					MelonLogger.Log("Patched Trap Death");
					MelonLogger.Log("Patched Snake Death");
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Trap Death", ConsoleColor.Red));
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Snake Death", ConsoleColor.Red));
					Patches.eDBITdmAPU = true;
				}
				if (__0 == "SyncKill")
				{
					MelonLogger.Log("Prevented Death By SyncKill");
					flag = false;
				}
				else if (__0 != "SyncSnakeAttack")
				{
					if (Patches.Inworld())
					{
						if (nBcbMnM7C7ZvL3AISZB.O7hME59iH3)
						{
							GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(false);
							GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(false);
							GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(false);
						}
						else
						{
							GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(true);
							GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(true);
							GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(true);
						}
					}
					flag = true;
				}
				else
				{
					MelonLogger.Log("Prevented Death By Snake");
					flag = false;
				}
			}
			return flag;
		}

		private static void v4UIys0ot5(object object_0)
		{
			try
			{
				if (object_0.get_gameObject().GetComponentInParent<VRC_PortalMarker>() == null)
				{
					string str = object_0.get_transform().get_position().ToString();
					MelonLogger.Log(string.Concat("Portal Spawned: vector3: ", str));
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage("<color=red>Portal Spawned Destroying it...</color>");
				}
			}
			catch
			{
				MelonLogger.Log("portalSpawn patch go brrr");
			}
		}
	}
}