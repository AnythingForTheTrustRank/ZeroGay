using a1f9Fk6X8PqG43BDAy2;
using Area51.Events;
using b3eD5DgJPcASx0xfHYB;
using Blaze.Modules;
using ExitGames.Client.Photon;
using HarmonyLib;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using OD9m6O9bemNUx4rutsX;
using Photon.Realtime;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using t5eG7owXnu4dEOdK95P;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using VRC;
using VRC.Core;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace Late_Night_V3
{
	public static class Patches
	{
		public static string WORLDID;

		private static bool euN3wDdT2Q;

		private static bool ryT3N1sUls;

		public static byte KYS;

		public static object KYS2;

		public static RaiseEventOptions KYS3;

		private static Patches rusb7R5Svim0ujavtQ3;

		static Patches()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			Patches.WORLDID = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
		}

		public static bool CheckMethod(MethodBase methodBase, string match)
		{
			bool flag;
			try
			{
				flag = (
					from instance in XrefScanner.XrefScan(methodBase)
					where false
					select instance).Any<XrefInstance>();
				return flag;
			}
			catch
			{
			}
			flag = false;
			return flag;
		}

		public static bool CheckUsed(MethodBase methodBase, string methodName)
		{
			bool flag;
			try
			{
				flag = (
					from instance in XrefScanner.UsedBy(methodBase)
					where (instance.TryResolve() != null ? instance.TryResolve().Name.Contains(methodName) : false)
					select instance).Any<XrefInstance>();
				return flag;
			}
			catch
			{
			}
			flag = false;
			return flag;
		}

		private static bool comfyMenu(object __instance, bool __0, bool __1)
		{
			// 
			// Current member / type: System.Boolean Late_Night_V3.Patches::comfyMenu(System.Object,System.Boolean,System.Boolean)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Boolean comfyMenu(System.Object,System.Boolean,System.Boolean)
			// 
			// Object reference not set to an instance of an object.
			//    at ..(UInt32 , Instruction ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 313
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 162
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 118
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 56
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static Patches eBwOh75XeNwaUJUQSSB()
		{
			return Patches.rusb7R5Svim0ujavtQ3;
		}

		public static bool GetIsFriend(this APIUser Instance)
		{
			return (Instance.get_isFriend() || APIUser.IsFriendsWith(Instance.get_id()) ? true : APIUser.get_CurrentUser().get_friendIDs().Contains(Instance.get_id()));
		}

		public static HarmonyMethod GetLocalPatch(string name)
		{
			HarmonyMethod harmonyMethod = new HarmonyMethod(typeof(Patches).GetMethod(name, BindingFlags.Static | BindingFlags.NonPublic));
			return harmonyMethod;
		}

		public static bool Inworld()
		{
			bool flag;
			flag = (!RoomManager.Method_Internal_Static_get_String_0().Contains(Patches.WORLDID) ? false : true);
			return flag;
		}

		private static void kqQ3QB6eHJ(object u0020)
		{
			try
			{
				if (u0020.get_gameObject().GetComponentInParent<VRC_PortalMarker>() == null)
				{
					string str = u0020.get_transform().get_position().ToString();
					MelonLogger.Log(string.Concat("Portal Spawned: vector3: ", str));
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage("<color=red>Portal Spawned Destroying it...</color>");
				}
			}
			catch
			{
				MelonLogger.Log("portalSpawn patch go brrr");
			}
		}

		private static bool OnAvatarAssetBundleLoad(ref object __0)
		{
			bool flag;
			bool flag1;
			GameObject gameObject = __0.Cast<GameObject>();
			if (gameObject == null)
			{
				flag = true;
			}
			else if (gameObject.get_name().ToLower().Contains("avatar"))
			{
				string _blueprintId = gameObject.GetComponent<PipelineManager>().get_blueprintId();
				int num = 0;
				while (num < (int)ZeroDayMain.Instance.OnAssetBundleLoadEventArray.Length)
				{
					if (!ZeroDayMain.Instance.OnAssetBundleLoadEventArray[num].OnAvatarAssetBundleLoad(gameObject, _blueprintId))
					{
						flag1 = false;
						return flag1;
					}
					else
					{
						num++;
					}
				}
				flag = true;
			}
			else
			{
				flag = true;
			}
			flag1 = flag;
			return flag1;
		}

		private static void onJoin(ref Player __0)
		{
			try
			{
				UIgbLCwYwfEUV2GA7DN.UVrwOoZAqi.Add(__0.get_gameObject().AddComponent<ZDUserInfo>());
				if (MainConfigSettings.Instance.joinleavelogger)
				{
					try
					{
						if (MainConfigSettings.Instance.PlayerESP)
						{
							Esp.ToggleESP(false);
							Esp.ToggleESP(true);
						}
					}
					catch (Exception exception)
					{
						MelonLogger.Log("Error In Esp Updater!!!");
						throw;
					}
					if (!__0.get_field_Private_APIUser_0().GetIsFriend())
					{
						VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(string.Concat(__0.Method_Internal_get_APIUser_0().get_displayName(), "<color=green> Joined</color>"));
						MainMenuLol.logjoin(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Joined"));
						MelonLogger.Log(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Joined"));
					}
					else
					{
						VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(string.Concat("<color=#e0cf16> ", __0.Method_Internal_get_APIUser_0().get_displayName(), " </color><color=#00e617> Joined</color>"));
						MainMenuLol.logjoin(string.Concat("<color=#e0cf16> FRIEND ", __0.Method_Internal_get_APIUser_0().get_displayName(), " </color><color=#00e617> Joined</color>"));
						MelonLogger.Log(string.Concat("FRIEND [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Joined"));
					}
				}
			}
			catch
			{
				MelonLogger.Log("Error In OnJoin_");
			}
		}

		private static void onLeft(ref Player __0)
		{
			try
			{
				if (MainConfigSettings.Instance.joinleavelogger)
				{
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(string.Concat(__0.Method_Internal_get_APIUser_0().get_displayName(), "<color=#ad0000> Left</color>"));
					MainMenuLol.logleave(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Left"));
					MelonLogger.Log(string.Concat("Player [", __0.Method_Internal_get_APIUser_0().get_displayName(), "] has Left"));
				}
			}
			catch
			{
			}
		}

		private static bool photonevents(ref EventData __0)
		{
			bool flag;
			try
			{
				if (__0.get_Code() == 4 && MainConfigSettings.Instance.Event4blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 6 && MainConfigSettings.Instance.Event6blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 8 && MainConfigSettings.Instance.Event8blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 9 && MainConfigSettings.Instance.Event9blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 33 && MainConfigSettings.Instance.Event33blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() == 209 && MainConfigSettings.Instance.Event209blockNonfriends)
				{
					flag = false;
				}
				else if (__0.get_Code() != 210 || !MainConfigSettings.Instance.Event210blockNonfriends)
				{
					flag = true;
					return flag;
				}
				else
				{
					flag = false;
				}
			}
			catch
			{
				flag = true;
				return flag;
			}
			return flag;
		}

		public static MethodInfo PlaceUI()
		{
			bool flag;
			MethodInfo methodInfo;
			foreach (XrefInstance xrefInstance in XrefScanner.XrefScan(typeof(VRCUiManager).GetMethod("LateUpdate")))
			{
				flag = (xrefInstance.Type != 1 || !(xrefInstance.TryResolve() != null) || (int)xrefInstance.TryResolve().GetParameters().Length != 2 ? false : ((IEnumerable<ParameterInfo>)xrefInstance.TryResolve().GetParameters()).All<ParameterInfo>((ParameterInfo a) => a.ParameterType == typeof(bool)));
				if (!flag)
				{
					continue;
				}
				methodInfo = (MethodInfo)xrefInstance.TryResolve();
				return methodInfo;
			}
			methodInfo = null;
			return methodInfo;
		}

		internal static bool RgT5pp5YDEwLfKHmcLt()
		{
			return Patches.rusb7R5Svim0ujavtQ3 == null;
		}

		private static bool UdonLogShit(ref string __0, object __1)
		{
			bool flag;
			if (__0.Contains(""))
			{
				MainMenuLol.LogUDONDEBUGGER(string.Concat(__0, " : From : ", __1.Method_Internal_get_APIUser_0().get_displayName()));
				MelonLogger.Log(string.Concat(new string[] { __0, " : From : ", __1.get_name(), " : ", __1.Method_Internal_get_APIUser_0().get_displayName() }));
			}
			if (eoiOZ192r1eDKM8RS8c.lgw9UORmhE)
			{
				if (!Patches.ryT3N1sUls)
				{
					MelonLogger.Log("Patched Stab Death");
					MelonLogger.Log("Patched Bullet Death");
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Stab Death", ConsoleColor.Red));
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Bullet Death", ConsoleColor.Red));
					Patches.ryT3N1sUls = true;
				}
				if (__0 == "BackStabDamage")
				{
					MelonLogger.Log("Prevented Death");
					flag = false;
					return flag;
				}
				else
				{
					if (!__0.Contains("HitDamage"))
					{
						goto Label1;
					}
					MelonLogger.Log("Prevented Death");
					flag = false;
					return flag;
				}
			}
		Label1:
			if (!LoV9yY6YR91Q6ZGX4wt.asg6VuKDgL)
			{
				flag = true;
			}
			else
			{
				if (!Patches.euN3wDdT2Q)
				{
					MelonLogger.Log("Patched Trap Death");
					MelonLogger.Log("Patched Snake Death");
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Trap Death", ConsoleColor.Red));
					VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Patched Snake Death", ConsoleColor.Red));
					Patches.euN3wDdT2Q = true;
				}
				if (__0 == "SyncKill")
				{
					MelonLogger.Log("Prevented Death By SyncKill");
					flag = false;
				}
				else if (__0 == "SyncSnakeAttack")
				{
					MelonLogger.Log("Prevented Death By Snake");
					flag = false;
				}
				else
				{
					if (Patches.Inworld())
					{
						if (!LoV9yY6YR91Q6ZGX4wt.asg6VuKDgL)
						{
							GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(true);
							GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(true);
							GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(true);
						}
						else
						{
							GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(false);
							GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(false);
							GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(false);
						}
					}
					flag = true;
				}
			}
			return flag;
		}
	}
}