using a1f9Fk6X8PqG43BDAy2;
using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC.Networking;

namespace KqOUaV9Y7mqO7ZZj1J4
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class fSSUQs9S8aLS5Kv5bp8
	{
		internal static fSSUQs9S8aLS5Kv5bp8 rZ6yUkd3Ufh4FlOoePh;

		public fSSUQs9S8aLS5Kv5bp8()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static fSSUQs9S8aLS5Kv5bp8 Aw3PQ8dsOTVjhv1Kxnf()
		{
			return fSSUQs9S8aLS5Kv5bp8.rZ6yUkd3Ufh4FlOoePh;
		}

		public static bool REI9Xw5s7X(ref string u0020, object u0020)
		{
			bool flag;
			if (!LoV9yY6YR91Q6ZGX4wt.asg6VuKDgL)
			{
				flag = true;
			}
			else
			{
				flag = (u0020 != "SyncSnakeAttack" ? true : false);
			}
			return flag;
		}

		internal static bool vgi4TUd9fudCVSyip78()
		{
			return fSSUQs9S8aLS5Kv5bp8.rZ6yUkd3Ufh4FlOoePh == null;
		}
	}
}