using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate Module tcbUII1AOmyrspXvkj4(object object_0);