using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCAvatarManager BpoApGL0fd330C1Epfs(object object_0);