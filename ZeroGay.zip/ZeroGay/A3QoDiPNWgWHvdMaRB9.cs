using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCPlayer A3QoDiPNWgWHvdMaRB9(object object_0);