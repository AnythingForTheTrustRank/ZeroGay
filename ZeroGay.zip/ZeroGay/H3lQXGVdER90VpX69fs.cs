using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate Type H3lQXGVdER90VpX69fs(Type );