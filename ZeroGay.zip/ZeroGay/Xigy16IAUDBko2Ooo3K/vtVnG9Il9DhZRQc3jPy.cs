using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using System;
using UnityEngine;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace Xigy16IAUDBko2Ooo3K
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class vtVnG9Il9DhZRQc3jPy
	{
		public static bool sDFId2Q12o;

		private static vtVnG9Il9DhZRQc3jPy vQr01wfFGajg7fyiQtI;

		static vtVnG9Il9DhZRQc3jPy()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			vtVnG9Il9DhZRQc3jPy.sDFId2Q12o = true;
		}

		public vtVnG9Il9DhZRQc3jPy()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static vtVnG9Il9DhZRQc3jPy Bt9ZtKfZyAVZdKNKR5K()
		{
			return vtVnG9Il9DhZRQc3jPy.vQr01wfFGajg7fyiQtI;
		}

		internal static bool lCTZ8wfX3eIlvRMmL7k()
		{
			return vtVnG9Il9DhZRQc3jPy.vQr01wfFGajg7fyiQtI == null;
		}

		public static void vmTIGUWYIe(ref string string_0)
		{
			if (vtVnG9Il9DhZRQc3jPy.sDFId2Q12o && string_0 == "SyncStart")
			{
				MeshRenderer component = GameObject.Find("Game Logic/Player Nodes/Player Node (0)/Corpse/Chalk outline (1)").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer = GameObject.Find("Game Logic/Player Nodes/Player Node (1)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component1 = GameObject.Find("Game Logic/Player Nodes/Player Node (2)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer1 = GameObject.Find("Game Logic/Player Nodes/Player Node (3)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component2 = GameObject.Find("Game Logic/Player Nodes/Player Node (4)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer2 = GameObject.Find("Game Logic/Player Nodes/Player Node (5)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component3 = GameObject.Find("Game Logic/Player Nodes/Player Node (6)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer3 = GameObject.Find("Game Logic/Player Nodes/Player Node (7)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component4 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer4 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component5 = GameObject.Find("Game Logic/Player Nodes/Player Node (10)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer5 = GameObject.Find("Game Logic/Player Nodes/Player Node (11)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component6 = GameObject.Find("Game Logic/Player Nodes/Player Node (12)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer6 = GameObject.Find("Game Logic/Player Nodes/Player Node (13)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component7 = GameObject.Find("Game Logic/Player Nodes/Player Node (14)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer7 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component8 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer8 = GameObject.Find("Game Logic/Player Nodes/Player Node (16)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component9 = GameObject.Find("Game Logic/Player Nodes/Player Node (17)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer9 = GameObject.Find("Game Logic/Player Nodes/Player Node (18)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component10 = GameObject.Find("Game Logic/Player Nodes/Player Node (19)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				component.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component1.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer1.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component2.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer2.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component3.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer3.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component4.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer4.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component5.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer5.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component6.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer6.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component7.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer7.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component8.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer8.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component9.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer9.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component10.get_transform().set_position(new Vector3(0f, 0f, 0f));
			}
			if (string_0 == "SyncCloseVoting")
			{
				MeshRenderer meshRenderer10 = GameObject.Find("Game Logic/Player Nodes/Player Node (0)/Corpse/Chalk outline (1)").GetComponent<MeshRenderer>();
				MeshRenderer component11 = GameObject.Find("Game Logic/Player Nodes/Player Node (1)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer11 = GameObject.Find("Game Logic/Player Nodes/Player Node (2)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component12 = GameObject.Find("Game Logic/Player Nodes/Player Node (3)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer12 = GameObject.Find("Game Logic/Player Nodes/Player Node (4)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component13 = GameObject.Find("Game Logic/Player Nodes/Player Node (5)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer13 = GameObject.Find("Game Logic/Player Nodes/Player Node (6)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component14 = GameObject.Find("Game Logic/Player Nodes/Player Node (7)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer14 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component15 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer15 = GameObject.Find("Game Logic/Player Nodes/Player Node (10)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component16 = GameObject.Find("Game Logic/Player Nodes/Player Node (11)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer16 = GameObject.Find("Game Logic/Player Nodes/Player Node (12)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component17 = GameObject.Find("Game Logic/Player Nodes/Player Node (13)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer17 = GameObject.Find("Game Logic/Player Nodes/Player Node (14)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component18 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer18 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component19 = GameObject.Find("Game Logic/Player Nodes/Player Node (16)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer19 = GameObject.Find("Game Logic/Player Nodes/Player Node (17)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component20 = GameObject.Find("Game Logic/Player Nodes/Player Node (18)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer20 = GameObject.Find("Game Logic/Player Nodes/Player Node (19)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				meshRenderer10.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component11.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer11.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component12.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer12.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component13.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer13.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component14.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer14.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component15.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer15.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component16.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer16.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component17.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer17.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component18.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer18.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component19.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer19.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component20.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer20.get_transform().set_position(new Vector3(0f, 0f, 0f));
			}
			if (vtVnG9Il9DhZRQc3jPy.sDFId2Q12o && string_0 == "SyncEmergencyMeeting")
			{
				MeshRenderer component21 = GameObject.Find("Game Logic/Player Nodes/Player Node (0)/Corpse/Chalk outline (1)").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer21 = GameObject.Find("Game Logic/Player Nodes/Player Node (1)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component22 = GameObject.Find("Game Logic/Player Nodes/Player Node (2)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer22 = GameObject.Find("Game Logic/Player Nodes/Player Node (3)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component23 = GameObject.Find("Game Logic/Player Nodes/Player Node (4)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer23 = GameObject.Find("Game Logic/Player Nodes/Player Node (5)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component24 = GameObject.Find("Game Logic/Player Nodes/Player Node (6)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer24 = GameObject.Find("Game Logic/Player Nodes/Player Node (7)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component25 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer25 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component26 = GameObject.Find("Game Logic/Player Nodes/Player Node (10)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer26 = GameObject.Find("Game Logic/Player Nodes/Player Node (11)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component27 = GameObject.Find("Game Logic/Player Nodes/Player Node (12)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer27 = GameObject.Find("Game Logic/Player Nodes/Player Node (13)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component28 = GameObject.Find("Game Logic/Player Nodes/Player Node (14)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer28 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component29 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer29 = GameObject.Find("Game Logic/Player Nodes/Player Node (16)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component30 = GameObject.Find("Game Logic/Player Nodes/Player Node (17)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer30 = GameObject.Find("Game Logic/Player Nodes/Player Node (18)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component31 = GameObject.Find("Game Logic/Player Nodes/Player Node (19)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				component21.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer21.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component22.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer22.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component23.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer23.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component24.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer24.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component25.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer25.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component26.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer26.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component27.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer27.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component28.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer28.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component29.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer29.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component30.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer30.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component31.get_transform().set_position(new Vector3(0f, 0f, 0f));
			}
			if (vtVnG9Il9DhZRQc3jPy.sDFId2Q12o && string_0 == "SyncBodyFound")
			{
				MeshRenderer meshRenderer31 = GameObject.Find("Game Logic/Player Nodes/Player Node (0)/Corpse/Chalk outline (1)").GetComponent<MeshRenderer>();
				MeshRenderer component32 = GameObject.Find("Game Logic/Player Nodes/Player Node (1)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer32 = GameObject.Find("Game Logic/Player Nodes/Player Node (2)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component33 = GameObject.Find("Game Logic/Player Nodes/Player Node (3)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer33 = GameObject.Find("Game Logic/Player Nodes/Player Node (4)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component34 = GameObject.Find("Game Logic/Player Nodes/Player Node (5)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer34 = GameObject.Find("Game Logic/Player Nodes/Player Node (6)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component35 = GameObject.Find("Game Logic/Player Nodes/Player Node (7)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer35 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component36 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer36 = GameObject.Find("Game Logic/Player Nodes/Player Node (10)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component37 = GameObject.Find("Game Logic/Player Nodes/Player Node (11)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer37 = GameObject.Find("Game Logic/Player Nodes/Player Node (12)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component38 = GameObject.Find("Game Logic/Player Nodes/Player Node (13)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer38 = GameObject.Find("Game Logic/Player Nodes/Player Node (14)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component39 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer39 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component40 = GameObject.Find("Game Logic/Player Nodes/Player Node (16)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer40 = GameObject.Find("Game Logic/Player Nodes/Player Node (17)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component41 = GameObject.Find("Game Logic/Player Nodes/Player Node (18)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer41 = GameObject.Find("Game Logic/Player Nodes/Player Node (19)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				meshRenderer31.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component32.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer32.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component33.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer33.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component34.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer34.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component35.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer35.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component36.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer36.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component37.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer37.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component38.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer38.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component39.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer39.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component40.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer40.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component41.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer41.get_transform().set_position(new Vector3(0f, 0f, 0f));
			}
			if (vtVnG9Il9DhZRQc3jPy.sDFId2Q12o && string_0 == "StartMeeting")
			{
				MeshRenderer component42 = GameObject.Find("Game Logic/Player Nodes/Player Node (0)/Corpse/Chalk outline (1)").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer42 = GameObject.Find("Game Logic/Player Nodes/Player Node (1)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component43 = GameObject.Find("Game Logic/Player Nodes/Player Node (2)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer43 = GameObject.Find("Game Logic/Player Nodes/Player Node (3)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component44 = GameObject.Find("Game Logic/Player Nodes/Player Node (4)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer44 = GameObject.Find("Game Logic/Player Nodes/Player Node (5)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component45 = GameObject.Find("Game Logic/Player Nodes/Player Node (6)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer45 = GameObject.Find("Game Logic/Player Nodes/Player Node (7)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component46 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer46 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component47 = GameObject.Find("Game Logic/Player Nodes/Player Node (10)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer47 = GameObject.Find("Game Logic/Player Nodes/Player Node (11)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component48 = GameObject.Find("Game Logic/Player Nodes/Player Node (12)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer48 = GameObject.Find("Game Logic/Player Nodes/Player Node (13)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component49 = GameObject.Find("Game Logic/Player Nodes/Player Node (14)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer49 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component50 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer50 = GameObject.Find("Game Logic/Player Nodes/Player Node (16)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component51 = GameObject.Find("Game Logic/Player Nodes/Player Node (17)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer51 = GameObject.Find("Game Logic/Player Nodes/Player Node (18)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component52 = GameObject.Find("Game Logic/Player Nodes/Player Node (19)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				component42.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer42.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component43.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer43.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component44.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer44.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component45.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer45.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component46.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer46.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component47.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer47.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component48.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer48.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component49.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer49.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component50.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer50.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component51.get_transform().set_position(new Vector3(0f, 0f, 0f));
				meshRenderer51.get_transform().set_position(new Vector3(0f, 0f, 0f));
				component52.get_transform().set_position(new Vector3(0f, 0f, 0f));
			}
		}
	}
}