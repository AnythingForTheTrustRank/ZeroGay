using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate char v9JdXIX41nvFWSKldSJ(object object_0, int int_0);