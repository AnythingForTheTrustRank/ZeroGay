using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void n5uHV0jcHevgleDIkjC(object , Vector2 );