using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string c6aJQRPoJ3xf379fUUY(ref float float_0);