using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate short EIicqK8lsuHI4NQGPUc(object object_0);