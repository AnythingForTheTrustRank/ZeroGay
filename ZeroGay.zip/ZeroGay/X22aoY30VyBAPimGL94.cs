using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate uint X22aoY30VyBAPimGL94(ref UIntPtr uintptr_0);