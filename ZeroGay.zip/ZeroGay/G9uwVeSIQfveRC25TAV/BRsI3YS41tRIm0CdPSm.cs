using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

namespace G9uwVeSIQfveRC25TAV
{
	internal class BRsI3YS41tRIm0CdPSm
	{
		internal static BRsI3YS41tRIm0CdPSm.ntk9pDYD0emiOwoNFlC[] YjrSUTBZGc;

		internal static int[] anTSTpWciy;

		internal static List<string> MJOSv2PIde;

		private static BinaryReader JgFSa3PrUd;

		private static byte[] UAbSgd9aZJ;

		private static bool EQnSWLUrdS;

		private static object nsvSumIXry;

		private static int EEZSS8O9k4;

		private static BRsI3YS41tRIm0CdPSm dsrdkHkkVRwXgI7vbW9f;

		static BRsI3YS41tRIm0CdPSm()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			BRsI3YS41tRIm0CdPSm.YjrSUTBZGc = null;
			BRsI3YS41tRIm0CdPSm.anTSTpWciy = null;
			BRsI3YS41tRIm0CdPSm.EQnSWLUrdS = false;
			BRsI3YS41tRIm0CdPSm.nsvSumIXry = 1;
		}

		public BRsI3YS41tRIm0CdPSm()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static void A1oSbyodhw(object u0020)
		{
			BRsI3YS41tRIm0CdPSm.JgFSa3PrUd = new BinaryReader(new MemoryStream(u0020));
			BRsI3YS41tRIm0CdPSm.UAbSgd9aZJ = new byte[255];
			int num = BRsI3YS41tRIm0CdPSm.iivShBVtZN(BRsI3YS41tRIm0CdPSm.JgFSa3PrUd);
			for (int i = 0; i < num; i++)
			{
				int num1 = BRsI3YS41tRIm0CdPSm.JgFSa3PrUd.ReadByte();
				BRsI3YS41tRIm0CdPSm.UAbSgd9aZJ[num1] = BRsI3YS41tRIm0CdPSm.JgFSa3PrUd.ReadByte();
			}
			num = BRsI3YS41tRIm0CdPSm.iivShBVtZN(BRsI3YS41tRIm0CdPSm.JgFSa3PrUd);
			BRsI3YS41tRIm0CdPSm.MJOSv2PIde = new List<string>(num);
			for (int j = 0; j < num; j++)
			{
				BRsI3YS41tRIm0CdPSm.MJOSv2PIde.Add(Encoding.Unicode.GetString(BRsI3YS41tRIm0CdPSm.JgFSa3PrUd.ReadBytes(BRsI3YS41tRIm0CdPSm.iivShBVtZN(BRsI3YS41tRIm0CdPSm.JgFSa3PrUd))));
			}
			num = BRsI3YS41tRIm0CdPSm.iivShBVtZN(BRsI3YS41tRIm0CdPSm.JgFSa3PrUd);
			BRsI3YS41tRIm0CdPSm.YjrSUTBZGc = new BRsI3YS41tRIm0CdPSm.ntk9pDYD0emiOwoNFlC[num];
			BRsI3YS41tRIm0CdPSm.anTSTpWciy = new int[num];
			for (int k = 0; k < num; k++)
			{
				BRsI3YS41tRIm0CdPSm.YjrSUTBZGc[k] = null;
				BRsI3YS41tRIm0CdPSm.anTSTpWciy[k] = BRsI3YS41tRIm0CdPSm.iivShBVtZN(BRsI3YS41tRIm0CdPSm.JgFSa3PrUd);
			}
			int position = (int)BRsI3YS41tRIm0CdPSm.JgFSa3PrUd.BaseStream.Position;
			for (int l = 0; l < num; l++)
			{
				int num2 = BRsI3YS41tRIm0CdPSm.anTSTpWciy[l];
				BRsI3YS41tRIm0CdPSm.anTSTpWciy[l] = position;
				position += num2;
			}
		}

		internal static object[] ArQStOELtM<qhgoFLSQWJS6YX5DdO8>(int u0020, object u0020, object u0020, ref qhgoFLSQWJS6YX5DdO8 u0020)
		{
			// 
			// Current member / type: System.Object[] G9uwVeSIQfveRC25TAV.BRsI3YS41tRIm0CdPSm::ArQStOELtM(System.Int32,System.Object,System.Object,qhgoFLSQWJS6YX5DdO8&)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Object[] ArQStOELtM(System.Int32,System.Object,System.Object,qhgoFLSQWJS6YX5DdO8&)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static BRsI3YS41tRIm0CdPSm bVDSVwkkJDFmZALc4gOq()
		{
			return BRsI3YS41tRIm0CdPSm.dsrdkHkkVRwXgI7vbW9f;
		}

		internal static void cNES2aUUEA()
		{
			if (BRsI3YS41tRIm0CdPSm.anTSTpWciy == null)
			{
				BinaryReader binaryReader = new BinaryReader(typeof(BRsI3YS41tRIm0CdPSm).Assembly.GetManifestResourceStream("AV6D6b7PJDlMylGrv0.fstKsF4ohvfQh7ILaY"));
				binaryReader.BaseStream.Position = 0L;
				byte[] numArray = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
				binaryReader.Close();
				BRsI3YS41tRIm0CdPSm.A1oSbyodhw(numArray);
			}
		}

		internal static bool e1KcIjkkLTDQHbgBOx3j()
		{
			return BRsI3YS41tRIm0CdPSm.dsrdkHkkVRwXgI7vbW9f == null;
		}

		internal static int iivShBVtZN(object u0020)
		{
			bool flag = false;
			uint num = 0;
			uint num1 = u0020.ReadByte();
			num = 0 | num1 & 63;
			if ((num1 & 64) != 0)
			{
				flag = true;
			}
			if (num1 < 128)
			{
				if (!flag)
				{
					return (int)num;
				}
				return (int)(~num);
			}
			int num2 = 0;
			while (true)
			{
				uint num3 = u0020.ReadByte();
				num = num | (num3 & 127) << (7 * num2 + 6 & 31);
				if (num3 < 128)
				{
					break;
				}
				num2++;
			}
			if (!flag)
			{
				return (int)num;
			}
			return (int)(~num);
		}

		internal static object[] jm0S6t1r2y()
		{
			return new object[1];
		}

		internal static object[] RU5Sw2rZf6(int u0020, object u0020, object u0020)
		{
			return BRsI3YS41tRIm0CdPSm.ArQStOELtM<int>(u0020, u0020, u0020, ref BRsI3YS41tRIm0CdPSm.EEZSS8O9k4);
		}

		internal static object[] ySdSND6tEF<rncfrDSCVAIqRfQ59Kn>(int u0020, object u0020, ref rncfrDSCVAIqRfQ59Kn u0020)
		{
			return BRsI3YS41tRIm0CdPSm.ArQStOELtM<rncfrDSCVAIqRfQ59Kn>(u0020, u0020, u0020, ref u0020);
		}

		private class culkMDYNslpPoTl5SXw : Exception
		{
			private static BRsI3YS41tRIm0CdPSm.culkMDYNslpPoTl5SXw NRn22Ik82lEsKMn5ErCg;

			public culkMDYNslpPoTl5SXw(string u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base(u0020);
			}

			internal static BRsI3YS41tRIm0CdPSm.culkMDYNslpPoTl5SXw lOp8Cik8hORUtnFKFWO9()
			{
				return BRsI3YS41tRIm0CdPSm.culkMDYNslpPoTl5SXw.NRn22Ik82lEsKMn5ErCg;
			}

			internal static bool VDny9Nk8brgkuX59Oxch()
			{
				return BRsI3YS41tRIm0CdPSm.culkMDYNslpPoTl5SXw.NRn22Ik82lEsKMn5ErCg == null;
			}
		}

		private class dFvs3iPJkXy6416AWVO : BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt
		{
			public string F5BP516MJi;

			internal static BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO BMTO7GkHTirk7SEHDijD;

			public dFvs3iPJkXy6416AWVO(string u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base(6);
				this.F5BP516MJi = u0020;
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.F5BP516MJi != null;
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				return this.F5BP516MJi;
			}

			internal static BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO E5uhZZkHaCTO9js7GjfX()
			{
				return BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO.BMTO7GkHTirk7SEHDijD;
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).evOjuZejQG(this);
				}
				return this.F5BP516MJi == u0020.CvnlU3IXkO(null);
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.hsKlwaTTVG(u0020);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.F5BP516MJi = ((BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO)u0020).F5BP516MJi;
			}

			internal static bool i4g4GrkHvpVHFdwxhKld()
			{
				return BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO.BMTO7GkHTirk7SEHDijD == null;
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).KyQjSu10fI(this);
				}
				return this.F5BP516MJi != u0020.CvnlU3IXkO(null);
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				return this;
			}

			public override string ToString()
			{
				if (this.F5BP516MJi == null)
				{
					return 5.ToString();
				}
				string str = '*'.ToString();
				char chr = '*';
				return string.Concat(str, this.F5BP516MJi, chr.ToString());
			}
		}

		internal enum dZxuXmPjV25we9fnrwv : byte
		{

		}

		internal enum eDCAu2PZaTvgALELhU3 : byte
		{

		}

		private class EHXm1aYIujTVydILT4U : BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D
		{
			public double kqAY66YyLe;

			public BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW DsbYtsUbFd;

			internal static BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U pNS3Fnk87pGSgRZ5Ft9F;

			public EHXm1aYIujTVydILT4U(double u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)5;
				this.DsbYtsUbFd = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)10;
				this.kqAY66YyLe = u0020;
			}

			public EHXm1aYIujTVydILT4U(BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = u0020.AdkPKdYKa9;
				this.DsbYtsUbFd = u0020.DsbYtsUbFd;
				this.kqAY66YyLe = u0020.kqAY66YyLe;
			}

			public EHXm1aYIujTVydILT4U(double u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)5;
				this.kqAY66YyLe = u0020;
				this.DsbYtsUbFd = u0020;
			}

			public EHXm1aYIujTVydILT4U(float u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)5;
				this.kqAY66YyLe = (double)u0020;
				this.DsbYtsUbFd = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)9;
			}

			public EHXm1aYIujTVydILT4U(float u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)5;
				this.kqAY66YyLe = (double)u0020;
				this.DsbYtsUbFd = u0020;
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U AQblmacrWV()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((float)this.kqAY66YyLe, 9);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W aV0lp8koBT()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((sbyte)this.kqAY66YyLe), 1);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b3DlZ1vlBC()
			{
				return this.bSylgOD1Tv();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b5ElWf0CKC()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((short)this.kqAY66YyLe, 3);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B5rlJDOwmv()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((uint)this.kqAY66YyLe), 6);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B7GliJVwUR()
			{
				return this.qqRlYZcuq0();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W bSylgOD1Tv()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((byte)this.kqAY66YyLe, 2);
			}

			public override bool buqjZToHQq(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe < ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt cguj6B2iXY(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe * ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO cGxlEOFbUS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.Gavl0MZqqr().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B7GliJVwUR().FH6SRpjuDo.GO8SlOKscJ);
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.RCglbwABSK();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (u0020 != null && u0020.IsByRef)
				{
					u0020 = u0020.GetElementType();
				}
				if (u0020 == typeof(float))
				{
					return (float)this.kqAY66YyLe;
				}
				if (u0020 == typeof(double))
				{
					return this.kqAY66YyLe;
				}
				if (!(u0020 == null) && !(u0020 == typeof(object)) || (int)this.DsbYtsUbFd != 9)
				{
					return this.kqAY66YyLe;
				}
				return (float)this.kqAY66YyLe;
			}

			public override bool cyBjla9WGE(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe <= ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W d0GlRc2a7L()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((sbyte)this.kqAY66YyLe), 1);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dHsjhXjesK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ dKTlxkpj1Q()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked((long)this.kqAY66YyLe), 7);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dMBjH0kCfL()
			{
				if ((int)this.DsbYtsUbFd == 9)
				{
					return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((float)(-this.kqAY66YyLe));
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)(-this.kqAY66YyLe));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W DP7lfDqxDB()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((int)this.kqAY66YyLe), 5);
			}

			public override bool EaCjXoObXK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe >= ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			internal static BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U EtmhKIk8IjlbpAR1j1IL()
			{
				return BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U.pNS3Fnk87pGSgRZ5Ft9F;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W eu0lTybe0W()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((!this.q57l2vpK1n() ? 0 : 1));
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return false;
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).evOjuZejQG(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.FrXPreN9nq())
				{
					return false;
				}
				return this.kqAY66YyLe == ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)pDI0AUPFaaR24dXe0vt).kqAY66YyLe;
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ FIglXEgdyQ()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)this.kqAY66YyLe, 7);
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.hsKlwaTTVG(u0020);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ Gavl0MZqqr()
			{
				return this.xwllOBxh3t();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt GthjMfGJXk(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe - ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ H3GloK8YWW()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked((ulong)this.kqAY66YyLe), 8);
			}

			internal static bool hCerqfk84ldYrBio0lrp()
			{
				return BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U.pNS3Fnk87pGSgRZ5Ft9F == null;
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U hdRlcPQNJV()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)this.kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W HeNlB8VrPZ()
			{
				return this.qfclaEtV55();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hoJlAy9b0V()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.kqAY66YyLe, 2);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt HqHj7mcRQX(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe - ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.kqAY66YyLe = ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
				this.DsbYtsUbFd = ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).DsbYtsUbFd;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hWSlLTopa3()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.kqAY66YyLe, 4);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W JQ5l5Gionr()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((uint)this.kqAY66YyLe), 6);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ jT9ljPZtDi()
			{
				return this.FIglXEgdyQ();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt K2rjTSWTBP(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ kl5ld64bfA()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked((ulong)this.kqAY66YyLe), 8);
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return false;
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).KyQjSu10fI(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.FrXPreN9nq())
				{
					return false;
				}
				return this.kqAY66YyLe != ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)pDI0AUPFaaR24dXe0vt).kqAY66YyLe;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W lVclVGHGWb()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.kqAY66YyLe, 4);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt LX3jvRuP7O(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
			}

			public override bool M2ijBdfvCo(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe > ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W mfnlFkZV24()
			{
				return this.U0llufhe9B();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MuDj2ESVFd(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MW1lhEmAfG(BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				switch (u0020)
				{
					case 1:
					{
						return this.qfclaEtV55();
					}
					case 2:
					{
						return this.bSylgOD1Tv();
					}
					case 3:
					{
						return this.b5ElWf0CKC();
					}
					case 4:
					{
						return this.U0llufhe9B();
					}
					case 5:
					{
						return this.oHqlSW6b45();
					}
					case 6:
					{
						return this.qqRlYZcuq0();
					}
					case 7:
					{
						return this.FIglXEgdyQ();
					}
					case 8:
					{
						return this.xwllOBxh3t();
					}
					case 9:
					{
						return this.AQblmacrWV();
					}
					case 10:
					{
						return this.wGllDQeBGn();
					}
					case 11:
					{
						return this.eu0lTybe0W();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W nDklnP9uew()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((short)this.kqAY66YyLe), 3);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt Ni9j4tniIe(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq() || !u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe * ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override bool oc0jO1XWAQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe > ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W oHqlSW6b45()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.kqAY66YyLe, 5);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt q0PjsQJ2ps(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe - ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override bool q57l2vpK1n()
			{
				return this.kqAY66YyLe == 0;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qfclaEtV55()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((sbyte)this.kqAY66YyLe, 1);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt QHqj9kqOCA(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe + ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qqRlYZcuq0()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((uint)this.kqAY66YyLe, 6);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt qXRjGWmv0L(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe + ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				return this;
			}

			public override bool RCglbwABSK()
			{
				return !this.q57l2vpK1n();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt RkFjUgwliF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO rrtlzquJpy()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.dKTlxkpj1Q().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.voYle2maYc().FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rT4jQ5XUP4(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe / ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rtwjNgsk8H(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe % ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s6tjIept8c(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe * ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s7Oj3eIaoc(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe + ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override bool Se8jY4rJ7g(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe >= ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W SOglrKDlkM()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((short)this.kqAY66YyLe), 3);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt T5Ojba52SB()
			{
				throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
			}

			public override bool THajPMZMuT(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe <= ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			public override bool ThjjjOubV1(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.kqAY66YyLe < ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe;
			}

			public override string ToString()
			{
				return this.kqAY66YyLe.ToString();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W U0llufhe9B()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((ushort)this.kqAY66YyLe, 4);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u6QjCWlWMF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u7ijtkwXum(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe / ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt VkljwO21ED(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.FrXPreN9nq())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this.kqAY66YyLe % ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).kqAY66YyLe);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W voYle2maYc()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((int)this.kqAY66YyLe), 5);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W W15lPh5RC4()
			{
				return this.b5ElWf0CKC();
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U wGllDQeBGn()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)this.kqAY66YyLe, 10);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO wNijkq3Yt8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.YQPl1OGXpG().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.DP7lfDqxDB().FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W x2GlKaLfLY()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.kqAY66YyLe, 2);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ xwllOBxh3t()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((ulong)this.kqAY66YyLe, 8);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO YNwj8YIExi()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.H3GloK8YWW().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.JQ5l5Gionr().FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D yqnlCrBSQ1()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U(this);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ YQPl1OGXpG()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked((long)this.kqAY66YyLe), 7);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W ysWllqqkwZ()
			{
				return this.oHqlSW6b45();
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO z3gjqNHGw8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.kl5ld64bfA().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B5rlJDOwmv().FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO zgLlyFEWVS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.jT9ljPZtDi().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.ysWllqqkwZ().FH6SRpjuDo.NFySjw3NeU);
			}
		}

		private class FOcQHDSLPRuSi0ejtOZ : BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D
		{
			public BRsI3YS41tRIm0CdPSm.KKUpVCSrhIaC4pDivuy pkkSoR3xjG;

			public BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW a89Sm8nygD;

			internal static BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ rCtjdPk8q58A0PAbqshI;

			public FOcQHDSLPRuSi0ejtOZ(long u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)2;
				this.pkkSoR3xjG.R6BSVkv4SB = u0020;
				this.a89Sm8nygD = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)7;
			}

			public FOcQHDSLPRuSi0ejtOZ(BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = u0020.AdkPKdYKa9;
				this.pkkSoR3xjG.R6BSVkv4SB = u0020.pkkSoR3xjG.R6BSVkv4SB;
				this.a89Sm8nygD = u0020.a89Sm8nygD;
			}

			public FOcQHDSLPRuSi0ejtOZ(long u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)2;
				this.pkkSoR3xjG.R6BSVkv4SB = u0020;
				this.a89Sm8nygD = u0020;
			}

			public FOcQHDSLPRuSi0ejtOZ(ulong u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)2;
				this.pkkSoR3xjG.ogcSA8800w = u0020;
				this.a89Sm8nygD = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)8;
			}

			public FOcQHDSLPRuSi0ejtOZ(ulong u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)2;
				this.pkkSoR3xjG.ogcSA8800w = u0020;
				this.a89Sm8nygD = u0020;
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U AQblmacrWV()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((float)this.pkkSoR3xjG.R6BSVkv4SB);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W aV0lp8koBT()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((sbyte)this.pkkSoR3xjG.ogcSA8800w)), 1);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b3DlZ1vlBC()
			{
				return this.bSylgOD1Tv();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b5ElWf0CKC()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.pkkSoR3xjG.O3dSxySaQL, 3);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B5rlJDOwmv()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((uint)this.pkkSoR3xjG.R6BSVkv4SB), 6);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B7GliJVwUR()
			{
				return this.qqRlYZcuq0();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W bSylgOD1Tv()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.pkkSoR3xjG.a2WSnbxtGc, 2);
			}

			public override bool buqjZToHQq(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.ogcSA8800w < ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w;
			}

			public BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W C9vS565XMB()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.pkkSoR3xjG.TwjSeffPsN, 15);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt cguj6B2iXY(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked(this.pkkSoR3xjG.ogcSA8800w * ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w));
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO cGxlEOFbUS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.Gavl0MZqqr().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B7GliJVwUR().FH6SRpjuDo.GO8SlOKscJ);
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.RCglbwABSK();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (u0020 != null && u0020.IsByRef)
				{
					u0020 = u0020.GetElementType();
				}
				if (u0020 == null || u0020 == typeof(object))
				{
					switch (this.a89Sm8nygD)
					{
						case 1:
						{
							return this.pkkSoR3xjG.TwjSeffPsN;
						}
						case 2:
						{
							return this.pkkSoR3xjG.a2WSnbxtGc;
						}
						case 3:
						{
							return this.pkkSoR3xjG.O3dSxySaQL;
						}
						case 4:
						{
							return this.pkkSoR3xjG.bdoSfZLxDX;
						}
						case 5:
						{
							return this.pkkSoR3xjG.BHQSKTolAy;
						}
						case 6:
						{
							return this.pkkSoR3xjG.fGeS199yWi;
						}
						case 7:
						{
							return this.pkkSoR3xjG.R6BSVkv4SB;
						}
						case 8:
						{
							return this.pkkSoR3xjG.ogcSA8800w;
						}
						case 9:
						case 10:
						case 12:
						case 13:
						case 14:
						{
							return this.pkkSoR3xjG.R6BSVkv4SB;
						}
						case 11:
						{
							return this.RCglbwABSK();
						}
						case 15:
						{
							return (char)this.pkkSoR3xjG.BHQSKTolAy;
						}
						default:
						{
							return this.pkkSoR3xjG.R6BSVkv4SB;
						}
					}
				}
				if (u0020 == typeof(int))
				{
					return this.pkkSoR3xjG.BHQSKTolAy;
				}
				if (u0020 == typeof(uint))
				{
					return this.pkkSoR3xjG.fGeS199yWi;
				}
				if (u0020 == typeof(short))
				{
					return this.pkkSoR3xjG.O3dSxySaQL;
				}
				if (u0020 == typeof(ushort))
				{
					return this.pkkSoR3xjG.bdoSfZLxDX;
				}
				if (u0020 == typeof(byte))
				{
					return this.pkkSoR3xjG.a2WSnbxtGc;
				}
				if (u0020 == typeof(sbyte))
				{
					return this.pkkSoR3xjG.TwjSeffPsN;
				}
				if (u0020 == typeof(bool))
				{
					return !this.q57l2vpK1n();
				}
				if (u0020 == typeof(long))
				{
					return this.pkkSoR3xjG.R6BSVkv4SB;
				}
				if (u0020 == typeof(ulong))
				{
					return this.pkkSoR3xjG.ogcSA8800w;
				}
				if (u0020 == typeof(char))
				{
					return (char)this.pkkSoR3xjG.R6BSVkv4SB;
				}
				if (!u0020.IsEnum)
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.tk2SJvF6PI(u0020);
			}

			public override bool cyBjla9WGE(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.ogcSA8800w <= ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W d0GlRc2a7L()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((sbyte)this.pkkSoR3xjG.R6BSVkv4SB), 1);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dHsjhXjesK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB ^ ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ dKTlxkpj1Q()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB, 7);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dMBjH0kCfL()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(-this.pkkSoR3xjG.R6BSVkv4SB);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W DP7lfDqxDB()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((int)this.pkkSoR3xjG.ogcSA8800w)), 5);
			}

			public override bool EaCjXoObXK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.ogcSA8800w >= ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W eu0lTybe0W()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((!this.q57l2vpK1n() ? 1 : 0));
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return ((BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8)u0020).evOjuZejQG(this);
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).evOjuZejQG(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.CsRPppYOTY())
				{
					return false;
				}
				return this.pkkSoR3xjG.R6BSVkv4SB == ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)pDI0AUPFaaR24dXe0vt).pkkSoR3xjG.R6BSVkv4SB;
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ FIglXEgdyQ()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB, 7);
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.hsKlwaTTVG(u0020);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ Gavl0MZqqr()
			{
				return this.xwllOBxh3t();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt GthjMfGJXk(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked(this.pkkSoR3xjG.R6BSVkv4SB - ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB));
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ H3GloK8YWW()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.ogcSA8800w, 8);
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U hdRlcPQNJV()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)((float)this.pkkSoR3xjG.ogcSA8800w));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W HeNlB8VrPZ()
			{
				return this.qfclaEtV55();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hoJlAy9b0V()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((byte)this.pkkSoR3xjG.ogcSA8800w)), 2);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt HqHj7mcRQX(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked(this.pkkSoR3xjG.ogcSA8800w - ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w));
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.pkkSoR3xjG = ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG;
				this.a89Sm8nygD = ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).a89Sm8nygD;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hWSlLTopa3()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((ushort)this.pkkSoR3xjG.ogcSA8800w)), 4);
			}

			internal static BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ iGL0SKk8886rASVubqgN()
			{
				return BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ.rCtjdPk8q58A0PAbqshI;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W JQ5l5Gionr()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((uint)this.pkkSoR3xjG.ogcSA8800w)), 6);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ jT9ljPZtDi()
			{
				return this.FIglXEgdyQ();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt K2rjTSWTBP(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.CsRPppYOTY())
				{
					return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB >> (((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.BHQSKTolAy & 63));
				}
				if (!u0020.SgSjiMaCIn())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB >> (((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & 63));
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ kl5ld64bfA()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked((ulong)this.pkkSoR3xjG.R6BSVkv4SB), 8);
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return false;
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).KyQjSu10fI(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.CsRPppYOTY())
				{
					return false;
				}
				return this.pkkSoR3xjG.ogcSA8800w != ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)pDI0AUPFaaR24dXe0vt).pkkSoR3xjG.ogcSA8800w;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W lVclVGHGWb()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.pkkSoR3xjG.R6BSVkv4SB, 4);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt LX3jvRuP7O(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.CsRPppYOTY())
				{
					return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.ogcSA8800w >> (((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.BHQSKTolAy & 63));
				}
				if (!u0020.SgSjiMaCIn())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.ogcSA8800w >> (((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & 63));
			}

			public override bool M2ijBdfvCo(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.ogcSA8800w > ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W mfnlFkZV24()
			{
				return this.U0llufhe9B();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MuDj2ESVFd(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB | ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MW1lhEmAfG(BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				switch (u0020)
				{
					case 1:
					{
						return this.qfclaEtV55();
					}
					case 2:
					{
						return this.bSylgOD1Tv();
					}
					case 3:
					{
						return this.b5ElWf0CKC();
					}
					case 4:
					{
						return this.U0llufhe9B();
					}
					case 5:
					{
						return this.oHqlSW6b45();
					}
					case 6:
					{
						return this.qqRlYZcuq0();
					}
					case 7:
					{
						return this.FIglXEgdyQ();
					}
					case 8:
					{
						return this.xwllOBxh3t();
					}
					case 9:
					case 10:
					case 12:
					case 13:
					case 14:
					{
						throw new Exception(4.ToString());
					}
					case 11:
					{
						return this.eu0lTybe0W();
					}
					case 15:
					{
						return this.C9vS565XMB();
					}
					case 16:
					{
						return this.yqnlCrBSQ1();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W nDklnP9uew()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((short)this.pkkSoR3xjG.ogcSA8800w)), 3);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt Ni9j4tniIe(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB * ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			public override bool oc0jO1XWAQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.R6BSVkv4SB > ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB;
			}

			internal override bool OHBjWnvYRZ()
			{
				return true;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W oHqlSW6b45()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.pkkSoR3xjG.BHQSKTolAy, 5);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt q0PjsQJ2ps(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB - ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			public override bool q57l2vpK1n()
			{
				if ((int)this.a89Sm8nygD == 7)
				{
					return this.pkkSoR3xjG.R6BSVkv4SB == 0L;
				}
				return this.pkkSoR3xjG.ogcSA8800w == 0L;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qfclaEtV55()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.pkkSoR3xjG.TwjSeffPsN, 1);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt QHqj9kqOCA(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked(this.pkkSoR3xjG.ogcSA8800w + ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qqRlYZcuq0()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.pkkSoR3xjG.fGeS199yWi, 6);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt qXRjGWmv0L(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB + ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				return this;
			}

			public override bool RCglbwABSK()
			{
				return !this.q57l2vpK1n();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt RkFjUgwliF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.CsRPppYOTY())
				{
					return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB << (((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.BHQSKTolAy & 63));
				}
				if (!u0020.SgSjiMaCIn())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB << (((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & 63));
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO rrtlzquJpy()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.dKTlxkpj1Q().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.voYle2maYc().FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rT4jQ5XUP4(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.ogcSA8800w / ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rtwjNgsk8H(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.ogcSA8800w % ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.ogcSA8800w);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s6tjIept8c(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked(this.pkkSoR3xjG.R6BSVkv4SB * ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s7Oj3eIaoc(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked(this.pkkSoR3xjG.R6BSVkv4SB + ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB));
			}

			public override bool Se8jY4rJ7g(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.R6BSVkv4SB >= ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W SOglrKDlkM()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((short)this.pkkSoR3xjG.R6BSVkv4SB), 3);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt T5Ojba52SB()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(~this.pkkSoR3xjG.R6BSVkv4SB);
			}

			public override bool THajPMZMuT(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.R6BSVkv4SB <= ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB;
			}

			public override bool ThjjjOubV1(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.pkkSoR3xjG.R6BSVkv4SB < ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB;
			}

			internal object tk2SJvF6PI(Type u0020)
			{
				Type underlyingType = Enum.GetUnderlyingType(u0020);
				if (underlyingType == typeof(int))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.BHQSKTolAy);
				}
				if (underlyingType == typeof(uint))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.fGeS199yWi);
				}
				if (underlyingType == typeof(short))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.O3dSxySaQL);
				}
				if (underlyingType == typeof(ushort))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.bdoSfZLxDX);
				}
				if (underlyingType == typeof(byte))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.a2WSnbxtGc);
				}
				if (underlyingType == typeof(sbyte))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.TwjSeffPsN);
				}
				if (underlyingType == typeof(long))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.R6BSVkv4SB);
				}
				if (underlyingType == typeof(ulong))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.ogcSA8800w);
				}
				if (underlyingType != typeof(char))
				{
					return Enum.ToObject(u0020, this.pkkSoR3xjG.R6BSVkv4SB);
				}
				return Enum.ToObject(u0020, (ushort)this.pkkSoR3xjG.BHQSKTolAy);
			}

			public override string ToString()
			{
				if ((int)this.a89Sm8nygD == 7)
				{
					return this.pkkSoR3xjG.R6BSVkv4SB.ToString();
				}
				return this.pkkSoR3xjG.ogcSA8800w.ToString();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W U0llufhe9B()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.pkkSoR3xjG.bdoSfZLxDX, 4);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u6QjCWlWMF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB & ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u7ijtkwXum(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB / ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			private static BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D v5USdwxoIh(object u0020)
			{
				BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D = u0020 as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				if (mXLA9LY4pdeld88e55D == null && u0020.oJVj0o8M8s())
				{
					mXLA9LY4pdeld88e55D = u0020.R5MjgxNnyG() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				}
				return mXLA9LY4pdeld88e55D;
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt VkljwO21ED(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.CsRPppYOTY())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.R6BSVkv4SB % ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).pkkSoR3xjG.R6BSVkv4SB);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W voYle2maYc()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((int)this.pkkSoR3xjG.R6BSVkv4SB), 5);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W W15lPh5RC4()
			{
				return this.b5ElWf0CKC();
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U wGllDQeBGn()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)this.pkkSoR3xjG.R6BSVkv4SB);
			}

			internal static bool WkdYYqk8kNeTT5iAjDwV()
			{
				return BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ.rCtjdPk8q58A0PAbqshI == null;
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO wNijkq3Yt8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.YQPl1OGXpG().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.DP7lfDqxDB().FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W x2GlKaLfLY()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.pkkSoR3xjG.R6BSVkv4SB, 2);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ xwllOBxh3t()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this.pkkSoR3xjG.ogcSA8800w, 8);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO YNwj8YIExi()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)((void*)(checked((uint)this.pkkSoR3xjG.ogcSA8800w))));
			}

			public override BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D yqnlCrBSQ1()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(this);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ YQPl1OGXpG()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((void*)(checked((long)this.pkkSoR3xjG.ogcSA8800w)), 7);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W ysWllqqkwZ()
			{
				return this.oHqlSW6b45();
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO z3gjqNHGw8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.kl5ld64bfA().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B5rlJDOwmv().FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO zgLlyFEWVS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.jT9ljPZtDi().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.ysWllqqkwZ().FH6SRpjuDo.NFySjw3NeU);
			}
		}

		private class fqT0ysXGZ6B4R0ihqVe
		{
			private List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB> PdQXsrHi7y;

			private MethodBase GbDXMEahpM;

			private static BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe gg5DutkHkuVTYTD6EMX2;

			public fqT0ysXGZ6B4R0ihqVe(MethodBase u0020, List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB> u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				this.PdQXsrHi7y = new List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB>();
				base();
				this.PdQXsrHi7y = u0020;
				this.GbDXMEahpM = u0020;
			}

			public fqT0ysXGZ6B4R0ihqVe(MethodBase u0020, BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB[] u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				this.PdQXsrHi7y = new List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB>();
				base();
				this.PdQXsrHi7y.AddRange(u0020);
			}

			internal static BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe bIY3vWkHHSjEfN4wygSb()
			{
				return BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe.gg5DutkHkuVTYTD6EMX2;
			}

			public override bool Equals(object u0020)
			{
				BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe _fqT0ysXGZ6B4R0ihqVe = u0020 as BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe;
				if (u0020 == null)
				{
					return false;
				}
				if (this.GbDXMEahpM != _fqT0ysXGZ6B4R0ihqVe.GbDXMEahpM)
				{
					return false;
				}
				if (this.PdQXsrHi7y.Count != _fqT0ysXGZ6B4R0ihqVe.PdQXsrHi7y.Count)
				{
					return false;
				}
				for (int i = 0; i < this.PdQXsrHi7y.Count; i++)
				{
					if (this.PdQXsrHi7y[i].JbMX89L6Ci != _fqT0ysXGZ6B4R0ihqVe.PdQXsrHi7y[i].JbMX89L6Ci)
					{
						return false;
					}
					if (this.PdQXsrHi7y[i].n23XHVmHwr != _fqT0ysXGZ6B4R0ihqVe.PdQXsrHi7y[i].n23XHVmHwr)
					{
						return false;
					}
				}
				return true;
			}

			public override int GetHashCode()
			{
				int hashCode = this.GbDXMEahpM.GetHashCode();
				foreach (BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB pdQXsrHi7y in this.PdQXsrHi7y)
				{
					int num = pdQXsrHi7y.JbMX89L6Ci.GetHashCode() + pdQXsrHi7y.n23XHVmHwr;
					hashCode = (hashCode ^ num) + num;
				}
				return hashCode;
			}

			public bool smlX9Nw7nt(int u0020)
			{
				bool flag;
				List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB>.Enumerator enumerator = this.PdQXsrHi7y.GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.n23XHVmHwr != u0020)
						{
							continue;
						}
						flag = true;
						return flag;
					}
					return false;
				}
				finally
				{
					((IDisposable)enumerator).Dispose();
				}
				return flag;
			}

			internal static bool WlIaTDkH82ri1cEPsDqL()
			{
				return BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe.gg5DutkHkuVTYTD6EMX2 == null;
			}

			public BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB xC4X3CIPxx(int u0020)
			{
				BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB oOfeb5XkKsXpJwgStnB;
				List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB>.Enumerator enumerator = this.PdQXsrHi7y.GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB current = enumerator.Current;
						if (current.n23XHVmHwr != u0020)
						{
							continue;
						}
						oOfeb5XkKsXpJwgStnB = current;
						return oOfeb5XkKsXpJwgStnB;
					}
					return null;
				}
				finally
				{
					((IDisposable)enumerator).Dispose();
				}
				return oOfeb5XkKsXpJwgStnB;
			}
		}

		internal class glyqPoYg91qSdBh3NXc : BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ
		{
			private Array xGuYWc6xaS;

			internal int zY5YubBlZQ;

			private static BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc XV8CLrk8PlQDXVK9SyNm;

			public glyqPoYg91qSdBh3NXc(int u0020, Array u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.xGuYWc6xaS = u0020;
				this.zY5YubBlZQ = u0020;
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)7;
			}

			internal static BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc aY3l4ak8jDTdig0pCI1o()
			{
				return BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc.XV8CLrk8PlQDXVK9SyNm;
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.R5MjgxNnyG().CJ4lvqi9kG();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				return this.R5MjgxNnyG().CvnlU3IXkO(u0020);
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return false;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc))
				{
					return false;
				}
				BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc _glyqPoYg91qSdBh3NXc = (BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc)u0020;
				if (_glyqPoYg91qSdBh3NXc.zY5YubBlZQ != this.zY5YubBlZQ)
				{
					return false;
				}
				if (_glyqPoYg91qSdBh3NXc.xGuYWc6xaS != this.xGuYWc6xaS)
				{
					return false;
				}
				return true;
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.qVnjpWd3hb(u0020);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc))
				{
					this.qVnjpWd3hb(u0020);
					return;
				}
				this.xGuYWc6xaS = ((BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc)u0020).xGuYWc6xaS;
				this.zY5YubBlZQ = ((BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc)u0020).zY5YubBlZQ;
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return true;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc))
				{
					return true;
				}
				BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc _glyqPoYg91qSdBh3NXc = (BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc)u0020;
				if (_glyqPoYg91qSdBh3NXc.zY5YubBlZQ != this.zY5YubBlZQ)
				{
					return true;
				}
				if (_glyqPoYg91qSdBh3NXc.xGuYWc6xaS != this.xGuYWc6xaS)
				{
					return true;
				}
				return false;
			}

			internal override bool OHBjWnvYRZ()
			{
				return this.R5MjgxNnyG().OHBjWnvYRZ();
			}

			internal static bool Px4Nbtk8ls3sjt3mdd8A()
			{
				return BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc.XV8CLrk8PlQDXVK9SyNm == null;
			}

			internal override void qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.xGuYWc6xaS.SetValue(u0020.CvnlU3IXkO(null), this.zY5YubBlZQ);
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				return BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(this.xGuYWc6xaS.GetType().GetElementType(), this.xGuYWc6xaS.GetValue(this.zY5YubBlZQ));
			}

			internal override IntPtr v4WjRI4rni()
			{
				throw new NotImplementedException();
			}
		}

		private class HJSlkMSD555eRxIKbsO : BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D
		{
			public BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D GjxYMGdHPP;

			public BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW QUEY7wJ94J;

			internal static BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO wrM7OKk8HVrah2sEgEdR;

			public HJSlkMSD555eRxIKbsO(IntPtr u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)3;
				if (IntPtr.Size == 8)
				{
					this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(u0020.ToInt64());
					this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
					return;
				}
				this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(u0020.ToInt32());
				this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
			}

			public HJSlkMSD555eRxIKbsO(UIntPtr u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)3;
				if (IntPtr.Size == 8)
				{
					this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(u0020.ToUInt64());
					this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
					return;
				}
				this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(u0020.ToUInt32());
				this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
			}

			public HJSlkMSD555eRxIKbsO()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)3;
				if (IntPtr.Size == 8)
				{
					this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(0L);
					this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
					return;
				}
				this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0);
				this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
			}

			public HJSlkMSD555eRxIKbsO(long u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)3;
				if (IntPtr.Size == 8)
				{
					this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(u0020);
					this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
					return;
				}
				this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020);
				this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)12;
			}

			public HJSlkMSD555eRxIKbsO(long u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)3;
				if (IntPtr.Size == 8)
				{
					this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(u0020);
					this.QUEY7wJ94J = u0020;
					return;
				}
				this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020);
				this.QUEY7wJ94J = u0020;
			}

			public HJSlkMSD555eRxIKbsO(ulong u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)4;
				if (IntPtr.Size == 8)
				{
					this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(u0020);
					this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)13;
					return;
				}
				this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((uint)u0020);
				this.QUEY7wJ94J = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)13;
			}

			public HJSlkMSD555eRxIKbsO(ulong u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)4;
				if (IntPtr.Size == 8)
				{
					this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(u0020);
					this.QUEY7wJ94J = u0020;
					return;
				}
				this.GjxYMGdHPP = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((uint)u0020);
				this.QUEY7wJ94J = u0020;
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U AQblmacrWV()
			{
				return this.GjxYMGdHPP.AQblmacrWV();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W aV0lp8koBT()
			{
				return this.GjxYMGdHPP.aV0lp8koBT();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b3DlZ1vlBC()
			{
				return this.bSylgOD1Tv();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b5ElWf0CKC()
			{
				return this.GjxYMGdHPP.b5ElWf0CKC();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B5rlJDOwmv()
			{
				return this.GjxYMGdHPP.B5rlJDOwmv();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B7GliJVwUR()
			{
				return this.qqRlYZcuq0();
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt BsMYHeOov9(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB % this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU % this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB % this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU % this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W bSylgOD1Tv()
			{
				return this.GjxYMGdHPP.bSylgOD1Tv();
			}

			public override bool buqjZToHQq(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ < ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w < ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w < ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ < ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ;
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt cguj6B2iXY(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w * (ulong)((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(checked(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ))));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w * ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(checked(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ * ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ)));
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO cGxlEOFbUS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.Gavl0MZqqr().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B7GliJVwUR().FH6SRpjuDo.GO8SlOKscJ);
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.RCglbwABSK();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (u0020 != null && u0020.IsByRef)
				{
					u0020 = u0020.GetElementType();
				}
				if (u0020 == typeof(IntPtr))
				{
					if (IntPtr.Size == 8)
					{
						return new IntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.R6BSVkv4SB);
					}
					return new IntPtr(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)this.GjxYMGdHPP).FH6SRpjuDo.NFySjw3NeU);
				}
				if (u0020 == typeof(UIntPtr))
				{
					if (IntPtr.Size == 8)
					{
						return new UIntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.ogcSA8800w);
					}
					return new UIntPtr(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)this.GjxYMGdHPP).FH6SRpjuDo.GO8SlOKscJ);
				}
				if (!(u0020 == null) && !(u0020 == typeof(object)))
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					if ((int)this.QUEY7wJ94J == 12)
					{
						return new IntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.R6BSVkv4SB);
					}
					return new UIntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.ogcSA8800w);
				}
				if ((int)this.QUEY7wJ94J == 12)
				{
					return new IntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.BHQSKTolAy);
				}
				return new UIntPtr(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)this.GjxYMGdHPP).FH6SRpjuDo.GO8SlOKscJ);
			}

			public override bool cyBjla9WGE(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ <= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w <= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w <= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ <= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W d0GlRc2a7L()
			{
				return this.GjxYMGdHPP.d0GlRc2a7L();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dHsjhXjesK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB ^ ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU ^ ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB ^ ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU ^ ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			internal IntPtr dkNSy1bnDX()
			{
				if (IntPtr.Size == 8)
				{
					return new IntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.R6BSVkv4SB);
				}
				return new IntPtr(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)this.GjxYMGdHPP).FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ dKTlxkpj1Q()
			{
				return this.GjxYMGdHPP.dKTlxkpj1Q();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dMBjH0kCfL()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(-((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(-((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)this.GjxYMGdHPP).FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W DP7lfDqxDB()
			{
				return this.GjxYMGdHPP.DP7lfDqxDB();
			}

			public override bool EaCjXoObXK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ >= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w >= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w >= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ >= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W eu0lTybe0W()
			{
				return this.GjxYMGdHPP.eu0lTybe0W();
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return false;
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).evOjuZejQG(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.OHBjWnvYRZ())
				{
					return false;
				}
				if (!pDI0AUPFaaR24dXe0vt.TOiP0fUvZ0())
				{
					if (!pDI0AUPFaaR24dXe0vt.tpmPR9FfWH())
					{
						return false;
					}
					int size = IntPtr.Size;
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB == ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				if (IntPtr.Size != 8)
				{
					return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU == ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
				}
				return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB == ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ FIglXEgdyQ()
			{
				return this.GjxYMGdHPP.FIglXEgdyQ();
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.hsKlwaTTVG(u0020);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ Gavl0MZqqr()
			{
				return this.xwllOBxh3t();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt GthjMfGJXk(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU - ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU)));
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ H3GloK8YWW()
			{
				return this.GjxYMGdHPP.H3GloK8YWW();
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U hdRlcPQNJV()
			{
				return this.GjxYMGdHPP.hdRlcPQNJV();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W HeNlB8VrPZ()
			{
				return this.qfclaEtV55();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hoJlAy9b0V()
			{
				return this.GjxYMGdHPP.hoJlAy9b0V();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt HqHj7mcRQX(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w - (ulong)((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(checked(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ))));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w - ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(checked(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ - ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ)));
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				IntPtr intPtr;
				if (u0020.tpmPR9FfWH())
				{
					if (IntPtr.Size == 8)
					{
						IntPtr num = new IntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.R6BSVkv4SB);
						IntPtr intPtr1 = new IntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).GjxYMGdHPP).pkkSoR3xjG.R6BSVkv4SB);
						*(void*)num = intPtr1.ToInt64();
						return;
					}
					IntPtr num1 = new IntPtr(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)this.GjxYMGdHPP).FH6SRpjuDo.NFySjw3NeU);
					IntPtr intPtr2 = new IntPtr(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).GjxYMGdHPP).FH6SRpjuDo.NFySjw3NeU);
					*(void*)num1 = intPtr2.ToInt32();
					return;
				}
				object obj = u0020.CvnlU3IXkO(null);
				if (obj == null)
				{
					return;
				}
				intPtr = (IntPtr.Size != 8 ? new IntPtr(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)this.GjxYMGdHPP).FH6SRpjuDo.NFySjw3NeU) : new IntPtr(((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)this.GjxYMGdHPP).pkkSoR3xjG.R6BSVkv4SB));
				Type type = obj.GetType();
				if (type == typeof(string))
				{
					return;
				}
				if (type == typeof(byte))
				{
					*(void*)intPtr = (byte)obj;
					return;
				}
				if (type == typeof(sbyte))
				{
					*(void*)intPtr = (sbyte)obj;
					return;
				}
				if (type == typeof(short))
				{
					*(void*)intPtr = (short)obj;
					return;
				}
				if (type == typeof(ushort))
				{
					*(void*)intPtr = (ushort)obj;
					return;
				}
				if (type == typeof(int))
				{
					*(void*)intPtr = (int)obj;
					return;
				}
				if (type == typeof(uint))
				{
					*(void*)intPtr = (uint)obj;
					return;
				}
				if (type == typeof(long))
				{
					*(void*)intPtr = (long)obj;
					return;
				}
				if (type == typeof(ulong))
				{
					*(void*)intPtr = (ulong)obj;
					return;
				}
				if (type == typeof(float))
				{
					*(void*)intPtr = (float)obj;
					return;
				}
				if (type == typeof(double))
				{
					*(void*)intPtr = (double)obj;
					return;
				}
				if (type == typeof(bool))
				{
					*(void*)intPtr = (bool)obj;
					return;
				}
				if (type == typeof(IntPtr))
				{
					*(void*)intPtr = (IntPtr)obj;
					return;
				}
				if (type == typeof(UIntPtr))
				{
					*(void*)intPtr = (UIntPtr)obj;
					return;
				}
				if (type != typeof(char))
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				*(void*)intPtr = (char)obj;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hWSlLTopa3()
			{
				return this.GjxYMGdHPP.hWSlLTopa3();
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt Jf6Y9BtLRf(BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W u0020)
			{
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(u0020.FH6SRpjuDo.NFySjw3NeU >> (this.FIglXEgdyQ().pkkSoR3xjG.BHQSKTolAy & 31)));
			}

			internal static bool JN8akik8GJ3awypDA1BU()
			{
				return BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO.wrM7OKk8HVrah2sEgEdR == null;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W JQ5l5Gionr()
			{
				return this.GjxYMGdHPP.JQ5l5Gionr();
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ jT9ljPZtDi()
			{
				return this.FIglXEgdyQ();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt K2rjTSWTBP(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB >> (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 63));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU >> (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 31)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB >> (((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.BHQSKTolAy & 63));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU >> (((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & 31)));
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt KdmYqvqqX0(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked((ulong)((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ - this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(checked(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ - this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ))));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w - this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(checked(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ - this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ)));
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ kl5ld64bfA()
			{
				return this.GjxYMGdHPP.kl5ld64bfA();
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return false;
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).KyQjSu10fI(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.OHBjWnvYRZ())
				{
					return false;
				}
				if (!pDI0AUPFaaR24dXe0vt.TOiP0fUvZ0())
				{
					if (!pDI0AUPFaaR24dXe0vt.tpmPR9FfWH())
					{
						return false;
					}
					int size = IntPtr.Size;
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w != ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				if (IntPtr.Size != 8)
				{
					return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ != ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
				}
				return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w != ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt l2LYseS7Bj(BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W u0020)
			{
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(u0020.FH6SRpjuDo.NFySjw3NeU << (this.FIglXEgdyQ().pkkSoR3xjG.BHQSKTolAy & 31)));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W lVclVGHGWb()
			{
				return this.GjxYMGdHPP.lVclVGHGWb();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt LX3jvRuP7O(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w >> (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 63));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ >> (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 31))));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w >> (((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.BHQSKTolAy & 63));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ >> (((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & 31))));
			}

			public override bool M2ijBdfvCo(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ > ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w > ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w > ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ > ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W mfnlFkZV24()
			{
				return this.U0llufhe9B();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MuDj2ESVFd(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB | ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU | ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB | ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU | ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MW1lhEmAfG(BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				switch (u0020)
				{
					case 1:
					{
						return this.qfclaEtV55();
					}
					case 2:
					{
						return this.bSylgOD1Tv();
					}
					case 3:
					{
						return this.b5ElWf0CKC();
					}
					case 4:
					{
						return this.U0llufhe9B();
					}
					case 5:
					{
						return this.oHqlSW6b45();
					}
					case 6:
					{
						return this.qqRlYZcuq0();
					}
					case 7:
					{
						return this.FIglXEgdyQ();
					}
					case 8:
					{
						return this.xwllOBxh3t();
					}
					case 9:
					case 10:
					case 14:
					case 15:
					{
						throw new Exception(4.ToString());
					}
					case 11:
					{
						return this.eu0lTybe0W();
					}
					case 12:
					{
						return this;
					}
					case 13:
					{
						return this;
					}
					case 16:
					{
						return this.yqnlCrBSQ1();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W nDklnP9uew()
			{
				return this.GjxYMGdHPP.nDklnP9uew();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt Ni9j4tniIe(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB * ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU * ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override bool oc0jO1XWAQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU > ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB > ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB > ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU > ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU;
			}

			internal override bool OHBjWnvYRZ()
			{
				return true;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W oHqlSW6b45()
			{
				return this.GjxYMGdHPP.oHqlSW6b45();
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt oSEYGwZFJM(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w % this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ % this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w % this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ % this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ));
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt oZ7Y8Hs50K(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w / this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ / this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w / this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ / this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ));
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt PHaSzlNP0q(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU - this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU - this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU)));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt q0PjsQJ2ps(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU - ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override bool q57l2vpK1n()
			{
				return this.GjxYMGdHPP.q57l2vpK1n();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qfclaEtV55()
			{
				return this.GjxYMGdHPP.qfclaEtV55();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt QHqj9kqOCA(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w + (ulong)((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(checked(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ))));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w + ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(checked(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ + ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ)));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qqRlYZcuq0()
			{
				return this.GjxYMGdHPP.qqRlYZcuq0();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt qXRjGWmv0L(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB + ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU + ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				return this;
			}

			public override bool RCglbwABSK()
			{
				return !this.q57l2vpK1n();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt RkFjUgwliF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB << (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 63));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU << (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 31)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB << (((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.BHQSKTolAy & 63));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU << (((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & 31)));
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO rrtlzquJpy()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.dKTlxkpj1Q().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.voYle2maYc().FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rT4jQ5XUP4(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w / ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ / ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w / ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ / ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rtwjNgsk8H(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w % ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ % ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w % ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)(this.oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ % ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.GO8SlOKscJ));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s6tjIept8c(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB * ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU * ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU)));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s7Oj3eIaoc(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU)));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(checked(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB + ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB));
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(checked(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU + ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU)));
			}

			public override bool Se8jY4rJ7g(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU >= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB >= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB >= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU >= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W SOglrKDlkM()
			{
				return this.GjxYMGdHPP.SOglrKDlkM();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt T5Ojba52SB()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(~this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(~this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override bool THajPMZMuT(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU <= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB <= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB <= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU <= ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU;
			}

			public override bool ThjjjOubV1(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size != 8)
					{
						return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU < ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
					}
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB < ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB < ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
				}
				return this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU < ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU;
			}

			public override string ToString()
			{
				return this.GjxYMGdHPP.ToString();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W U0llufhe9B()
			{
				return this.GjxYMGdHPP.U0llufhe9B();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u6QjCWlWMF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB & ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB & ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u7ijtkwXum(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB / ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU / ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB / ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU / ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			internal override bool usRjFyXAAy()
			{
				return true;
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt VkljwO21ED(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB % ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU % ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB % ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU % ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt Vm0SEQyERt(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU - this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB - this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU - this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W voYle2maYc()
			{
				return this.GjxYMGdHPP.voYle2maYc();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W W15lPh5RC4()
			{
				return this.b5ElWf0CKC();
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U wGllDQeBGn()
			{
				return this.GjxYMGdHPP.wGllDQeBGn();
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO wNijkq3Yt8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.YQPl1OGXpG().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.DP7lfDqxDB().FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W x2GlKaLfLY()
			{
				return this.GjxYMGdHPP.x2GlKaLfLY();
			}

			internal void XcTSc6GmkQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.tpmPR9FfWH())
				{
					this.hsKlwaTTVG(u0020);
					return;
				}
				this.GjxYMGdHPP = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).GjxYMGdHPP;
				this.QUEY7wJ94J = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).QUEY7wJ94J;
			}

			internal static BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO XU4XO6k83jmnXp29ZkCY()
			{
				return BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO.wrM7OKk8HVrah2sEgEdR;
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ xwllOBxh3t()
			{
				return this.GjxYMGdHPP.xwllOBxh3t();
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt YesYk0Edxr(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					if (IntPtr.Size == 8)
					{
						return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB / this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
					}
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU / this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB / this.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)(((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU / this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO YNwj8YIExi()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.H3GloK8YWW().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.JQ5l5Gionr().FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D yqnlCrBSQ1()
			{
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO()
				{
					GjxYMGdHPP = this.GjxYMGdHPP.yqnlCrBSQ1(),
					QUEY7wJ94J = this.QUEY7wJ94J
				};
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ YQPl1OGXpG()
			{
				return this.GjxYMGdHPP.YQPl1OGXpG();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W ysWllqqkwZ()
			{
				return this.oHqlSW6b45();
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO z3gjqNHGw8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.kl5ld64bfA().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B5rlJDOwmv().FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO zgLlyFEWVS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.jT9ljPZtDi().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.ysWllqqkwZ().FH6SRpjuDo.NFySjw3NeU);
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt zHeY3PKOih(BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W u0020)
			{
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)((ulong)(u0020.FH6SRpjuDo.GO8SlOKscJ >> (this.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU & 31))));
			}
		}

		private class J73ZKePAQS1jY9pDRn8 : BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt
		{
			public object Hv9PVo08fd;

			public Type h10PL4ynEh;

			internal static BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8 flvOuokHbhx3nRuRvChJ;

			public J73ZKePAQS1jY9pDRn8()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				this(null);
			}

			public J73ZKePAQS1jY9pDRn8(object u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base(0);
				this.Hv9PVo08fd = u0020;
				this.h10PL4ynEh = null;
			}

			public J73ZKePAQS1jY9pDRn8(object u0020, Type u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base(0);
				this.Hv9PVo08fd = u0020;
				this.h10PL4ynEh = u0020;
			}

			internal override bool CJ4lvqi9kG()
			{
				if (this.Hv9PVo08fd == null)
				{
					return false;
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt hv9PVo08fd = this.Hv9PVo08fd as BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt;
				if (hv9PVo08fd == null)
				{
					return true;
				}
				if (hv9PVo08fd.CvnlU3IXkO(null) == null)
				{
					return false;
				}
				return true;
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (this.Hv9PVo08fd == null)
				{
					return null;
				}
				if (u0020 != null && u0020.IsByRef)
				{
					u0020 = u0020.GetElementType();
				}
				if (!(this.Hv9PVo08fd is BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt))
				{
					object hv9PVo08fd = this.Hv9PVo08fd;
					if (hv9PVo08fd != null && u0020 != null && hv9PVo08fd.GetType() != u0020)
					{
						if (u0020 == typeof(RuntimeFieldHandle) && hv9PVo08fd is FieldInfo)
						{
							hv9PVo08fd = ((FieldInfo)hv9PVo08fd).FieldHandle;
						}
						else if (u0020 == typeof(RuntimeTypeHandle) && hv9PVo08fd is Type)
						{
							hv9PVo08fd = ((Type)hv9PVo08fd).TypeHandle;
						}
						else if (u0020 == typeof(RuntimeMethodHandle) && hv9PVo08fd is MethodBase)
						{
							hv9PVo08fd = ((MethodBase)hv9PVo08fd).MethodHandle;
						}
					}
					return hv9PVo08fd;
				}
				if (this.h10PL4ynEh != null)
				{
					return ((BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt)this.Hv9PVo08fd).CvnlU3IXkO(this.h10PL4ynEh);
				}
				object fieldHandle = ((BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt)this.Hv9PVo08fd).CvnlU3IXkO(u0020);
				if (fieldHandle != null && u0020 != null && fieldHandle.GetType() != u0020)
				{
					if (u0020 == typeof(RuntimeFieldHandle) && fieldHandle is FieldInfo)
					{
						fieldHandle = ((FieldInfo)fieldHandle).FieldHandle;
					}
					else if (u0020 == typeof(RuntimeTypeHandle) && fieldHandle is Type)
					{
						fieldHandle = ((Type)fieldHandle).TypeHandle;
					}
					else if (u0020 == typeof(RuntimeMethodHandle) && fieldHandle is MethodBase)
					{
						fieldHandle = ((MethodBase)fieldHandle).MethodHandle;
					}
				}
				return fieldHandle;
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).evOjuZejQG(this);
				}
				return this.CvnlU3IXkO(null) == u0020.CvnlU3IXkO(null);
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.hsKlwaTTVG(u0020);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8))
				{
					this.Hv9PVo08fd = u0020.R5MjgxNnyG();
					return;
				}
				this.Hv9PVo08fd = ((BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8)u0020).Hv9PVo08fd;
				this.h10PL4ynEh = ((BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8)u0020).h10PL4ynEh;
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).KyQjSu10fI(this);
				}
				return this.CvnlU3IXkO(null) != u0020.CvnlU3IXkO(null);
			}

			internal static bool NXwSsMkHhM9tp7PR6nSB()
			{
				return BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8.flvOuokHbhx3nRuRvChJ == null;
			}

			internal static BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8 QD087xkHU8tDxjdb2STS()
			{
				return BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8.flvOuokHbhx3nRuRvChJ;
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt hv9PVo08fd = this.Hv9PVo08fd as BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt;
				if (hv9PVo08fd == null)
				{
					return this;
				}
				return hv9PVo08fd.R5MjgxNnyG();
			}

			public override string ToString()
			{
				if (this.Hv9PVo08fd != null)
				{
					return this.Hv9PVo08fd.ToString();
				}
				return 5.ToString();
			}
		}

		private delegate object JLhxt0X7DCmV00GKOpY(object target, object[] paramters);

		private delegate void Kkc65eX66JfXDDeYYwQ(IntPtr s, IntPtr t, uint c);

		[StructLayout(LayoutKind.Explicit)]
		private struct KKUpVCSrhIaC4pDivuy
		{
			[FieldOffset(0)]
			public byte a2WSnbxtGc;

			[FieldOffset(0)]
			public sbyte TwjSeffPsN;

			[FieldOffset(0)]
			public ushort bdoSfZLxDX;

			[FieldOffset(0)]
			public short O3dSxySaQL;

			[FieldOffset(0)]
			public uint fGeS199yWi;

			[FieldOffset(0)]
			public int BHQSKTolAy;

			[FieldOffset(0)]
			public ulong ogcSA8800w;

			[FieldOffset(0)]
			public long R6BSVkv4SB;
		}

		internal class klTxZLY2Hvtos3CbvnT
		{
			internal BRsI3YS41tRIm0CdPSm.dZxuXmPjV25we9fnrwv mEJYbEIsgP;

			internal object wn7YhLUPc1;

			private static BRsI3YS41tRIm0CdPSm.klTxZLY2Hvtos3CbvnT SV9BXMk8adjTSYcRaGfi;

			public klTxZLY2Hvtos3CbvnT()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				this.mEJYbEIsgP = (BRsI3YS41tRIm0CdPSm.dZxuXmPjV25we9fnrwv)126;
				base();
			}

			internal static bool QlbTsGk8g0GBS3rHYYOi()
			{
				return BRsI3YS41tRIm0CdPSm.klTxZLY2Hvtos3CbvnT.SV9BXMk8adjTSYcRaGfi == null;
			}

			internal static BRsI3YS41tRIm0CdPSm.klTxZLY2Hvtos3CbvnT RwwHrnk8WeTnfbnAA8Ll()
			{
				return BRsI3YS41tRIm0CdPSm.klTxZLY2Hvtos3CbvnT.SV9BXMk8adjTSYcRaGfi;
			}

			public override string ToString()
			{
				object obj = this.mEJYbEIsgP;
				if (this.wn7YhLUPc1 == null)
				{
					return obj.ToString();
				}
				char chr = 'H';
				return string.Concat(obj.ToString(), chr.ToString(), this.wn7YhLUPc1.ToString());
			}
		}

		internal enum LidKBuYwT2NO2mUOWFY : byte
		{

		}

		private class MuHuwbYCeEiTLXCDHPF : Exception
		{
			private static BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF md9MBkk8Uo8k2CxQZxjo;

			public MuHuwbYCeEiTLXCDHPF()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			public MuHuwbYCeEiTLXCDHPF(string u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base(u0020);
			}

			internal static bool AvOM6vk8Tj4xr4l93wwJ()
			{
				return BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF.md9MBkk8Uo8k2CxQZxjo == null;
			}

			internal static BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF To57Auk8vVPWuFckcyZu()
			{
				return BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF.md9MBkk8Uo8k2CxQZxjo;
			}
		}

		private abstract class MXLA9LY4pdeld88e55D : BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt
		{
			internal static BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D Fa2l8ek89Ev5Brk2RaWH;

			protected MXLA9LY4pdeld88e55D()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			public abstract BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U AQblmacrWV();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W aV0lp8koBT();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b3DlZ1vlBC();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b5ElWf0CKC();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B5rlJDOwmv();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B7GliJVwUR();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W bSylgOD1Tv();

			public abstract bool buqjZToHQq(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt cguj6B2iXY(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO cGxlEOFbUS();

			public abstract bool cyBjla9WGE(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W d0GlRc2a7L();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dHsjhXjesK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ dKTlxkpj1Q();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dMBjH0kCfL();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W DP7lfDqxDB();

			public abstract bool EaCjXoObXK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W eu0lTybe0W();

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ FIglXEgdyQ();

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ Gavl0MZqqr();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt GthjMfGJXk(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ H3GloK8YWW();

			public abstract BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U hdRlcPQNJV();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W HeNlB8VrPZ();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hoJlAy9b0V();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt HqHj7mcRQX(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hWSlLTopa3();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W JQ5l5Gionr();

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ jT9ljPZtDi();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt K2rjTSWTBP(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ kl5ld64bfA();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W lVclVGHGWb();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt LX3jvRuP7O(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract bool M2ijBdfvCo(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W mfnlFkZV24();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MuDj2ESVFd(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MW1lhEmAfG(BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W nDklnP9uew();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt Ni9j4tniIe(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract bool oc0jO1XWAQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W oHqlSW6b45();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt q0PjsQJ2ps(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract bool q57l2vpK1n();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qfclaEtV55();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt QHqj9kqOCA(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qqRlYZcuq0();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt qXRjGWmv0L(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract bool RCglbwABSK();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt RkFjUgwliF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO rrtlzquJpy();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rT4jQ5XUP4(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rtwjNgsk8H(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s6tjIept8c(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s7Oj3eIaoc(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract bool Se8jY4rJ7g(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			internal override bool SgSjiMaCIn()
			{
				return true;
			}

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W SOglrKDlkM();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt T5Ojba52SB();

			public abstract bool THajPMZMuT(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract bool ThjjjOubV1(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			internal static bool tWrXlrk8s9vXP90t9AQK()
			{
				return BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D.Fa2l8ek89Ev5Brk2RaWH == null;
			}

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W U0llufhe9B();

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u6QjCWlWMF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u7ijtkwXum(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt VkljwO21ED(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W voYle2maYc();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W W15lPh5RC4();

			public abstract BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U wGllDQeBGn();

			public abstract BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO wNijkq3Yt8();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W x2GlKaLfLY();

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ xwllOBxh3t();

			public abstract BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO YNwj8YIExi();

			public abstract BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D yqnlCrBSQ1();

			public abstract BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ YQPl1OGXpG();

			public abstract BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W ysWllqqkwZ();

			public abstract BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO z3gjqNHGw8();

			public abstract BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO zgLlyFEWVS();

			internal static BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D zKfHyUk8MeDgjysMrqda()
			{
				return BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D.Fa2l8ek89Ev5Brk2RaWH;
			}
		}

		internal class nRoQfMYlgvjqXAmr875 : BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ
		{
			private BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt uHhYj6BNnj;

			private Type laAYZVJ2vO;

			private static BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875 XVhRGnk8rB4WAWlquT4G;

			public nRoQfMYlgvjqXAmr875(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020, Type u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.uHhYj6BNnj = u0020;
				this.laAYZVJ2vO = u0020;
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)7;
			}

			internal static bool adyDf6k8nZ4pIG46jgOa()
			{
				return BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875.XVhRGnk8rB4WAWlquT4G == null;
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.R5MjgxNnyG().CJ4lvqi9kG();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (this.uHhYj6BNnj == null)
				{
					return new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null);
				}
				if (!(u0020 == null) && !(u0020 == typeof(object)))
				{
					return this.uHhYj6BNnj.CvnlU3IXkO(u0020);
				}
				return this.uHhYj6BNnj.CvnlU3IXkO(this.laAYZVJ2vO);
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return false;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875))
				{
					return false;
				}
				BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875 _nRoQfMYlgvjqXAmr875 = (BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875)u0020;
				if (_nRoQfMYlgvjqXAmr875.laAYZVJ2vO != this.laAYZVJ2vO)
				{
					return false;
				}
				if (this.uHhYj6BNnj != null)
				{
					return this.uHhYj6BNnj.evOjuZejQG(_nRoQfMYlgvjqXAmr875.uHhYj6BNnj);
				}
				if (_nRoQfMYlgvjqXAmr875.uHhYj6BNnj != null)
				{
					return false;
				}
				return true;
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.qVnjpWd3hb(u0020);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875))
				{
					this.uHhYj6BNnj.hsKlwaTTVG(u0020);
					return;
				}
				this.laAYZVJ2vO = ((BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875)u0020).laAYZVJ2vO;
				this.uHhYj6BNnj = ((BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875)u0020).uHhYj6BNnj;
			}

			internal static BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875 j4Wy3Yk8eHAt43aMkQjg()
			{
				return BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875.XVhRGnk8rB4WAWlquT4G;
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return true;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875))
				{
					return true;
				}
				BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875 _nRoQfMYlgvjqXAmr875 = (BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875)u0020;
				if (_nRoQfMYlgvjqXAmr875.laAYZVJ2vO != this.laAYZVJ2vO)
				{
					return true;
				}
				if (this.uHhYj6BNnj != null)
				{
					return this.uHhYj6BNnj.KyQjSu10fI(_nRoQfMYlgvjqXAmr875.uHhYj6BNnj);
				}
				if (_nRoQfMYlgvjqXAmr875.uHhYj6BNnj != null)
				{
					return true;
				}
				return false;
			}

			internal override bool OHBjWnvYRZ()
			{
				return this.R5MjgxNnyG().OHBjWnvYRZ();
			}

			internal override void qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.uHhYj6BNnj = u0020;
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				if (this.uHhYj6BNnj == null)
				{
					return new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null);
				}
				return this.uHhYj6BNnj.R5MjgxNnyG();
			}

			internal override IntPtr v4WjRI4rni()
			{
				throw new NotImplementedException();
			}
		}

		internal class ntk9pDYD0emiOwoNFlC
		{
			internal MethodBase OrjYcfiCq7;

			internal List<BRsI3YS41tRIm0CdPSm.klTxZLY2Hvtos3CbvnT> Kp5YyMoCrK;

			internal BRsI3YS41tRIm0CdPSm.OJjUSiYFQ9bkELECCjX[] ffCYE6MCG5;

			internal List<BRsI3YS41tRIm0CdPSm.zHMZlrYpcFP7oL8MBET> KOhYzR5bYd;

			internal List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec> YYpXqh68Cp;

			private static BRsI3YS41tRIm0CdPSm.ntk9pDYD0emiOwoNFlC Lhe1gJk8DON0bCrXrAuW;

			public ntk9pDYD0emiOwoNFlC()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal static BRsI3YS41tRIm0CdPSm.ntk9pDYD0emiOwoNFlC aM5sfUk8yTbx0LOTge0s()
			{
				return BRsI3YS41tRIm0CdPSm.ntk9pDYD0emiOwoNFlC.Lhe1gJk8DON0bCrXrAuW;
			}

			internal static bool HYSDJXk8ct3CwQrOJ1d1()
			{
				return BRsI3YS41tRIm0CdPSm.ntk9pDYD0emiOwoNFlC.Lhe1gJk8DON0bCrXrAuW == null;
			}
		}

		internal class O0ASV5Yx65d5pus25Ec
		{
			public int YWgY1NLXY6;

			public int QFPYKAFenG;

			public BRsI3YS41tRIm0CdPSm.ys1NI3YVD4nmbEeC9Sp sBiYAvW7NR;

			internal static BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec S8frG8k8Lp6Txc0gDuSG;

			public O0ASV5Yx65d5pus25Ec()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal static bool TqKCqOk8JIHbVjsUbKdH()
			{
				return BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec.S8frG8k8Lp6Txc0gDuSG == null;
			}

			internal static BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec vvStKAk85tqby5ia6TIt()
			{
				return BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec.S8frG8k8Lp6Txc0gDuSG;
			}
		}

		internal class O0bRICPdRH7uXLNciXu
		{
			private List<BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt> Vx6PyAZgNK;

			internal static BRsI3YS41tRIm0CdPSm.O0bRICPdRH7uXLNciXu vjopRokHgyQLYbRnQ0p6;

			public O0bRICPdRH7uXLNciXu()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				this.Vx6PyAZgNK = new List<BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt>();
				base();
			}

			public void bLcPoePGi1()
			{
				this.Vx6PyAZgNK.Clear();
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt daUPcrrcU3()
			{
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = this.vipPDE7HfC();
				if (this.Vx6PyAZgNK.Count != 0)
				{
					this.Vx6PyAZgNK.RemoveAt(this.Vx6PyAZgNK.Count - 1);
				}
				return pDI0AUPFaaR24dXe0vt;
			}

			internal static bool h7AZFxkHWmtmP0bMXSFZ()
			{
				return BRsI3YS41tRIm0CdPSm.O0bRICPdRH7uXLNciXu.vjopRokHgyQLYbRnQ0p6 == null;
			}

			public void lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.Vx6PyAZgNK.Add(u0020);
			}

			internal static BRsI3YS41tRIm0CdPSm.O0bRICPdRH7uXLNciXu unlR2HkHuFkpnsXgI650()
			{
				return BRsI3YS41tRIm0CdPSm.O0bRICPdRH7uXLNciXu.vjopRokHgyQLYbRnQ0p6;
			}

			public BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt vipPDE7HfC()
			{
				return this.Vx6PyAZgNK[this.Vx6PyAZgNK.Count - 1];
			}

			public int xLqe4PZWEH()
			{
				return this.Vx6PyAZgNK.Count;
			}
		}

		internal class OJjUSiYFQ9bkELECCjX
		{
			public int p8JYijJ1el;

			public bool Lp4Y0Px7gQ;

			public BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW pOFYRFQprs;

			internal static BRsI3YS41tRIm0CdPSm.OJjUSiYFQ9bkELECCjX NixXNZk8fHVKspWWaWe5;

			public OJjUSiYFQ9bkELECCjX()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal static bool GCKexnk8xUMs9vRsjs2P()
			{
				return BRsI3YS41tRIm0CdPSm.OJjUSiYFQ9bkELECCjX.NixXNZk8fHVKspWWaWe5 == null;
			}

			internal static BRsI3YS41tRIm0CdPSm.OJjUSiYFQ9bkELECCjX wn0LTIk81uOtQMcqKq9n()
			{
				return BRsI3YS41tRIm0CdPSm.OJjUSiYFQ9bkELECCjX.NixXNZk8fHVKspWWaWe5;
			}
		}

		private class OOfeb5XkKsXpJwgStnB
		{
			internal FieldInfo JbMX89L6Ci;

			internal int n23XHVmHwr;

			internal static BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB UB5iZkk8EECJPkxpsx3i;

			public OOfeb5XkKsXpJwgStnB(FieldInfo u0020, int u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.JbMX89L6Ci = u0020;
				this.n23XHVmHwr = u0020;
			}

			internal static BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB q294irkHqvM0DOZ7lPKH()
			{
				return BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB.UB5iZkk8EECJPkxpsx3i;
			}

			internal static bool y0n5KRk8zwBHsFU039a7()
			{
				return BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB.UB5iZkk8EECJPkxpsx3i == null;
			}
		}

		private delegate object ORWUaLX4jmnc2O81rRo(object target);

		internal abstract class PDI0AUPFaaR24dXe0vt
		{
			internal BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3 AdkPKdYKa9;

			private static BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt UKINTIkHNoObtYeUmb0Q;

			public PDI0AUPFaaR24dXe0vt()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal PDI0AUPFaaR24dXe0vt(BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3 u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = u0020;
			}

			internal static BRsI3YS41tRIm0CdPSm.LidKBuYwT2NO2mUOWFY c64PeINyuD(Type u0020)
			{
				Type elementType = u0020;
				if (elementType == null)
				{
					return 18;
				}
				if (elementType.IsByRef)
				{
					elementType = elementType.GetElementType();
				}
				if (elementType == typeof(string))
				{
					return 14;
				}
				if (elementType == typeof(byte))
				{
					return 2;
				}
				if (elementType == typeof(sbyte))
				{
					return 1;
				}
				if (elementType == typeof(short))
				{
					return 3;
				}
				if (elementType == typeof(ushort))
				{
					return 4;
				}
				if (elementType == typeof(int))
				{
					return 5;
				}
				if (elementType == typeof(uint))
				{
					return 6;
				}
				if (elementType == typeof(long))
				{
					return 7;
				}
				if (elementType == typeof(ulong))
				{
					return 8;
				}
				if (elementType == typeof(float))
				{
					return 9;
				}
				if (elementType == typeof(double))
				{
					return 10;
				}
				if (elementType == typeof(bool))
				{
					return 11;
				}
				if (elementType == typeof(IntPtr))
				{
					return 12;
				}
				if (elementType == typeof(UIntPtr))
				{
					return 13;
				}
				if (elementType == typeof(char))
				{
					return 15;
				}
				if (elementType == typeof(object))
				{
					return 0;
				}
				if (elementType.IsEnum)
				{
					return 16;
				}
				return 17;
			}

			internal bool cB0PirV4Hs()
			{
				return (int)this.AdkPKdYKa9 == 0;
			}

			internal abstract bool CJ4lvqi9kG();

			internal bool CsRPppYOTY()
			{
				return (int)this.AdkPKdYKa9 == 2;
			}

			internal abstract object CvnlU3IXkO(Type u0020);

			internal static bool dGhY84kHCxy0eRcuZeja()
			{
				return BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.UKINTIkHNoObtYeUmb0Q == null;
			}

			internal bool dXRPnvT2k3()
			{
				return (int)this.AdkPKdYKa9 == 6;
			}

			internal abstract bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			private static BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt fLKPxNgaHi(object u0020)
			{
				if (u0020 != null && u0020.GetType().IsEnum)
				{
					Type underlyingType = Enum.GetUnderlyingType(u0020.GetType());
					object obj = Convert.ChangeType(u0020, underlyingType);
					BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.lhIP1FRo0H(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(underlyingType, obj));
					if (pDI0AUPFaaR24dXe0vt != null)
					{
						return pDI0AUPFaaR24dXe0vt as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
					}
				}
				return new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(u0020);
			}

			internal bool FrXPreN9nq()
			{
				return (int)this.AdkPKdYKa9 == 5;
			}

			internal abstract void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			internal abstract void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			internal static BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt iK7NBxkH2bjYYr5wgh9O()
			{
				return BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.UKINTIkHNoObtYeUmb0Q;
			}

			internal abstract bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			private static BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D lhIP1FRo0H(object u0020)
			{
				BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D = u0020 as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				if (mXLA9LY4pdeld88e55D == null && u0020.oJVj0o8M8s())
				{
					mXLA9LY4pdeld88e55D = u0020.R5MjgxNnyG() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				}
				return mXLA9LY4pdeld88e55D;
			}

			internal static BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt O4QPfZrxdO(Type u0020, object u0020)
			{
				BRsI3YS41tRIm0CdPSm.LidKBuYwT2NO2mUOWFY lidKBuYwT2NO2mUOWFY = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.c64PeINyuD(u0020);
				BRsI3YS41tRIm0CdPSm.LidKBuYwT2NO2mUOWFY lidKBuYwT2NO2mUOWFY1 = (BRsI3YS41tRIm0CdPSm.LidKBuYwT2NO2mUOWFY)18;
				if (u0020 != null)
				{
					lidKBuYwT2NO2mUOWFY1 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.c64PeINyuD(u0020.GetType());
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt j73ZKePAQS1jY9pDRn8 = null;
				switch (lidKBuYwT2NO2mUOWFY)
				{
					case 0:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
						{
							j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.fLKPxNgaHi(u0020);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(u0020);
							break;
						}
					}
					case 1:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 <= 2)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 == 1)
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((sbyte)u0020, 1);
								break;
							}
							else if ((int)lidKBuYwT2NO2mUOWFY1 == 2)
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((sbyte)((byte)u0020), 1);
								break;
							}
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 == 15)
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((sbyte)((char)u0020), 1);
								break;
							}
						}
						else if ((bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1, 1);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0, 1);
							break;
						}
						throw new InvalidCastException();
					}
					case 2:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 <= 2)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 == 1)
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)((sbyte)u0020), 2);
								break;
							}
							else if ((int)lidKBuYwT2NO2mUOWFY1 == 2)
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020, 2);
								break;
							}
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 == 15)
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)((char)u0020), 2);
								break;
							}
						}
						else if ((bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1, 2);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0, 2);
							break;
						}
						throw new InvalidCastException();
					}
					case 3:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 == 3)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((short)u0020, 3);
							break;
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
							{
								throw new InvalidCastException();
							}
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((short)((char)u0020), 3);
							break;
						}
						else if (!(bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0, 3);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1, 3);
							break;
						}
					}
					case 4:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 == 4)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020, 4);
							break;
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
							{
								throw new InvalidCastException();
							}
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((char)u0020, 4);
							break;
						}
						else if ((bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1, 4);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0, 4);
							break;
						}
					}
					case 5:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 == 5)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020, 5);
							break;
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
							{
								throw new InvalidCastException();
							}
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((char)u0020, 5);
							break;
						}
						else if ((bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1, 5);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0, 5);
							break;
						}
					}
					case 6:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 == 6)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((uint)u0020, 6);
							break;
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
							{
								throw new InvalidCastException();
							}
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((char)u0020, 6);
							break;
						}
						else if ((bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1, 6);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0, 6);
							break;
						}
					}
					case 7:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 == 7)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)u0020, 7);
							break;
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
							{
								throw new InvalidCastException();
							}
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)((char)u0020), 7);
							break;
						}
						else if (!(bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(0L, 7);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(1L, 7);
							break;
						}
					}
					case 8:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 == 8)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((ulong)u0020, 8);
							break;
						}
						else if ((int)lidKBuYwT2NO2mUOWFY1 != 11)
						{
							if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
							{
								throw new InvalidCastException();
							}
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((ulong)((char)u0020), 8);
							break;
						}
						else if (!(bool)u0020)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(0L, 8);
							break;
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(1L, 8);
							break;
						}
					}
					case 9:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 != 9)
						{
							throw new InvalidCastException();
						}
						j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((float)u0020);
						break;
					}
					case 10:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 != 10)
						{
							throw new InvalidCastException();
						}
						j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)u0020);
						break;
					}
					case 11:
					{
						switch (lidKBuYwT2NO2mUOWFY1)
						{
							case 1:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((sbyte)u0020 != 0);
								break;
							}
							case 2:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((byte)u0020 != 0);
								break;
							}
							case 3:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((short)u0020 != 0);
								break;
							}
							case 4:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((ushort)u0020 != 0);
								break;
							}
							case 5:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020 != 0);
								break;
							}
							case 6:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((uint)u0020 != 0);
								break;
							}
							case 7:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((long)u0020 > 0L);
								break;
							}
							case 8:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((ulong)u0020 > 0L);
								break;
							}
							case 9:
							case 10:
							case 12:
							case 13:
							case 14:
							case 15:
							case 16:
							{
								throw new InvalidCastException();
							}
							case 11:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((bool)u0020);
								break;
							}
							case 17:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(u0020 != null);
								break;
							}
							case 18:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(false);
								break;
							}
							default:
							{
								goto case 17;
							}
						}
						break;
					}
					case 12:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 != 12)
						{
							throw new InvalidCastException();
						}
						j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((IntPtr)u0020);
						break;
					}
					case 13:
					{
						if ((int)lidKBuYwT2NO2mUOWFY1 != 13)
						{
							throw new InvalidCastException();
						}
						j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((UIntPtr)u0020);
						break;
					}
					case 14:
					{
						j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO(u0020 as string);
						break;
					}
					case 15:
					{
						switch (lidKBuYwT2NO2mUOWFY1)
						{
							case 1:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((sbyte)u0020, 15);
								break;
							}
							case 2:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020, 15);
								break;
							}
							case 3:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((short)u0020, 15);
								break;
							}
							case 4:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020, 15);
								break;
							}
							case 5:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020, 15);
								break;
							}
							case 6:
							{
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)u0020, 15);
								break;
							}
							default:
							{
								if ((int)lidKBuYwT2NO2mUOWFY1 != 15)
								{
									throw new InvalidCastException();
								}
								j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((char)u0020, 15);
								break;
							}
						}
						break;
					}
					case 16:
					case 17:
					{
						j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.fLKPxNgaHi(u0020);
						break;
					}
					case 18:
					{
						throw new InvalidCastException();
					}
				}
				if (u0020.IsByRef)
				{
					j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.nRoQfMYlgvjqXAmr875(j73ZKePAQS1jY9pDRn8, u0020.GetElementType());
				}
				return j73ZKePAQS1jY9pDRn8;
			}

			internal virtual bool OHBjWnvYRZ()
			{
				return false;
			}

			internal virtual bool oJVj0o8M8s()
			{
				return false;
			}

			internal abstract BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG();

			internal virtual bool SgSjiMaCIn()
			{
				return false;
			}

			internal bool TOiP0fUvZ0()
			{
				return (int)this.AdkPKdYKa9 == 1;
			}

			internal bool tpmPR9FfWH()
			{
				if ((int)this.AdkPKdYKa9 == 3)
				{
					return true;
				}
				return (int)this.AdkPKdYKa9 == 4;
			}

			internal virtual bool usRjFyXAAy()
			{
				return false;
			}
		}

		internal class qBG0R0YTMijeb5KsNtB : BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ
		{
			private BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I qDpYv9BrIu;

			internal int w6eYaj5RVE;

			private static BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB p3Jnxlk8Xvp4bYVynj8X;

			public qBG0R0YTMijeb5KsNtB(int u0020, BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.qDpYv9BrIu = u0020;
				this.w6eYaj5RVE = u0020;
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)7;
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.R5MjgxNnyG().CJ4lvqi9kG();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (this.qDpYv9BrIu.pm0P6am0Ua[this.w6eYaj5RVE] == null)
				{
					return null;
				}
				return this.R5MjgxNnyG().CvnlU3IXkO(u0020);
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return false;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB))
				{
					return false;
				}
				if (((BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)u0020).w6eYaj5RVE == this.w6eYaj5RVE)
				{
					return true;
				}
				return false;
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.qVnjpWd3hb(u0020);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020 is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)
				{
					this.qDpYv9BrIu = ((BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)u0020).qDpYv9BrIu;
					this.w6eYaj5RVE = ((BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)u0020).w6eYaj5RVE;
					return;
				}
				BRsI3YS41tRIm0CdPSm.zHMZlrYpcFP7oL8MBET item = this.qDpYv9BrIu.CqHP4vveCn.KOhYzR5bYd[this.w6eYaj5RVE];
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ) || ((int)item.IZTYnytKfE & 226) <= 0)
				{
					this.qVnjpWd3hb(u0020);
					return;
				}
				this.qVnjpWd3hb((u0020 as BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ).R5MjgxNnyG());
			}

			internal static BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB kxvoiOk8BsnKC0CZSKep()
			{
				return BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB.p3Jnxlk8Xvp4bYVynj8X;
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return true;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB))
				{
					return true;
				}
				if (((BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)u0020).w6eYaj5RVE != this.w6eYaj5RVE)
				{
					return true;
				}
				return false;
			}

			internal override bool OHBjWnvYRZ()
			{
				return this.R5MjgxNnyG().OHBjWnvYRZ();
			}

			internal override void qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.qDpYv9BrIu.pm0P6am0Ua[this.w6eYaj5RVE] = u0020;
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				if (this.qDpYv9BrIu.pm0P6am0Ua[this.w6eYaj5RVE] == null)
				{
					return new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null);
				}
				return this.qDpYv9BrIu.pm0P6am0Ua[this.w6eYaj5RVE].R5MjgxNnyG();
			}

			internal override IntPtr v4WjRI4rni()
			{
				throw new NotImplementedException();
			}

			internal static bool WD5AhOk8OW4OoMHyYn00()
			{
				return BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB.p3Jnxlk8Xvp4bYVynj8X == null;
			}
		}

		internal class qIRTKAXt5lwtBFs4O9I
		{
			internal BRsI3YS41tRIm0CdPSm.ntk9pDYD0emiOwoNFlC CqHP4vveCn;

			internal BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[] MnCPIjta1t;

			internal BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[] pm0P6am0Ua;

			internal BRsI3YS41tRIm0CdPSm.O0bRICPdRH7uXLNciXu kxpPtJIMy4;

			internal BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt xivPQGYE5d;

			internal Exception y2TPwZO5TM;

			internal List<IntPtr> KAyPNNvZUm;

			private int DhoPCkFW2H;

			private int GvsP2tCtHy;

			private int vGoPbqKVrt;

			private object M69Ph76OUs;

			private bool xPTPUnM962;

			private bool K4LPTCcv1n;

			private bool OQqPvlPn82;

			private bool Ms6PaJpOOL;

			private static Dictionary<Type, int> pDiPgL0VDi;

			private static Dictionary<object, BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt> dbGPWsIaD7;

			private static Dictionary<MethodBase, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY> QhFPuf6ZGo;

			private static Dictionary<MethodBase, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY> h0uPSEceyx;

			private static Dictionary<BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY> Y3APYbfxQe;

			private static Dictionary<BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY> He6PXsMOfl;

			private static Dictionary<BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY> CtcPOfDPwc;

			private static Dictionary<Type, BRsI3YS41tRIm0CdPSm.ORWUaLX4jmnc2O81rRo> PfEPBwpjXn;

			private static BRsI3YS41tRIm0CdPSm.RpU0YoXIL8v6XQEk4Lp PxuPPBYgnr;

			private static BRsI3YS41tRIm0CdPSm.Kkc65eX66JfXDDeYYwQ r41PlK88Om;

			private static BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I M4DpCCkHGOVNuCgFeCT4;

			static qIRTKAXt5lwtBFs4O9I()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.dbGPWsIaD7 = new Dictionary<object, BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt>();
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.QhFPuf6ZGo = new Dictionary<MethodBase, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY>();
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.h0uPSEceyx = new Dictionary<MethodBase, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY>();
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.Y3APYbfxQe = new Dictionary<BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY>();
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.He6PXsMOfl = new Dictionary<BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY>();
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.CtcPOfDPwc = new Dictionary<BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe, BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY>();
			}

			public qIRTKAXt5lwtBFs4O9I()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				this.MnCPIjta1t = new BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[0];
				this.pm0P6am0Ua = new BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[0];
				this.kxpPtJIMy4 = new BRsI3YS41tRIm0CdPSm.O0bRICPdRH7uXLNciXu();
				this.vGoPbqKVrt = -1;
				base();
			}

			private BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt alPOrjkbba(int u0020)
			{
				return this.pm0P6am0Ua[u0020];
			}

			private void BUYBJtDF7x(int u0020, BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.pm0P6am0Ua[u0020] = this.JYZXvLSAki(u0020, this.CqHP4vveCn.KOhYzR5bYd[u0020].IZTYnytKfE, this.CqHP4vveCn.KOhYzR5bYd[u0020].vcRYeCHnUg);
			}

			private static IntPtr cALP9r5N9q(object u0020)
			{
				IntPtr intPtr;
				object obj;
				if (u0020 == null)
				{
					return IntPtr.Zero;
				}
				if (u0020.tpmPR9FfWH())
				{
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).dkNSy1bnDX();
				}
				if (u0020.oJVj0o8M8s())
				{
					BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ _vlDU7kYUiRiPNypdIDJ = (BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020;
					try
					{
						intPtr = _vlDU7kYUiRiPNypdIDJ.v4WjRI4rni();
					}
					catch
					{
						obj = u0020.CvnlU3IXkO(typeof(IntPtr));
						if (obj == null || !(obj.GetType() == typeof(IntPtr)))
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						return (IntPtr)obj;
					}
					return intPtr;
				}
				obj = u0020.CvnlU3IXkO(typeof(IntPtr));
				if (obj == null || !(obj.GetType() == typeof(IntPtr)))
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return (IntPtr)obj;
			}

			private static BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY CmPPqNVuHC(object u0020, bool u0020)
			{
				BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY = null;
				if (!u0020)
				{
					if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.h0uPSEceyx.TryGetValue(u0020, out jLhxt0X7DCmV00GKOpY))
					{
						return jLhxt0X7DCmV00GKOpY;
					}
				}
				else if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.QhFPuf6ZGo.TryGetValue(u0020, out jLhxt0X7DCmV00GKOpY))
				{
					return jLhxt0X7DCmV00GKOpY;
				}
				MethodInfo methodInfo = u0020 as MethodInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object), typeof(object[]) }, true);
				ILGenerator lGenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = u0020.GetParameters();
				Type[] parameterType = new Type[(int)parameters.Length];
				for (int i = 0; i < (int)parameterType.Length; i++)
				{
					if (!parameters[i].ParameterType.IsByRef)
					{
						parameterType[i] = parameters[i].ParameterType;
					}
					else
					{
						parameterType[i] = parameters[i].ParameterType.GetElementType();
					}
				}
				int length = (int)parameterType.Length;
				if (u0020.DeclaringType.IsValueType)
				{
					length++;
				}
				LocalBuilder[] localBuilderArray = new LocalBuilder[length];
				for (int j = 0; j < (int)parameterType.Length; j++)
				{
					localBuilderArray[j] = lGenerator.DeclareLocal(parameterType[j]);
				}
				if (u0020.DeclaringType.IsValueType)
				{
					localBuilderArray[(int)localBuilderArray.Length - 1] = lGenerator.DeclareLocal(u0020.DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < (int)parameterType.Length; k++)
				{
					lGenerator.Emit(OpCodes.Ldarg_1);
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, k);
					lGenerator.Emit(OpCodes.Ldelem_Ref);
					if (parameterType[k].IsValueType)
					{
						lGenerator.Emit(OpCodes.Unbox_Any, parameterType[k]);
					}
					else if (parameterType[k] != typeof(object))
					{
						lGenerator.Emit(OpCodes.Castclass, parameterType[k]);
					}
					lGenerator.Emit(OpCodes.Stloc, localBuilderArray[k]);
				}
				if (!u0020.IsStatic)
				{
					lGenerator.Emit(OpCodes.Ldarg_0);
					if (u0020.DeclaringType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Unbox, u0020.DeclaringType);
						lGenerator.Emit(OpCodes.Stloc, localBuilderArray[(int)localBuilderArray.Length - 1]);
						lGenerator.Emit(OpCodes.Ldloc_S, localBuilderArray[(int)localBuilderArray.Length - 1]);
					}
					else
					{
						lGenerator.Emit(OpCodes.Castclass, u0020.DeclaringType);
					}
				}
				for (int l = 0; l < (int)parameterType.Length; l++)
				{
					if (!parameters[l].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldloca_S, localBuilderArray[l]);
					}
				}
				if (!u0020)
				{
					if (methodInfo == null)
					{
						lGenerator.Emit(OpCodes.Callvirt, u0020 as ConstructorInfo);
					}
					else
					{
						lGenerator.EmitCall(OpCodes.Callvirt, methodInfo, null);
					}
				}
				else if (methodInfo != null)
				{
					lGenerator.EmitCall(OpCodes.Call, methodInfo, null);
				}
				else
				{
					lGenerator.Emit(OpCodes.Call, u0020 as ConstructorInfo);
				}
				if (methodInfo == null || methodInfo.ReturnType == typeof(void))
				{
					lGenerator.Emit(OpCodes.Ldnull);
				}
				else if (methodInfo.ReturnType.IsByRef)
				{
					Type elementType = methodInfo.ReturnType.GetElementType();
					if (!elementType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Ldind_Ref, elementType);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldobj, elementType);
					}
					if (elementType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Box, elementType);
					}
				}
				else if (methodInfo.ReturnType.IsValueType)
				{
					lGenerator.Emit(OpCodes.Box, methodInfo.ReturnType);
				}
				for (int m = 0; m < (int)parameterType.Length; m++)
				{
					if (parameters[m].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldarg_1);
						BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, m);
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
						if (localBuilderArray[m].LocalType.IsValueType)
						{
							lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
						}
						lGenerator.Emit(OpCodes.Stelem_Ref);
					}
				}
				lGenerator.Emit(OpCodes.Ret);
				BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY1 = (BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY)dynamicMethod.CreateDelegate(typeof(BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY));
				if (!u0020)
				{
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.h0uPSEceyx.Add(u0020, jLhxt0X7DCmV00GKOpY1);
				}
				else
				{
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.QhFPuf6ZGo.Add(u0020, jLhxt0X7DCmV00GKOpY1);
				}
				return jLhxt0X7DCmV00GKOpY1;
			}

			internal static bool dxxSUjkH3HEoGnBaHSym()
			{
				return BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.M4DpCCkHGOVNuCgFeCT4 == null;
			}

			private static BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D F9CP3MCBGS(object u0020)
			{
				BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D = u0020 as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				if (mXLA9LY4pdeld88e55D == null && u0020.oJVj0o8M8s())
				{
					mXLA9LY4pdeld88e55D = u0020.R5MjgxNnyG() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				}
				return mXLA9LY4pdeld88e55D;
			}

			internal void Ge9XQom4kh()
			{
				bool flag = false;
				this.s0KXNniPPi(ref flag);
			}

			internal void HYFXwA5u8j()
			{
				this.kxpPtJIMy4.bLcPoePGi1();
				this.pm0P6am0Ua = null;
				if (this.KAyPNNvZUm != null)
				{
					foreach (IntPtr kAyPNNvZUm in this.KAyPNNvZUm)
					{
						try
						{
							Marshal.FreeHGlobal(kAyPNNvZUm);
						}
						catch
						{
						}
					}
					this.KAyPNNvZUm.Clear();
					this.KAyPNNvZUm = null;
				}
			}

			private static void iSkPMbDLGQ(IntPtr u0020, byte u0020, int u0020)
			{
				if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.PxuPPBYgnr == null)
				{
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(void), new Type[] { typeof(IntPtr), typeof(byte), typeof(int) }, typeof(BRsI3YS41tRIm0CdPSm), true);
					ILGenerator lGenerator = dynamicMethod.GetILGenerator();
					lGenerator.Emit(OpCodes.Ldarg_0);
					lGenerator.Emit(OpCodes.Ldarg_1);
					lGenerator.Emit(OpCodes.Ldarg_2);
					lGenerator.Emit(OpCodes.Initblk);
					lGenerator.Emit(OpCodes.Ret);
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.PxuPPBYgnr = (BRsI3YS41tRIm0CdPSm.RpU0YoXIL8v6XQEk4Lp)dynamicMethod.CreateDelegate(typeof(BRsI3YS41tRIm0CdPSm.RpU0YoXIL8v6XQEk4Lp));
				}
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.PxuPPBYgnr(u0020, u0020, u0020);
			}

			internal void Ja4X2tO0AP(int u0020, int u0020)
			{
				if (this.CqHP4vveCn.YYpXqh68Cp != null)
				{
					foreach (BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec yYpXqh68Cp in this.CqHP4vveCn.YYpXqh68Cp)
					{
						if (yYpXqh68Cp.sBiYAvW7NR.KrNYmeU4BI != 2 || yYpXqh68Cp.sBiYAvW7NR.LOBYLK1Y3x < u0020 || yYpXqh68Cp.sBiYAvW7NR.mJ2YJqCDCf > u0020)
						{
							continue;
						}
						this.GvsP2tCtHy = yYpXqh68Cp.sBiYAvW7NR.LOBYLK1Y3x;
						this.DhoPCkFW2H = this.GvsP2tCtHy;
						bool flag = false;
						this.s0KXNniPPi(ref flag);
						if (!flag)
						{
							continue;
						}
						return;
					}
				}
			}

			private static BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY JnaPktXyF6(object u0020, bool u0020, object u0020)
			{
				BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY = null;
				if (u0020)
				{
					if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.Y3APYbfxQe.TryGetValue(u0020, out jLhxt0X7DCmV00GKOpY))
					{
						return jLhxt0X7DCmV00GKOpY;
					}
				}
				else if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.He6PXsMOfl.TryGetValue(u0020, out jLhxt0X7DCmV00GKOpY))
				{
					return jLhxt0X7DCmV00GKOpY;
				}
				MethodInfo methodInfo = u0020 as MethodInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object), typeof(object[]) }, typeof(BRsI3YS41tRIm0CdPSm), true);
				ILGenerator lGenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = u0020.GetParameters();
				Type[] elementType = new Type[(int)parameters.Length];
				for (int i = 0; i < (int)elementType.Length; i++)
				{
					if (parameters[i].ParameterType.IsByRef)
					{
						elementType[i] = parameters[i].ParameterType.GetElementType();
					}
					else
					{
						elementType[i] = parameters[i].ParameterType;
					}
				}
				int length = (int)elementType.Length;
				if (u0020.DeclaringType.IsValueType)
				{
					length++;
				}
				LocalBuilder[] localBuilderArray = new LocalBuilder[length];
				for (int j = 0; j < (int)elementType.Length; j++)
				{
					if (!u0020.smlX9Nw7nt(j))
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(elementType[j]);
					}
					else
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(typeof(object));
					}
				}
				if (u0020.DeclaringType.IsValueType)
				{
					localBuilderArray[(int)localBuilderArray.Length - 1] = lGenerator.DeclareLocal(u0020.DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < (int)elementType.Length; k++)
				{
					lGenerator.Emit(OpCodes.Ldarg_1);
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, k);
					lGenerator.Emit(OpCodes.Ldelem_Ref);
					if (!u0020.smlX9Nw7nt(k))
					{
						if (elementType[k].IsValueType)
						{
							lGenerator.Emit(OpCodes.Unbox_Any, elementType[k]);
						}
						else if (elementType[k] != typeof(object))
						{
							lGenerator.Emit(OpCodes.Castclass, elementType[k]);
						}
					}
					lGenerator.Emit(OpCodes.Stloc, localBuilderArray[k]);
				}
				if (!u0020.IsStatic)
				{
					lGenerator.Emit(OpCodes.Ldarg_0);
					if (!u0020.DeclaringType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Castclass, u0020.DeclaringType);
					}
					else
					{
						lGenerator.Emit(OpCodes.Unbox, u0020.DeclaringType);
						lGenerator.Emit(OpCodes.Stloc, localBuilderArray[(int)localBuilderArray.Length - 1]);
						lGenerator.Emit(OpCodes.Ldloc_S, localBuilderArray[(int)localBuilderArray.Length - 1]);
					}
				}
				for (int l = 0; l < (int)elementType.Length; l++)
				{
					if (u0020.smlX9Nw7nt(l))
					{
						BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB oOfeb5XkKsXpJwgStnB = u0020.xC4X3CIPxx(l);
						if (oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.IsStatic)
						{
							lGenerator.Emit(OpCodes.Ldsflda, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci);
						}
						else if (!oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.DeclaringType.IsValueType)
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Castclass, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci);
						}
						else
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Unbox, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci);
						}
					}
					else if (!parameters[l].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldloca_S, localBuilderArray[l]);
					}
				}
				if (u0020)
				{
					if (methodInfo != null)
					{
						lGenerator.EmitCall(OpCodes.Call, methodInfo, null);
					}
					else
					{
						lGenerator.Emit(OpCodes.Call, u0020 as ConstructorInfo);
					}
				}
				else if (methodInfo == null)
				{
					lGenerator.Emit(OpCodes.Callvirt, u0020 as ConstructorInfo);
				}
				else
				{
					lGenerator.EmitCall(OpCodes.Callvirt, methodInfo, null);
				}
				if (methodInfo == null || methodInfo.ReturnType == typeof(void))
				{
					lGenerator.Emit(OpCodes.Ldnull);
				}
				else if (methodInfo.ReturnType.IsByRef)
				{
					Type type = methodInfo.ReturnType.GetElementType();
					if (!type.IsValueType)
					{
						lGenerator.Emit(OpCodes.Ldind_Ref, type);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldobj, type);
					}
					if (type.IsValueType)
					{
						lGenerator.Emit(OpCodes.Box, type);
					}
				}
				else if (methodInfo.ReturnType.IsValueType)
				{
					lGenerator.Emit(OpCodes.Box, methodInfo.ReturnType);
				}
				for (int m = 0; m < (int)elementType.Length; m++)
				{
					if (parameters[m].ParameterType.IsByRef)
					{
						if (u0020.smlX9Nw7nt(m))
						{
							BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB oOfeb5XkKsXpJwgStnB1 = u0020.xC4X3CIPxx(m);
							if (oOfeb5XkKsXpJwgStnB1.JbMX89L6Ci.IsStatic)
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldsfld, oOfeb5XkKsXpJwgStnB1.JbMX89L6Ci);
								if (oOfeb5XkKsXpJwgStnB1.JbMX89L6Ci.FieldType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
							else
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
								if (localBuilderArray[m].LocalType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
						}
						else
						{
							lGenerator.Emit(OpCodes.Ldarg_1);
							BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, m);
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
							if (localBuilderArray[m].LocalType.IsValueType)
							{
								lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
							}
							lGenerator.Emit(OpCodes.Stelem_Ref);
						}
					}
				}
				lGenerator.Emit(OpCodes.Ret);
				BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY1 = (BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY)dynamicMethod.CreateDelegate(typeof(BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY));
				if (u0020)
				{
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.Y3APYbfxQe.Add(u0020, jLhxt0X7DCmV00GKOpY1);
				}
				else
				{
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.He6PXsMOfl.Add(u0020, jLhxt0X7DCmV00GKOpY1);
				}
				return jLhxt0X7DCmV00GKOpY1;
			}

			private BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt JYZXvLSAki(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020, bool u0020 = false)
			{
				if (!u0020 && u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).MW1lhEmAfG(u0020);
				}
				if (u0020.CsRPppYOTY())
				{
					return ((BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ)u0020).MW1lhEmAfG(u0020);
				}
				if (u0020.FrXPreN9nq())
				{
					return ((BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U)u0020).MW1lhEmAfG(u0020);
				}
				if (!u0020.tpmPR9FfWH())
				{
					return u0020;
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).MW1lhEmAfG(u0020);
			}

			private static void kr6PHcrbwt(object u0020, int u0020)
			{
				switch (u0020)
				{
					case -1:
					{
						u0020.Emit(OpCodes.Ldc_I4_M1);
						return;
					}
					case 0:
					{
						u0020.Emit(OpCodes.Ldc_I4_0);
						return;
					}
					case 1:
					{
						u0020.Emit(OpCodes.Ldc_I4_1);
						return;
					}
					case 2:
					{
						u0020.Emit(OpCodes.Ldc_I4_2);
						return;
					}
					case 3:
					{
						u0020.Emit(OpCodes.Ldc_I4_3);
						return;
					}
					case 4:
					{
						u0020.Emit(OpCodes.Ldc_I4_4);
						return;
					}
					case 5:
					{
						u0020.Emit(OpCodes.Ldc_I4_5);
						return;
					}
					case 6:
					{
						u0020.Emit(OpCodes.Ldc_I4_6);
						return;
					}
					case 7:
					{
						u0020.Emit(OpCodes.Ldc_I4_7);
						return;
					}
					case 8:
					{
						u0020.Emit(OpCodes.Ldc_I4_8);
						return;
					}
					default:
					{
						if (u0020 <= -129 || u0020 >= 128)
						{
							break;
						}
						else
						{
							u0020.Emit(OpCodes.Ldc_I4_S, (sbyte)u0020);
							return;
						}
					}
				}
				u0020.Emit(OpCodes.Ldc_I4, u0020);
			}

			private static BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY KVOP8ERfLQ(object u0020, bool u0020, object u0020)
			{
				BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY = null;
				if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.CtcPOfDPwc.TryGetValue(u0020, out jLhxt0X7DCmV00GKOpY))
				{
					return jLhxt0X7DCmV00GKOpY;
				}
				ConstructorInfo constructorInfo = u0020 as ConstructorInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object), typeof(object[]) }, typeof(BRsI3YS41tRIm0CdPSm), true);
				ILGenerator lGenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = u0020.GetParameters();
				Type[] elementType = new Type[(int)parameters.Length];
				for (int i = 0; i < (int)elementType.Length; i++)
				{
					if (parameters[i].ParameterType.IsByRef)
					{
						elementType[i] = parameters[i].ParameterType.GetElementType();
					}
					else
					{
						elementType[i] = parameters[i].ParameterType;
					}
				}
				int length = (int)elementType.Length;
				if (u0020.DeclaringType.IsValueType)
				{
					length++;
				}
				LocalBuilder[] localBuilderArray = new LocalBuilder[length];
				for (int j = 0; j < (int)elementType.Length; j++)
				{
					if (u0020.smlX9Nw7nt(j))
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(typeof(object));
					}
					else
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(elementType[j]);
					}
				}
				if (u0020.DeclaringType.IsValueType)
				{
					localBuilderArray[(int)localBuilderArray.Length - 1] = lGenerator.DeclareLocal(u0020.DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < (int)elementType.Length; k++)
				{
					lGenerator.Emit(OpCodes.Ldarg_1);
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, k);
					lGenerator.Emit(OpCodes.Ldelem_Ref);
					if (!u0020.smlX9Nw7nt(k))
					{
						if (elementType[k].IsValueType)
						{
							lGenerator.Emit(OpCodes.Unbox_Any, elementType[k]);
						}
						else if (elementType[k] != typeof(object))
						{
							lGenerator.Emit(OpCodes.Castclass, elementType[k]);
						}
					}
					lGenerator.Emit(OpCodes.Stloc, localBuilderArray[k]);
				}
				for (int l = 0; l < (int)elementType.Length; l++)
				{
					if (u0020.smlX9Nw7nt(l))
					{
						BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB oOfeb5XkKsXpJwgStnB = u0020.xC4X3CIPxx(l);
						if (oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.IsStatic)
						{
							lGenerator.Emit(OpCodes.Ldsflda, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci);
						}
						else if (!oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.DeclaringType.IsValueType)
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Castclass, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci);
						}
						else
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Unbox, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, oOfeb5XkKsXpJwgStnB.JbMX89L6Ci);
						}
					}
					else if (parameters[l].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldloca_S, localBuilderArray[l]);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
					}
				}
				lGenerator.Emit(OpCodes.Newobj, u0020 as ConstructorInfo);
				if (constructorInfo.DeclaringType.IsValueType)
				{
					lGenerator.Emit(OpCodes.Box, constructorInfo.DeclaringType);
				}
				for (int m = 0; m < (int)elementType.Length; m++)
				{
					if (parameters[m].ParameterType.IsByRef)
					{
						if (u0020.smlX9Nw7nt(m))
						{
							BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB oOfeb5XkKsXpJwgStnB1 = u0020.xC4X3CIPxx(m);
							if (!oOfeb5XkKsXpJwgStnB1.JbMX89L6Ci.IsStatic)
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
								if (localBuilderArray[m].LocalType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
							else
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldsfld, oOfeb5XkKsXpJwgStnB1.JbMX89L6Ci);
								if (oOfeb5XkKsXpJwgStnB1.JbMX89L6Ci.FieldType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
						}
						else
						{
							lGenerator.Emit(OpCodes.Ldarg_1);
							BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.kr6PHcrbwt(lGenerator, m);
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
							if (localBuilderArray[m].LocalType.IsValueType)
							{
								lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
							}
							lGenerator.Emit(OpCodes.Stelem_Ref);
						}
					}
				}
				lGenerator.Emit(OpCodes.Ret);
				BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY1 = (BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY)dynamicMethod.CreateDelegate(typeof(BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY));
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.CtcPOfDPwc.Add(u0020, jLhxt0X7DCmV00GKOpY1);
				return jLhxt0X7DCmV00GKOpY1;
			}

			private static BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt lhDPGqr26t(object u0020)
			{
				if (u0020.R5MjgxNnyG().cB0PirV4Hs())
				{
					object obj = u0020.CvnlU3IXkO(null);
					if (obj != null && obj.GetType().IsEnum)
					{
						Type underlyingType = Enum.GetUnderlyingType(obj.GetType());
						object obj1 = Convert.ChangeType(obj, underlyingType);
						BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.F9CP3MCBGS(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(underlyingType, obj1));
						if (pDI0AUPFaaR24dXe0vt != null)
						{
							return pDI0AUPFaaR24dXe0vt as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
						}
					}
				}
				return u0020;
			}

			private static int R4IB0cuSjA(Type u0020)
			{
				int num;
				if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.pDiPgL0VDi == null)
				{
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.pDiPgL0VDi = new Dictionary<Type, int>();
				}
				try
				{
					int num1 = 0;
					if (!BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.pDiPgL0VDi.TryGetValue(u0020, out num1))
					{
						DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(int), Type.EmptyTypes, true);
						ILGenerator lGenerator = dynamicMethod.GetILGenerator();
						lGenerator.Emit(OpCodes.Sizeof, u0020);
						lGenerator.Emit(OpCodes.Ret);
						num1 = (int)dynamicMethod.Invoke(null, null);
						BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.pDiPgL0VDi[u0020] = num1;
						num = num1;
					}
					else
					{
						num = num1;
					}
				}
				catch
				{
					num = 0;
				}
				return num;
			}

			internal static BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I RcSTQikH9rnmHsnVpJlU()
			{
				return BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.M4DpCCkHGOVNuCgFeCT4;
			}

			internal void s0KXNniPPi(ref bool u0020)
			{
				while (true)
				{
					if (this.DhoPCkFW2H <= -2)
					{
						this.kxpPtJIMy4.bLcPoePGi1();
						break;
					}
					else
					{
						if (this.xPTPUnM962)
						{
							this.xPTPUnM962 = false;
							int gvsP2tCtHy = this.GvsP2tCtHy;
							int dhoPCkFW2H = this.DhoPCkFW2H;
							this.Ja4X2tO0AP(this.GvsP2tCtHy, this.DhoPCkFW2H);
							this.DhoPCkFW2H = dhoPCkFW2H;
							this.GvsP2tCtHy = gvsP2tCtHy;
						}
						if (this.OQqPvlPn82)
						{
							this.OQqPvlPn82 = false;
							return;
						}
						if (this.K4LPTCcv1n)
						{
							this.K4LPTCcv1n = false;
							return;
						}
						this.GvsP2tCtHy = this.DhoPCkFW2H;
						BRsI3YS41tRIm0CdPSm.klTxZLY2Hvtos3CbvnT item = this.CqHP4vveCn.Kp5YyMoCrK[this.DhoPCkFW2H];
						this.M69Ph76OUs = item.wn7YhLUPc1;
						try
						{
							this.wsRXUXATWj(item);
						}
						catch (Exception exception)
						{
							Exception innerException = exception;
							if (innerException is TargetInvocationException)
							{
								TargetInvocationException targetInvocationException = (TargetInvocationException)innerException;
								if (targetInvocationException.InnerException != null)
								{
									innerException = targetInvocationException.InnerException;
								}
							}
							this.y2TPwZO5TM = innerException;
							u0020 = true;
							this.kxpPtJIMy4.bLcPoePGi1();
							int num = this.GvsP2tCtHy;
							BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec o0ASV5Yx65d5pus25Ec = this.SfHXbfYwYN(num, innerException);
							List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec> o0ASV5Yx65d5pus25Ecs = this.vNqXhIhLun(num, false);
							List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec> o0ASV5Yx65d5pus25Ecs1 = new List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec>();
							if (o0ASV5Yx65d5pus25Ec != null)
							{
								o0ASV5Yx65d5pus25Ecs1.Add(o0ASV5Yx65d5pus25Ec);
							}
							if (o0ASV5Yx65d5pus25Ecs != null && o0ASV5Yx65d5pus25Ecs.Count > 0)
							{
								o0ASV5Yx65d5pus25Ecs1.AddRange(o0ASV5Yx65d5pus25Ecs);
							}
							o0ASV5Yx65d5pus25Ecs1.Sort((BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec x, BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec y) => x.sBiYAvW7NR.LOBYLK1Y3x.CompareTo(y.sBiYAvW7NR.LOBYLK1Y3x));
							BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec o0ASV5Yx65d5pus25Ec1 = null;
							List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec>.Enumerator enumerator = o0ASV5Yx65d5pus25Ecs1.GetEnumerator();
							try
							{
								while (true)
								{
									if (enumerator.MoveNext())
									{
										BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec current = enumerator.Current;
										if (current.sBiYAvW7NR.KrNYmeU4BI == 0)
										{
											o0ASV5Yx65d5pus25Ec1 = current;
											break;
										}
										else
										{
											this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(innerException));
											this.GvsP2tCtHy = current.sBiYAvW7NR.aUGYo4U3DZ;
											this.DhoPCkFW2H = this.GvsP2tCtHy;
											this.Ge9XQom4kh();
											if (this.Ms6PaJpOOL)
											{
												this.Ms6PaJpOOL = false;
												o0ASV5Yx65d5pus25Ec1 = current;
												break;
											}
										}
									}
									else
									{
										break;
									}
								}
							}
							finally
							{
								((IDisposable)enumerator).Dispose();
							}
							if (o0ASV5Yx65d5pus25Ec1 == null)
							{
								throw innerException;
							}
							this.vGoPbqKVrt = o0ASV5Yx65d5pus25Ec1.sBiYAvW7NR.LOBYLK1Y3x;
							this.t2sXCHLfZf(num, o0ASV5Yx65d5pus25Ec1.sBiYAvW7NR.LOBYLK1Y3x);
							if (this.vGoPbqKVrt >= 0)
							{
								this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(innerException));
								this.GvsP2tCtHy = this.vGoPbqKVrt;
								this.DhoPCkFW2H = this.GvsP2tCtHy;
								this.vGoPbqKVrt = -1;
								this.Ge9XQom4kh();
							}
							break;
						}
						this.DhoPCkFW2H++;
					}
				}
			}

			internal BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec SfHXbfYwYN(int u0020, Exception u0020)
			{
				BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec o0ASV5Yx65d5pus25Ec = null;
				if (this.CqHP4vveCn.YYpXqh68Cp != null)
				{
					foreach (BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec yYpXqh68Cp in this.CqHP4vveCn.YYpXqh68Cp)
					{
						if (yYpXqh68Cp.sBiYAvW7NR.KrNYmeU4BI != 0 || !(yYpXqh68Cp.sBiYAvW7NR.cJtYdoaxLX == u0020.GetType()) && (!(yYpXqh68Cp.sBiYAvW7NR.cJtYdoaxLX != null) || !(yYpXqh68Cp.sBiYAvW7NR.cJtYdoaxLX.FullName == u0020.GetType().FullName) && !(yYpXqh68Cp.sBiYAvW7NR.cJtYdoaxLX.FullName == typeof(object).FullName) && !(yYpXqh68Cp.sBiYAvW7NR.cJtYdoaxLX.FullName == typeof(Exception).FullName)) || u0020 < yYpXqh68Cp.YWgY1NLXY6 || u0020 > yYpXqh68Cp.QFPYKAFenG)
						{
							continue;
						}
						if (o0ASV5Yx65d5pus25Ec != null)
						{
							if (yYpXqh68Cp.sBiYAvW7NR.LOBYLK1Y3x >= o0ASV5Yx65d5pus25Ec.sBiYAvW7NR.LOBYLK1Y3x)
							{
								continue;
							}
							o0ASV5Yx65d5pus25Ec = yYpXqh68Cp;
						}
						else
						{
							o0ASV5Yx65d5pus25Ec = yYpXqh68Cp;
						}
					}
				}
				return o0ASV5Yx65d5pus25Ec;
			}

			private static BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D sLaB5jbCG2(object u0020)
			{
				BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D = u0020 as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				if (mXLA9LY4pdeld88e55D == null && u0020.oJVj0o8M8s())
				{
					mXLA9LY4pdeld88e55D = u0020.R5MjgxNnyG() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				}
				return mXLA9LY4pdeld88e55D;
			}

			internal void t2sXCHLfZf(int u0020, int u0020)
			{
				if (this.CqHP4vveCn.YYpXqh68Cp != null)
				{
					foreach (BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec yYpXqh68Cp in this.CqHP4vveCn.YYpXqh68Cp)
					{
						if (yYpXqh68Cp.sBiYAvW7NR.KrNYmeU4BI != 4 && yYpXqh68Cp.sBiYAvW7NR.KrNYmeU4BI != 2 || yYpXqh68Cp.sBiYAvW7NR.LOBYLK1Y3x < u0020 || yYpXqh68Cp.sBiYAvW7NR.mJ2YJqCDCf > u0020)
						{
							continue;
						}
						this.GvsP2tCtHy = yYpXqh68Cp.sBiYAvW7NR.LOBYLK1Y3x;
						this.DhoPCkFW2H = this.GvsP2tCtHy;
						bool flag = false;
						this.s0KXNniPPi(ref flag);
						if (!flag)
						{
							continue;
						}
						return;
					}
				}
			}

			private static object tfyPsRBjdw(object u0020)
			{
				BRsI3YS41tRIm0CdPSm.ORWUaLX4jmnc2O81rRo oRWUaLX4jmnc2O81rRo;
				object obj;
				if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.PfEPBwpjXn == null)
				{
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.PfEPBwpjXn = new Dictionary<Type, BRsI3YS41tRIm0CdPSm.ORWUaLX4jmnc2O81rRo>();
				}
				if (u0020 == null)
				{
					return null;
				}
				try
				{
					Type type = u0020.GetType();
					if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.PfEPBwpjXn.TryGetValue(type, out oRWUaLX4jmnc2O81rRo))
					{
						obj = oRWUaLX4jmnc2O81rRo(u0020);
					}
					else
					{
						DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object) }, true);
						ILGenerator lGenerator = dynamicMethod.GetILGenerator();
						lGenerator.Emit(OpCodes.Ldarg_0);
						lGenerator.Emit(OpCodes.Unbox_Any, type);
						lGenerator.Emit(OpCodes.Box, type);
						lGenerator.Emit(OpCodes.Ret);
						BRsI3YS41tRIm0CdPSm.ORWUaLX4jmnc2O81rRo oRWUaLX4jmnc2O81rRo1 = (BRsI3YS41tRIm0CdPSm.ORWUaLX4jmnc2O81rRo)dynamicMethod.CreateDelegate(typeof(BRsI3YS41tRIm0CdPSm.ORWUaLX4jmnc2O81rRo));
						BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.PfEPBwpjXn.Add(type, oRWUaLX4jmnc2O81rRo1);
						obj = oRWUaLX4jmnc2O81rRo1(u0020);
					}
				}
				catch
				{
					obj = null;
				}
				return obj;
			}

			internal List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec> vNqXhIhLun(int u0020, bool u0020)
			{
				if (this.CqHP4vveCn.YYpXqh68Cp == null)
				{
					return null;
				}
				List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec> o0ASV5Yx65d5pus25Ecs = new List<BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec>();
				foreach (BRsI3YS41tRIm0CdPSm.O0ASV5Yx65d5pus25Ec yYpXqh68Cp in this.CqHP4vveCn.YYpXqh68Cp)
				{
					if ((yYpXqh68Cp.sBiYAvW7NR.KrNYmeU4BI & 1) != 1 || u0020 < yYpXqh68Cp.YWgY1NLXY6 || u0020 > yYpXqh68Cp.QFPYKAFenG)
					{
						continue;
					}
					o0ASV5Yx65d5pus25Ecs.Add(yYpXqh68Cp);
				}
				if (o0ASV5Yx65d5pus25Ecs.Count == 0)
				{
					return null;
				}
				return o0ASV5Yx65d5pus25Ecs;
			}

			private static void wBYP7DUvyA(IntPtr u0020, IntPtr u0020, uint u0020)
			{
				if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.r41PlK88Om == null)
				{
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(void), new Type[] { typeof(IntPtr), typeof(IntPtr), typeof(uint) }, typeof(BRsI3YS41tRIm0CdPSm), true);
					ILGenerator lGenerator = dynamicMethod.GetILGenerator();
					lGenerator.Emit(OpCodes.Ldarg_0);
					lGenerator.Emit(OpCodes.Ldarg_1);
					lGenerator.Emit(OpCodes.Ldarg_2);
					lGenerator.Emit(OpCodes.Cpblk);
					lGenerator.Emit(OpCodes.Ret);
					BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.r41PlK88Om = (BRsI3YS41tRIm0CdPSm.Kkc65eX66JfXDDeYYwQ)dynamicMethod.CreateDelegate(typeof(BRsI3YS41tRIm0CdPSm.Kkc65eX66JfXDDeYYwQ));
				}
				BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.r41PlK88Om(u0020, u0020, u0020);
			}

			private void wsRXUXATWj(BRsI3YS41tRIm0CdPSm.klTxZLY2Hvtos3CbvnT u0020)
			{
				bool flag;
				BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D;
				object value;
				BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D1;
				IntPtr intPtr;
				object obj;
				FieldInfo fieldInfo;
				Type elementType;
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt j73ZKePAQS1jY9pDRn8;
				int m69Ph76OUs;
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt;
				Module module;
				uint gO8SlOKscJ;
				Array arrays;
				long r6BSVkv4SB;
				switch (u0020.mEJYbEIsgP)
				{
					case 0:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.rtwjNgsk8H(mXLA9LY4pdeld88e55D));
						return;
					}
					case 1:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = (BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)this.kxpPtJIMy4.daUPcrrcU3();
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.GthjMfGJXk(mXLA9LY4pdeld88e55D));
						return;
					}
					case 2:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null || mXLA9LY4pdeld88e55D1 == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.MuDj2ESVFd(mXLA9LY4pdeld88e55D1));
						return;
					}
					case 3:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.hoJlAy9b0V());
						return;
					}
					case 4:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						value = this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
						BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.dbGPWsIaD7[value] = j73ZKePAQS1jY9pDRn8;
						return;
					}
					case 5:
					{
						arrays = (Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(arrays.Length, 5));
						return;
					}
					case 6:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(sbyte), value));
						return;
					}
					case 7:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.u7ijtkwXum(mXLA9LY4pdeld88e55D));
						return;
					}
					case 8:
					{
						throw (Exception)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
					}
					case 9:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.kl5ld64bfA());
						return;
					}
					case 10:
					case 49:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						value = j73ZKePAQS1jY9pDRn8.CvnlU3IXkO(elementType);
						if (value != null)
						{
							if (elementType.IsValueType)
							{
								value = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.tfyPsRBjdw(value);
							}
							j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value);
						}
						else if (!elementType.IsValueType)
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null);
						}
						else
						{
							value = Activator.CreateInstance(elementType);
							j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value);
						}
						BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ _vlDU7kYUiRiPNypdIDJ = this.kxpPtJIMy4.daUPcrrcU3() as BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ;
						if (_vlDU7kYUiRiPNypdIDJ == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						_vlDU7kYUiRiPNypdIDJ.hsKlwaTTVG(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 11:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.Gavl0MZqqr());
						return;
					}
					case 12:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 13:
					{
						BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt1 = this.kxpPtJIMy4.daUPcrrcU3();
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (pDI0AUPFaaR24dXe0vt1.evOjuZejQG(j73ZKePAQS1jY9pDRn8))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 14:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.nDklnP9uew());
						return;
					}
					case 15:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (!j73ZKePAQS1jY9pDRn8.oJVj0o8M8s())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						value = j73ZKePAQS1jY9pDRn8.CvnlU3IXkO(null);
						if (value != null)
						{
							j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(value.GetType(), value);
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null);
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 16:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)this.M69Ph76OUs));
						return;
					}
					case 17:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8.SgSjiMaCIn())
						{
							j73ZKePAQS1jY9pDRn8 = ((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)j73ZKePAQS1jY9pDRn8).HeNlB8VrPZ();
						}
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 18:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.AQblmacrWV());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((float)(*(void*)intPtr), 9));
						return;
					}
					case 19:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null));
						return;
					}
					case 20:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.mfnlFkZV24());
						return;
					}
					case 21:
					case 34:
					case 37:
					case 56:
					case 108:
					case 109:
					case 113:
					case 150:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						Array arrays1 = (Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
						elementType = arrays1.GetType().GetElementType();
						arrays1.SetValue(j73ZKePAQS1jY9pDRn8.CvnlU3IXkO(elementType), mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						return;
					}
					case 22:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(double), value));
						return;
					}
					case 23:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(short), value));
						return;
					}
					case 24:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8.SgSjiMaCIn())
						{
							j73ZKePAQS1jY9pDRn8 = ((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)j73ZKePAQS1jY9pDRn8).ysWllqqkwZ();
						}
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 25:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.Ni9j4tniIe(mXLA9LY4pdeld88e55D));
						return;
					}
					case 26:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						value = j73ZKePAQS1jY9pDRn8.CvnlU3IXkO(null);
						if (value == null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null));
							return;
						}
						if (elementType.IsAssignableFrom(value.GetType()))
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(j73ZKePAQS1jY9pDRn8);
							return;
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null));
						return;
					}
					case 27:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.YNwj8YIExi());
						return;
					}
					case 28:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.jT9ljPZtDi());
						return;
					}
					case 29:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)this.M69Ph76OUs));
						return;
					}
					case 30:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).oc0jO1XWAQ(j73ZKePAQS1jY9pDRn8))
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1));
							return;
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0));
						return;
					}
					case 31:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						if (this.CqHP4vveCn.OrjYcfiCq7.IsStatic)
						{
							this.MnCPIjta1t[m69Ph76OUs] = this.JYZXvLSAki(this.kxpPtJIMy4.daUPcrrcU3(), this.CqHP4vveCn.ffCYE6MCG5[m69Ph76OUs].pOFYRFQprs, false);
							return;
						}
						this.MnCPIjta1t[m69Ph76OUs] = this.JYZXvLSAki(this.kxpPtJIMy4.daUPcrrcU3(), this.CqHP4vveCn.ffCYE6MCG5[m69Ph76OUs - 1].pOFYRFQprs, false);
						return;
					}
					case 32:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.d0GlRc2a7L());
						return;
					}
					case 33:
					case 43:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						module = typeof(BRsI3YS41tRIm0CdPSm).Module;
						BRsI3YS41tRIm0CdPSm.O0bRICPdRH7uXLNciXu o0bRICPdRH7uXLNciXu = this.kxpPtJIMy4;
						RuntimeMethodHandle methodHandle = module.ResolveMethod(m69Ph76OUs).MethodHandle;
						o0bRICPdRH7uXLNciXu.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(methodHandle.GetFunctionPointer()));
						return;
					}
					case 35:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.YQPl1OGXpG());
						return;
					}
					case 36:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).THajPMZMuT(j73ZKePAQS1jY9pDRn8))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 38:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).oc0jO1XWAQ(j73ZKePAQS1jY9pDRn8))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 39:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.wGllDQeBGn());
						return;
					}
					case 40:
					case 73:
					case 127:
					case 137:
					case 145:
					case 152:
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					case 41:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.W15lPh5RC4());
						return;
					}
					case 42:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8.SgSjiMaCIn())
						{
							j73ZKePAQS1jY9pDRn8 = ((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)j73ZKePAQS1jY9pDRn8).AQblmacrWV();
						}
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 44:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						fieldInfo = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveField(m69Ph76OUs);
						value = this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(fieldInfo.FieldType);
						fieldInfo.SetValue(null, value);
						return;
					}
					case 45:
					{
						this.DhoPCkFW2H = -3;
						if (this.kxpPtJIMy4.xLqe4PZWEH() > 0)
						{
							this.xivPQGYE5d = this.kxpPtJIMy4.daUPcrrcU3();
						}
						return;
					}
					case 46:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						bool hQq = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).buqjZToHQq(j73ZKePAQS1jY9pDRn8);
						if (hQq)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1));
							if (!hQq)
							{
								return;
							}
						}
						else
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0));
							if (!hQq)
							{
								return;
							}
						}
						this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						return;
					}
					case 47:
					{
						j73ZKePAQS1jY9pDRn8 = this.pm0P6am0Ua[(int)this.M69Ph76OUs];
						this.kxpPtJIMy4.lKnPmFQ2gZ(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 48:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						value = this.kxpPtJIMy4.daUPcrrcU3().R5MjgxNnyG().CvnlU3IXkO(elementType);
						j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value);
						this.kxpPtJIMy4.lKnPmFQ2gZ(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 50:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.RkFjUgwliF(mXLA9LY4pdeld88e55D));
						return;
					}
					case 51:
					{
						value = this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
						j73ZKePAQS1jY9pDRn8 = null;
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.dbGPWsIaD7.TryGetValue(value, out j73ZKePAQS1jY9pDRn8))
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(j73ZKePAQS1jY9pDRn8);
							return;
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null));
						return;
					}
					case 52:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(byte), value));
						return;
					}
					case 53:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null || mXLA9LY4pdeld88e55D1 == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.dHsjhXjesK(mXLA9LY4pdeld88e55D1));
						return;
					}
					case 54:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.HqHj7mcRQX(mXLA9LY4pdeld88e55D));
						return;
					}
					case 55:
					{
						int[] numArray = (int[])this.M69Ph76OUs;
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						r6BSVkv4SB = mXLA9LY4pdeld88e55D.FIglXEgdyQ().pkkSoR3xjG.R6BSVkv4SB;
						if ((r6BSVkv4SB < 0L || mXLA9LY4pdeld88e55D.FrXPreN9nq()) && IntPtr.Size == 4)
						{
							r6BSVkv4SB = (long)((int)r6BSVkv4SB);
						}
						if (mXLA9LY4pdeld88e55D.TOiP0fUvZ0())
						{
							BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W _rdueeLSZp3Asm7kVn7W = (BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)mXLA9LY4pdeld88e55D;
							if ((int)_rdueeLSZp3Asm7kVn7W.FruSpXH759 == 6)
							{
								r6BSVkv4SB = (long)_rdueeLSZp3Asm7kVn7W.FH6SRpjuDo.GO8SlOKscJ;
							}
						}
						if (r6BSVkv4SB < (long)((int)numArray.Length) && r6BSVkv4SB >= 0L)
						{
							this.DhoPCkFW2H = numArray[checked((IntPtr)r6BSVkv4SB)] - 1;
						}
						return;
					}
					case 57:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.mfnlFkZV24());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)(*(void*)intPtr), 4));
						return;
					}
					case 58:
					{
						return;
					}
					case 59:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						fieldInfo = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveField(m69Ph76OUs);
						value = this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(fieldInfo.FieldType, fieldInfo.GetValue(value)));
						return;
					}
					case 60:
					case 64:
					case 72:
					case 142:
					case 146:
					case 164:
					{
						return;
					}
					case 61:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).cyBjla9WGE(j73ZKePAQS1jY9pDRn8))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 62:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).ThjjjOubV1(j73ZKePAQS1jY9pDRn8))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 63:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).ThjjjOubV1(j73ZKePAQS1jY9pDRn8))
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1));
							return;
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0));
						return;
					}
					case 65:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ _vlDU7kYUiRiPNypdIDJ1 = this.kxpPtJIMy4.daUPcrrcU3() as BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ;
						if (_vlDU7kYUiRiPNypdIDJ1 == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						value = _vlDU7kYUiRiPNypdIDJ1.CvnlU3IXkO(elementType);
						if (value != null)
						{
							if (elementType.IsValueType)
							{
								value = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.tfyPsRBjdw(value);
							}
							j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value);
						}
						else if (elementType.IsValueType)
						{
							value = Activator.CreateInstance(elementType);
							j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value);
						}
						else
						{
							j73ZKePAQS1jY9pDRn8 = new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null);
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 66:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						fieldInfo = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveField(m69Ph76OUs);
						BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt2 = this.kxpPtJIMy4.daUPcrrcU3();
						pDI0AUPFaaR24dXe0vt2.R5MjgxNnyG();
						value = pDI0AUPFaaR24dXe0vt2.CvnlU3IXkO(null);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR(fieldInfo, value));
						return;
					}
					case 67:
					{
						throw this.y2TPwZO5TM;
					}
					case 68:
					{
						BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D2 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.vipPDE7HfC());
						if (mXLA9LY4pdeld88e55D2 == null)
						{
							throw new ArithmeticException(0.ToString());
						}
						BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U eHXm1aYIujTVydILT4U = mXLA9LY4pdeld88e55D2 as BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U;
						if (eHXm1aYIujTVydILT4U != null)
						{
							if (double.IsNaN(eHXm1aYIujTVydILT4U.kqAY66YyLe))
							{
								throw new OverflowException(2.ToString());
							}
							if (double.IsInfinity(eHXm1aYIujTVydILT4U.kqAY66YyLe))
							{
								throw new OverflowException(1.ToString());
							}
						}
						return;
					}
					case 69:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)this.kxpPtJIMy4.daUPcrrcU3()).dMBjH0kCfL());
						return;
					}
					case 70:
					{
						this.kxpPtJIMy4.daUPcrrcU3();
						return;
					}
					case 71:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8.SgSjiMaCIn())
						{
							j73ZKePAQS1jY9pDRn8 = ((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)j73ZKePAQS1jY9pDRn8).zgLlyFEWVS();
						}
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 74:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.voYle2maYc());
						return;
					}
					case 75:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						fieldInfo = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveField(m69Ph76OUs);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(fieldInfo.FieldType, fieldInfo.GetValue(null)));
						return;
					}
					case 76:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.K2rjTSWTBP(mXLA9LY4pdeld88e55D));
						return;
					}
					case 77:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.M69Ph76OUs));
						return;
					}
					case 78:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(long), value));
						return;
					}
					case 79:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.B5rlJDOwmv());
						return;
					}
					case 80:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.cguj6B2iXY(mXLA9LY4pdeld88e55D));
						return;
					}
					case 81:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8.SgSjiMaCIn())
						{
							j73ZKePAQS1jY9pDRn8 = ((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)j73ZKePAQS1jY9pDRn8).wGllDQeBGn();
						}
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 82:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.b3DlZ1vlBC());
						return;
					}
					case 83:
					{
						this.OQqPvlPn82 = true;
						return;
					}
					case 84:
					{
						if (BRsI3YS41tRIm0CdPSm.MJOSv2PIde.Count != 0)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO(BRsI3YS41tRIm0CdPSm.MJOSv2PIde[(int)this.M69Ph76OUs]));
							return;
						}
						module = typeof(BRsI3YS41tRIm0CdPSm).Module;
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.dFvs3iPJkXy6416AWVO(module.ResolveString((int)this.M69Ph76OUs | 1879048192)));
						return;
					}
					case 85:
					{
						if (this.kxpPtJIMy4.daUPcrrcU3().KyQjSu10fI(this.kxpPtJIMy4.daUPcrrcU3()))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 86:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.hWSlLTopa3());
						return;
					}
					case 87:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						fieldInfo = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveField(m69Ph76OUs);
						value = this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(fieldInfo.FieldType);
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						obj = j73ZKePAQS1jY9pDRn8.CvnlU3IXkO(null);
						if (obj == null)
						{
							elementType = fieldInfo.DeclaringType;
							if (elementType.IsByRef)
							{
								elementType = elementType.GetElementType();
							}
							if (!elementType.IsValueType)
							{
								throw new NullReferenceException();
							}
							obj = Activator.CreateInstance(elementType);
							if (j73ZKePAQS1jY9pDRn8 is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)
							{
								((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)j73ZKePAQS1jY9pDRn8).qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, obj));
							}
						}
						fieldInfo.SetValue(obj, value);
						return;
					}
					case 88:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).EaCjXoObXK(j73ZKePAQS1jY9pDRn8))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 89:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.HeNlB8VrPZ());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((sbyte)(*(void*)intPtr), 1));
						return;
					}
					case 90:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						fieldInfo = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveField(m69Ph76OUs);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR(fieldInfo, null));
						return;
					}
					case 91:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((float)this.M69Ph76OUs));
						return;
					}
					case 92:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.wNijkq3Yt8());
						return;
					}
					case 93:
					{
						mXLA9LY4pdeld88e55D = this.kxpPtJIMy4.daUPcrrcU3() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
						intPtr = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.cALP9r5N9q(this.kxpPtJIMy4.daUPcrrcU3());
						IntPtr intPtr1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.cALP9r5N9q(this.kxpPtJIMy4.daUPcrrcU3());
						if (intPtr != IntPtr.Zero && intPtr1 != IntPtr.Zero)
						{
							gO8SlOKscJ = mXLA9LY4pdeld88e55D.qqRlYZcuq0().FH6SRpjuDo.GO8SlOKscJ;
							BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.wBYP7DUvyA(intPtr1, intPtr, gO8SlOKscJ);
						}
						return;
					}
					case 94:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY((int)this.M69Ph76OUs, this));
						return;
					}
					case 95:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.z3gjqNHGw8());
						return;
					}
					case 96:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(this.MnCPIjta1t[(int)this.M69Ph76OUs]);
						return;
					}
					case 97:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (!BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).buqjZToHQq(j73ZKePAQS1jY9pDRn8))
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0));
							return;
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1));
						return;
					}
					case 98:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						ConstructorInfo constructorInfo = (ConstructorInfo)typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveMethod(m69Ph76OUs);
						ParameterInfo[] parameters = constructorInfo.GetParameters();
						object[] objArray = new object[(int)parameters.Length];
						BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[] pDI0AUPFaaR24dXe0vtArray = new BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[(int)parameters.Length];
						List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB> oOfeb5XkKsXpJwgStnBs = null;
						BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe _fqT0ysXGZ6B4R0ihqVe = null;
						for (int i = 0; i < (int)parameters.Length; i++)
						{
							j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
							elementType = parameters[(int)parameters.Length - 1 - i].ParameterType;
							obj = null;
							flag = false;
							if (elementType.IsByRef)
							{
								BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR _sag78IYS7BLZBHUWApR = j73ZKePAQS1jY9pDRn8 as BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR;
								if (_sag78IYS7BLZBHUWApR != null)
								{
									if (oOfeb5XkKsXpJwgStnBs == null)
									{
										oOfeb5XkKsXpJwgStnBs = new List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB>();
									}
									oOfeb5XkKsXpJwgStnBs.Add(new BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB(_sag78IYS7BLZBHUWApR.jRyYYOKBSg, i));
									obj = _sag78IYS7BLZBHUWApR.fIjYX8KMAw;
									if (!(obj is BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt))
									{
										flag = true;
									}
									else
									{
										j73ZKePAQS1jY9pDRn8 = obj as BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt;
									}
								}
							}
							if (!flag)
							{
								if (j73ZKePAQS1jY9pDRn8 != null)
								{
									obj = j73ZKePAQS1jY9pDRn8.CvnlU3IXkO(elementType);
								}
								if (obj == null)
								{
									if (elementType.IsByRef)
									{
										elementType = elementType.GetElementType();
									}
									if (elementType.IsValueType)
									{
										obj = Activator.CreateInstance(elementType);
										if (j73ZKePAQS1jY9pDRn8 is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)
										{
											((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)j73ZKePAQS1jY9pDRn8).qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, obj));
										}
									}
								}
							}
							pDI0AUPFaaR24dXe0vtArray[(int)objArray.Length - 1 - i] = j73ZKePAQS1jY9pDRn8;
							objArray[(int)objArray.Length - 1 - i] = obj;
						}
						BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY = null;
						if (oOfeb5XkKsXpJwgStnBs != null)
						{
							_fqT0ysXGZ6B4R0ihqVe = new BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe(constructorInfo, oOfeb5XkKsXpJwgStnBs);
							jLhxt0X7DCmV00GKOpY = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.KVOP8ERfLQ(constructorInfo, true, _fqT0ysXGZ6B4R0ihqVe);
						}
						value = null;
						value = (jLhxt0X7DCmV00GKOpY != null ? jLhxt0X7DCmV00GKOpY(null, objArray) : constructorInfo.Invoke(objArray));
						for (int j = 0; j < (int)parameters.Length; j++)
						{
							if (parameters[j].ParameterType.IsByRef && (_fqT0ysXGZ6B4R0ihqVe == null || !_fqT0ysXGZ6B4R0ihqVe.smlX9Nw7nt(j)))
							{
								if (pDI0AUPFaaR24dXe0vtArray[j].tpmPR9FfWH())
								{
									((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)pDI0AUPFaaR24dXe0vtArray[j]).XcTSc6GmkQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(parameters[j].ParameterType, objArray[j]));
								}
								else if (pDI0AUPFaaR24dXe0vtArray[j] is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)
								{
									pDI0AUPFaaR24dXe0vtArray[j].hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(parameters[j].ParameterType.GetElementType(), objArray[j]));
								}
								else
								{
									pDI0AUPFaaR24dXe0vtArray[j].hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(parameters[j].ParameterType, objArray[j]));
								}
							}
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(constructorInfo.DeclaringType, value));
						return;
					}
					case 99:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.aV0lp8koBT());
						return;
					}
					case 100:
					{
						intPtr = Marshal.AllocHGlobal((this.kxpPtJIMy4.daUPcrrcU3() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D).oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						if (this.KAyPNNvZUm == null)
						{
							this.KAyPNNvZUm = new List<IntPtr>();
						}
						this.KAyPNNvZUm.Add(intPtr);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(intPtr));
						return;
					}
					case 101:
					{
						mXLA9LY4pdeld88e55D = this.kxpPtJIMy4.daUPcrrcU3() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
						mXLA9LY4pdeld88e55D1 = this.kxpPtJIMy4.daUPcrrcU3() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
						intPtr = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.cALP9r5N9q(this.kxpPtJIMy4.daUPcrrcU3());
						if (intPtr != IntPtr.Zero)
						{
							byte nn1SX233sl = mXLA9LY4pdeld88e55D1.bSylgOD1Tv().FH6SRpjuDo.Nn1SX233sl;
							gO8SlOKscJ = mXLA9LY4pdeld88e55D.qqRlYZcuq0().FH6SRpjuDo.GO8SlOKscJ;
							BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.iSkPMbDLGQ(intPtr, nn1SX233sl, (int)gO8SlOKscJ);
						}
						return;
					}
					case 102:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.H3GloK8YWW());
						return;
					}
					case 103:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.jT9ljPZtDi());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)(*(void*)intPtr), 7));
						return;
					}
					case 104:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.rrtlzquJpy());
						return;
					}
					case 105:
					{
						this.YeJBzg7tu7(true);
						return;
					}
					case 106:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null || mXLA9LY4pdeld88e55D1 == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.u6QjCWlWMF(mXLA9LY4pdeld88e55D1));
						return;
					}
					case 107:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.s7Oj3eIaoc(mXLA9LY4pdeld88e55D));
						return;
					}
					case 110:
					{
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType((int)this.M69Ph76OUs);
						value = this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(elementType) ?? Activator.CreateInstance(elementType);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.tfyPsRBjdw(value))));
						return;
					}
					case 111:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						Array arrays2 = (Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
						value = arrays2.GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						elementType = arrays2.GetType().GetElementType();
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value));
						return;
					}
					case 112:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ _vlDU7kYUiRiPNypdIDJ2 = this.kxpPtJIMy4.daUPcrrcU3() as BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ;
						if (_vlDU7kYUiRiPNypdIDJ2 == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						if (!elementType.IsValueType)
						{
							_vlDU7kYUiRiPNypdIDJ2.qVnjpWd3hb(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null));
							return;
						}
						value = Activator.CreateInstance(elementType);
						_vlDU7kYUiRiPNypdIDJ2.qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value));
						return;
					}
					case 114:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.HeNlB8VrPZ());
						return;
					}
					case 115:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.zgLlyFEWVS());
						return;
					}
					case 116:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						gO8SlOKscJ = (uint)BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.R4IB0cuSjA(typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs));
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(gO8SlOKscJ, 6));
						return;
					}
					case 117:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(this.kxpPtJIMy4.vipPDE7HfC());
						return;
					}
					case 118:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.W15lPh5RC4());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((short)(*(void*)intPtr), 3));
						return;
					}
					case 119:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.QHqj9kqOCA(mXLA9LY4pdeld88e55D));
						return;
					}
					case 120:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.B7GliJVwUR());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((uint)(*(void*)intPtr), 6));
						return;
					}
					case 121:
					{
						this.YeJBzg7tu7(false);
						return;
					}
					case 122:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.wGllDQeBGn());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)(*(void*)intPtr), 10));
						return;
					}
					case 123:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.DP7lfDqxDB());
						return;
					}
					case 124:
					{
						flag = false;
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						flag = (j73ZKePAQS1jY9pDRn8 != null ? !j73ZKePAQS1jY9pDRn8.CJ4lvqi9kG() : true);
						if (flag)
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 125:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.x2GlKaLfLY());
						return;
					}
					case 126:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						Type type = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						arrays = Array.CreateInstance(type, mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(arrays));
						return;
					}
					case 128:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.JQ5l5Gionr());
						return;
					}
					case 129:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.AQblmacrWV());
						return;
					}
					case 130:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(this.kxpPtJIMy4.daUPcrrcU3().R5MjgxNnyG());
						return;
					}
					case 131:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.rT4jQ5XUP4(mXLA9LY4pdeld88e55D));
						return;
					}
					case 132:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.SOglrKDlkM());
						return;
					}
					case 133:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						pDI0AUPFaaR24dXe0vt = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(pDI0AUPFaaR24dXe0vt);
						if (mXLA9LY4pdeld88e55D1 != null && mXLA9LY4pdeld88e55D != null)
						{
							if (mXLA9LY4pdeld88e55D1.M2ijBdfvCo(j73ZKePAQS1jY9pDRn8))
							{
								this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1));
								return;
							}
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0));
							return;
						}
						if (j73ZKePAQS1jY9pDRn8.KyQjSu10fI(pDI0AUPFaaR24dXe0vt))
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1));
							return;
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0));
						return;
					}
					case 134:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(float), value));
						return;
					}
					case 135:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(int), value));
						return;
					}
					case 136:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.q0PjsQJ2ps(mXLA9LY4pdeld88e55D));
						return;
					}
					case 138:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.T5Ojba52SB());
						return;
					}
					case 139:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.B7GliJVwUR());
						return;
					}
					case 140:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.hdRlcPQNJV());
						return;
					}
					case 141:
					{
						this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						this.xPTPUnM962 = true;
						return;
					}
					case 143:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).SetValue(j73ZKePAQS1jY9pDRn8.CvnlU3IXkO(elementType), mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						return;
					}
					case 144:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.CJ4lvqi9kG())
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 147:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						this.pm0P6am0Ua[m69Ph76OUs] = this.JYZXvLSAki(this.kxpPtJIMy4.daUPcrrcU3(), this.CqHP4vveCn.KOhYzR5bYd[m69Ph76OUs].IZTYnytKfE, this.CqHP4vveCn.KOhYzR5bYd[m69Ph76OUs].vcRYeCHnUg);
						return;
					}
					case 148:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.dKTlxkpj1Q());
						return;
					}
					case 149:
					{
						BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt3 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.lhDPGqr26t(this.kxpPtJIMy4.daUPcrrcU3());
						j73ZKePAQS1jY9pDRn8 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.lhDPGqr26t(this.kxpPtJIMy4.daUPcrrcU3());
						if (!pDI0AUPFaaR24dXe0vt3.evOjuZejQG(j73ZKePAQS1jY9pDRn8))
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(0));
							return;
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(1));
						return;
					}
					case 151:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.qXRjGWmv0L(mXLA9LY4pdeld88e55D));
						return;
					}
					case 153:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.s6tjIept8c(mXLA9LY4pdeld88e55D));
						return;
					}
					case 154:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.lVclVGHGWb());
						return;
					}
					case 155:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(ushort), value));
						return;
					}
					case 156:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3()).Se8jY4rJ7g(j73ZKePAQS1jY9pDRn8))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 157:
					{
						this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						return;
					}
					case 158:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8.SgSjiMaCIn())
						{
							j73ZKePAQS1jY9pDRn8 = ((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)j73ZKePAQS1jY9pDRn8).jT9ljPZtDi();
						}
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 159:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						if (j73ZKePAQS1jY9pDRn8.SgSjiMaCIn())
						{
							j73ZKePAQS1jY9pDRn8 = ((BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D)j73ZKePAQS1jY9pDRn8).W15lPh5RC4();
						}
						this.kxpPtJIMy4.daUPcrrcU3().fVJlNHULc6(j73ZKePAQS1jY9pDRn8);
						return;
					}
					case 160:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(IntPtr), value));
						return;
					}
					case 161:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.ysWllqqkwZ());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)(*(void*)intPtr), 5));
						return;
					}
					case 162:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						pDI0AUPFaaR24dXe0vt = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(pDI0AUPFaaR24dXe0vt);
						if (mXLA9LY4pdeld88e55D1 != null && mXLA9LY4pdeld88e55D != null)
						{
							if (mXLA9LY4pdeld88e55D1.M2ijBdfvCo(j73ZKePAQS1jY9pDRn8))
							{
								this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
							}
							return;
						}
						if (j73ZKePAQS1jY9pDRn8.KyQjSu10fI(pDI0AUPFaaR24dXe0vt))
						{
							this.DhoPCkFW2H = (int)this.M69Ph76OUs - 1;
						}
						return;
					}
					case 163:
					{
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB((int)this.M69Ph76OUs, this));
						return;
					}
					case 165:
					{
						this.Ms6PaJpOOL = (bool)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(typeof(bool));
						this.K4LPTCcv1n = true;
						return;
					}
					case 166:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.b3DlZ1vlBC());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)(*(void*)intPtr), 2));
						return;
					}
					case 167:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						arrays = (Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.glyqPoYg91qSdBh3NXc(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU, arrays));
						return;
					}
					case 168:
					{
						j73ZKePAQS1jY9pDRn8 = this.kxpPtJIMy4.daUPcrrcU3();
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(j73ZKePAQS1jY9pDRn8);
						if (j73ZKePAQS1jY9pDRn8 != null && j73ZKePAQS1jY9pDRn8.oJVj0o8M8s() && mXLA9LY4pdeld88e55D != null)
						{
							this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.zgLlyFEWVS());
							return;
						}
						if (mXLA9LY4pdeld88e55D == null || !mXLA9LY4pdeld88e55D.tpmPR9FfWH())
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						intPtr = ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)mXLA9LY4pdeld88e55D).dkNSy1bnDX();
						if (IntPtr.Size == 8)
						{
							r6BSVkv4SB = (long)(*(void*)intPtr);
							this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(r6BSVkv4SB, 12));
							return;
						}
						m69Ph76OUs = (int)(*(void*)intPtr);
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)m69Ph76OUs, 12));
						return;
					}
					case 169:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.cGxlEOFbUS());
						return;
					}
					case 170:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.VkljwO21ED(mXLA9LY4pdeld88e55D));
						return;
					}
					case 171:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						elementType = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveType(m69Ph76OUs);
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(elementType, value));
						return;
					}
					case 172:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						value = ((Array)this.kxpPtJIMy4.daUPcrrcU3().CvnlU3IXkO(null)).GetValue(mXLA9LY4pdeld88e55D.oHqlSW6b45().FH6SRpjuDo.NFySjw3NeU);
						this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(typeof(uint), value));
						return;
					}
					case 173:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D.ysWllqqkwZ());
						return;
					}
					case 174:
					{
						m69Ph76OUs = (int)this.M69Ph76OUs;
						module = typeof(BRsI3YS41tRIm0CdPSm).Module;
						value = null;
						try
						{
							value = module.ResolveType(m69Ph76OUs);
						}
						catch
						{
							try
							{
								value = module.ResolveMethod(m69Ph76OUs);
							}
							catch
							{
								try
								{
									value = module.ResolveField(m69Ph76OUs);
								}
								catch
								{
									value = module.ResolveMember(m69Ph76OUs);
								}
							}
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(value));
						return;
					}
					case 175:
					{
						mXLA9LY4pdeld88e55D = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						mXLA9LY4pdeld88e55D1 = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.sLaB5jbCG2(this.kxpPtJIMy4.daUPcrrcU3());
						if (mXLA9LY4pdeld88e55D1 == null || mXLA9LY4pdeld88e55D == null)
						{
							throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
						}
						this.kxpPtJIMy4.lKnPmFQ2gZ(mXLA9LY4pdeld88e55D1.LX3jvRuP7O(mXLA9LY4pdeld88e55D));
						return;
					}
					default:
					{
						return;
					}
				}
			}

			private void YeJBzg7tu7(bool u0020)
			{
				int m69Ph76OUs = (int)this.M69Ph76OUs;
				MethodBase methodBase = typeof(BRsI3YS41tRIm0CdPSm).Module.ResolveMethod(m69Ph76OUs);
				MethodInfo methodInfo = methodBase as MethodInfo;
				ParameterInfo[] parameters = methodBase.GetParameters();
				object[] objArray = new object[(int)parameters.Length];
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[] pDI0AUPFaaR24dXe0vtArray = new BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt[(int)parameters.Length];
				List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB> oOfeb5XkKsXpJwgStnBs = null;
				BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe _fqT0ysXGZ6B4R0ihqVe = null;
				for (int i = 0; i < (int)parameters.Length; i++)
				{
					BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = this.kxpPtJIMy4.daUPcrrcU3();
					Type parameterType = parameters[(int)parameters.Length - 1 - i].ParameterType;
					object obj = null;
					bool flag = false;
					if (parameterType.IsByRef)
					{
						BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR _sag78IYS7BLZBHUWApR = pDI0AUPFaaR24dXe0vt as BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR;
						if (_sag78IYS7BLZBHUWApR != null)
						{
							if (oOfeb5XkKsXpJwgStnBs == null)
							{
								oOfeb5XkKsXpJwgStnBs = new List<BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB>();
							}
							oOfeb5XkKsXpJwgStnBs.Add(new BRsI3YS41tRIm0CdPSm.OOfeb5XkKsXpJwgStnB(_sag78IYS7BLZBHUWApR.jRyYYOKBSg, i));
							obj = _sag78IYS7BLZBHUWApR.fIjYX8KMAw;
							if (!(obj is BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt))
							{
								flag = true;
							}
							else
							{
								pDI0AUPFaaR24dXe0vt = obj as BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt;
							}
						}
					}
					if (!flag)
					{
						if (pDI0AUPFaaR24dXe0vt != null)
						{
							obj = pDI0AUPFaaR24dXe0vt.CvnlU3IXkO(parameterType);
						}
						if (obj == null)
						{
							if (parameterType.IsByRef)
							{
								parameterType = parameterType.GetElementType();
							}
							if (parameterType.IsValueType)
							{
								obj = Activator.CreateInstance(parameterType);
								if (pDI0AUPFaaR24dXe0vt is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)
								{
									((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)pDI0AUPFaaR24dXe0vt).qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(parameterType, obj));
								}
							}
						}
					}
					pDI0AUPFaaR24dXe0vtArray[(int)objArray.Length - 1 - i] = pDI0AUPFaaR24dXe0vt;
					objArray[(int)objArray.Length - 1 - i] = obj;
				}
				BRsI3YS41tRIm0CdPSm.JLhxt0X7DCmV00GKOpY jLhxt0X7DCmV00GKOpY = null;
				if (oOfeb5XkKsXpJwgStnBs != null)
				{
					_fqT0ysXGZ6B4R0ihqVe = new BRsI3YS41tRIm0CdPSm.fqT0ysXGZ6B4R0ihqVe(methodBase, oOfeb5XkKsXpJwgStnBs);
					jLhxt0X7DCmV00GKOpY = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.JnaPktXyF6(methodBase, u0020, _fqT0ysXGZ6B4R0ihqVe);
				}
				else if (methodInfo != null && methodInfo.ReturnType.IsByRef)
				{
					jLhxt0X7DCmV00GKOpY = BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I.CmPPqNVuHC(methodBase, u0020);
				}
				object obj1 = null;
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt1 = null;
				if (!methodBase.IsStatic)
				{
					pDI0AUPFaaR24dXe0vt1 = this.kxpPtJIMy4.daUPcrrcU3();
					if (pDI0AUPFaaR24dXe0vt1 != null)
					{
						obj1 = pDI0AUPFaaR24dXe0vt1.CvnlU3IXkO(methodBase.DeclaringType);
					}
					if (obj1 == null)
					{
						Type declaringType = methodBase.DeclaringType;
						if (declaringType.IsByRef)
						{
							declaringType = declaringType.GetElementType();
						}
						if (!declaringType.IsValueType)
						{
							throw new NullReferenceException();
						}
						obj1 = Activator.CreateInstance(declaringType);
						if (pDI0AUPFaaR24dXe0vt1 is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB)
						{
							((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)pDI0AUPFaaR24dXe0vt1).qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(declaringType, obj1));
						}
					}
				}
				object obj2 = null;
				obj2 = (jLhxt0X7DCmV00GKOpY != null ? jLhxt0X7DCmV00GKOpY(obj1, objArray) : methodBase.Invoke(obj1, objArray));
				for (int j = 0; j < (int)parameters.Length; j++)
				{
					if (parameters[j].ParameterType.IsByRef && (_fqT0ysXGZ6B4R0ihqVe == null || !_fqT0ysXGZ6B4R0ihqVe.smlX9Nw7nt(j)))
					{
						if (pDI0AUPFaaR24dXe0vtArray[j].tpmPR9FfWH())
						{
							((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)pDI0AUPFaaR24dXe0vtArray[j]).XcTSc6GmkQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(parameters[j].ParameterType, objArray[j]));
						}
						else if (!(pDI0AUPFaaR24dXe0vtArray[j] is BRsI3YS41tRIm0CdPSm.qBG0R0YTMijeb5KsNtB))
						{
							pDI0AUPFaaR24dXe0vtArray[j].hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(parameters[j].ParameterType, objArray[j]));
						}
						else
						{
							pDI0AUPFaaR24dXe0vtArray[j].hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(parameters[j].ParameterType.GetElementType(), objArray[j]));
						}
					}
				}
				if (methodInfo != null && methodInfo.ReturnType != typeof(void))
				{
					this.kxpPtJIMy4.lKnPmFQ2gZ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(methodInfo.ReturnType, obj2));
				}
			}

			private void YZVOnXSOxt(int u0020)
			{
				this.BUYBJtDF7x(u0020, this.kxpPtJIMy4.daUPcrrcU3());
			}
		}

		internal enum QweUR0PEi6k3YhmqBvW
		{

		}

		private class rdueeLSZp3Asm7kVn7W : BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D
		{
			public BRsI3YS41tRIm0CdPSm.riqr12SYQpiKx8o9ycg FH6SRpjuDo;

			public BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW FruSpXH759;

			private static BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W yKK7hFkkmGTOlcPm5FhK;

			public rdueeLSZp3Asm7kVn7W(bool u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)1;
				if (!u0020)
				{
					this.FH6SRpjuDo.NFySjw3NeU = 0;
				}
				else
				{
					this.FH6SRpjuDo.NFySjw3NeU = 1;
				}
				this.FruSpXH759 = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)11;
			}

			public rdueeLSZp3Asm7kVn7W(BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = u0020.AdkPKdYKa9;
				this.FH6SRpjuDo.NFySjw3NeU = u0020.FH6SRpjuDo.NFySjw3NeU;
				this.FruSpXH759 = u0020.FruSpXH759;
			}

			public rdueeLSZp3Asm7kVn7W(int u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)1;
				this.FH6SRpjuDo.NFySjw3NeU = u0020;
				this.FruSpXH759 = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)5;
			}

			public rdueeLSZp3Asm7kVn7W(uint u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)1;
				this.FH6SRpjuDo.GO8SlOKscJ = u0020;
				this.FruSpXH759 = (BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW)6;
			}

			public rdueeLSZp3Asm7kVn7W(int u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)1;
				this.FH6SRpjuDo.NFySjw3NeU = u0020;
				this.FruSpXH759 = u0020;
			}

			public rdueeLSZp3Asm7kVn7W(uint u0020, BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)1;
				this.FH6SRpjuDo.GO8SlOKscJ = u0020;
				this.FruSpXH759 = u0020;
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U AQblmacrWV()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((float)this.FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W aV0lp8koBT()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((sbyte)this.FH6SRpjuDo.GO8SlOKscJ)), 1);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b3DlZ1vlBC()
			{
				return this.bSylgOD1Tv();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W b5ElWf0CKC()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.rX9SPGZMyK, 3);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B5rlJDOwmv()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((uint)this.FH6SRpjuDo.NFySjw3NeU), 6);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W B7GliJVwUR()
			{
				return this.qqRlYZcuq0();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W bSylgOD1Tv()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.Nn1SX233sl, 2);
			}

			public override bool buqjZToHQq(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return this.FH6SRpjuDo.GO8SlOKscJ < ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).M2ijBdfvCo(this);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt cguj6B2iXY(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked(this.FH6SRpjuDo.GO8SlOKscJ * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).cguj6B2iXY(this);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO cGxlEOFbUS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.Gavl0MZqqr().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B7GliJVwUR().FH6SRpjuDo.GO8SlOKscJ);
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.RCglbwABSK();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (u0020 != null && u0020.IsByRef)
				{
					u0020 = u0020.GetElementType();
				}
				if (u0020 == null || u0020 == typeof(object))
				{
					switch (this.FruSpXH759)
					{
						case 1:
						{
							return this.FH6SRpjuDo.fZ7SOmopvW;
						}
						case 2:
						{
							return this.FH6SRpjuDo.Nn1SX233sl;
						}
						case 3:
						{
							return this.FH6SRpjuDo.rX9SPGZMyK;
						}
						case 4:
						{
							return this.FH6SRpjuDo.vLSSBtRfXt;
						}
						case 5:
						{
							return this.FH6SRpjuDo.NFySjw3NeU;
						}
						case 6:
						{
							return this.FH6SRpjuDo.GO8SlOKscJ;
						}
						case 7:
						{
							return (long)this.FH6SRpjuDo.NFySjw3NeU;
						}
						case 8:
						{
							return (ulong)this.FH6SRpjuDo.GO8SlOKscJ;
						}
						case 9:
						case 10:
						case 12:
						case 13:
						case 14:
						{
							return this.FH6SRpjuDo.NFySjw3NeU;
						}
						case 11:
						{
							return this.RCglbwABSK();
						}
						case 15:
						{
							return (char)this.FH6SRpjuDo.NFySjw3NeU;
						}
						default:
						{
							return this.FH6SRpjuDo.NFySjw3NeU;
						}
					}
				}
				if (u0020 == typeof(int))
				{
					return this.FH6SRpjuDo.NFySjw3NeU;
				}
				if (u0020 == typeof(uint))
				{
					return this.FH6SRpjuDo.GO8SlOKscJ;
				}
				if (u0020 == typeof(short))
				{
					return this.FH6SRpjuDo.rX9SPGZMyK;
				}
				if (u0020 == typeof(ushort))
				{
					return this.FH6SRpjuDo.vLSSBtRfXt;
				}
				if (u0020 == typeof(byte))
				{
					return this.FH6SRpjuDo.Nn1SX233sl;
				}
				if (u0020 == typeof(sbyte))
				{
					return this.FH6SRpjuDo.fZ7SOmopvW;
				}
				if (u0020 == typeof(bool))
				{
					return !this.q57l2vpK1n();
				}
				if (u0020 == typeof(long))
				{
					return (long)this.FH6SRpjuDo.NFySjw3NeU;
				}
				if (u0020 == typeof(ulong))
				{
					return (ulong)this.FH6SRpjuDo.GO8SlOKscJ;
				}
				if (u0020 == typeof(char))
				{
					return (char)this.FH6SRpjuDo.NFySjw3NeU;
				}
				if (u0020 == typeof(IntPtr))
				{
					return new IntPtr(this.FH6SRpjuDo.NFySjw3NeU);
				}
				if (u0020 == typeof(UIntPtr))
				{
					return new UIntPtr(this.FH6SRpjuDo.GO8SlOKscJ);
				}
				if (!u0020.IsEnum)
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return this.VN1SFE2tX1(u0020);
			}

			public override bool cyBjla9WGE(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).EaCjXoObXK(this);
				}
				return this.FH6SRpjuDo.GO8SlOKscJ <= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W d0GlRc2a7L()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((sbyte)this.FH6SRpjuDo.NFySjw3NeU), 1);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dHsjhXjesK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU ^ ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).dHsjhXjesK(this);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ dKTlxkpj1Q()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)this.FH6SRpjuDo.NFySjw3NeU, 7);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt dMBjH0kCfL()
			{
				BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW fruSpXH759 = this.FruSpXH759;
				switch (fruSpXH759)
				{
					case 1:
					case 3:
					case 5:
					{
						return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(-this.FH6SRpjuDo.NFySjw3NeU);
					}
					case 2:
					case 4:
					{
						return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)(-(ulong)this.FH6SRpjuDo.GO8SlOKscJ));
					}
					default:
					{
						if ((int)fruSpXH759 == 11)
						{
							return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(-this.FH6SRpjuDo.NFySjw3NeU);
						}
						if ((int)fruSpXH759 != 15)
						{
							return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)(-(ulong)this.FH6SRpjuDo.GO8SlOKscJ));
						}
						return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(-this.FH6SRpjuDo.NFySjw3NeU);
					}
				}
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W DP7lfDqxDB()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((int)this.FH6SRpjuDo.GO8SlOKscJ)), 5);
			}

			public override bool EaCjXoObXK(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).cyBjla9WGE(this);
				}
				return this.FH6SRpjuDo.GO8SlOKscJ >= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W eu0lTybe0W()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((!this.q57l2vpK1n() ? 1 : 0));
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return ((BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8)u0020).evOjuZejQG(this);
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).evOjuZejQG(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.OHBjWnvYRZ())
				{
					return false;
				}
				if (pDI0AUPFaaR24dXe0vt.CsRPppYOTY())
				{
					return false;
				}
				if (!pDI0AUPFaaR24dXe0vt.TOiP0fUvZ0())
				{
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)pDI0AUPFaaR24dXe0vt).evOjuZejQG(this);
				}
				return this.FH6SRpjuDo.NFySjw3NeU == ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)pDI0AUPFaaR24dXe0vt).FH6SRpjuDo.NFySjw3NeU;
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ FIglXEgdyQ()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)this.FH6SRpjuDo.NFySjw3NeU, 7);
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.hsKlwaTTVG(u0020);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ Gavl0MZqqr()
			{
				return this.xwllOBxh3t();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt GthjMfGJXk(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).PHaSzlNP0q(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked(this.FH6SRpjuDo.NFySjw3NeU - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ H3GloK8YWW()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((ulong)this.FH6SRpjuDo.GO8SlOKscJ, 8);
			}

			private static BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D HcSS01YjSq(object u0020)
			{
				BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D mXLA9LY4pdeld88e55D = u0020 as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				if (mXLA9LY4pdeld88e55D == null && u0020.oJVj0o8M8s())
				{
					mXLA9LY4pdeld88e55D = u0020.R5MjgxNnyG() as BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D;
				}
				return mXLA9LY4pdeld88e55D;
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U hdRlcPQNJV()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)((float)this.FH6SRpjuDo.GO8SlOKscJ));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W HeNlB8VrPZ()
			{
				return this.qfclaEtV55();
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hoJlAy9b0V()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((byte)this.FH6SRpjuDo.GO8SlOKscJ)), 2);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt HqHj7mcRQX(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked(this.FH6SRpjuDo.GO8SlOKscJ - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).KdmYqvqqX0(this);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.FH6SRpjuDo = ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo;
				this.FruSpXH759 = ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FruSpXH759;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W hWSlLTopa3()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((ushort)this.FH6SRpjuDo.GO8SlOKscJ)), 4);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W JQ5l5Gionr()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.GO8SlOKscJ, 6);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ jT9ljPZtDi()
			{
				return this.FIglXEgdyQ();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt K2rjTSWTBP(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).Jf6Y9BtLRf(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU >> (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 31));
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ kl5ld64bfA()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ(checked((ulong)this.FH6SRpjuDo.NFySjw3NeU), 8);
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.cB0PirV4Hs())
				{
					return false;
				}
				if (u0020.oJVj0o8M8s())
				{
					return ((BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ)u0020).KyQjSu10fI(this);
				}
				BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt pDI0AUPFaaR24dXe0vt = u0020.R5MjgxNnyG();
				if (!pDI0AUPFaaR24dXe0vt.OHBjWnvYRZ())
				{
					return false;
				}
				if (pDI0AUPFaaR24dXe0vt.CsRPppYOTY())
				{
					return false;
				}
				if (!pDI0AUPFaaR24dXe0vt.TOiP0fUvZ0())
				{
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)pDI0AUPFaaR24dXe0vt).KyQjSu10fI(this);
				}
				return this.FH6SRpjuDo.GO8SlOKscJ != ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)pDI0AUPFaaR24dXe0vt).FH6SRpjuDo.GO8SlOKscJ;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W lVclVGHGWb()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.FH6SRpjuDo.NFySjw3NeU, 4);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt LX3jvRuP7O(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).zHeY3PKOih(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.GO8SlOKscJ >> (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 31));
			}

			public override bool M2ijBdfvCo(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return this.FH6SRpjuDo.GO8SlOKscJ > ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).buqjZToHQq(this);
			}

			internal static BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W MbelY3kkcIkwZiDgCc2b()
			{
				return BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W.yKK7hFkkmGTOlcPm5FhK;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W mfnlFkZV24()
			{
				return this.U0llufhe9B();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MuDj2ESVFd(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).MuDj2ESVFd(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU | ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt MW1lhEmAfG(BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW u0020)
			{
				switch (u0020)
				{
					case 1:
					{
						return this.qfclaEtV55();
					}
					case 2:
					{
						return this.bSylgOD1Tv();
					}
					case 3:
					{
						return this.b5ElWf0CKC();
					}
					case 4:
					{
						return this.U0llufhe9B();
					}
					case 5:
					{
						return this.oHqlSW6b45();
					}
					case 6:
					{
						return this.qqRlYZcuq0();
					}
					case 7:
					case 8:
					case 9:
					case 10:
					case 12:
					case 13:
					case 14:
					{
						throw new Exception(4.ToString());
					}
					case 11:
					{
						return this.eu0lTybe0W();
					}
					case 15:
					{
						return this.nPMSi0b6XJ();
					}
					case 16:
					{
						return this.yqnlCrBSQ1();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W nDklnP9uew()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((void*)(checked((short)this.FH6SRpjuDo.GO8SlOKscJ)), 3);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt Ni9j4tniIe(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).Ni9j4tniIe(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
			}

			public BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W nPMSi0b6XJ()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU, 15);
			}

			public override bool oc0jO1XWAQ(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return this.FH6SRpjuDo.NFySjw3NeU > ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).ThjjjOubV1(this);
			}

			internal override bool OHBjWnvYRZ()
			{
				return true;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W oHqlSW6b45()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU, 5);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt q0PjsQJ2ps(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU - ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).Vm0SEQyERt(this);
			}

			public override bool q57l2vpK1n()
			{
				BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW fruSpXH759 = this.FruSpXH759;
				switch (fruSpXH759)
				{
					case 1:
					case 3:
					case 5:
					case 7:
					{
						return this.FH6SRpjuDo.NFySjw3NeU == 0;
					}
					case 2:
					case 4:
					case 6:
					{
						return this.FH6SRpjuDo.GO8SlOKscJ == 0;
					}
					default:
					{
						if ((int)fruSpXH759 == 11)
						{
							return this.FH6SRpjuDo.NFySjw3NeU == 0;
						}
						if ((int)fruSpXH759 != 15)
						{
							return this.FH6SRpjuDo.GO8SlOKscJ == 0;
						}
						return this.FH6SRpjuDo.NFySjw3NeU == 0;
					}
				}
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qfclaEtV55()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.fZ7SOmopvW, 1);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt QHqj9kqOCA(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).QHqj9kqOCA(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked(this.FH6SRpjuDo.GO8SlOKscJ + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ));
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W qqRlYZcuq0()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.GO8SlOKscJ, 6);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt qXRjGWmv0L(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).qXRjGWmv0L(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				return this;
			}

			public override bool RCglbwABSK()
			{
				return !this.q57l2vpK1n();
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt RkFjUgwliF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).l2LYseS7Bj(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU << (((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU & 31));
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO rrtlzquJpy()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.dKTlxkpj1Q().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.voYle2maYc().FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rT4jQ5XUP4(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oZ7Y8Hs50K(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.GO8SlOKscJ / ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt rtwjNgsk8H(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.GO8SlOKscJ % ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.GO8SlOKscJ);
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oSEYGwZFJM(this);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s6tjIept8c(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).s6tjIept8c(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked(this.FH6SRpjuDo.NFySjw3NeU * ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt s7Oj3eIaoc(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked(this.FH6SRpjuDo.NFySjw3NeU + ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU));
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).s7Oj3eIaoc(this);
			}

			public override bool Se8jY4rJ7g(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).THajPMZMuT(this);
				}
				return this.FH6SRpjuDo.NFySjw3NeU >= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W SOglrKDlkM()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(checked((short)this.FH6SRpjuDo.NFySjw3NeU), 3);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt T5Ojba52SB()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(~this.FH6SRpjuDo.NFySjw3NeU);
			}

			public override bool THajPMZMuT(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).Se8jY4rJ7g(this);
				}
				return this.FH6SRpjuDo.NFySjw3NeU <= ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
			}

			public override bool ThjjjOubV1(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return this.FH6SRpjuDo.NFySjw3NeU < ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU;
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).oc0jO1XWAQ(this);
			}

			public override string ToString()
			{
				BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW fruSpXH759 = this.FruSpXH759;
				switch (fruSpXH759)
				{
					case 1:
					case 3:
					case 5:
					{
						return this.FH6SRpjuDo.NFySjw3NeU.ToString();
					}
					case 2:
					case 4:
					{
						return this.FH6SRpjuDo.GO8SlOKscJ.ToString();
					}
					default:
					{
						if ((int)fruSpXH759 != 11)
						{
							return this.FH6SRpjuDo.GO8SlOKscJ.ToString();
						}
						return this.FH6SRpjuDo.NFySjw3NeU.ToString();
					}
				}
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W U0llufhe9B()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.vLSSBtRfXt, 4);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u6QjCWlWMF(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).u6QjCWlWMF(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU & ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u7ijtkwXum(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (u0020.TOiP0fUvZ0())
				{
					return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU / ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
				}
				if (!u0020.tpmPR9FfWH())
				{
					throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
				}
				return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).YesYk0Edxr(this);
			}

			public override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt VkljwO21ED(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (u0020.oJVj0o8M8s())
				{
					u0020 = u0020.R5MjgxNnyG();
				}
				if (!u0020.TOiP0fUvZ0())
				{
					if (!u0020.tpmPR9FfWH())
					{
						throw new BRsI3YS41tRIm0CdPSm.MuHuwbYCeEiTLXCDHPF();
					}
					return ((BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO)u0020).BsMYHeOov9(this);
				}
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU % ((BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W)u0020).FH6SRpjuDo.NFySjw3NeU);
			}

			internal object VN1SFE2tX1(Type u0020)
			{
				Type underlyingType = Enum.GetUnderlyingType(u0020);
				if (underlyingType == typeof(int))
				{
					return Enum.ToObject(u0020, this.FH6SRpjuDo.NFySjw3NeU);
				}
				if (underlyingType == typeof(uint))
				{
					return Enum.ToObject(u0020, this.FH6SRpjuDo.GO8SlOKscJ);
				}
				if (underlyingType == typeof(short))
				{
					return Enum.ToObject(u0020, this.FH6SRpjuDo.rX9SPGZMyK);
				}
				if (underlyingType == typeof(ushort))
				{
					return Enum.ToObject(u0020, this.FH6SRpjuDo.vLSSBtRfXt);
				}
				if (underlyingType == typeof(byte))
				{
					return Enum.ToObject(u0020, this.FH6SRpjuDo.Nn1SX233sl);
				}
				if (underlyingType == typeof(sbyte))
				{
					return Enum.ToObject(u0020, this.FH6SRpjuDo.fZ7SOmopvW);
				}
				if (underlyingType == typeof(long))
				{
					return Enum.ToObject(u0020, (long)this.FH6SRpjuDo.NFySjw3NeU);
				}
				if (underlyingType == typeof(ulong))
				{
					return Enum.ToObject(u0020, (ulong)this.FH6SRpjuDo.GO8SlOKscJ);
				}
				if (underlyingType != typeof(char))
				{
					return Enum.ToObject(u0020, this.FH6SRpjuDo.NFySjw3NeU);
				}
				return Enum.ToObject(u0020, (ushort)this.FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W voYle2maYc()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this.FH6SRpjuDo.NFySjw3NeU, 5);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W W15lPh5RC4()
			{
				return this.b5ElWf0CKC();
			}

			public override BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U wGllDQeBGn()
			{
				return new BRsI3YS41tRIm0CdPSm.EHXm1aYIujTVydILT4U((double)this.FH6SRpjuDo.NFySjw3NeU);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO wNijkq3Yt8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.YQPl1OGXpG().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.DP7lfDqxDB().FH6SRpjuDo.NFySjw3NeU);
			}

			internal static bool x1OgsvkkDIBF4eqTYsw3()
			{
				return BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W.yKK7hFkkmGTOlcPm5FhK == null;
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W x2GlKaLfLY()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W((int)this.FH6SRpjuDo.NFySjw3NeU, 2);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ xwllOBxh3t()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((ulong)this.FH6SRpjuDo.GO8SlOKscJ, 8);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO YNwj8YIExi()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.H3GloK8YWW().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.JQ5l5Gionr().FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.MXLA9LY4pdeld88e55D yqnlCrBSQ1()
			{
				return new BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W(this);
			}

			public override BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ YQPl1OGXpG()
			{
				return new BRsI3YS41tRIm0CdPSm.FOcQHDSLPRuSi0ejtOZ((long)this.FH6SRpjuDo.GO8SlOKscJ, 7);
			}

			public override BRsI3YS41tRIm0CdPSm.rdueeLSZp3Asm7kVn7W ysWllqqkwZ()
			{
				return this.oHqlSW6b45();
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO z3gjqNHGw8()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.kl5ld64bfA().pkkSoR3xjG.ogcSA8800w);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((ulong)this.B5rlJDOwmv().FH6SRpjuDo.GO8SlOKscJ);
			}

			public override BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO zgLlyFEWVS()
			{
				if (IntPtr.Size == 8)
				{
					return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO(this.jT9ljPZtDi().pkkSoR3xjG.R6BSVkv4SB);
				}
				return new BRsI3YS41tRIm0CdPSm.HJSlkMSD555eRxIKbsO((long)this.ysWllqqkwZ().FH6SRpjuDo.NFySjw3NeU);
			}
		}

		[StructLayout(LayoutKind.Explicit)]
		public struct riqr12SYQpiKx8o9ycg
		{
			[FieldOffset(0)]
			public byte Nn1SX233sl;

			[FieldOffset(0)]
			public sbyte fZ7SOmopvW;

			[FieldOffset(0)]
			public ushort vLSSBtRfXt;

			[FieldOffset(0)]
			public short rX9SPGZMyK;

			[FieldOffset(0)]
			public uint GO8SlOKscJ;

			[FieldOffset(0)]
			public int NFySjw3NeU;
		}

		private delegate void RpU0YoXIL8v6XQEk4Lp(IntPtr a, byte b, int c);

		internal class sag78IYS7BLZBHUWApR : BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ
		{
			internal FieldInfo jRyYYOKBSg;

			internal object fIjYX8KMAw;

			internal static BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR ybuE6Qk8Zx26s2CO1TRu;

			public sag78IYS7BLZBHUWApR(FieldInfo u0020, object u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.jRyYYOKBSg = u0020;
				this.fIjYX8KMAw = u0020;
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)7;
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.R5MjgxNnyG().CJ4lvqi9kG();
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				return this.R5MjgxNnyG().CvnlU3IXkO(u0020);
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return false;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR))
				{
					return false;
				}
				BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR _sag78IYS7BLZBHUWApR = (BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR)u0020;
				if (_sag78IYS7BLZBHUWApR.jRyYYOKBSg != this.jRyYYOKBSg)
				{
					return false;
				}
				if (_sag78IYS7BLZBHUWApR.fIjYX8KMAw != this.fIjYX8KMAw)
				{
					return false;
				}
				return true;
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.qVnjpWd3hb(u0020);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR))
				{
					this.qVnjpWd3hb(u0020);
					return;
				}
				this.jRyYYOKBSg = ((BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR)u0020).jRyYYOKBSg;
				this.fIjYX8KMAw = ((BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR)u0020).fIjYX8KMAw;
			}

			internal static bool iGCA22k8FtrdU7CTHdbt()
			{
				return BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR.ybuE6Qk8Zx26s2CO1TRu == null;
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return true;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR))
				{
					return true;
				}
				BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR _sag78IYS7BLZBHUWApR = (BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR)u0020;
				if (_sag78IYS7BLZBHUWApR.jRyYYOKBSg != this.jRyYYOKBSg)
				{
					return true;
				}
				if (_sag78IYS7BLZBHUWApR.fIjYX8KMAw != this.fIjYX8KMAw)
				{
					return true;
				}
				return false;
			}

			internal override bool OHBjWnvYRZ()
			{
				return this.R5MjgxNnyG().OHBjWnvYRZ();
			}

			internal override void qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (this.fIjYX8KMAw == null || !(this.fIjYX8KMAw is BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt))
				{
					this.jRyYYOKBSg.SetValue(this.fIjYX8KMAw, u0020.CvnlU3IXkO(null));
					return;
				}
				this.jRyYYOKBSg.SetValue(((BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt)this.fIjYX8KMAw).CvnlU3IXkO(null), u0020.CvnlU3IXkO(null));
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				if (this.fIjYX8KMAw == null || !(this.fIjYX8KMAw is BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt))
				{
					return BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(this.jRyYYOKBSg.FieldType, this.jRyYYOKBSg.GetValue(this.fIjYX8KMAw));
				}
				return BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt.O4QPfZrxdO(this.jRyYYOKBSg.FieldType, this.jRyYYOKBSg.GetValue(((BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt)this.fIjYX8KMAw).CvnlU3IXkO(null)));
			}

			internal static BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR tXWGQmk8iDbZKcs7U2nm()
			{
				return BRsI3YS41tRIm0CdPSm.sag78IYS7BLZBHUWApR.ybuE6Qk8Zx26s2CO1TRu;
			}

			internal override IntPtr v4WjRI4rni()
			{
				throw new NotImplementedException();
			}
		}

		internal enum sq9YVRYQdWRDA7h4NDW : byte
		{

		}

		internal abstract class vlDU7kYUiRiPNypdIDJ : BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt
		{
			internal static BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ SWI45Gk8uD6rNtDBKsTn;

			public vlDU7kYUiRiPNypdIDJ()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal override bool oJVj0o8M8s()
			{
				return true;
			}

			internal abstract void qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020);

			internal static BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ rvhmPbk8Y3rfdIH5eQtV()
			{
				return BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ.SWI45Gk8uD6rNtDBKsTn;
			}

			internal override bool usRjFyXAAy()
			{
				return true;
			}

			internal abstract IntPtr v4WjRI4rni();

			internal static bool zaFuhPk8SSw7JXVdwVHQ()
			{
				return BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ.SWI45Gk8uD6rNtDBKsTn == null;
			}
		}

		internal class wl9xoPYOvxeLfWsDuUY : BRsI3YS41tRIm0CdPSm.vlDU7kYUiRiPNypdIDJ
		{
			private BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I hZdYBstixy;

			internal int QtkYP5neMe;

			private static BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY AjZni0k80wwdNiNyTTO3;

			public wl9xoPYOvxeLfWsDuUY(int u0020, BRsI3YS41tRIm0CdPSm.qIRTKAXt5lwtBFs4O9I u0020)
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
				this.hZdYBstixy = u0020;
				this.QtkYP5neMe = u0020;
				this.AdkPKdYKa9 = (BRsI3YS41tRIm0CdPSm.eDCAu2PZaTvgALELhU3)7;
			}

			internal override bool CJ4lvqi9kG()
			{
				return this.R5MjgxNnyG().CJ4lvqi9kG();
			}

			internal static bool Cr5kWtk8RYV8GPxXtPUj()
			{
				return BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY.AjZni0k80wwdNiNyTTO3 == null;
			}

			internal override object CvnlU3IXkO(Type u0020)
			{
				if (this.hZdYBstixy.MnCPIjta1t[this.QtkYP5neMe] == null)
				{
					return null;
				}
				return this.R5MjgxNnyG().CvnlU3IXkO(u0020);
			}

			internal override bool evOjuZejQG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return false;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY))
				{
					return false;
				}
				return ((BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY)u0020).QtkYP5neMe == this.QtkYP5neMe;
			}

			internal override void fVJlNHULc6(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.qVnjpWd3hb(u0020);
			}

			internal override void hsKlwaTTVG(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY))
				{
					this.qVnjpWd3hb(u0020);
					return;
				}
				this.hZdYBstixy = ((BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY)u0020).hZdYBstixy;
				this.QtkYP5neMe = ((BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY)u0020).QtkYP5neMe;
			}

			internal override bool KyQjSu10fI(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				if (!u0020.oJVj0o8M8s())
				{
					return true;
				}
				if (!(u0020 is BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY))
				{
					return true;
				}
				return ((BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY)u0020).QtkYP5neMe != this.QtkYP5neMe;
			}

			internal override bool OHBjWnvYRZ()
			{
				return this.R5MjgxNnyG().OHBjWnvYRZ();
			}

			internal override void qVnjpWd3hb(BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt u0020)
			{
				this.hZdYBstixy.MnCPIjta1t[this.QtkYP5neMe] = u0020;
			}

			internal override BRsI3YS41tRIm0CdPSm.PDI0AUPFaaR24dXe0vt R5MjgxNnyG()
			{
				if (this.hZdYBstixy.MnCPIjta1t[this.QtkYP5neMe] == null)
				{
					return new BRsI3YS41tRIm0CdPSm.J73ZKePAQS1jY9pDRn8(null);
				}
				return this.hZdYBstixy.MnCPIjta1t[this.QtkYP5neMe].R5MjgxNnyG();
			}

			internal override IntPtr v4WjRI4rni()
			{
				throw new NotImplementedException();
			}

			internal static BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY zdre0tk8pr9VWORE1YNK()
			{
				return BRsI3YS41tRIm0CdPSm.wl9xoPYOvxeLfWsDuUY.AjZni0k80wwdNiNyTTO3;
			}
		}

		internal class ys1NI3YVD4nmbEeC9Sp
		{
			public int LOBYLK1Y3x;

			public int mJ2YJqCDCf;

			public byte QhNY5seSWe;

			public Type cJtYdoaxLX;

			public int aUGYo4U3DZ;

			public int KrNYmeU4BI;

			private static BRsI3YS41tRIm0CdPSm.ys1NI3YVD4nmbEeC9Sp YOFAt4k8d5sgAZoapeYw;

			public ys1NI3YVD4nmbEeC9Sp()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal static bool AuEJXIk8o2H3nGGg6s9f()
			{
				return BRsI3YS41tRIm0CdPSm.ys1NI3YVD4nmbEeC9Sp.YOFAt4k8d5sgAZoapeYw == null;
			}

			internal static BRsI3YS41tRIm0CdPSm.ys1NI3YVD4nmbEeC9Sp MqnKwkk8mOF4ulrylkff()
			{
				return BRsI3YS41tRIm0CdPSm.ys1NI3YVD4nmbEeC9Sp.YOFAt4k8d5sgAZoapeYw;
			}
		}

		internal class zHMZlrYpcFP7oL8MBET
		{
			public int S5xYrcHeXb;

			public BRsI3YS41tRIm0CdPSm.sq9YVRYQdWRDA7h4NDW IZTYnytKfE;

			public bool vcRYeCHnUg;

			public Type jdFYfxuJ26;

			internal static BRsI3YS41tRIm0CdPSm.zHMZlrYpcFP7oL8MBET k9Ze7Ek8K0r1Pphn1uKA;

			public zHMZlrYpcFP7oL8MBET()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				this.jdFYfxuJ26 = typeof(object);
				base();
			}

			internal static bool tyKX1hk8AuMqBeOEvkOM()
			{
				return BRsI3YS41tRIm0CdPSm.zHMZlrYpcFP7oL8MBET.k9Ze7Ek8K0r1Pphn1uKA == null;
			}

			internal static BRsI3YS41tRIm0CdPSm.zHMZlrYpcFP7oL8MBET XOEu5xk8VRQphhWhaxnQ()
			{
				return BRsI3YS41tRIm0CdPSm.zHMZlrYpcFP7oL8MBET.k9Ze7Ek8K0r1Pphn1uKA;
			}
		}
	}
}