using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void hn6dEN3pjdCZBEhLoLA(object object_0, object object_1, int int_0);