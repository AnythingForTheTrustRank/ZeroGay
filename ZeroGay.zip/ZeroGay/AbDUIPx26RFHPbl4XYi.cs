using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.UI.Elements;

internal delegate void AbDUIPx26RFHPbl4XYi(object , MenuStateController );