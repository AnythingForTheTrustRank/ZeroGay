using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate float oAxGjJV7mBhlNxDmttP(object object_0);