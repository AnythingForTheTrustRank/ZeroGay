using b3eD5DgJPcASx0xfHYB;
using System;
using System.IO;

internal delegate Stream MrtwPVFLBGN8VqPJgus(object , string );