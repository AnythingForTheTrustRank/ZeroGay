using AksgHVKH9UOXlBDvRpO;
using Photon.Realtime;
using System;

internal delegate void GaNVbWVY0WrAQBcWE9u(object object_0, EventCaching eventCaching_0);