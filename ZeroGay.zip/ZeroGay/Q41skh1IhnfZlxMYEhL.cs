using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate void Q41skh1IhnfZlxMYEhL(ref AsyncVoidMethodBuilder asyncVoidMethodBuilder_0, Exception exception_0);