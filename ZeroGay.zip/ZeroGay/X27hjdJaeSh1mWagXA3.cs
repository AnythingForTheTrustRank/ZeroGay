using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool X27hjdJaeSh1mWagXA3(object object_0);