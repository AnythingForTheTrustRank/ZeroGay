using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace oTCyZcCwZias2O0KCyR
{
	internal class Ky6GChCQ0MJq38TE8Mv
	{
		protected GameObject XvFCvpEoCK;

		protected TextMeshProUGUI eDRCaMkQGA;

		private static Ky6GChCQ0MJq38TE8Mv TamwLpDY4f2X2EWBnSf;

		public Ky6GChCQ0MJq38TE8Mv(QMNestedButton u0020, float u0020, float u0020, string u0020, Color? u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.owJCNokoxT(u0020.GetMenuObject().get_transform().get_parent(), u0020, u0020, u0020, u0020);
		}

		public Ky6GChCQ0MJq38TE8Mv(Transform u0020, float u0020, float u0020, string u0020, Color? u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.owJCNokoxT(u0020, u0020, u0020, u0020, u0020);
		}

		public void AeSCTRgpZH()
		{
			try
			{
				UnityEngine.Object.Destroy(this.XvFCvpEoCK);
				vBMVdGwfepiujjMKYNt.IhgwJGNFo7.Remove(this);
			}
			catch
			{
			}
		}

		public void CnUCUY7g4n(Vector2 u0020)
		{
			this.XvFCvpEoCK.GetComponent<RectTransform>().set_anchoredPosition(u0020);
		}

		public void FmaCbtBpGf(string u0020)
		{
			this.eDRCaMkQGA.set_text(u0020);
		}

		public void hZOCh2n4dd(Color u0020)
		{
			this.eDRCaMkQGA.set_color(u0020);
		}

		public TextMeshProUGUI KfcC2EWvoo()
		{
			return this.eDRCaMkQGA;
		}

		internal static Ky6GChCQ0MJq38TE8Mv LDKBipDORtrFlbs54P9()
		{
			return Ky6GChCQ0MJq38TE8Mv.TamwLpDY4f2X2EWBnSf;
		}

		private void owJCNokoxT(Transform u0020, float u0020, float u0020, string u0020, Color? u0020)
		{
			this.XvFCvpEoCK = UnityEngine.Object.Instantiate<GameObject>(GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickLinks/LeftItemContainer/Text_Title"), u0020, false);
			this.XvFCvpEoCK.set_name(string.Format("{0}-QMLabel-{1}", "WTFBlaze", yLWOmZwmRqSychwym35.Fn2N9KXqf1()));
			this.eDRCaMkQGA = this.XvFCvpEoCK.GetComponent<TextMeshProUGUI>();
			this.eDRCaMkQGA.set_alignment(514);
			this.eDRCaMkQGA.set_autoSizeTextContainer(true);
			this.eDRCaMkQGA.set_enableWordWrapping(false);
			this.eDRCaMkQGA.set_fontSize(32f);
			this.eDRCaMkQGA.set_richText(true);
			this.CnUCUY7g4n(new Vector2(u0020, u0020));
			this.FmaCbtBpGf(u0020);
			if (u0020.HasValue)
			{
				this.hZOCh2n4dd(u0020.Value);
			}
			vBMVdGwfepiujjMKYNt.IhgwJGNFo7.Add(this);
		}

		internal static bool PUlNIvDXJdj2F8ffXCS()
		{
			return Ky6GChCQ0MJq38TE8Mv.TamwLpDY4f2X2EWBnSf == null;
		}

		public GameObject YheCCAvfBP()
		{
			return this.XvFCvpEoCK;
		}
	}
}