using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int VNVcyXWlagXwxdWHBiB(object object_0, char char_0);