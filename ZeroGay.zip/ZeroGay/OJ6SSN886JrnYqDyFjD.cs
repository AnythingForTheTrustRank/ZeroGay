using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void OJ6SSN886JrnYqDyFjD(object object_0, string string_0);