using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate float Sbs9pOZmvKkXcydpg0U(string string_0);