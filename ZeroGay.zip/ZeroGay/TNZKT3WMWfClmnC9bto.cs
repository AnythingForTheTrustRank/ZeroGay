using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate IntPtr TNZKT3WMWfClmnC9bto(object object_0);