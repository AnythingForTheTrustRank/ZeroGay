using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;

namespace gpd3oZtw5qhYneWRlWY
{
	internal static class QdA6prtQJZNe9CGe8IK
	{
		public static bool R1utb4YCsM;

		public static bool sIHthAjKoE;

		public static System.Collections.Generic.List<VRC.SDKBase.VRC_Pickup> wHHtUwtWJM;

		public static Il2CppSystem.Collections.Generic.List<VRCPickup> EiCtTsXeBS;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger> yajtvS6fLW;

		public static Il2CppSystem.Collections.Generic.List<VRC_ObjectSync> nmStap9gNl;

		public static VRC_EventHandler yj3tgpFqii;

		public static Il2CppArrayBase<UdonBehaviour> x1xtWD3ael;

		public static VRC_SyncVideoPlayer Tw0tu6R5Iw;

		public static string[] MIotSQfH0Y;

		public static bool VsOtYxwksj;

		public static bool r5LtXjAwrm;

		public static Player RIbtOqTLrt;

		private static QdA6prtQJZNe9CGe8IK JmfNlydVVedBw8A6Fke;

		static QdA6prtQJZNe9CGe8IK()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			QdA6prtQJZNe9CGe8IK.R1utb4YCsM = false;
			QdA6prtQJZNe9CGe8IK.sIHthAjKoE = false;
			QdA6prtQJZNe9CGe8IK.wHHtUwtWJM = new System.Collections.Generic.List<VRC.SDKBase.VRC_Pickup>();
			QdA6prtQJZNe9CGe8IK.EiCtTsXeBS = new Il2CppSystem.Collections.Generic.List<VRCPickup>();
			QdA6prtQJZNe9CGe8IK.yajtvS6fLW = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger>();
			QdA6prtQJZNe9CGe8IK.nmStap9gNl = new Il2CppSystem.Collections.Generic.List<VRC_ObjectSync>();
			QdA6prtQJZNe9CGe8IK.VsOtYxwksj = false;
			QdA6prtQJZNe9CGe8IK.r5LtXjAwrm = true;
		}

		internal static IEnumerator idqtCg9iJH()
		{
			GameObject.Find("Lobby Area Bounds");
			GameObject gameObject1 = GameObject.Find("Game Area Bounds");
			System.Collections.Generic.List<GameObject> gameObjects = new System.Collections.Generic.List<GameObject>();
			GameObject gameObject = GameObject.Find("Player Nodes");
			foreach (Transform transform in gameObject.GetComponentsInChildren<Transform>())
			{
				if (transform.get_name() != gameObject.get_name())
				{
					gameObjects.Add(transform.get_gameObject());
				}
			}
			while (QdA6prtQJZNe9CGe8IK.r5LtXjAwrm)
			{
				float single = Vector3.Distance(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position(), gameObject1.get_transform().get_position());
				if (single > 100f && single < 129f)
				{
					foreach (GameObject gameObject2 in gameObjects)
					{
						QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject2, "SyncAssignM", null, false);
					}
				}
				yield return new WaitForSeconds(0.5f);
			}
		}

		internal static bool ISG0KtdLbcoIH6wSrEG()
		{
			return QdA6prtQJZNe9CGe8IK.JmfNlydVVedBw8A6Fke == null;
		}

		public static void iXUt274MFU(object u0020, object u0020, Player u0020 = null, bool u0020 = false)
		{
			if (u0020 == null)
			{
				foreach (UdonBehaviour udonBehaviour in QdA6prtQJZNe9CGe8IK.x1xtWD3ael)
				{
					if (!udonBehaviour.get__eventTable().ContainsKey(u0020))
					{
						continue;
					}
					udonBehaviour.SendCustomNetworkEvent(0, u0020);
				}
			}
			else
			{
				UdonBehaviour component = u0020.GetComponent<UdonBehaviour>();
				if (u0020 != null)
				{
					Networking.SetOwner(u0020.get_field_Private_VRCPlayerApi_0(), u0020);
					component.SendCustomNetworkEvent(1, u0020);
				}
				else if (!u0020)
				{
					component.SendCustomNetworkEvent(0, u0020);
				}
				else
				{
					component.SendCustomEvent(u0020);
				}
			}
		}

		internal static QdA6prtQJZNe9CGe8IK pIuRDKdJ9k9n0dlUaFw()
		{
			return QdA6prtQJZNe9CGe8IK.JmfNlydVVedBw8A6Fke;
		}

		public static void YuvtNeYvOM(object u0020)
		{
			foreach (Player array in PlayerManager.Method_Public_Static_get_PlayerManager_0().get_field_Private_List_1_Player_0().ToArray())
			{
				if (array.get_field_Private_APIUser_0().get_id() != u0020)
				{
					continue;
				}
				QdA6prtQJZNe9CGe8IK.RIbtOqTLrt = array;
			}
		}
	}
}