using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using UnityEngine.UI;

internal delegate Color VrH3eTfUc03TMyaWZxw(ref ColorBlock );