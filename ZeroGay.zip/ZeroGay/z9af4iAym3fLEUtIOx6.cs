using b3eD5DgJPcASx0xfHYB;
using System;
using System.Runtime.CompilerServices;

internal delegate void z9af4iAym3fLEUtIOx6(ref AsyncVoidMethodBuilder , Exception );