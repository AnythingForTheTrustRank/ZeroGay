using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void LjmtgwXLrXmGWj6IuB9(object object_0, Color32 color32_0);