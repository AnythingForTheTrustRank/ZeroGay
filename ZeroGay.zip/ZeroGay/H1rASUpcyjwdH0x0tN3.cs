using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string[] H1rASUpcyjwdH0x0tN3(object object_0, char[] char_0);