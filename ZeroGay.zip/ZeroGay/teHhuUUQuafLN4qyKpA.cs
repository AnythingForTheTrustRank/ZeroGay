using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void teHhuUUQuafLN4qyKpA(string string_0, object[] object_0);