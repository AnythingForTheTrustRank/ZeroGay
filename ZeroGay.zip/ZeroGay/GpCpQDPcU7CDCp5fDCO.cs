using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;

internal delegate Queue<AssetBundleDownload> GpCpQDPcU7CDCp5fDCO(object object_0);