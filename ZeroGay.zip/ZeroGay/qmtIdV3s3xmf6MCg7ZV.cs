using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string qmtIdV3s3xmf6MCg7ZV(ref ulong ulong_0);