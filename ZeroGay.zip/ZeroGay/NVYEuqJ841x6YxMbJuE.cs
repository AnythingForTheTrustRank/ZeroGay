using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate bool NVYEuqJ841x6YxMbJuE(object , Type );