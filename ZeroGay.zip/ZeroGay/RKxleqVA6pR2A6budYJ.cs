using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string RKxleqVA6pR2A6budYJ(object , byte[] );