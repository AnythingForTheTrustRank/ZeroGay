using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.SDKBase;

internal delegate VRC_Pickup fs1oC6A85eaPLAXBEpj(object );