using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate RuntimeMethodHandle aQysJILLnAEkx2ufVfR(object );