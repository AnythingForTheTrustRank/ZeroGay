using AksgHVKH9UOXlBDvRpO;
using System;
using System.IO;

internal delegate object WCAuutWHMqVHWZbatUD(object object_0, Stream stream_0);