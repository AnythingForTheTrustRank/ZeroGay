using b3eD5DgJPcASx0xfHYB;
using Blaze.API.Wings;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements;

namespace eW8HpLwDaJje18l6kCc
{
	internal static class yLWOmZwmRqSychwym35
	{
		private static QuickMenu IWfN7rBxAP;

		private static GameObject BqnN4J3wk9;

		private static GameObject ryHNINN6WC;

		private static GameObject poNN6eTQGD;

		private static GameObject p5kNtM6OjL;

		private static GameObject DWLNQVkojE;

		private static GameObject OkPNw1hfKX;

		private static GameObject MYQNNBwoNr;

		private static Sprite Uv3NCeNtWr;

		private static Sprite scbN2NlQFp;

		private static System.Random iDANbIBf4P;

		internal static BaseWing kt5Nht53WZ;

		internal static BaseWing IbwNU1nLI7;

		internal static Action<BaseWing> wNsNTSTyhR;

		internal static Action emCNvZ9NTQ;

		internal static Action CxINajR569;

		internal static yLWOmZwmRqSychwym35 Y9G95gmzAcNQbAvBc9M;

		static yLWOmZwmRqSychwym35()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			yLWOmZwmRqSychwym35.iDANbIBf4P = new System.Random();
			yLWOmZwmRqSychwym35.kt5Nht53WZ = new BaseWing();
			yLWOmZwmRqSychwym35.IbwNU1nLI7 = new BaseWing();
			yLWOmZwmRqSychwym35.wNsNTSTyhR = (BaseWing _) => {
			};
			yLWOmZwmRqSychwym35.emCNvZ9NTQ = () => {
				yLWOmZwmRqSychwym35.emCNvZ9NTQ = () => {
				};
				yLWOmZwmRqSychwym35.wNsNTSTyhR(yLWOmZwmRqSychwym35.kt5Nht53WZ);
			};
			yLWOmZwmRqSychwym35.CxINajR569 = () => {
				yLWOmZwmRqSychwym35.CxINajR569 = () => {
				};
				yLWOmZwmRqSychwym35.wNsNTSTyhR(yLWOmZwmRqSychwym35.IbwNU1nLI7);
			};
		}

		internal static void AUyNsBTZDb(this object u0020)
		{
			u0020.huONMoRi0U(null);
		}

		internal static GameObject dlsNkO5BD8()
		{
			if (yLWOmZwmRqSychwym35.p5kNtM6OjL == null)
			{
				yLWOmZwmRqSychwym35.p5kNtM6OjL = GameObject.Find("UserInterface").get_transform().Find("MenuContent/Screens/Settings/AudioDevicePanel/VolumeSlider").get_gameObject();
			}
			return yLWOmZwmRqSychwym35.p5kNtM6OjL;
		}

		internal static int Fn2N9KXqf1()
		{
			return yLWOmZwmRqSychwym35.iDANbIBf4P.Next(10000, 99999);
		}

		internal static GameObject GnTNH0od2b()
		{
			if (yLWOmZwmRqSychwym35.MYQNNBwoNr == null)
			{
				yLWOmZwmRqSychwym35.MYQNNBwoNr = GameObject.Find("UserInterface/MenuContent/Screens/Avatar/AvatarPreviewBase");
			}
			return yLWOmZwmRqSychwym35.MYQNNBwoNr;
		}

		internal static GameObject hkkNqIMM7Q()
		{
			if (yLWOmZwmRqSychwym35.poNN6eTQGD == null)
			{
				yLWOmZwmRqSychwym35.poNN6eTQGD = GameObject.Find("UserInterface").get_transform().Find("MenuContent/Popups/PerformanceSettingsPopup/Popup/Pages/Page_LimitAvatarPerformance/Tooltip_Details").get_gameObject();
			}
			return yLWOmZwmRqSychwym35.poNN6eTQGD;
		}

		internal static void huONMoRi0U(this object u0020, Func<Transform, bool> u0020)
		{
			for (int i = u0020.get_childCount() - 1; i >= 0; i--)
			{
				if (u0020 == null || u0020(u0020.GetChild(i)))
				{
					UnityEngine.Object.DestroyImmediate(u0020.GetChild(i).get_gameObject());
				}
			}
		}

		internal static bool iNV6yDDqf7o6bY9hBBD()
		{
			return yLWOmZwmRqSychwym35.Y9G95gmzAcNQbAvBc9M == null;
		}

		internal static QuickMenu KWIwcIFxsB()
		{
			if (yLWOmZwmRqSychwym35.IWfN7rBxAP == null)
			{
				yLWOmZwmRqSychwym35.IWfN7rBxAP = Resources.FindObjectsOfTypeAll<QuickMenu>().get_Item(0);
			}
			return yLWOmZwmRqSychwym35.IWfN7rBxAP;
		}

		public static Sprite NBXN3wbHYn()
		{
			if (yLWOmZwmRqSychwym35.scbN2NlQFp == null)
			{
				yLWOmZwmRqSychwym35.scbN2NlQFp = GameObject.Find("UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Settings/Panel_QM_ScrollRect/Viewport/VerticalLayoutGroup/Buttons_UI_Elements_Row_1/Button_ToggleQMInfo/Icon_Off").GetComponent<Image>().get_sprite();
			}
			return yLWOmZwmRqSychwym35.scbN2NlQFp;
		}

		internal static GameObject oBOwEBOhW7()
		{
			if (yLWOmZwmRqSychwym35.BqnN4J3wk9 == null)
			{
				foreach (Button componentsInChild in yLWOmZwmRqSychwym35.KWIwcIFxsB().GetComponentsInChildren<Button>(true))
				{
					if (componentsInChild.get_name() != "Button_Screenshot")
					{
						continue;
					}
					yLWOmZwmRqSychwym35.BqnN4J3wk9 = componentsInChild.get_gameObject();
				}
			}
			return yLWOmZwmRqSychwym35.BqnN4J3wk9;
		}

		internal static GameObject qkCN8xt0Qw()
		{
			if (yLWOmZwmRqSychwym35.DWLNQVkojE == null)
			{
				yLWOmZwmRqSychwym35.DWLNQVkojE = GameObject.Find("UserInterface").get_transform().Find("MenuContent/Screens/Settings/AudioDevicePanel/LevelText").get_gameObject();
			}
			return yLWOmZwmRqSychwym35.DWLNQVkojE;
		}

		public static Sprite svgNGwaoi4()
		{
			if (yLWOmZwmRqSychwym35.Uv3NCeNtWr == null)
			{
				yLWOmZwmRqSychwym35.Uv3NCeNtWr = GameObject.Find("UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Notifications/Panel_NoNotifications_Message/Icon").GetComponent<Image>().get_sprite();
			}
			return yLWOmZwmRqSychwym35.Uv3NCeNtWr;
		}

		internal static GameObject urjwyqmP5S()
		{
			if (yLWOmZwmRqSychwym35.OkPNw1hfKX == null)
			{
				yLWOmZwmRqSychwym35.OkPNw1hfKX = GameObject.Find("UserInterface/MenuContent/Screens");
			}
			return yLWOmZwmRqSychwym35.OkPNw1hfKX;
		}

		internal static yLWOmZwmRqSychwym35 wrNHDiDkxhh2rTLHPYw()
		{
			return yLWOmZwmRqSychwym35.Y9G95gmzAcNQbAvBc9M;
		}

		internal static GameObject z1twzw6Ggk()
		{
			if (yLWOmZwmRqSychwym35.ryHNINN6WC == null)
			{
				yLWOmZwmRqSychwym35.ryHNINN6WC = GameObject.Find("UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard").get_gameObject();
			}
			return yLWOmZwmRqSychwym35.ryHNINN6WC;
		}

		public enum S17b6ogswY7KLvgkjg8
		{
			Worlds,
			Avatars,
			Social,
			Settings,
			Safety,
			UserInfo
		}
	}
}