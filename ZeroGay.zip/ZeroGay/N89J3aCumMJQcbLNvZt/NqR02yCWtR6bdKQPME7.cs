using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using Mono.WebBrowser;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace N89J3aCumMJQcbLNvZt
{
	internal class NqR02yCWtR6bdKQPME7
	{
		public QMNestedButton BT0CF8RuJo;

		public QMSingleButton I6GCicNHKR;

		public QMSingleButton WbGC0ORRlS;

		public QMSingleButton FyRCRJ1uJ7;

		public List<NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2> Ve7CpCODAA;

		private int AXQCrnlXhp;

		private int Y6FCn77uaL;

		private int ooICeWF4eT;

		private Action<NqR02yCWtR6bdKQPME7> Lc9Cf8yRKa;

		public int akFCx9eji1;

		public bool EbZC1mwjSv;

		public bool UsGCKE5Drq;

		public bool pD1CAEPHVh;

		internal static NqR02yCWtR6bdKQPME7 CapSU1DjZPVkw2B0IDp;

		public NqR02yCWtR6bdKQPME7(QMNestedButton u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.Ve7CpCODAA = new List<NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2>();
			this.AXQCrnlXhp = 0;
			this.Y6FCn77uaL = 0;
			this.ooICeWF4eT = 0;
			this.akFCx9eji1 = 0;
			this.EbZC1mwjSv = true;
			this.UsGCKE5Drq = false;
			this.pD1CAEPHVh = false;
			base();
			this.BT0CF8RuJo = u0020;
			QMNestedButton bT0CF8RuJo = this.BT0CF8RuJo;
			string str = (this.akFCx9eji1 + 1).ToString();
			int num = this.ooICeWF4eT + 1;
			string str1 = string.Concat("Page:\n", str, " of ", num.ToString());
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			this.FyRCRJ1uJ7 = new QMSingleButton(bT0CF8RuJo, 4f, 1.65f, str1, () => {
			}, "", nullable1, nullable, false);
			this.FyRCRJ1uJ7.GetGameObject().GetComponent<Button>().set_enabled(false);
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			this.WbGC0ORRlS = new QMSingleButton(this.BT0CF8RuJo, 4f, 1.15f, "Back", () => this.nvGCSBZGf3(this.akFCx9eji1 - 1), "Go Back", nullable2, nullable, true);
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			this.I6GCicNHKR = new QMSingleButton(this.BT0CF8RuJo, 4f, 2.55f, "Next", () => this.nvGCSBZGf3(this.akFCx9eji1 + 1), "Go Next", nullable3, nullable, true);
		}

		public void AQgCYLHUyT(Action<NqR02yCWtR6bdKQPME7> u0020, bool u0020 = true)
		{
			try
			{
				this.Lc9Cf8yRKa = u0020;
				this.BT0CF8RuJo.GetMainButton().SetAction(() => {
					if (u0020)
					{
						this.p1CCBve9Ym();
					}
					this.Lc9Cf8yRKa(this);
					this.BT0CF8RuJo.OpenMe();
					this.nvGCSBZGf3(0);
				});
			}
			catch (Mono.WebBrowser.Exception exception)
			{
				Console.WriteLine(exception);
			}
		}

		public void BONClTNHwZ(QMButtonBase u0020, int u0020, float u0020 = 0f, float u0020 = 0f)
		{
			if (this.EbZC1mwjSv)
			{
				u0020.SetLocation((float)this.AXQCrnlXhp, (float)this.Y6FCn77uaL);
			}
			u0020.SetActive(false);
			this.Ve7CpCODAA.Add(new NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2()
			{
				b4CgWI5CZo = u0020,
				peoguNKUPm = u0020
			});
			if (!this.pD1CAEPHVh && u0020 > this.ooICeWF4eT)
			{
				this.ooICeWF4eT = u0020;
			}
		}

		public void by5CXpqbIp()
		{
			this.p1CCBve9Ym();
			Action<NqR02yCWtR6bdKQPME7> lc9Cf8yRKa = this.Lc9Cf8yRKa;
			if (lc9Cf8yRKa != null)
			{
				lc9Cf8yRKa(this);
			}
			else
			{
			}
			this.BT0CF8RuJo.OpenMe();
			this.nvGCSBZGf3(0);
		}

		public void FDSCOknYOq()
		{
			foreach (NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2 ve7CpCODAA in this.Ve7CpCODAA)
			{
				UnityEngine.Object.Destroy(ve7CpCODAA.b4CgWI5CZo.GetGameObject());
			}
			this.Ve7CpCODAA.Clear();
			if (this.BT0CF8RuJo.GetBackButton() != null)
			{
				UnityEngine.Object.Destroy(this.BT0CF8RuJo.GetBackButton());
			}
			if (this.FyRCRJ1uJ7 != null)
			{
				this.FyRCRJ1uJ7.DestroyMe();
			}
			if (this.WbGC0ORRlS != null)
			{
				this.WbGC0ORRlS.DestroyMe();
			}
			if (this.I6GCicNHKR != null)
			{
				this.I6GCicNHKR.DestroyMe();
			}
		}

		internal static NqR02yCWtR6bdKQPME7 GBbxFODFXaSo6ACDPCI()
		{
			return NqR02yCWtR6bdKQPME7.CapSU1DjZPVkw2B0IDp;
		}

		internal static bool ltmweWDZ1hSohYKntpU()
		{
			return NqR02yCWtR6bdKQPME7.CapSU1DjZPVkw2B0IDp == null;
		}

		public void mZiCPn6PR6(QMButtonBase u0020)
		{
			if (this.AXQCrnlXhp < 4)
			{
				this.AXQCrnlXhp++;
			}
			if (this.AXQCrnlXhp == 4)
			{
				this.AXQCrnlXhp = 1;
				this.Y6FCn77uaL++;
			}
			if (this.Y6FCn77uaL == 4)
			{
				this.Y6FCn77uaL = 0;
				this.ooICeWF4eT++;
			}
			if (this.EbZC1mwjSv)
			{
				u0020.SetLocation((float)this.AXQCrnlXhp, (float)this.Y6FCn77uaL);
			}
			u0020.SetActive(false);
			this.Ve7CpCODAA.Add(new NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2()
			{
				b4CgWI5CZo = u0020,
				peoguNKUPm = this.ooICeWF4eT
			});
		}

		public void nvGCSBZGf3(int u0020)
		{
			if (this.UsGCKE5Drq || u0020 >= 0 && u0020 <= this.ooICeWF4eT)
			{
				foreach (NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2 ve7CpCODAA in this.Ve7CpCODAA)
				{
					if (ve7CpCODAA.peoguNKUPm != u0020)
					{
						QMButtonBase qMButtonBase = ve7CpCODAA.b4CgWI5CZo;
						if (qMButtonBase != null)
						{
							qMButtonBase.SetActive(false);
						}
						else
						{
						}
					}
					else
					{
						QMButtonBase qMButtonBase1 = ve7CpCODAA.b4CgWI5CZo;
						if (qMButtonBase1 != null)
						{
							qMButtonBase1.SetActive(true);
						}
						else
						{
						}
					}
				}
				this.akFCx9eji1 = u0020;
				QMSingleButton fyRCRJ1uJ7 = this.FyRCRJ1uJ7;
				string str = (this.akFCx9eji1 + 1).ToString();
				int num = this.ooICeWF4eT + 1;
				fyRCRJ1uJ7.SetButtonText(string.Concat("Page:\n", str, " of ", num.ToString()));
			}
		}

		public void p1CCBve9Ym()
		{
			try
			{
				foreach (NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2 ve7CpCODAA in this.Ve7CpCODAA)
				{
					UnityEngine.Object.Destroy(ve7CpCODAA.b4CgWI5CZo.GetGameObject());
				}
				this.Ve7CpCODAA.Clear();
				this.AXQCrnlXhp = 0;
				this.Y6FCn77uaL = 0;
				this.ooICeWF4eT = 0;
				this.akFCx9eji1 = 0;
			}
			catch
			{
			}
		}

		public class HNvwwlggYVFyn5EUou2
		{
			public QMButtonBase b4CgWI5CZo;

			public int peoguNKUPm;

			internal static NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2 v9J2j2kqot5xUqEDLfGL;

			public HNvwwlggYVFyn5EUou2()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal static NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2 jOEcEHkqDynsRl02QYWC()
			{
				return NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2.v9J2j2kqot5xUqEDLfGL;
			}

			internal static bool ng5Pmekqm3AIIB49mAZQ()
			{
				return NqR02yCWtR6bdKQPME7.HNvwwlggYVFyn5EUou2.v9J2j2kqot5xUqEDLfGL == null;
			}
		}
	}
}