using a1f9Fk6X8PqG43BDAy2;
using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using q4loiAuxF6MNtBcZrh7;
using System;
using UnityEngine;
using VRC.Networking;

namespace BMxfXU9Be1PoX23cWSP
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class QWypHs9OZ0BZ0mPXsnY
	{
		public static string Mvj9jrJEQP;

		private static QWypHs9OZ0BZ0mPXsnY E8ZRYndMn8naPZ3rGv5;

		static QWypHs9OZ0BZ0mPXsnY()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			QWypHs9OZ0BZ0mPXsnY.Mvj9jrJEQP = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
		}

		public QWypHs9OZ0BZ0mPXsnY()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static bool DHB9PSN6pt()
		{
			bool flag;
			flag = (RoomManager.Method_Internal_Static_get_String_0().Contains(QWypHs9OZ0BZ0mPXsnY.Mvj9jrJEQP) ? true : false);
			return flag;
		}

		internal static bool mGnec3d73Qlwx7dU9V4()
		{
			return QWypHs9OZ0BZ0mPXsnY.E8ZRYndMn8naPZ3rGv5 == null;
		}

		internal static QWypHs9OZ0BZ0mPXsnY qF4dg4d4m22yH0xQgfj()
		{
			return QWypHs9OZ0BZ0mPXsnY.E8ZRYndMn8naPZ3rGv5;
		}

		public static bool xAV9lIgDEm(ref string u0020, object u0020)
		{
			if (QWypHs9OZ0BZ0mPXsnY.DHB9PSN6pt())
			{
				if (!LoV9yY6YR91Q6ZGX4wt.asg6VuKDgL)
				{
					GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(true);
					GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(true);
					GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(true);
				}
				else
				{
					GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(false);
					GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(false);
					GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(false);
				}
			}
			return true;
		}
	}
}