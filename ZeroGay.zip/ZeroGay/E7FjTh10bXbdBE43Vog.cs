using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate double E7FjTh10bXbdBE43Vog(double double_0);