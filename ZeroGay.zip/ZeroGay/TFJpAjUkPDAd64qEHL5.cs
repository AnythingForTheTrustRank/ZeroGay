using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate bool TFJpAjUkPDAd64qEHL5(Vector3 vector3_0, Vector3 vector3_1);