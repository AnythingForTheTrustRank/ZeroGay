using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool pmARSD3NfjpMSEN5QuD(IntPtr intptr_0, IntPtr intptr_1);