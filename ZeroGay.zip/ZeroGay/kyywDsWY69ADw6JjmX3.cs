using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void kyywDsWY69ADw6JjmX3(object object_0, byte[] byte_0);