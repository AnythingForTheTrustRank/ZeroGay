using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate byte[] D6pSMhPk0vwiZfLJjH3(object object_0, string string_0);