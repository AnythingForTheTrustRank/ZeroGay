using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using VRC.SDKBase;

internal delegate VRCPlayerApi QAyMKpAG1YmoAdI4pPd(GameObject );