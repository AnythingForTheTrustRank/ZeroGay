using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.UI.Core;

internal delegate void LUa5hIxBS1RFFAuHkyC(object , string , UIContext , bool );