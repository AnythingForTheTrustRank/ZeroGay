using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void L7mPcp1De89I9wA8p7l(Array , int , Array , int , int );