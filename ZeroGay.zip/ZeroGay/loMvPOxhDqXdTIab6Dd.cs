using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.UI.Elements;

internal delegate void loMvPOxhDqXdTIab6Dd(object , List<UIPage> );