using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Vector2 P16pJYfzKfJ11C4q2v6();