using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDKBase;

namespace heukOMwwUqO1LCjGTek
{
	internal class b3d8XTwQ9fVOFfxeNFl : MonoBehaviour
	{
		public static bool cYYw2Iprtu;

		public static float jkZwboCNyW;

		internal static b3d8XTwQ9fVOFfxeNFl n8rEcmoLmp6vZuxAJN5;

		public b3d8XTwQ9fVOFfxeNFl(IntPtr u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base(u0020);
		}

		internal static bool ky5BGkoJ4WCvZ1b8J0G()
		{
			return b3d8XTwQ9fVOFfxeNFl.n8rEcmoLmp6vZuxAJN5 == null;
		}

		internal static b3d8XTwQ9fVOFfxeNFl NeF3udo5GLu2o1JFlNc()
		{
			return b3d8XTwQ9fVOFfxeNFl.n8rEcmoLmp6vZuxAJN5;
		}

		private void OnCollisionEnter(Collision collision)
		{
			if (!collision.get_transform().get_name().Contains("VRCPlayer"))
			{
				foreach (ContactPoint contact in collision.get_contacts())
				{
					if (!b3d8XTwQ9fVOFfxeNFl.cYYw2Iprtu)
					{
						continue;
					}
					Vector3 vector3 = new Vector3(contact.get_point().x, contact.get_point().y, contact.get_point().z);
					b3d8XTwQ9fVOFfxeNFl.UXXwNcoylh().get_transform().set_position(vector3);
					UnityEngine.Object.Destroy(base.get_gameObject());
				}
			}
		}

		private void OnCollisionExit(Collision other)
		{
		}

		private void OnDestroy()
		{
			b3d8XTwQ9fVOFfxeNFl.cYYw2Iprtu = false;
		}

		public void OnDisable()
		{
			b3d8XTwQ9fVOFfxeNFl.cYYw2Iprtu = false;
		}

		public void OnEnable()
		{
			b3d8XTwQ9fVOFfxeNFl.cYYw2Iprtu = false;
		}

		public void Start()
		{
		}

		public void Update()
		{
			if (base.get_gameObject().GetComponent<VRC_Pickup>().get_IsHeld())
			{
				b3d8XTwQ9fVOFfxeNFl.cYYw2Iprtu = true;
			}
			if (b3d8XTwQ9fVOFfxeNFl.cYYw2Iprtu)
			{
				base.get_gameObject().GetComponent<Rigidbody>().set_useGravity(true);
				base.get_gameObject().GetComponent<BoxCollider>().set_isTrigger(false);
			}
			b3d8XTwQ9fVOFfxeNFl.jkZwboCNyW = 0f;
		}

		internal static GameObject UXXwNcoylh()
		{
			GameObject gameObject;
			GameObject[] activeScene = SceneManager.GetActiveScene();
			int num = 0;
			while (true)
			{
				if (num < (int)activeScene.Length)
				{
					GameObject gameObject1 = activeScene[num];
					if (gameObject1.get_name().StartsWith("VRCPlayer[Local]"))
					{
						gameObject = gameObject1;
						break;
					}
					else
					{
						num++;
					}
				}
				else
				{
					gameObject = new GameObject();
					break;
				}
			}
			return gameObject;
		}
	}
}