using AksgHVKH9UOXlBDvRpO;
using BestHTTP;
using DI1Ec8yA4vBbNqCqHF;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using System;
using System.Collections.Generic;
using TMPro;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using VRC.Udon;
using X7IetPATbOXxq4U7Vmy;

namespace RjT7emc7tqaURbFlcDX
{
	internal static class mDXrgOcTInjaUDi52SW
	{
		internal static System.Collections.Generic.List<string> UuvcJ7a0EM;

		private static System.Collections.Generic.List<GameObject> VYvc80Sxc9;

		private static mDXrgOcTInjaUDi52SW b9VdeYfYe86K9GSEB1Z;

		static mDXrgOcTInjaUDi52SW()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			mDXrgOcTInjaUDi52SW.UuvcJ7a0EM = new System.Collections.Generic.List<string>();
			mDXrgOcTInjaUDi52SW.VYvc80Sxc9 = new System.Collections.Generic.List<GameObject>();
		}

		public static Il2CppSystem.Collections.Generic.List<Player> aTbcH11HZw()
		{
			return PlayerManager.get_field_Private_Static_PlayerManager_0().get_field_Private_List_1_Player_0();
		}

		internal static bool b1AeGBfBQtFrQCpOkSk()
		{
			return mDXrgOcTInjaUDi52SW.b9VdeYfYe86K9GSEB1Z == null;
		}

		public static void bJPcs8MtPg(object object_0)
		{
			string str = string.Concat("user/", object_0, "/friendRequest");
			ApiDictContainer apiDictContainer = new ApiDictContainer(new string[0]);
			mDXrgOcTInjaUDi52SW.EC5cRioQ8X(str, 2, apiDictContainer, true, null);
		}

		internal static void e6AclFwXPC(bool bool_0)
		{
			Il2CppArrayBase<VRC_Trigger> il2CppArrayBase = Resources.FindObjectsOfTypeAll<VRC_Trigger>();
			Il2CppArrayBase<UdonBehaviour> il2CppArrayBase1 = Resources.FindObjectsOfTypeAll<UdonBehaviour>();
			foreach (VRC_Trigger vRCTrigger in il2CppArrayBase)
			{
				if ((vRCTrigger == null || vRCTrigger.get_gameObject() == null || !vRCTrigger.get_gameObject().get_active() || vRCTrigger.get_name().Contains("ViewFinder") ? true : HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null))
				{
					continue;
				}
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(vRCTrigger.GetComponentInChildren<MeshRenderer>(), bool_0);
			}
			foreach (UdonBehaviour udonBehaviour in il2CppArrayBase1)
			{
				if ((udonBehaviour == null || udonBehaviour.get_gameObject() == null || !udonBehaviour.get_gameObject().get_active() || udonBehaviour.get_name().Contains("ViewFinder") || HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null ? true : !udonBehaviour.get__eventTable().System_Collections_IDictionary_Contains("_interact")))
				{
					continue;
				}
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(udonBehaviour.GetComponentInChildren<MeshRenderer>(), bool_0);
			}
		}

		internal static void EC5cRioQ8X(object object_0, HTTPMethods httpmethods_0, ApiContainer apiContainer_0 = null, bool bool_0 = true, Il2CppSystem.Collections.Generic.Dictionary<string, Il2CppSystem.Object> dictionary_0 = null)
		{
			API.SendRequest(object_0, httpmethods_0, apiContainer_0, dictionary_0, true, bool_0, 3600f, 2, null, null);
		}

		internal static PlayerManager GdSctbvYZC()
		{
			return PlayerManager.Method_Public_Static_get_PlayerManager_0();
		}

		internal static void iJmcqyR6Bn()
		{
			mDXrgOcTInjaUDi52SW.ViUchjsOHt();
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().HideScreen("POPUP");
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().Method_Public_Virtual_New_Void_Boolean_0(false);
		}

		internal static void jBjcKYWbh3(bool bool_0)
		{
			foreach (VRC_Pickup vRCPickup in Resources.FindObjectsOfTypeAll<VRC_Pickup>())
			{
				if ((vRCPickup == null || vRCPickup.get_gameObject() == null || !vRCPickup.get_gameObject().get_active() || !vRCPickup.get_enabled() || !vRCPickup.get_pickupable() || vRCPickup.get_name().Contains("ViewFinder") ? true : HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null))
				{
					continue;
				}
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(vRCPickup.GetComponentInChildren<MeshRenderer>(), bool_0);
			}
		}

		internal static void JJ9cC1ykbT(object object_0, Color? nullable_0)
		{
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_Text_0().set_color(nullable_0.Value);
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Private_List_1_String_0().Add(string.Concat("[Late Night]\n", object_0));
		}

		internal static Player jLAceWeXcv()
		{
			Player player;
			string _text = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local/ScrollRect/Viewport/VerticalLayoutGroup/UserProfile_Compact/PanelBG/Info/Text_Username_NonFriend").GetComponent<TextMeshProUGUI>().get_text();
			Il2CppSystem.Collections.Generic.List<Player>.Enumerator enumerator = PlayerManager.get_field_Private_Static_PlayerManager_0().get_field_Private_List_1_Player_0().GetEnumerator();
			while (true)
			{
				if (!enumerator.MoveNext())
				{
					player = null;
					break;
				}
				else
				{
					Player _current = enumerator.get_current();
					if (_current.Method_Public_get_VRCPlayerApi_0().get_displayName() == _text)
					{
						player = _current;
						break;
					}
				}
			}
			return player;
		}

		internal static void l2tcAMG1bF(bool bool_0)
		{
			GameObject[] gameObjectArray = GameObject.FindGameObjectsWithTag("Player");
			for (int i = 0; i < (int)gameObjectArray.Length; i++)
			{
				if ((gameObjectArray[i] == null ? false : gameObjectArray[i].get_transform().Find("SelectRegion")))
				{
					Renderer component = gameObjectArray[i].get_transform().Find("SelectRegion").GetComponent<Renderer>();
					if (component != null)
					{
						mDXrgOcTInjaUDi52SW.Ro7cGmwx8U(component, bool_0);
					}
				}
			}
		}

		internal static Transform oO5ciYRBnc()
		{
			return GameObject.Find("/UserInterface/QuickMenu/ShortcutMenu").get_transform();
		}

		internal static VRCPlayer rNpcdWYZKL()
		{
			return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
		}

		internal static void Ro7cGmwx8U(object object_0, bool bool_0)
		{
			if (HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() != null)
			{
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(object_0, bool_0);
			}
		}

		internal static Il2CppSystem.Collections.Generic.List<Player> u6McvysnaI()
		{
			return ScwDo7aJqt0Ery0psC.zPiH6vW2x().get_field_Private_List_1_Player_0();
		}

		internal static Transform ViUc0PMIaL()
		{
			return GameObject.Find("/UserInterface/QuickMenu/UserInteractMenu").get_transform();
		}

		internal static void ViUchjsOHt()
		{
			mDXrgOcTInjaUDi52SW.oO5ciYRBnc().get_gameObject().SetActive(false);
			mDXrgOcTInjaUDi52SW.ViUc0PMIaL().get_gameObject().SetActive(false);
			for (int i = 0; i < mDXrgOcTInjaUDi52SW.VYvc80Sxc9.Count; i++)
			{
				mDXrgOcTInjaUDi52SW.VYvc80Sxc9[i].SetActive(false);
			}
		}

		internal static mDXrgOcTInjaUDi52SW XCOUQ8frXPklo9pUrem()
		{
			return mDXrgOcTInjaUDi52SW.b9VdeYfYe86K9GSEB1Z;
		}
	}
}