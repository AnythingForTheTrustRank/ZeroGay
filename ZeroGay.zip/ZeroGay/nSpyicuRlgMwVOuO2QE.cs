using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void nSpyicuRlgMwVOuO2QE(object object_0, TextAnchor textAnchor_0);