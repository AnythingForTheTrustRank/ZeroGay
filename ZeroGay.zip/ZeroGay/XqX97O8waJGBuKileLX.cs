using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void XqX97O8waJGBuKileLX(object object_0, bool bool_0);