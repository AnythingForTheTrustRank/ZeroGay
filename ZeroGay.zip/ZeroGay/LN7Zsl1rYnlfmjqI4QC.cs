using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void LN7Zsl1rYnlfmjqI4QC(object object_0, string string_0, bool bool_0);