using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using MelonLoader;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using X7IetPATbOXxq4U7Vmy;

namespace DdrQhYOSxxUr8ga8aOm
{
	internal class wU7oNsOjabh7rJBPZf4
	{
		internal static wU7oNsOjabh7rJBPZf4 I4icR8f9vZqQeqOBNH1;

		public wU7oNsOjabh7rJBPZf4(string string_0, MethodBase methodBase_0, HarmonyMethod harmonyMethod_0, HarmonyMethod harmonyMethod_1)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.udQOzX4u8d(string_0);
			this.I0fInrOrLR(methodBase_0);
			this.ykHIIqU2WT(harmonyMethod_0);
			this.SPOIY5Dodx(harmonyMethod_1);
		}

		internal static bool D30Zjgf0yptOjIbH5W2()
		{
			return wU7oNsOjabh7rJBPZf4.I4icR8f9vZqQeqOBNH1 == null;
		}

		public void RyLObZBD3K()
		{
			string name;
			string str;
			try
			{
				Harmony harmony = new Harmony(this.kvJONEwDX4());
				harmony.Patch(this.FGMIcASWpy(), this.EUVIO2wQND(), this.AiPI6V0ys0(), null, null, null);
				string[] fullName = new string[] { "[Patches] Patching ", this.FGMIcASWpy().DeclaringType.FullName, ".", this.FGMIcASWpy().Name, " | with ", null, null };
				HarmonyMethod harmonyMethod = this.EUVIO2wQND();
				string[] strArrays = fullName;
				if (harmonyMethod != null)
				{
					name = harmonyMethod.method.Name;
				}
				else
				{
					name = null;
				}
				strArrays[5] = name;
				HarmonyMethod harmonyMethod1 = this.AiPI6V0ys0();
				string[] strArrays1 = fullName;
				if (harmonyMethod1 != null)
				{
					str = harmonyMethod1.method.Name;
				}
				else
				{
					str = null;
				}
				strArrays1[6] = str;
				MelonLogger.Log(string.Concat(fullName), new object[] { false, ConsoleColor.White });
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				MelonLogger.Error(string.Concat(new string[] { "Error in AttemptPatch! - ", exception.Message, " From:AttemptPatch ", exception.Source, " - Stack:AttemptPatch ", exception.StackTrace }));
			}
		}

		internal static wU7oNsOjabh7rJBPZf4 UJVpO7fx833hsbpkKSw()
		{
			return wU7oNsOjabh7rJBPZf4.I4icR8f9vZqQeqOBNH1;
		}
	}
}