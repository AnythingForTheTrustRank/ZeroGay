using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using UnhollowerRuntimeLib;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace S1wLZ8cFViHc431ckm5
{
	internal class S80pEucu4oflvN30all
	{
		public static S80pEucu4oflvN30all.I73FhReGCMgEmsL1vsh dYwckfk7vR;

		private static S80pEucu4oflvN30all WaiVOZfyxk8EwbVJo0P;

		public S80pEucu4oflvN30all()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static S80pEucu4oflvN30all.I73FhReGCMgEmsL1vsh Huvc1AEg2d()
		{
			S80pEucu4oflvN30all.I73FhReGCMgEmsL1vsh i73FhReGCMgEmsL1vsh;
			if (S80pEucu4oflvN30all.dYwckfk7vR == null)
			{
				MethodInfo methodInfo = ((IEnumerable<MethodInfo>)typeof(VRCUiPopupManager).GetMethods(BindingFlags.Instance | BindingFlags.Public)).Single<MethodInfo>((MethodInfo m) => ((int)m.GetParameters().Length != 7 ? false : S80pEucu4oflvN30all.y0rcVJyKrK(m, "Popups/StandardPopupV2")));
				S80pEucu4oflvN30all.dYwckfk7vR = (S80pEucu4oflvN30all.I73FhReGCMgEmsL1vsh)Delegate.CreateDelegate(typeof(S80pEucu4oflvN30all.I73FhReGCMgEmsL1vsh), VRCUiPopupManager.get_field_Private_Static_VRCUiPopupManager_0(), methodInfo);
				i73FhReGCMgEmsL1vsh = S80pEucu4oflvN30all.dYwckfk7vR;
			}
			else
			{
				i73FhReGCMgEmsL1vsh = S80pEucu4oflvN30all.dYwckfk7vR;
			}
			return i73FhReGCMgEmsL1vsh;
		}

		internal static bool Pl4Y4UfTNO9P5jQEExK()
		{
			return S80pEucu4oflvN30all.WaiVOZfyxk8EwbVJo0P == null;
		}

		public static void sJmcXUllN6(object object_0, object object_1, object object_2, bool bool_0, Action<string> action_0, System.Action action_1 = null)
		{
			VRCUiPopupManager.Method_Public_Static_get_VRCUiPopupManager_PDM_0().Method_Public_Void_String_String_InputType_Boolean_String_Action_3_String_List_1_KeyCode_Text_Action_String_Boolean_Action_1_VRCUiPopup_Boolean_Int32_1(object_0, "", 0, bool_0, object_1, DelegateSupport.ConvertDelegate<Il2CppSystem.Action<string, Il2CppSystem.Collections.Generic.List<KeyCode>, Text>>(new Action<string, Il2CppSystem.Collections.Generic.List<KeyCode>, Text>((string a, Il2CppSystem.Collections.Generic.List<KeyCode> b, Text c) => {
				Action<string> action = action_0;
				if (action != null)
				{
					action(a);
				}
				else
				{
				}
			})), DelegateSupport.ConvertDelegate<Il2CppSystem.Action>(action_1), object_2, true, null, false, 0);
		}

		internal static S80pEucu4oflvN30all uj6oJof7isgycnDFeAG()
		{
			return S80pEucu4oflvN30all.WaiVOZfyxk8EwbVJo0P;
		}

		public static bool y0rcVJyKrK(object object_0, object object_1)
		{
			return XrefScanner.XrefScan(object_0).Any<XrefInstance>((XrefInstance xref) => {
				bool flag;
				if (xref.Type == 0)
				{
					Il2CppSystem.Object obj = xref.ReadAsObject();
					flag = (obj != null ? obj.ToString().IndexOf(object_1, StringComparison.OrdinalIgnoreCase) >= 0 : false);
				}
				else
				{
					flag = false;
				}
				return flag;
			});
		}

		public static void Y7ocZR5RLP()
		{
			GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Darkness").SetActive(false);
			GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Popup/BorderImage").GetComponent<Image>().set_color(new Color(0f, 0f, 0f, 0.1f));
			GameObject.Find("UserInterface/MenuContent/Popups/StandardPopupV2/Popup/Panel").GetComponent<Image>().set_color(new Color(102f, 0f, 102f, 0.1f));
		}

		public static void zUTcLvPTox()
		{
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().HideScreen("POPUP");
		}

		public delegate void I73FhReGCMgEmsL1vsh(string title, string text, string leftButtonText, Il2CppSystem.Action leftButtonAction, string rightButtonText, Il2CppSystem.Action rightButtonAction, Il2CppSystem.Action<VRCUiPopup> additionalShit = null);
	}
}