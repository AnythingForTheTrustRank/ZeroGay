using System;

internal class <Module>{42DA9D3C-1FDA-4E5F-98A3-1062531ACC71}
{

}