using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool uJSlhu8XMKPXoUlbbR4(string string_0, string string_1);