using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.Udon.Common.Interfaces;

internal delegate void hAj4pWn9Af1kP89KEPm(object , NetworkEventTarget , string );