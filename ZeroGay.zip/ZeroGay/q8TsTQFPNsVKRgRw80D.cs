using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Color q8TsTQFPNsVKRgRw80D();