using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using X7IetPATbOXxq4U7Vmy;

namespace HdsmvfAPYqEVFmIuQdn
{
	internal class jyRxpEAUNlcH3bE07bK
	{
		internal static jyRxpEAUNlcH3bE07bK.XUXO9Mdl6GFc6JhHJhK[] BmCAfoUAVQ;

		internal static int[] YV7AmavwWY;

		internal static List<string> YbZADR2iqk;

		private static BinaryReader cckAgCCwVV;

		private static byte[] D42A4Ty1ha;

		private static bool M4OAjRLQAd;

		private static object HrcASeVU3k;

		private static int KpIAbFcbkh;

		private static jyRxpEAUNlcH3bE07bK KLMp1ic5HCgi25s6EWbk;

		static jyRxpEAUNlcH3bE07bK()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			jyRxpEAUNlcH3bE07bK.BmCAfoUAVQ = null;
			jyRxpEAUNlcH3bE07bK.YV7AmavwWY = null;
			jyRxpEAUNlcH3bE07bK.M4OAjRLQAd = false;
			jyRxpEAUNlcH3bE07bK.HrcASeVU3k = 1;
		}

		public jyRxpEAUNlcH3bE07bK()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static object[] aBUAVZN0uh<hIDYmRALACWjBIob9kB>(int int_0, object object_0, ref hIDYmRALACWjBIob9kB gparam_0)
		{
			return jyRxpEAUNlcH3bE07bK.x45AFQO5FM<hIDYmRALACWjBIob9kB>(int_0, object_0, gparam_0, ref gparam_0);
		}

		internal static int gqOAks93L0(object object_0)
		{
			bool flag = false;
			uint num = 0;
			uint num1 = object_0.ReadByte();
			num = 0 | num1 & 63;
			if ((num1 & 64) != 0)
			{
				flag = true;
			}
			if (num1 < 128)
			{
				if (!flag)
				{
					return (int)num;
				}
				return (int)(~num);
			}
			int num2 = 0;
			while (true)
			{
				uint num3 = object_0.ReadByte();
				num = num | (num3 & 127) << (7 * num2 + 6 & 31);
				if (num3 < 128)
				{
					break;
				}
				num2++;
			}
			if (!flag)
			{
				return (int)num;
			}
			return (int)(~num);
		}

		internal static object[] mnqAZ13Fvp(int int_0, object object_0, object object_1)
		{
			return jyRxpEAUNlcH3bE07bK.x45AFQO5FM<int>(int_0, object_0, object_1, ref jyRxpEAUNlcH3bE07bK.KpIAbFcbkh);
		}

		internal static void o4mA1UFvt1()
		{
			if (jyRxpEAUNlcH3bE07bK.YV7AmavwWY == null)
			{
				BinaryReader binaryReader = new BinaryReader(typeof(jyRxpEAUNlcH3bE07bK).Assembly.GetManifestResourceStream("EHA3TuBFxR25bwYRQo.T5iKhqr7hGnwUqsk3O"));
				binaryReader.BaseStream.Position = 0L;
				byte[] numArray = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
				binaryReader.Close();
				jyRxpEAUNlcH3bE07bK.td6A3yhPcG(numArray);
			}
		}

		internal static object[] P6TAuCPrkv()
		{
			return new object[1];
		}

		internal static void td6A3yhPcG(object object_0)
		{
			jyRxpEAUNlcH3bE07bK.cckAgCCwVV = new BinaryReader(new MemoryStream(object_0));
			jyRxpEAUNlcH3bE07bK.D42A4Ty1ha = new byte[255];
			int num = jyRxpEAUNlcH3bE07bK.gqOAks93L0(jyRxpEAUNlcH3bE07bK.cckAgCCwVV);
			for (int i = 0; i < num; i++)
			{
				int num1 = jyRxpEAUNlcH3bE07bK.cckAgCCwVV.ReadByte();
				jyRxpEAUNlcH3bE07bK.D42A4Ty1ha[num1] = jyRxpEAUNlcH3bE07bK.cckAgCCwVV.ReadByte();
			}
			num = jyRxpEAUNlcH3bE07bK.gqOAks93L0(jyRxpEAUNlcH3bE07bK.cckAgCCwVV);
			jyRxpEAUNlcH3bE07bK.YbZADR2iqk = new List<string>(num);
			for (int j = 0; j < num; j++)
			{
				jyRxpEAUNlcH3bE07bK.YbZADR2iqk.Add(Encoding.Unicode.GetString(jyRxpEAUNlcH3bE07bK.cckAgCCwVV.ReadBytes(jyRxpEAUNlcH3bE07bK.gqOAks93L0(jyRxpEAUNlcH3bE07bK.cckAgCCwVV))));
			}
			num = jyRxpEAUNlcH3bE07bK.gqOAks93L0(jyRxpEAUNlcH3bE07bK.cckAgCCwVV);
			jyRxpEAUNlcH3bE07bK.BmCAfoUAVQ = new jyRxpEAUNlcH3bE07bK.XUXO9Mdl6GFc6JhHJhK[num];
			jyRxpEAUNlcH3bE07bK.YV7AmavwWY = new int[num];
			for (int k = 0; k < num; k++)
			{
				jyRxpEAUNlcH3bE07bK.BmCAfoUAVQ[k] = null;
				jyRxpEAUNlcH3bE07bK.YV7AmavwWY[k] = jyRxpEAUNlcH3bE07bK.gqOAks93L0(jyRxpEAUNlcH3bE07bK.cckAgCCwVV);
			}
			int position = (int)jyRxpEAUNlcH3bE07bK.cckAgCCwVV.BaseStream.Position;
			for (int l = 0; l < num; l++)
			{
				int yV7AmavwWY = jyRxpEAUNlcH3bE07bK.YV7AmavwWY[l];
				jyRxpEAUNlcH3bE07bK.YV7AmavwWY[l] = position;
				position += yV7AmavwWY;
			}
		}

		internal static jyRxpEAUNlcH3bE07bK u8S4DPc5RGpddTCQ3GOr()
		{
			return jyRxpEAUNlcH3bE07bK.KLMp1ic5HCgi25s6EWbk;
		}

		internal static object[] x45AFQO5FM<oXe2DGAXveYgua3TPtu>(int int_0, object object_0, object object_1, ref oXe2DGAXveYgua3TPtu gparam_0)
		{
			// 
			// Current member / type: System.Object[] HdsmvfAPYqEVFmIuQdn.jyRxpEAUNlcH3bE07bK::x45AFQO5FM(System.Int32,System.Object,System.Object,oXe2DGAXveYgua3TPtu&)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Object[] x45AFQO5FM(System.Int32,System.Object,System.Object,oXe2DGAXveYgua3TPtu&)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static bool y7gZKxc5sjueqsQitdAV()
		{
			return jyRxpEAUNlcH3bE07bK.KLMp1ic5HCgi25s6EWbk == null;
		}

		private class A2WrVaGlYvdxxQfYJpy : jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4
		{
			public jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 gavGphT3je;

			public jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND bxcGWmvxIK;

			private static jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy uHNdtdc58o7Q1VLJKEWY;

			public A2WrVaGlYvdxxQfYJpy(IntPtr intptr_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)3;
				if (IntPtr.Size == 8)
				{
					this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(intptr_0.ToInt64());
					this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
					return;
				}
				this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(intptr_0.ToInt32());
				this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
			}

			public A2WrVaGlYvdxxQfYJpy(UIntPtr uintptr_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)3;
				if (IntPtr.Size == 8)
				{
					this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(uintptr_0.ToUInt64());
					this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
					return;
				}
				this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(uintptr_0.ToUInt32());
				this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
			}

			public A2WrVaGlYvdxxQfYJpy()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)3;
				if (IntPtr.Size == 8)
				{
					this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(0L);
					this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
					return;
				}
				this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0);
				this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
			}

			public A2WrVaGlYvdxxQfYJpy(long long_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)3;
				if (IntPtr.Size == 8)
				{
					this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(long_0);
					this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
					return;
				}
				this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)long_0);
				this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)12;
			}

			public A2WrVaGlYvdxxQfYJpy(long long_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)3;
				if (IntPtr.Size == 8)
				{
					this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(long_0);
					this.bxcGWmvxIK = lDlkEeGX3ctg76JDHND_0;
					return;
				}
				this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)long_0);
				this.bxcGWmvxIK = lDlkEeGX3ctg76JDHND_0;
			}

			public A2WrVaGlYvdxxQfYJpy(ulong ulong_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)4;
				if (IntPtr.Size == 8)
				{
					this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(ulong_0);
					this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)13;
					return;
				}
				this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((uint)ulong_0);
				this.bxcGWmvxIK = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)13;
			}

			public A2WrVaGlYvdxxQfYJpy(ulong ulong_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)4;
				if (IntPtr.Size == 8)
				{
					this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(ulong_0);
					this.bxcGWmvxIK = lDlkEeGX3ctg76JDHND_0;
					return;
				}
				this.gavGphT3je = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((uint)ulong_0);
				this.bxcGWmvxIK = lDlkEeGX3ctg76JDHND_0;
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW aeD0jvkG0o()
			{
				return this.gavGphT3je.aeD0jvkG0o();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 afbxVgfTCY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp << (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 63));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps << (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 31)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp << (((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.efeGehWbf6 & 63));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps << (((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & 31)));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 AIrxLYOPbe(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp >> (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 63));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps >> (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 31)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp >> (((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.efeGehWbf6 & 63));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps >> (((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & 31)));
			}

			public override bool AIWJ56fpmE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU < ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
					}
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD < ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD < ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU < ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ASAxYcksDW()
			{
				return this.gavGphT3je.ASAxYcksDW();
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (type_0 != null && type_0.IsByRef)
				{
					type_0 = type_0.GetElementType();
				}
				if (type_0 == typeof(IntPtr))
				{
					if (IntPtr.Size == 8)
					{
						return new IntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.qMbGqoMUDp);
					}
					return new IntPtr(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)this.gavGphT3je).kTNGBJtJF0.VSLGOF3Fps);
				}
				if (type_0 == typeof(UIntPtr))
				{
					if (IntPtr.Size == 8)
					{
						return new UIntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.Do4GCrshxD);
					}
					return new UIntPtr(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)this.gavGphT3je).kTNGBJtJF0.zaBGQHNwcU);
				}
				if (!(type_0 == null) && !(type_0 == typeof(object)))
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					if ((int)this.bxcGWmvxIK == 12)
					{
						return new IntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.qMbGqoMUDp);
					}
					return new UIntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.Do4GCrshxD);
				}
				if ((int)this.bxcGWmvxIK == 12)
				{
					return new IntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.efeGehWbf6);
				}
				return new UIntPtr(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)this.gavGphT3je).kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW bom045C5yQ()
			{
				return this.gavGphT3je.bom045C5yQ();
			}

			public override bool C2DxgtwF4s(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps >= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
					}
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp >= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp >= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps >= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb CLj0bGxkbn()
			{
				return this.JNO0f6Ww4D();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ctr0ZHYfwg(jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				switch (lDlkEeGX3ctg76JDHND_0)
				{
					case 1:
					{
						return this.ixd03qpXfA();
					}
					case 2:
					{
						return this.u360kVINWM();
					}
					case 3:
					{
						return this.JNO0f6Ww4D();
					}
					case 4:
					{
						return this.wDv0moVOmC();
					}
					case 5:
					{
						return this.T6x0DEWO2j();
					}
					case 6:
					{
						return this.xPC0gkXCdf();
					}
					case 7:
					{
						return this.bom045C5yQ();
					}
					case 8:
					{
						return this.aeD0jvkG0o();
					}
					case 9:
					case 10:
					case 14:
					case 15:
					{
						throw new Exception(4.ToString());
					}
					case 11:
					{
						return this.J2C0L5xhmC();
					}
					case 12:
					{
						return this;
					}
					case 13:
					{
						return this;
					}
					case 16:
					{
						return this.VtI0uXXMvw();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 cv9xPNKjLE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD % ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU % ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD % ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU % ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 D1fxFGeqb7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp | ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps | ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp | ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps | ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).D8TxDuVrlI(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.JSXxfJmewI())
				{
					return false;
				}
				if (!_leA9Ha0oP4AaSA2idq0.Eym0Y22UOo())
				{
					if (!_leA9Ha0oP4AaSA2idq0.v790Bk1BmX())
					{
						return false;
					}
					int size = IntPtr.Size;
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD != ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				if (IntPtr.Size != 8)
				{
					return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU != ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
				}
				return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD != ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
			}

			internal static bool DdPG9jc5E9Y8rSV5vvbJ()
			{
				return jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy.uHNdtdc58o7Q1VLJKEWY == null;
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 dyyGvOyqa9(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps - this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps - this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps)));
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				return this;
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 EdGGJAvGoV(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD % this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU % this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD % this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU % this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU));
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ElDGdI5fso(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps - this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps - this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override bool Eme0FYs6nR()
			{
				return this.gavGphT3je.Eme0FYs6nR();
			}

			public override bool endx4m7CQT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU >= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
					}
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD >= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD >= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU >= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ErsxxFLS44(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps - ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps)));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb F8qxT1rsi6()
			{
				return this.gavGphT3je.F8qxT1rsi6();
			}

			internal static jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy FDaP3kc5wNumekRFZY6D()
			{
				return jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy.uHNdtdc58o7Q1VLJKEWY;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FEsx6tlZCe()
			{
				return this.gavGphT3je.FEsx6tlZCe();
			}

			public override bool ffI0XduT5O()
			{
				return !this.Eme0FYs6nR();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FscxMh0y89()
			{
				return this.gavGphT3je.FscxMh0y89();
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy Fu6xtFY6Su()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.pnExQQrrXk().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.vxLxnN4YIU().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 gduxhTRAky()
			{
				return this.gavGphT3je.gduxhTRAky();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 GK8x1mthyY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD >> (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 63));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU >> (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 31))));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD >> (((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.efeGehWbf6 & 63));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU >> (((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & 31))));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 gOuxp90V6G(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp / ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps / ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp / ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps / ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override bool IG7xjsK4EF(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps > ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
					}
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp > ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp > ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps > ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps;
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				IntPtr intPtr;
				if (leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					if (IntPtr.Size == 8)
					{
						IntPtr num = new IntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.qMbGqoMUDp);
						IntPtr intPtr1 = new IntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).gavGphT3je).B3wGtwGQYo.qMbGqoMUDp);
						*(void*)num = intPtr1.ToInt64();
						return;
					}
					IntPtr num1 = new IntPtr(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)this.gavGphT3je).kTNGBJtJF0.VSLGOF3Fps);
					IntPtr intPtr2 = new IntPtr(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).gavGphT3je).kTNGBJtJF0.VSLGOF3Fps);
					*(void*)num1 = intPtr2.ToInt32();
					return;
				}
				object obj = leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null);
				if (obj == null)
				{
					return;
				}
				intPtr = (IntPtr.Size != 8 ? new IntPtr(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)this.gavGphT3je).kTNGBJtJF0.VSLGOF3Fps) : new IntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.qMbGqoMUDp));
				Type type = obj.GetType();
				if (type == typeof(string))
				{
					return;
				}
				if (type == typeof(byte))
				{
					*(void*)intPtr = (byte)obj;
					return;
				}
				if (type == typeof(sbyte))
				{
					*(void*)intPtr = (sbyte)obj;
					return;
				}
				if (type == typeof(short))
				{
					*(void*)intPtr = (short)obj;
					return;
				}
				if (type == typeof(ushort))
				{
					*(void*)intPtr = (ushort)obj;
					return;
				}
				if (type == typeof(int))
				{
					*(void*)intPtr = (int)obj;
					return;
				}
				if (type == typeof(uint))
				{
					*(void*)intPtr = (uint)obj;
					return;
				}
				if (type == typeof(long))
				{
					*(void*)intPtr = (long)obj;
					return;
				}
				if (type == typeof(ulong))
				{
					*(void*)intPtr = (ulong)obj;
					return;
				}
				if (type == typeof(float))
				{
					*(void*)intPtr = (float)obj;
					return;
				}
				if (type == typeof(double))
				{
					*(void*)intPtr = (double)obj;
					return;
				}
				if (type == typeof(bool))
				{
					*(void*)intPtr = (bool)obj;
					return;
				}
				if (type == typeof(IntPtr))
				{
					*(void*)intPtr = (IntPtr)obj;
					return;
				}
				if (type == typeof(UIntPtr))
				{
					*(void*)intPtr = (UIntPtr)obj;
					return;
				}
				if (type != typeof(char))
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				*(void*)intPtr = (char)obj;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ixd03qpXfA()
			{
				return this.gavGphT3je.ixd03qpXfA();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J2C0L5xhmC()
			{
				return this.gavGphT3je.J2C0L5xhmC();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J39xB0fFjG()
			{
				return this.gavGphT3je.J39xB0fFjG();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Jl4xcF8KnQ()
			{
				return this.wDv0moVOmC();
			}

			public override bool JNkxbaE9i0(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps <= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
					}
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp <= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp <= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps <= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb JNO0f6Ww4D()
			{
				return this.gavGphT3je.JNO0f6Ww4D();
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.JSXxfJmewI())
				{
					return false;
				}
				if (!_leA9Ha0oP4AaSA2idq0.Eym0Y22UOo())
				{
					if (!_leA9Ha0oP4AaSA2idq0.v790Bk1BmX())
					{
						return false;
					}
					int size = IntPtr.Size;
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp == ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				if (IntPtr.Size != 8)
				{
					return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps == ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
				}
				return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp == ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
			}

			internal override bool JSXxfJmewI()
			{
				return true;
			}

			internal IntPtr KhkGGSdMs1()
			{
				if (IntPtr.Size == 8)
				{
					return new IntPtr(((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.qMbGqoMUDp);
				}
				return new IntPtr(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)this.gavGphT3je).kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb KTBxI7JM1N()
			{
				return this.gavGphT3je.KTBxI7JM1N();
			}

			internal override bool lBKJcRIfK8()
			{
				return true;
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lFDxK1rVZS()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.lYyxrsIRV7().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.ASAxYcksDW().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LgEx00tIXr(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp - ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps - ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lGKxGefAaJ()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.xN5xqf54GS().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.OBOxedVMZo().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LJgxESAkAG(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp * ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps * ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps)));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb LpNxocNMFW()
			{
				return this.gavGphT3je.LpNxocNMFW();
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 lvIG0dDQOu(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD / this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU / this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD / this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU / this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU));
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW lYyxrsIRV7()
			{
				return this.gavGphT3je.lYyxrsIRV7();
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 MwrGEmq5Y4(jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb fr14lrGIXaRSLEjVDsb_0)
			{
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(fr14lrGIXaRSLEjVDsb_0.kTNGBJtJF0.VSLGOF3Fps >> (this.bom045C5yQ().B3wGtwGQYo.efeGehWbf6 & 31)));
			}

			public override bool MwSxSSYZQ3(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU > ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
					}
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD > ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD > ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU > ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 mZUxWFSSW6(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD / ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU / ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD / ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU / ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU));
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 N2YxsjFtx6()
			{
				return this.gavGphT3je.N2YxsjFtx6();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW nBW0zA6Cn1()
			{
				return this.bom045C5yQ();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Nnox7pcLUS()
			{
				return this.gavGphT3je.Nnox7pcLUS();
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 NXfGwfnvBP(jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb fr14lrGIXaRSLEjVDsb_0)
			{
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(fr14lrGIXaRSLEjVDsb_0.kTNGBJtJF0.VSLGOF3Fps << (this.bom045C5yQ().B3wGtwGQYo.efeGehWbf6 & 31)));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 OaTxvqmDKP(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp + ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps + ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb OBOxedVMZo()
			{
				return this.gavGphT3je.OBOxedVMZo();
			}

			internal void oyxGAVlfDS(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					this.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
					return;
				}
				this.gavGphT3je = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).gavGphT3je;
				this.bxcGWmvxIK = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bxcGWmvxIK;
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy PD5xRl3JtH()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.nBW0zA6Cn1().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.PO50N2hhDU().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 pEZxd6HgCc()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(-((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)this.gavGphT3je).B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(-((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)this.gavGphT3je).kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW pnExQQrrXk()
			{
				return this.aeD0jvkG0o();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb PO50N2hhDU()
			{
				return this.T6x0DEWO2j();
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 PU8GiwPvZ6(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked((ulong)((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU - this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(checked(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU - this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU))));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD - this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(checked(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU - this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU)));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 q5bxim1OPw(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps)));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp + ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(checked(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps + ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps)));
			}

			internal override bool qjs01aMKus()
			{
				return this.ffI0XduT5O();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 QkpxwApqeH(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD * (ulong)((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(checked(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU))));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD * ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(checked(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU * ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU)));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb qwAxaCXBp2()
			{
				return this.gavGphT3je.qwAxaCXBp2();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb RFK0SjXY75()
			{
				return this.ixd03qpXfA();
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 RPiG9Fvkdi(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp / this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps / this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp / this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps / this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW rROx2jU6yR()
			{
				return this.gavGphT3je.rROx2jU6yR();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 s2NxJDBMr7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD - (ulong)((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(checked(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU))));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD - ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(checked(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU - ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU)));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 S9hxU3utYx(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp % ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps % ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp % ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps % ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 SRix9vq6s5(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD + (ulong)((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU));
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(checked(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU))));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(checked(this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD + ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD));
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)(checked(this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU + ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU)));
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 swMG8BYRIe(jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb fr14lrGIXaRSLEjVDsb_0)
			{
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)((ulong)(fr14lrGIXaRSLEjVDsb_0.kTNGBJtJF0.zaBGQHNwcU >> (this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & 31))));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb T6x0DEWO2j()
			{
				return this.gavGphT3je.T6x0DEWO2j();
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 tCpGx2QQnb(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp % this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps % this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp % this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps % this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override string ToString()
			{
				return this.gavGphT3je.ToString();
			}

			public override bool U2yxzSjQyb(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps < ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
					}
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp < ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp < ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps < ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb u360kVINWM()
			{
				return this.gavGphT3je.u360kVINWM();
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy UjQxA95UDE()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.rROx2jU6yR().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.J39xB0fFjG().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 vsvxZprm8I(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp ^ ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps ^ ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp ^ ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps ^ ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy vTfxlGJn0p()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.W7TxCiinJ2().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.Nnox7pcLUS().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 VtI0uXXMvw()
			{
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy()
				{
					gavGphT3je = this.gavGphT3je.VtI0uXXMvw(),
					bxcGWmvxIK = this.bxcGWmvxIK
				};
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb vxLxnN4YIU()
			{
				return this.xPC0gkXCdf();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW W7TxCiinJ2()
			{
				return this.gavGphT3je.W7TxCiinJ2();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wDv0moVOmC()
			{
				return this.gavGphT3je.wDv0moVOmC();
			}

			public override bool wgXxNAO14B(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size != 8)
					{
						return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU <= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
					}
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD <= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return this.bom045C5yQ().B3wGtwGQYo.Do4GCrshxD <= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.Do4GCrshxD;
				}
				return this.T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU <= ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.zaBGQHNwcU;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 WibxXYkaNk()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(~this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(~this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 wLFxHSrDCX()
			{
				return this.gavGphT3je.wLFxHSrDCX();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wpEx5XwQs6()
			{
				return this.u360kVINWM();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW xN5xqf54GS()
			{
				return this.gavGphT3je.xN5xqf54GS();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb xPC0gkXCdf()
			{
				return this.gavGphT3je.xPC0gkXCdf();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 y8Dx80UigU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp * ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps * ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb YShxOlBEdt()
			{
				return this.gavGphT3je.YShxOlBEdt();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Yxvxyosj9C()
			{
				return this.gavGphT3je.Yxvxyosj9C();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 YygxuJKocU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (IntPtr.Size == 8)
					{
						return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp & ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
					}
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp & ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)(this.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps));
			}
		}

		internal enum aZ8KWt0Osr8yQkeyDNt : byte
		{

		}

		private delegate void bR5v0WdP1N6qNlWwDyn(IntPtr a, byte b, int c);

		private class CNf2hXGLXo0gcl4gpbD : Exception
		{
			private static jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD lCuMX6c5DjR42QNWOyHo;

			public CNf2hXGLXo0gcl4gpbD()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			public CNf2hXGLXo0gcl4gpbD(string string_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base(string_0);
			}

			internal static bool BK0gVnc5gfJC31pDTB9o()
			{
				return jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD.lCuMX6c5DjR42QNWOyHo == null;
			}

			internal static jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD inZU4Nc54iib1Bt5Lg4J()
			{
				return jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD.lCuMX6c5DjR42QNWOyHo;
			}
		}

		private class DSrCAE0HG6QoVKaj94t : jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0
		{
			public string b3G0sCKKtO;

			internal static jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t sSoCeHccge4FD9gglsZF;

			public DSrCAE0HG6QoVKaj94t(string string_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base(6);
				this.b3G0sCKKtO = string_0;
			}

			internal override object B550VtrALj(Type type_0)
			{
				return this.b3G0sCKKtO;
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).D8TxDuVrlI(this);
				}
				return this.b3G0sCKKtO != leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null);
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				return this;
			}

			internal static bool HqQZ6Jcc4NYqSfERCuT3()
			{
				return jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t.sSoCeHccge4FD9gglsZF == null;
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.b3G0sCKKtO = ((jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t)leA9Ha0oP4AaSA2idq0_0).b3G0sCKKtO;
			}

			internal static jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t JaggUcccj9CtgfHqRHwt()
			{
				return jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t.sSoCeHccge4FD9gglsZF;
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				return this.b3G0sCKKtO == leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null);
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
			}

			internal override bool qjs01aMKus()
			{
				return this.b3G0sCKKtO != null;
			}

			public override string ToString()
			{
				if (this.b3G0sCKKtO == null)
				{
					return 5.ToString();
				}
				string str = '*'.ToString();
				char chr = '*';
				return string.Concat(str, this.b3G0sCKKtO, chr.ToString());
			}
		}

		private class FR14lrGIXaRSLEjVDsb : jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4
		{
			public jyRxpEAUNlcH3bE07bK.s8RE0VANPf3vC4p7rwH kTNGBJtJF0;

			public jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND ENkGrsAFRR;

			internal static jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb SbqSi9c5AGOULGiJFH15;

			public FR14lrGIXaRSLEjVDsb(bool bool_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)1;
				if (bool_0)
				{
					this.kTNGBJtJF0.VSLGOF3Fps = 1;
				}
				else
				{
					this.kTNGBJtJF0.VSLGOF3Fps = 0;
				}
				this.ENkGrsAFRR = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)11;
			}

			public FR14lrGIXaRSLEjVDsb(jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb fr14lrGIXaRSLEjVDsb_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = fr14lrGIXaRSLEjVDsb_0.OXE0eJU437;
				this.kTNGBJtJF0.VSLGOF3Fps = fr14lrGIXaRSLEjVDsb_0.kTNGBJtJF0.VSLGOF3Fps;
				this.ENkGrsAFRR = fr14lrGIXaRSLEjVDsb_0.ENkGrsAFRR;
			}

			public FR14lrGIXaRSLEjVDsb(int int_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)1;
				this.kTNGBJtJF0.VSLGOF3Fps = int_0;
				this.ENkGrsAFRR = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)5;
			}

			public FR14lrGIXaRSLEjVDsb(uint uint_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)1;
				this.kTNGBJtJF0.zaBGQHNwcU = uint_0;
				this.ENkGrsAFRR = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)6;
			}

			public FR14lrGIXaRSLEjVDsb(int int_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)1;
				this.kTNGBJtJF0.VSLGOF3Fps = int_0;
				this.ENkGrsAFRR = lDlkEeGX3ctg76JDHND_0;
			}

			public FR14lrGIXaRSLEjVDsb(uint uint_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)1;
				this.kTNGBJtJF0.zaBGQHNwcU = uint_0;
				this.ENkGrsAFRR = lDlkEeGX3ctg76JDHND_0;
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW aeD0jvkG0o()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((ulong)this.kTNGBJtJF0.zaBGQHNwcU, 8);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 afbxVgfTCY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).NXfGwfnvBP(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps << (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 31));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 AIrxLYOPbe(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).MwrGEmq5Y4(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps >> (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 31));
			}

			public override bool AIWJ56fpmE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return this.kTNGBJtJF0.zaBGQHNwcU < ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).MwSxSSYZQ3(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ASAxYcksDW()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps, 5);
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (type_0 != null && type_0.IsByRef)
				{
					type_0 = type_0.GetElementType();
				}
				if (type_0 == null || type_0 == typeof(object))
				{
					switch (this.ENkGrsAFRR)
					{
						case 1:
						{
							return this.kTNGBJtJF0.YEZG58dt5p;
						}
						case 2:
						{
							return this.kTNGBJtJF0.JGqAzCDQNa;
						}
						case 3:
						{
							return this.kTNGBJtJF0.zpyGnvw2Mm;
						}
						case 4:
						{
							return this.kTNGBJtJF0.aiaGcWLrgg;
						}
						case 5:
						{
							return this.kTNGBJtJF0.VSLGOF3Fps;
						}
						case 6:
						{
							return this.kTNGBJtJF0.zaBGQHNwcU;
						}
						case 7:
						{
							return (long)this.kTNGBJtJF0.VSLGOF3Fps;
						}
						case 8:
						{
							return (ulong)this.kTNGBJtJF0.zaBGQHNwcU;
						}
						case 9:
						case 10:
						case 12:
						case 13:
						case 14:
						{
							return this.kTNGBJtJF0.VSLGOF3Fps;
						}
						case 11:
						{
							return this.ffI0XduT5O();
						}
						case 15:
						{
							return (char)this.kTNGBJtJF0.VSLGOF3Fps;
						}
						default:
						{
							return this.kTNGBJtJF0.VSLGOF3Fps;
						}
					}
				}
				if (type_0 == typeof(int))
				{
					return this.kTNGBJtJF0.VSLGOF3Fps;
				}
				if (type_0 == typeof(uint))
				{
					return this.kTNGBJtJF0.zaBGQHNwcU;
				}
				if (type_0 == typeof(short))
				{
					return this.kTNGBJtJF0.zpyGnvw2Mm;
				}
				if (type_0 == typeof(ushort))
				{
					return this.kTNGBJtJF0.aiaGcWLrgg;
				}
				if (type_0 == typeof(byte))
				{
					return this.kTNGBJtJF0.JGqAzCDQNa;
				}
				if (type_0 == typeof(sbyte))
				{
					return this.kTNGBJtJF0.YEZG58dt5p;
				}
				if (type_0 == typeof(bool))
				{
					return !this.Eme0FYs6nR();
				}
				if (type_0 == typeof(long))
				{
					return (long)this.kTNGBJtJF0.VSLGOF3Fps;
				}
				if (type_0 == typeof(ulong))
				{
					return (ulong)this.kTNGBJtJF0.zaBGQHNwcU;
				}
				if (type_0 == typeof(char))
				{
					return (char)this.kTNGBJtJF0.VSLGOF3Fps;
				}
				if (type_0 == typeof(IntPtr))
				{
					return new IntPtr(this.kTNGBJtJF0.VSLGOF3Fps);
				}
				if (type_0 == typeof(UIntPtr))
				{
					return new UIntPtr(this.kTNGBJtJF0.zaBGQHNwcU);
				}
				if (!type_0.IsEnum)
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.PGLGoincBB(type_0);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW bom045C5yQ()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)this.kTNGBJtJF0.VSLGOF3Fps, 7);
			}

			public override bool C2DxgtwF4s(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).JNkxbaE9i0(this);
				}
				return this.kTNGBJtJF0.VSLGOF3Fps >= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb CLj0bGxkbn()
			{
				return this.JNO0f6Ww4D();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ctr0ZHYfwg(jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				switch (lDlkEeGX3ctg76JDHND_0)
				{
					case 1:
					{
						return this.ixd03qpXfA();
					}
					case 2:
					{
						return this.u360kVINWM();
					}
					case 3:
					{
						return this.JNO0f6Ww4D();
					}
					case 4:
					{
						return this.wDv0moVOmC();
					}
					case 5:
					{
						return this.T6x0DEWO2j();
					}
					case 6:
					{
						return this.xPC0gkXCdf();
					}
					case 7:
					case 8:
					case 9:
					case 10:
					case 12:
					case 13:
					case 14:
					{
						throw new Exception(4.ToString());
					}
					case 11:
					{
						return this.J2C0L5xhmC();
					}
					case 15:
					{
						return this.Ik9G6Kit48();
					}
					case 16:
					{
						return this.VtI0uXXMvw();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 cv9xPNKjLE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).EdGGJAvGoV(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.zaBGQHNwcU % ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 D1fxFGeqb7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps | ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).D1fxFGeqb7(this);
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).D8TxDuVrlI(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.JSXxfJmewI())
				{
					return false;
				}
				if (_leA9Ha0oP4AaSA2idq0.BKf0rut3Ig())
				{
					return false;
				}
				if (!_leA9Ha0oP4AaSA2idq0.Eym0Y22UOo())
				{
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_leA9Ha0oP4AaSA2idq0).D8TxDuVrlI(this);
				}
				return this.kTNGBJtJF0.zaBGQHNwcU != ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)_leA9Ha0oP4AaSA2idq0).kTNGBJtJF0.zaBGQHNwcU;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				return this;
			}

			public override bool Eme0FYs6nR()
			{
				jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND eNkGrsAFRR = this.ENkGrsAFRR;
				switch (eNkGrsAFRR)
				{
					case 1:
					case 3:
					case 5:
					case 7:
					{
						return this.kTNGBJtJF0.VSLGOF3Fps == 0;
					}
					case 2:
					case 4:
					case 6:
					{
						return this.kTNGBJtJF0.zaBGQHNwcU == 0;
					}
					default:
					{
						if ((int)eNkGrsAFRR == 11)
						{
							return this.kTNGBJtJF0.VSLGOF3Fps == 0;
						}
						if ((int)eNkGrsAFRR != 15)
						{
							return this.kTNGBJtJF0.zaBGQHNwcU == 0;
						}
						return this.kTNGBJtJF0.VSLGOF3Fps == 0;
					}
				}
			}

			public override bool endx4m7CQT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).wgXxNAO14B(this);
				}
				return this.kTNGBJtJF0.zaBGQHNwcU >= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ErsxxFLS44(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked(this.kTNGBJtJF0.VSLGOF3Fps - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).dyyGvOyqa9(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb F8qxT1rsi6()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((ushort)this.kTNGBJtJF0.zaBGQHNwcU)), 4);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FEsx6tlZCe()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((short)this.kTNGBJtJF0.zaBGQHNwcU)), 3);
			}

			public override bool ffI0XduT5O()
			{
				return !this.Eme0FYs6nR();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FscxMh0y89()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.kTNGBJtJF0.VSLGOF3Fps, 2);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy Fu6xtFY6Su()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.pnExQQrrXk().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.vxLxnN4YIU().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 gduxhTRAky()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((float)this.kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 GK8x1mthyY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).swMG8BYRIe(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.zaBGQHNwcU >> (((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps & 31));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 gOuxp90V6G(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).RPiG9Fvkdi(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps / ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
			}

			public override bool IG7xjsK4EF(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return this.kTNGBJtJF0.VSLGOF3Fps > ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).U2yxzSjQyb(this);
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.kTNGBJtJF0 = ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0;
				this.ENkGrsAFRR = ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).ENkGrsAFRR;
			}

			public jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Ik9G6Kit48()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps, 15);
			}

			internal static jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ImV8pic5dQpH8takQdMd()
			{
				return jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb.SbqSi9c5AGOULGiJFH15;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ixd03qpXfA()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.YEZG58dt5p, 1);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J2C0L5xhmC()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((!this.Eme0FYs6nR() ? 1 : 0));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J39xB0fFjG()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((int)this.kTNGBJtJF0.zaBGQHNwcU)), 5);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Jl4xcF8KnQ()
			{
				return this.wDv0moVOmC();
			}

			public override bool JNkxbaE9i0(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).C2DxgtwF4s(this);
				}
				return this.kTNGBJtJF0.VSLGOF3Fps <= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb JNO0f6Ww4D()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.zpyGnvw2Mm, 3);
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return ((jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.JSXxfJmewI())
				{
					return false;
				}
				if (_leA9Ha0oP4AaSA2idq0.BKf0rut3Ig())
				{
					return false;
				}
				if (!_leA9Ha0oP4AaSA2idq0.Eym0Y22UOo())
				{
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_leA9Ha0oP4AaSA2idq0).JOKxmtllMB(this);
				}
				return this.kTNGBJtJF0.VSLGOF3Fps == ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)_leA9Ha0oP4AaSA2idq0).kTNGBJtJF0.VSLGOF3Fps;
			}

			internal override bool JSXxfJmewI()
			{
				return true;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb KTBxI7JM1N()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((sbyte)this.kTNGBJtJF0.zaBGQHNwcU)), 1);
			}

			internal static bool kUqcmtc5GQRCXqY7ctti()
			{
				return jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb.SbqSi9c5AGOULGiJFH15 == null;
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lFDxK1rVZS()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.lYyxrsIRV7().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.ASAxYcksDW().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LgEx00tIXr(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).ElDGdI5fso(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lGKxGefAaJ()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.xN5xqf54GS().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.OBOxedVMZo().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LJgxESAkAG(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked(this.kTNGBJtJF0.VSLGOF3Fps * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).LJgxESAkAG(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb LpNxocNMFW()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((short)this.kTNGBJtJF0.VSLGOF3Fps), 3);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW lYyxrsIRV7()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)this.kTNGBJtJF0.VSLGOF3Fps, 7);
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
			}

			public override bool MwSxSSYZQ3(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return this.kTNGBJtJF0.zaBGQHNwcU > ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).AIWJ56fpmE(this);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 mZUxWFSSW6(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).lvIG0dDQOu(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.zaBGQHNwcU / ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 N2YxsjFtx6()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)((float)this.kTNGBJtJF0.zaBGQHNwcU));
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW nBW0zA6Cn1()
			{
				return this.bom045C5yQ();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Nnox7pcLUS()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((uint)this.kTNGBJtJF0.VSLGOF3Fps), 6);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 OaTxvqmDKP(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).OaTxvqmDKP(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb OBOxedVMZo()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.zaBGQHNwcU, 6);
			}

			private static jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 OfyGYjZl0V(object object_0)
			{
				jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 object0 = object_0 as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				if (object0 == null && object_0.lFyJQh378A())
				{
					object0 = object_0.e4VxkrOKkN() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				}
				return object0;
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy PD5xRl3JtH()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.nBW0zA6Cn1().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.PO50N2hhDU().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 pEZxd6HgCc()
			{
				jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND eNkGrsAFRR = this.ENkGrsAFRR;
				switch (eNkGrsAFRR)
				{
					case 1:
					case 3:
					case 5:
					{
						return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(-this.kTNGBJtJF0.VSLGOF3Fps);
					}
					case 2:
					case 4:
					{
						return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)(-(ulong)this.kTNGBJtJF0.zaBGQHNwcU));
					}
					default:
					{
						if ((int)eNkGrsAFRR == 11)
						{
							return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(-this.kTNGBJtJF0.VSLGOF3Fps);
						}
						if ((int)eNkGrsAFRR != 15)
						{
							return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)(-(ulong)this.kTNGBJtJF0.zaBGQHNwcU));
						}
						return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(-this.kTNGBJtJF0.VSLGOF3Fps);
					}
				}
			}

			internal object PGLGoincBB(Type type_0)
			{
				Type underlyingType = Enum.GetUnderlyingType(type_0);
				if (underlyingType == typeof(int))
				{
					return Enum.ToObject(type_0, this.kTNGBJtJF0.VSLGOF3Fps);
				}
				if (underlyingType == typeof(uint))
				{
					return Enum.ToObject(type_0, this.kTNGBJtJF0.zaBGQHNwcU);
				}
				if (underlyingType == typeof(short))
				{
					return Enum.ToObject(type_0, this.kTNGBJtJF0.zpyGnvw2Mm);
				}
				if (underlyingType == typeof(ushort))
				{
					return Enum.ToObject(type_0, this.kTNGBJtJF0.aiaGcWLrgg);
				}
				if (underlyingType == typeof(byte))
				{
					return Enum.ToObject(type_0, this.kTNGBJtJF0.JGqAzCDQNa);
				}
				if (underlyingType == typeof(sbyte))
				{
					return Enum.ToObject(type_0, this.kTNGBJtJF0.YEZG58dt5p);
				}
				if (underlyingType == typeof(long))
				{
					return Enum.ToObject(type_0, (long)this.kTNGBJtJF0.VSLGOF3Fps);
				}
				if (underlyingType == typeof(ulong))
				{
					return Enum.ToObject(type_0, (ulong)this.kTNGBJtJF0.zaBGQHNwcU);
				}
				if (underlyingType != typeof(char))
				{
					return Enum.ToObject(type_0, this.kTNGBJtJF0.VSLGOF3Fps);
				}
				return Enum.ToObject(type_0, (ushort)this.kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW pnExQQrrXk()
			{
				return this.aeD0jvkG0o();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb PO50N2hhDU()
			{
				return this.T6x0DEWO2j();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 q5bxim1OPw(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).q5bxim1OPw(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked(this.kTNGBJtJF0.VSLGOF3Fps + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps));
			}

			internal override bool qjs01aMKus()
			{
				return this.ffI0XduT5O();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 QkpxwApqeH(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked(this.kTNGBJtJF0.zaBGQHNwcU * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).QkpxwApqeH(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb qwAxaCXBp2()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((byte)this.kTNGBJtJF0.zaBGQHNwcU)), 2);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb RFK0SjXY75()
			{
				return this.ixd03qpXfA();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW rROx2jU6yR()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)this.kTNGBJtJF0.zaBGQHNwcU, 7);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 s2NxJDBMr7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked(this.kTNGBJtJF0.zaBGQHNwcU - ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).PU8GiwPvZ6(this);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 S9hxU3utYx(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps % ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).tCpGx2QQnb(this);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 SRix9vq6s5(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).SRix9vq6s5(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked(this.kTNGBJtJF0.zaBGQHNwcU + ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb T6x0DEWO2j()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps, 5);
			}

			public override string ToString()
			{
				jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND eNkGrsAFRR = this.ENkGrsAFRR;
				switch (eNkGrsAFRR)
				{
					case 1:
					case 3:
					case 5:
					{
						return this.kTNGBJtJF0.VSLGOF3Fps.ToString();
					}
					case 2:
					case 4:
					{
						return this.kTNGBJtJF0.zaBGQHNwcU.ToString();
					}
					default:
					{
						if ((int)eNkGrsAFRR != 11)
						{
							return this.kTNGBJtJF0.zaBGQHNwcU.ToString();
						}
						return this.kTNGBJtJF0.VSLGOF3Fps.ToString();
					}
				}
			}

			public override bool U2yxzSjQyb(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return this.kTNGBJtJF0.VSLGOF3Fps < ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps;
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).IG7xjsK4EF(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb u360kVINWM()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.JGqAzCDQNa, 2);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy UjQxA95UDE()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.rROx2jU6yR().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.J39xB0fFjG().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 vsvxZprm8I(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).vsvxZprm8I(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps ^ ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy vTfxlGJn0p()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.W7TxCiinJ2().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.Nnox7pcLUS().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 VtI0uXXMvw()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb vxLxnN4YIU()
			{
				return this.xPC0gkXCdf();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW W7TxCiinJ2()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked((ulong)this.kTNGBJtJF0.VSLGOF3Fps), 8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wDv0moVOmC()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.aiaGcWLrgg, 4);
			}

			public override bool wgXxNAO14B(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).endx4m7CQT(this);
				}
				return this.kTNGBJtJF0.zaBGQHNwcU <= ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.zaBGQHNwcU;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 WibxXYkaNk()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(~this.kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 wLFxHSrDCX()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)this.kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wpEx5XwQs6()
			{
				return this.u360kVINWM();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW xN5xqf54GS()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((ulong)this.kTNGBJtJF0.zaBGQHNwcU, 8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb xPC0gkXCdf()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.zaBGQHNwcU, 6);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 y8Dx80UigU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps * ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).y8Dx80UigU(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb YShxOlBEdt()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((sbyte)this.kTNGBJtJF0.VSLGOF3Fps), 1);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Yxvxyosj9C()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.kTNGBJtJF0.VSLGOF3Fps, 4);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 YygxuJKocU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).YygxuJKocU(this);
				}
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.kTNGBJtJF0.VSLGOF3Fps & ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).kTNGBJtJF0.VSLGOF3Fps);
			}
		}

		internal class HafCVDGmIDyKmskHSEP : jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT
		{
			private jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht OTkGDC0cHg;

			internal int dUVGgcVmwa;

			internal static jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP pwbTpxcccniVQCU39TpC;

			public HafCVDGmIDyKmskHSEP(int int_0, jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht hburDWdFlVuC5umhXht_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OTkGDC0cHg = hburDWdFlVuC5umhXht_0;
				this.dUVGgcVmwa = int_0;
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)7;
			}

			internal override IntPtr aplJOYYo3O()
			{
				throw new NotImplementedException();
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (this.OTkGDC0cHg.Xto9u3WxQY[this.dUVGgcVmwa] == null)
				{
					return null;
				}
				return this.e4VxkrOKkN().B550VtrALj(type_0);
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return true;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP))
				{
					return true;
				}
				if (((jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)leA9Ha0oP4AaSA2idq0_0).dUVGgcVmwa != this.dUVGgcVmwa)
				{
					return true;
				}
				return false;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				if (this.OTkGDC0cHg.Xto9u3WxQY[this.dUVGgcVmwa] == null)
				{
					return new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null);
				}
				return this.OTkGDC0cHg.Xto9u3WxQY[this.dUVGgcVmwa].e4VxkrOKkN();
			}

			internal static jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP EQ3cDSccQcMN9pJnvjvF()
			{
				return jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP.pwbTpxcccniVQCU39TpC;
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)
				{
					this.OTkGDC0cHg = ((jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)leA9Ha0oP4AaSA2idq0_0).OTkGDC0cHg;
					this.dUVGgcVmwa = ((jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)leA9Ha0oP4AaSA2idq0_0).dUVGgcVmwa;
					return;
				}
				jyRxpEAUNlcH3bE07bK.xiiVHYdrh2Wy4l9H8wq item = this.OTkGDC0cHg.EIo9Uhr0DF.wYNdvFYKwB[this.dUVGgcVmwa];
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT) || ((int)item.CltdMTgipO & 226) <= 0)
				{
					this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
					return;
				}
				this.QhFJINNrIN((leA9Ha0oP4AaSA2idq0_0 as jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT).e4VxkrOKkN());
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return false;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP))
				{
					return false;
				}
				if (((jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)leA9Ha0oP4AaSA2idq0_0).dUVGgcVmwa == this.dUVGgcVmwa)
				{
					return true;
				}
				return false;
			}

			internal override bool JSXxfJmewI()
			{
				return this.e4VxkrOKkN().JSXxfJmewI();
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
			}

			internal override void QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.OTkGDC0cHg.Xto9u3WxQY[this.dUVGgcVmwa] = leA9Ha0oP4AaSA2idq0_0;
			}

			internal override bool qjs01aMKus()
			{
				return this.e4VxkrOKkN().qjs01aMKus();
			}

			internal static bool sk3jWtccnqUb9bxvVY8a()
			{
				return jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP.pwbTpxcccniVQCU39TpC == null;
			}
		}

		internal class HBUrDWdFlVuC5umhXht
		{
			internal jyRxpEAUNlcH3bE07bK.XUXO9Mdl6GFc6JhHJhK EIo9Uhr0DF;

			internal jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[] aSm9Pn8nCP;

			internal jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[] Xto9u3WxQY;

			internal jyRxpEAUNlcH3bE07bK.w6jpMb0Rkw8HjOr2xos Qpw9FAEf54;

			internal jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 dPu9XZ7s2L;

			internal Exception P959ZbR8oj;

			internal List<IntPtr> K0e9Vgn9Ex;

			private int B9n9LCHQq0;

			private int Ajo91whOkO;

			private int IZb93DjfIb;

			private object d9P9klDQ9w;

			private bool F6n9f9x65k;

			private bool FFG9mZW8DX;

			private bool dYf9DCi0w4;

			private bool xwF9gbU1AD;

			private static Dictionary<Type, int> fEO94sciuI;

			private static Dictionary<object, jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0> fWI9jVp50h;

			private static Dictionary<MethodBase, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE> FZn9SmJTjr;

			private static Dictionary<MethodBase, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE> cJF9boxpgB;

			private static Dictionary<jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE> b6N9NW03cF;

			private static Dictionary<jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE> S0i9zt0M72;

			private static Dictionary<jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE> oFD05OhSIP;

			private static Dictionary<Type, jyRxpEAUNlcH3bE07bK.k0i8POdUROEZ854hSaj> fHr0cRwEVR;

			private static jyRxpEAUNlcH3bE07bK.bR5v0WdP1N6qNlWwDyn NCs0nAH7lJ;

			private static jyRxpEAUNlcH3bE07bK.sZZ5YWduisjjsjhW7uY unO0QpF164;

			internal static jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht NOyh5ZccE1LWTDhOYphv;

			static HBUrDWdFlVuC5umhXht()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fWI9jVp50h = new Dictionary<object, jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0>();
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.FZn9SmJTjr = new Dictionary<MethodBase, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE>();
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.cJF9boxpgB = new Dictionary<MethodBase, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE>();
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.b6N9NW03cF = new Dictionary<jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE>();
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.S0i9zt0M72 = new Dictionary<jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE>();
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.oFD05OhSIP = new Dictionary<jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO, jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE>();
			}

			public HBUrDWdFlVuC5umhXht()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				this.aSm9Pn8nCP = new jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[0];
				this.Xto9u3WxQY = new jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[0];
				this.Qpw9FAEf54 = new jyRxpEAUNlcH3bE07bK.w6jpMb0Rkw8HjOr2xos();
				this.IZb93DjfIb = -1;
				base();
			}

			internal void AirdV4ru8A(ref bool bool_0)
			{
				while (true)
				{
					if (this.B9n9LCHQq0 <= -2)
					{
						this.Qpw9FAEf54.c2X0tj4ouL();
						break;
					}
					else
					{
						if (this.F6n9f9x65k)
						{
							this.F6n9f9x65k = false;
							int ajo91whOkO = this.Ajo91whOkO;
							int b9n9LCHQq0 = this.B9n9LCHQq0;
							this.mAod1VNqTY(this.Ajo91whOkO, this.B9n9LCHQq0);
							this.B9n9LCHQq0 = b9n9LCHQq0;
							this.Ajo91whOkO = ajo91whOkO;
						}
						if (this.dYf9DCi0w4)
						{
							this.dYf9DCi0w4 = false;
							return;
						}
						if (this.FFG9mZW8DX)
						{
							this.FFG9mZW8DX = false;
							return;
						}
						this.Ajo91whOkO = this.B9n9LCHQq0;
						jyRxpEAUNlcH3bE07bK.sVb83IG1u6ZbkqvM6XP item = this.EIo9Uhr0DF.kiSdGj4IZJ[this.B9n9LCHQq0];
						this.d9P9klDQ9w = item.tECGkPNKGe;
						try
						{
							this.Wmpdf5KPiJ(item);
						}
						catch (Exception exception)
						{
							Exception innerException = exception;
							if (innerException is TargetInvocationException)
							{
								TargetInvocationException targetInvocationException = (TargetInvocationException)innerException;
								if (targetInvocationException.InnerException != null)
								{
									innerException = targetInvocationException.InnerException;
								}
							}
							this.P959ZbR8oj = innerException;
							bool_0 = true;
							this.Qpw9FAEf54.c2X0tj4ouL();
							int num = this.Ajo91whOkO;
							jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX jFcSR6dTBGIgDFch6vX = this.xVOd3ntiEn(num, innerException);
							List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX> jFcSR6dTBGIgDFch6vXes = this.UAAdky7JXU(num, false);
							List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX> jFcSR6dTBGIgDFch6vXes1 = new List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX>();
							if (jFcSR6dTBGIgDFch6vX != null)
							{
								jFcSR6dTBGIgDFch6vXes1.Add(jFcSR6dTBGIgDFch6vX);
							}
							if (jFcSR6dTBGIgDFch6vXes != null && jFcSR6dTBGIgDFch6vXes.Count > 0)
							{
								jFcSR6dTBGIgDFch6vXes1.AddRange(jFcSR6dTBGIgDFch6vXes);
							}
							jFcSR6dTBGIgDFch6vXes1.Sort((jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX x, jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX y) => x.Db3dClUCyb.IhYdhLIMeS.CompareTo(y.Db3dClUCyb.IhYdhLIMeS));
							jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX jFcSR6dTBGIgDFch6vX1 = null;
							List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX>.Enumerator enumerator = jFcSR6dTBGIgDFch6vXes1.GetEnumerator();
							try
							{
								while (true)
								{
									if (enumerator.MoveNext())
									{
										jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX current = enumerator.Current;
										if (current.Db3dClUCyb.JEqdKDjJeC == 0)
										{
											jFcSR6dTBGIgDFch6vX1 = current;
											break;
										}
										else
										{
											this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(innerException));
											this.Ajo91whOkO = current.Db3dClUCyb.DWAdt7aFtS;
											this.B9n9LCHQq0 = this.Ajo91whOkO;
											this.OlBdXDRwFp();
											if (this.xwF9gbU1AD)
											{
												this.xwF9gbU1AD = false;
												jFcSR6dTBGIgDFch6vX1 = current;
												break;
											}
										}
									}
									else
									{
										break;
									}
								}
							}
							finally
							{
								((IDisposable)enumerator).Dispose();
							}
							if (jFcSR6dTBGIgDFch6vX1 == null)
							{
								throw innerException;
							}
							this.IZb93DjfIb = jFcSR6dTBGIgDFch6vX1.Db3dClUCyb.IhYdhLIMeS;
							this.Q3YdL7guea(num, jFcSR6dTBGIgDFch6vX1.Db3dClUCyb.IhYdhLIMeS);
							if (this.IZb93DjfIb >= 0)
							{
								this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(innerException));
								this.Ajo91whOkO = this.IZb93DjfIb;
								this.B9n9LCHQq0 = this.Ajo91whOkO;
								this.IZb93DjfIb = -1;
								this.OlBdXDRwFp();
							}
							break;
						}
						this.B9n9LCHQq0++;
					}
				}
			}

			private static IntPtr b1k9EKjicT(object object_0)
			{
				IntPtr intPtr;
				object obj;
				if (object_0 == null)
				{
					return IntPtr.Zero;
				}
				if (object_0.v790Bk1BmX())
				{
					return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)object_0).KhkGGSdMs1();
				}
				if (object_0.lFyJQh378A())
				{
					jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT object0 = (jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)object_0;
					try
					{
						intPtr = object0.aplJOYYo3O();
					}
					catch
					{
						obj = object_0.B550VtrALj(typeof(IntPtr));
						if (obj == null || !(obj.GetType() == typeof(IntPtr)))
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						return (IntPtr)obj;
					}
					return intPtr;
				}
				obj = object_0.B550VtrALj(typeof(IntPtr));
				if (obj == null || !(obj.GetType() == typeof(IntPtr)))
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return (IntPtr)obj;
			}

			private void C2E9HF3fTV(int int_0, jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.Xto9u3WxQY[int_0] = this.RN8dDvEJnD(leA9Ha0oP4AaSA2idq0_0, this.EIo9Uhr0DF.wYNdvFYKwB[int_0].CltdMTgipO, this.EIo9Uhr0DF.wYNdvFYKwB[int_0].FHadayiPnr);
			}

			private static object CS69wAKt9s(object object_0)
			{
				jyRxpEAUNlcH3bE07bK.k0i8POdUROEZ854hSaj _k0i8POdUROEZ854hSaj;
				object object0;
				if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fHr0cRwEVR == null)
				{
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fHr0cRwEVR = new Dictionary<Type, jyRxpEAUNlcH3bE07bK.k0i8POdUROEZ854hSaj>();
				}
				if (object_0 == null)
				{
					return null;
				}
				try
				{
					Type type = object_0.GetType();
					if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fHr0cRwEVR.TryGetValue(type, out _k0i8POdUROEZ854hSaj))
					{
						object0 = _k0i8POdUROEZ854hSaj(object_0);
					}
					else
					{
						DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object) }, true);
						ILGenerator lGenerator = dynamicMethod.GetILGenerator();
						lGenerator.Emit(OpCodes.Ldarg_0);
						lGenerator.Emit(OpCodes.Unbox_Any, type);
						lGenerator.Emit(OpCodes.Box, type);
						lGenerator.Emit(OpCodes.Ret);
						jyRxpEAUNlcH3bE07bK.k0i8POdUROEZ854hSaj _k0i8POdUROEZ854hSaj1 = (jyRxpEAUNlcH3bE07bK.k0i8POdUROEZ854hSaj)dynamicMethod.CreateDelegate(typeof(jyRxpEAUNlcH3bE07bK.k0i8POdUROEZ854hSaj));
						jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fHr0cRwEVR.Add(type, _k0i8POdUROEZ854hSaj1);
						object0 = _k0i8POdUROEZ854hSaj1(object_0);
					}
				}
				catch
				{
					object0 = null;
				}
				return object0;
			}

			private static void Dxg9xmaiwx(object object_0, int int_0)
			{
				switch (int_0)
				{
					case -1:
					{
						object_0.Emit(OpCodes.Ldc_I4_M1);
						return;
					}
					case 0:
					{
						object_0.Emit(OpCodes.Ldc_I4_0);
						return;
					}
					case 1:
					{
						object_0.Emit(OpCodes.Ldc_I4_1);
						return;
					}
					case 2:
					{
						object_0.Emit(OpCodes.Ldc_I4_2);
						return;
					}
					case 3:
					{
						object_0.Emit(OpCodes.Ldc_I4_3);
						return;
					}
					case 4:
					{
						object_0.Emit(OpCodes.Ldc_I4_4);
						return;
					}
					case 5:
					{
						object_0.Emit(OpCodes.Ldc_I4_5);
						return;
					}
					case 6:
					{
						object_0.Emit(OpCodes.Ldc_I4_6);
						return;
					}
					case 7:
					{
						object_0.Emit(OpCodes.Ldc_I4_7);
						return;
					}
					case 8:
					{
						object_0.Emit(OpCodes.Ldc_I4_8);
						return;
					}
					default:
					{
						if (int_0 <= -129 || int_0 >= 128)
						{
							break;
						}
						else
						{
							object_0.Emit(OpCodes.Ldc_I4_S, (sbyte)int_0);
							return;
						}
					}
				}
				object_0.Emit(OpCodes.Ldc_I4, int_0);
			}

			private static void DXS9p70NnV(IntPtr intptr_0, byte byte_0, int int_0)
			{
				if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.NCs0nAH7lJ == null)
				{
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(void), new Type[] { typeof(IntPtr), typeof(byte), typeof(int) }, typeof(jyRxpEAUNlcH3bE07bK), true);
					ILGenerator lGenerator = dynamicMethod.GetILGenerator();
					lGenerator.Emit(OpCodes.Ldarg_0);
					lGenerator.Emit(OpCodes.Ldarg_1);
					lGenerator.Emit(OpCodes.Ldarg_2);
					lGenerator.Emit(OpCodes.Initblk);
					lGenerator.Emit(OpCodes.Ret);
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.NCs0nAH7lJ = (jyRxpEAUNlcH3bE07bK.bR5v0WdP1N6qNlWwDyn)dynamicMethod.CreateDelegate(typeof(jyRxpEAUNlcH3bE07bK.bR5v0WdP1N6qNlWwDyn));
				}
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.NCs0nAH7lJ(intptr_0, byte_0, int_0);
			}

			private void l969v4tddu(bool bool_0)
			{
				int num = (int)this.d9P9klDQ9w;
				MethodBase methodBase = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveMethod(num);
				MethodInfo methodInfo = methodBase as MethodInfo;
				ParameterInfo[] parameters = methodBase.GetParameters();
				object[] objArray = new object[(int)parameters.Length];
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[] leA9Ha0oP4AaSA2idq0Array = new jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[(int)parameters.Length];
				List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL> pLsU0rd9OKulQRgoEBLs = null;
				jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO _p481LxdJNmdNfriwEHO = null;
				for (int i = 0; i < (int)parameters.Length; i++)
				{
					jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = this.Qpw9FAEf54.nws0A8A7sG();
					Type parameterType = parameters[(int)parameters.Length - 1 - i].ParameterType;
					object obj = null;
					bool flag = false;
					if (parameterType.IsByRef)
					{
						jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB kTm31lGbFDDwe0QcrjB = _leA9Ha0oP4AaSA2idq0 as jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB;
						if (kTm31lGbFDDwe0QcrjB != null)
						{
							if (pLsU0rd9OKulQRgoEBLs == null)
							{
								pLsU0rd9OKulQRgoEBLs = new List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL>();
							}
							pLsU0rd9OKulQRgoEBLs.Add(new jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL(kTm31lGbFDDwe0QcrjB.Wd4GNZmaAW, i));
							obj = kTm31lGbFDDwe0QcrjB.pWPGzr94Xa;
							if (obj is jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0)
							{
								_leA9Ha0oP4AaSA2idq0 = obj as jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0;
							}
							else
							{
								flag = true;
							}
						}
					}
					if (!flag)
					{
						if (_leA9Ha0oP4AaSA2idq0 != null)
						{
							obj = _leA9Ha0oP4AaSA2idq0.B550VtrALj(parameterType);
						}
						if (obj == null)
						{
							if (parameterType.IsByRef)
							{
								parameterType = parameterType.GetElementType();
							}
							if (parameterType.IsValueType)
							{
								obj = Activator.CreateInstance(parameterType);
								if (_leA9Ha0oP4AaSA2idq0 is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)
								{
									((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)_leA9Ha0oP4AaSA2idq0).QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(parameterType, obj));
								}
							}
						}
					}
					leA9Ha0oP4AaSA2idq0Array[(int)objArray.Length - 1 - i] = _leA9Ha0oP4AaSA2idq0;
					objArray[(int)objArray.Length - 1 - i] = obj;
				}
				jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE = null;
				if (pLsU0rd9OKulQRgoEBLs != null)
				{
					_p481LxdJNmdNfriwEHO = new jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO(methodBase, pLsU0rd9OKulQRgoEBLs);
					_r4nv1bdWw1MJmxvckeE = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.yAd99JKGsU(methodBase, bool_0, _p481LxdJNmdNfriwEHO);
				}
				else if (methodInfo != null && methodInfo.ReturnType.IsByRef)
				{
					_r4nv1bdWw1MJmxvckeE = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Rxy9inFQrU(methodBase, bool_0);
				}
				object obj1 = null;
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq01 = null;
				if (!methodBase.IsStatic)
				{
					_leA9Ha0oP4AaSA2idq01 = this.Qpw9FAEf54.nws0A8A7sG();
					if (_leA9Ha0oP4AaSA2idq01 != null)
					{
						obj1 = _leA9Ha0oP4AaSA2idq01.B550VtrALj(methodBase.DeclaringType);
					}
					if (obj1 == null)
					{
						Type declaringType = methodBase.DeclaringType;
						if (declaringType.IsByRef)
						{
							declaringType = declaringType.GetElementType();
						}
						if (!declaringType.IsValueType)
						{
							throw new NullReferenceException();
						}
						obj1 = Activator.CreateInstance(declaringType);
						if (_leA9Ha0oP4AaSA2idq01 is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)
						{
							((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)_leA9Ha0oP4AaSA2idq01).QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(declaringType, obj1));
						}
					}
				}
				object obj2 = null;
				obj2 = (_r4nv1bdWw1MJmxvckeE == null ? methodBase.Invoke(obj1, objArray) : _r4nv1bdWw1MJmxvckeE(obj1, objArray));
				for (int j = 0; j < (int)parameters.Length; j++)
				{
					if (parameters[j].ParameterType.IsByRef && (_p481LxdJNmdNfriwEHO == null || !_p481LxdJNmdNfriwEHO.vZHdE3at2i(j)))
					{
						if (leA9Ha0oP4AaSA2idq0Array[j].v790Bk1BmX())
						{
							((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0Array[j]).oyxGAVlfDS(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(parameters[j].ParameterType, objArray[j]));
						}
						else if (leA9Ha0oP4AaSA2idq0Array[j] is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)
						{
							leA9Ha0oP4AaSA2idq0Array[j].ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(parameters[j].ParameterType.GetElementType(), objArray[j]));
						}
						else
						{
							leA9Ha0oP4AaSA2idq0Array[j].ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(parameters[j].ParameterType, objArray[j]));
						}
					}
				}
				if (methodInfo != null && methodInfo.ReturnType != typeof(void))
				{
					this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(methodInfo.ReturnType, obj2));
				}
			}

			internal void mAod1VNqTY(int int_0, int int_1)
			{
				if (this.EIo9Uhr0DF.lwRdiOdWOb != null)
				{
					foreach (jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX eIo9Uhr0DF in this.EIo9Uhr0DF.lwRdiOdWOb)
					{
						if (eIo9Uhr0DF.Db3dClUCyb.JEqdKDjJeC != 2 || eIo9Uhr0DF.Db3dClUCyb.IhYdhLIMeS < int_0 || eIo9Uhr0DF.Db3dClUCyb.rnSdHXXcow > int_1)
						{
							continue;
						}
						this.Ajo91whOkO = eIo9Uhr0DF.Db3dClUCyb.IhYdhLIMeS;
						this.B9n9LCHQq0 = this.Ajo91whOkO;
						bool flag = false;
						this.AirdV4ru8A(ref flag);
						if (!flag)
						{
							continue;
						}
						return;
					}
				}
			}

			private static jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 n6b98XxKvm(object object_0)
			{
				jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 object0 = object_0 as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				if (object0 == null && object_0.lFyJQh378A())
				{
					object0 = object_0.e4VxkrOKkN() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				}
				return object0;
			}

			private void NTyiMR0VNl(int int_0)
			{
				this.C2E9HF3fTV(int_0, this.Qpw9FAEf54.nws0A8A7sG());
			}

			internal void OlBdXDRwFp()
			{
				bool flag = false;
				this.AirdV4ru8A(ref flag);
			}

			internal void Q3YdL7guea(int int_0, int int_1)
			{
				if (this.EIo9Uhr0DF.lwRdiOdWOb != null)
				{
					foreach (jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX eIo9Uhr0DF in this.EIo9Uhr0DF.lwRdiOdWOb)
					{
						if (eIo9Uhr0DF.Db3dClUCyb.JEqdKDjJeC != 4 && eIo9Uhr0DF.Db3dClUCyb.JEqdKDjJeC != 2 || eIo9Uhr0DF.Db3dClUCyb.IhYdhLIMeS < int_0 || eIo9Uhr0DF.Db3dClUCyb.rnSdHXXcow > int_1)
						{
							continue;
						}
						this.Ajo91whOkO = eIo9Uhr0DF.Db3dClUCyb.IhYdhLIMeS;
						this.B9n9LCHQq0 = this.Ajo91whOkO;
						bool flag = false;
						this.AirdV4ru8A(ref flag);
						if (!flag)
						{
							continue;
						}
						return;
					}
				}
			}

			private jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 RN8dDvEJnD(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0, bool bool_0 = false)
			{
				if (!bool_0 && leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.Eym0Y22UOo())
				{
					return ((jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)leA9Ha0oP4AaSA2idq0_0).ctr0ZHYfwg(lDlkEeGX3ctg76JDHND_0);
				}
				if (leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					return ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).ctr0ZHYfwg(lDlkEeGX3ctg76JDHND_0);
				}
				if (leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					return ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).ctr0ZHYfwg(lDlkEeGX3ctg76JDHND_0);
				}
				if (!leA9Ha0oP4AaSA2idq0_0.v790Bk1BmX())
				{
					return leA9Ha0oP4AaSA2idq0_0;
				}
				return ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0_0).ctr0ZHYfwg(lDlkEeGX3ctg76JDHND_0);
			}

			internal static bool rS02eVccwQOYfyS51pDn()
			{
				return jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.NOyh5ZccE1LWTDhOYphv == null;
			}

			private static void RVt9WaJj50(IntPtr intptr_0, IntPtr intptr_1, uint uint_0)
			{
				if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.unO0QpF164 == null)
				{
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(void), new Type[] { typeof(IntPtr), typeof(IntPtr), typeof(uint) }, typeof(jyRxpEAUNlcH3bE07bK), true);
					ILGenerator lGenerator = dynamicMethod.GetILGenerator();
					lGenerator.Emit(OpCodes.Ldarg_0);
					lGenerator.Emit(OpCodes.Ldarg_1);
					lGenerator.Emit(OpCodes.Ldarg_2);
					lGenerator.Emit(OpCodes.Cpblk);
					lGenerator.Emit(OpCodes.Ret);
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.unO0QpF164 = (jyRxpEAUNlcH3bE07bK.sZZ5YWduisjjsjhW7uY)dynamicMethod.CreateDelegate(typeof(jyRxpEAUNlcH3bE07bK.sZZ5YWduisjjsjhW7uY));
				}
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.unO0QpF164(intptr_0, intptr_1, uint_0);
			}

			private static jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE Rxy9inFQrU(object object_0, bool bool_0)
			{
				jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE = null;
				if (!bool_0)
				{
					if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.cJF9boxpgB.TryGetValue(object_0, out _r4nv1bdWw1MJmxvckeE))
					{
						return _r4nv1bdWw1MJmxvckeE;
					}
				}
				else if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.FZn9SmJTjr.TryGetValue(object_0, out _r4nv1bdWw1MJmxvckeE))
				{
					return _r4nv1bdWw1MJmxvckeE;
				}
				MethodInfo object0 = object_0 as MethodInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object), typeof(object[]) }, true);
				ILGenerator lGenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = object_0.GetParameters();
				Type[] parameterType = new Type[(int)parameters.Length];
				for (int i = 0; i < (int)parameterType.Length; i++)
				{
					if (!parameters[i].ParameterType.IsByRef)
					{
						parameterType[i] = parameters[i].ParameterType;
					}
					else
					{
						parameterType[i] = parameters[i].ParameterType.GetElementType();
					}
				}
				int length = (int)parameterType.Length;
				if (object_0.DeclaringType.IsValueType)
				{
					length++;
				}
				LocalBuilder[] localBuilderArray = new LocalBuilder[length];
				for (int j = 0; j < (int)parameterType.Length; j++)
				{
					localBuilderArray[j] = lGenerator.DeclareLocal(parameterType[j]);
				}
				if (object_0.DeclaringType.IsValueType)
				{
					localBuilderArray[(int)localBuilderArray.Length - 1] = lGenerator.DeclareLocal(object_0.DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < (int)parameterType.Length; k++)
				{
					lGenerator.Emit(OpCodes.Ldarg_1);
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, k);
					lGenerator.Emit(OpCodes.Ldelem_Ref);
					if (parameterType[k].IsValueType)
					{
						lGenerator.Emit(OpCodes.Unbox_Any, parameterType[k]);
					}
					else if (parameterType[k] != typeof(object))
					{
						lGenerator.Emit(OpCodes.Castclass, parameterType[k]);
					}
					lGenerator.Emit(OpCodes.Stloc, localBuilderArray[k]);
				}
				if (!object_0.IsStatic)
				{
					lGenerator.Emit(OpCodes.Ldarg_0);
					if (!object_0.DeclaringType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Castclass, object_0.DeclaringType);
					}
					else
					{
						lGenerator.Emit(OpCodes.Unbox, object_0.DeclaringType);
						lGenerator.Emit(OpCodes.Stloc, localBuilderArray[(int)localBuilderArray.Length - 1]);
						lGenerator.Emit(OpCodes.Ldloc_S, localBuilderArray[(int)localBuilderArray.Length - 1]);
					}
				}
				for (int l = 0; l < (int)parameterType.Length; l++)
				{
					if (parameters[l].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldloca_S, localBuilderArray[l]);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
					}
				}
				if (bool_0)
				{
					if (object0 == null)
					{
						lGenerator.Emit(OpCodes.Call, object_0 as ConstructorInfo);
					}
					else
					{
						lGenerator.EmitCall(OpCodes.Call, object0, null);
					}
				}
				else if (object0 == null)
				{
					lGenerator.Emit(OpCodes.Callvirt, object_0 as ConstructorInfo);
				}
				else
				{
					lGenerator.EmitCall(OpCodes.Callvirt, object0, null);
				}
				if (object0 == null || object0.ReturnType == typeof(void))
				{
					lGenerator.Emit(OpCodes.Ldnull);
				}
				else if (object0.ReturnType.IsByRef)
				{
					Type elementType = object0.ReturnType.GetElementType();
					if (!elementType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Ldind_Ref, elementType);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldobj, elementType);
					}
					if (elementType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Box, elementType);
					}
				}
				else if (object0.ReturnType.IsValueType)
				{
					lGenerator.Emit(OpCodes.Box, object0.ReturnType);
				}
				for (int m = 0; m < (int)parameterType.Length; m++)
				{
					if (parameters[m].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldarg_1);
						jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, m);
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
						if (localBuilderArray[m].LocalType.IsValueType)
						{
							lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
						}
						lGenerator.Emit(OpCodes.Stelem_Ref);
					}
				}
				lGenerator.Emit(OpCodes.Ret);
				jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE1 = (jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE)dynamicMethod.CreateDelegate(typeof(jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE));
				if (bool_0)
				{
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.FZn9SmJTjr.Add(object_0, _r4nv1bdWw1MJmxvckeE1);
				}
				else
				{
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.cJF9boxpgB.Add(object_0, _r4nv1bdWw1MJmxvckeE1);
				}
				return _r4nv1bdWw1MJmxvckeE1;
			}

			private static jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 T4B9sBFTFg(object object_0)
			{
				jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 object0 = object_0 as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				if (object0 == null && object_0.lFyJQh378A())
				{
					object0 = object_0.e4VxkrOKkN() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				}
				return object0;
			}

			private static int T5Z9YZGZ3n(Type type_0)
			{
				int num;
				if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fEO94sciuI == null)
				{
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fEO94sciuI = new Dictionary<Type, int>();
				}
				try
				{
					int num1 = 0;
					if (!jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fEO94sciuI.TryGetValue(type_0, out num1))
					{
						DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(int), Type.EmptyTypes, true);
						ILGenerator lGenerator = dynamicMethod.GetILGenerator();
						lGenerator.Emit(OpCodes.Sizeof, type_0);
						lGenerator.Emit(OpCodes.Ret);
						num1 = (int)dynamicMethod.Invoke(null, null);
						jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fEO94sciuI[type_0] = num1;
						num = num1;
					}
					else
					{
						num = num1;
					}
				}
				catch
				{
					num = 0;
				}
				return num;
			}

			internal List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX> UAAdky7JXU(int int_0, bool bool_0)
			{
				if (this.EIo9Uhr0DF.lwRdiOdWOb == null)
				{
					return null;
				}
				List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX> jFcSR6dTBGIgDFch6vXes = new List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX>();
				foreach (jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX eIo9Uhr0DF in this.EIo9Uhr0DF.lwRdiOdWOb)
				{
					if ((eIo9Uhr0DF.Db3dClUCyb.JEqdKDjJeC & 1) != 1 || int_0 < eIo9Uhr0DF.uHZd7cIBmK || int_0 > eIo9Uhr0DF.If6deLgLUC)
					{
						continue;
					}
					jFcSR6dTBGIgDFch6vXes.Add(eIo9Uhr0DF);
				}
				if (jFcSR6dTBGIgDFch6vXes.Count == 0)
				{
					return null;
				}
				return jFcSR6dTBGIgDFch6vXes;
			}

			internal void VlMdZ0DxVQ()
			{
				this.Qpw9FAEf54.c2X0tj4ouL();
				this.Xto9u3WxQY = null;
				if (this.K0e9Vgn9Ex != null)
				{
					foreach (IntPtr k0e9Vgn9Ex in this.K0e9Vgn9Ex)
					{
						try
						{
							Marshal.FreeHGlobal(k0e9Vgn9Ex);
						}
						catch
						{
						}
					}
					this.K0e9Vgn9Ex.Clear();
					this.K0e9Vgn9Ex = null;
				}
			}

			private jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 VnHi2pUGWD(int int_0)
			{
				return this.Xto9u3WxQY[int_0];
			}

			private void Wmpdf5KPiJ(jyRxpEAUNlcH3bE07bK.sVb83IG1u6ZbkqvM6XP sVb83IG1u6ZbkqvM6XP_0)
			{
				Type elementType;
				uint num;
				object obj;
				jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 _ub3yhfGU9uM2BP4kQQ4;
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0;
				IntPtr intPtr;
				bool flag;
				long b3wGtwGQYo;
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _wLXsfX0CtM6lkRpgimf;
				jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 _ub3yhfGU9uM2BP4kQQ41;
				object value;
				Module module;
				FieldInfo fieldInfo;
				Array arrays;
				int num1;
				switch (sVb83IG1u6ZbkqvM6XP_0.VGbG3kYEQE)
				{
					case 0:
					{
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType((int)this.d9P9klDQ9w);
						value = this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(elementType) ?? Activator.CreateInstance(elementType);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.CS69wAKt9s(value))));
						return;
					}
					case 1:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.vTfxlGJn0p());
						return;
					}
					case 2:
					case 12:
					case 58:
					case 80:
					case 113:
					case 149:
					case 157:
					case 159:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						Array arrays1 = (Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
						elementType = arrays1.GetType().GetElementType();
						arrays1.SetValue(_wLXsfX0CtM6lkRpgimf.B550VtrALj(elementType), _ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						return;
					}
					case 3:
					{
						num1 = (int)this.d9P9klDQ9w;
						if (this.EIo9Uhr0DF.d3JdACOT1O.IsStatic)
						{
							this.aSm9Pn8nCP[num1] = this.RN8dDvEJnD(this.Qpw9FAEf54.nws0A8A7sG(), this.EIo9Uhr0DF.r2IddyNrH5[num1].kL6dBTlsp4, false);
							return;
						}
						this.aSm9Pn8nCP[num1] = this.RN8dDvEJnD(this.Qpw9FAEf54.nws0A8A7sG(), this.EIo9Uhr0DF.r2IddyNrH5[num1 - 1].kL6dBTlsp4, false);
						return;
					}
					case 4:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 5:
					{
						this.xwF9gbU1AD = (bool)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(typeof(bool));
						this.FFG9mZW8DX = true;
						return;
					}
					case 6:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						_leA9Ha0oP4AaSA2idq0 = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_leA9Ha0oP4AaSA2idq0);
						if (_ub3yhfGU9uM2BP4kQQ41 != null && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							if (_ub3yhfGU9uM2BP4kQQ41.MwSxSSYZQ3(_wLXsfX0CtM6lkRpgimf))
							{
								this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
							}
							return;
						}
						if (_wLXsfX0CtM6lkRpgimf.D8TxDuVrlI(_leA9Ha0oP4AaSA2idq0))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 7:
					{
						value = this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
						_wLXsfX0CtM6lkRpgimf = null;
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fWI9jVp50h.TryGetValue(value, out _wLXsfX0CtM6lkRpgimf))
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_wLXsfX0CtM6lkRpgimf);
							return;
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null));
						return;
					}
					case 8:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.vxLxnN4YIU());
						return;
					}
					case 9:
					{
						throw (Exception)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
					}
					case 10:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP((int)this.d9P9klDQ9w, this));
						return;
					}
					case 11:
					case 14:
					case 36:
					case 40:
					case 63:
					case 141:
					{
						throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
					}
					case 13:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.rROx2jU6yR());
						return;
					}
					case 15:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf.uliJnV0bkk())
						{
							_wLXsfX0CtM6lkRpgimf = ((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)_wLXsfX0CtM6lkRpgimf).wLFxHSrDCX();
						}
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 16:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(float), value));
						return;
					}
					case 17:
					{
						num1 = (int)this.d9P9klDQ9w;
						Type type = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						arrays = Array.CreateInstance(type, _ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(arrays));
						return;
					}
					case 18:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.LpNxocNMFW());
						return;
					}
					case 19:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.d9P9klDQ9w));
						return;
					}
					case 20:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.LJgxESAkAG(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 21:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = (jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)this.Qpw9FAEf54.nws0A8A7sG();
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.ErsxxFLS44(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 22:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.xN5xqf54GS());
						return;
					}
					case 23:
					case 33:
					case 39:
					case 53:
					case 68:
					case 137:
					{
						return;
					}
					case 24:
					{
						num1 = (int)this.d9P9klDQ9w;
						fieldInfo = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveField(num1);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(fieldInfo.FieldType, fieldInfo.GetValue(null)));
						return;
					}
					case 25:
					{
						jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 _ub3yhfGU9uM2BP4kQQ42 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.gsU0l8Uviv());
						if (_ub3yhfGU9uM2BP4kQQ42 == null)
						{
							throw new ArithmeticException(0.ToString());
						}
						jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 uZehaBGPBl166kGCJj8 = _ub3yhfGU9uM2BP4kQQ42 as jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8;
						if (uZehaBGPBl166kGCJj8 != null)
						{
							if (double.IsNaN(uZehaBGPBl166kGCJj8.OLPGunv0l8))
							{
								throw new OverflowException(2.ToString());
							}
							if (double.IsInfinity(uZehaBGPBl166kGCJj8.OLPGunv0l8))
							{
								throw new OverflowException(1.ToString());
							}
						}
						return;
					}
					case 26:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						_leA9Ha0oP4AaSA2idq0 = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_leA9Ha0oP4AaSA2idq0);
						if (_ub3yhfGU9uM2BP4kQQ41 != null && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							if (_ub3yhfGU9uM2BP4kQQ41.MwSxSSYZQ3(_wLXsfX0CtM6lkRpgimf))
							{
								this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1));
								return;
							}
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0));
							return;
						}
						if (!_wLXsfX0CtM6lkRpgimf.D8TxDuVrlI(_leA9Ha0oP4AaSA2idq0))
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0));
							return;
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1));
						return;
					}
					case 27:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.q5bxim1OPw(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 28:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null || _ub3yhfGU9uM2BP4kQQ41 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.D1fxFGeqb7(_ub3yhfGU9uM2BP4kQQ41));
						return;
					}
					case 29:
					{
						num1 = (int)this.d9P9klDQ9w;
						fieldInfo = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveField(num1);
						jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq01 = this.Qpw9FAEf54.nws0A8A7sG();
						_leA9Ha0oP4AaSA2idq01.e4VxkrOKkN();
						value = _leA9Ha0oP4AaSA2idq01.B550VtrALj(null);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB(fieldInfo, value));
						return;
					}
					case 30:
					{
						if (this.Qpw9FAEf54.nws0A8A7sG().D8TxDuVrlI(this.Qpw9FAEf54.nws0A8A7sG()))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 31:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf.uliJnV0bkk())
						{
							_wLXsfX0CtM6lkRpgimf = ((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)_wLXsfX0CtM6lkRpgimf).CLj0bGxkbn();
						}
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 32:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(uint), value));
						return;
					}
					case 34:
					case 42:
					{
						num1 = (int)this.d9P9klDQ9w;
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						value = _wLXsfX0CtM6lkRpgimf.B550VtrALj(elementType);
						if (value != null)
						{
							if (elementType.IsValueType)
							{
								value = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.CS69wAKt9s(value);
							}
							_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value);
						}
						else if (elementType.IsValueType)
						{
							value = Activator.CreateInstance(elementType);
							_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value);
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null);
						}
						jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT _k18BcGGfvFEps11heXT = this.Qpw9FAEf54.nws0A8A7sG() as jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT;
						if (_k18BcGGfvFEps11heXT == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						_k18BcGGfvFEps11heXT.ik90UsF9KT(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 35:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.Jl4xcF8KnQ());
						return;
					}
					case 37:
					{
						this.l969v4tddu(true);
						return;
					}
					case 38:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(byte), value));
						return;
					}
					case 41:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.afbxVgfTCY(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 43:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						value = this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
						jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.fWI9jVp50h[value] = _wLXsfX0CtM6lkRpgimf;
						return;
					}
					case 44:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.RFK0SjXY75());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((sbyte)(*(void*)intPtr), 1));
						return;
					}
					case 45:
					case 166:
					{
						num1 = (int)this.d9P9klDQ9w;
						module = typeof(jyRxpEAUNlcH3bE07bK).Module;
						jyRxpEAUNlcH3bE07bK.w6jpMb0Rkw8HjOr2xos qpw9FAEf54 = this.Qpw9FAEf54;
						RuntimeMethodHandle methodHandle = module.ResolveMethod(num1).MethodHandle;
						qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(methodHandle.GetFunctionPointer()));
						return;
					}
					case 46:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.gOuxp90V6G(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 47:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.SRix9vq6s5(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 48:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.PO50N2hhDU());
						return;
					}
					case 49:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(double), value));
						return;
					}
					case 50:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.wLFxHSrDCX());
						return;
					}
					case 51:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf.uliJnV0bkk())
						{
							_wLXsfX0CtM6lkRpgimf = ((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)_wLXsfX0CtM6lkRpgimf).PO50N2hhDU();
						}
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 52:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.F8qxT1rsi6());
						return;
					}
					case 54:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.wpEx5XwQs6());
						return;
					}
					case 55:
					{
						_ub3yhfGU9uM2BP4kQQ4 = this.Qpw9FAEf54.nws0A8A7sG() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
						intPtr = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.b1k9EKjicT(this.Qpw9FAEf54.nws0A8A7sG());
						IntPtr intPtr1 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.b1k9EKjicT(this.Qpw9FAEf54.nws0A8A7sG());
						if (intPtr != IntPtr.Zero && intPtr1 != IntPtr.Zero)
						{
							num = _ub3yhfGU9uM2BP4kQQ4.xPC0gkXCdf().kTNGBJtJF0.zaBGQHNwcU;
							jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.RVt9WaJj50(intPtr1, intPtr, num);
						}
						return;
					}
					case 56:
					{
						throw this.P959ZbR8oj;
					}
					case 57:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(ushort), value));
						return;
					}
					case 59:
					{
						num1 = (int)this.d9P9klDQ9w;
						num = (uint)jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T5Z9YZGZ3n(typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1));
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(num, 6));
						return;
					}
					case 60:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						Array arrays2 = (Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
						value = arrays2.GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						elementType = arrays2.GetType().GetElementType();
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value));
						return;
					}
					case 61:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.J39xB0fFjG());
						return;
					}
					case 62:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.PD5xRl3JtH());
						return;
					}
					case 64:
					{
						num1 = (int)this.d9P9klDQ9w;
						fieldInfo = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveField(num1);
						value = this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(fieldInfo.FieldType);
						fieldInfo.SetValue(null, value);
						return;
					}
					case 65:
					{
						num1 = (int)this.d9P9klDQ9w;
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						value = this.Qpw9FAEf54.nws0A8A7sG().e4VxkrOKkN().B550VtrALj(elementType);
						_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value);
						this.Qpw9FAEf54.lwm0Kd30PY(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 66:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.LgEx00tIXr(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 67:
					{
						num1 = (int)this.d9P9klDQ9w;
						this.Xto9u3WxQY[num1] = this.RN8dDvEJnD(this.Qpw9FAEf54.nws0A8A7sG(), this.EIo9Uhr0DF.wYNdvFYKwB[num1].CltdMTgipO, this.EIo9Uhr0DF.wYNdvFYKwB[num1].FHadayiPnr);
						return;
					}
					case 69:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)this.d9P9klDQ9w));
						return;
					}
					case 70:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.PD5xRl3JtH());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						if (IntPtr.Size == 8)
						{
							b3wGtwGQYo = (long)(*(void*)intPtr);
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(b3wGtwGQYo, 12));
							return;
						}
						num1 = (int)(*(void*)intPtr);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)num1, 12));
						return;
					}
					case 71:
					{
						jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq02 = this.Qpw9FAEf54.nws0A8A7sG();
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_leA9Ha0oP4AaSA2idq02.JOKxmtllMB(_wLXsfX0CtM6lkRpgimf))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 72:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null || _ub3yhfGU9uM2BP4kQQ41 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.YygxuJKocU(_ub3yhfGU9uM2BP4kQQ41));
						return;
					}
					case 73:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(this.Qpw9FAEf54.nws0A8A7sG().e4VxkrOKkN());
						return;
					}
					case 74:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf.uliJnV0bkk())
						{
							_wLXsfX0CtM6lkRpgimf = ((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)_wLXsfX0CtM6lkRpgimf).PD5xRl3JtH();
						}
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 75:
					{
						num1 = (int)this.d9P9klDQ9w;
						fieldInfo = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveField(num1);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB(fieldInfo, null));
						return;
					}
					case 76:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.N2YxsjFtx6());
						return;
					}
					case 77:
					{
						return;
					}
					case 78:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.Yxvxyosj9C());
						return;
					}
					case 79:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.CLj0bGxkbn());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((short)(*(void*)intPtr), 3));
						return;
					}
					case 81:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)this.Qpw9FAEf54.nws0A8A7sG()).pEZxd6HgCc());
						return;
					}
					case 82:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (!_wLXsfX0CtM6lkRpgimf.lFyJQh378A())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						value = _wLXsfX0CtM6lkRpgimf.B550VtrALj(null);
						if (value == null)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null);
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(value.GetType(), value);
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 83:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((float)this.d9P9klDQ9w));
						return;
					}
					case 84:
					{
						num1 = (int)this.d9P9klDQ9w;
						ConstructorInfo constructorInfo = (ConstructorInfo)typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveMethod(num1);
						ParameterInfo[] parameters = constructorInfo.GetParameters();
						object[] objArray = new object[(int)parameters.Length];
						jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[] leA9Ha0oP4AaSA2idq0Array = new jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0[(int)parameters.Length];
						List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL> pLsU0rd9OKulQRgoEBLs = null;
						jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO _p481LxdJNmdNfriwEHO = null;
						for (int i = 0; i < (int)parameters.Length; i++)
						{
							_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
							elementType = parameters[(int)parameters.Length - 1 - i].ParameterType;
							obj = null;
							flag = false;
							if (elementType.IsByRef)
							{
								jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB kTm31lGbFDDwe0QcrjB = _wLXsfX0CtM6lkRpgimf as jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB;
								if (kTm31lGbFDDwe0QcrjB != null)
								{
									if (pLsU0rd9OKulQRgoEBLs == null)
									{
										pLsU0rd9OKulQRgoEBLs = new List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL>();
									}
									pLsU0rd9OKulQRgoEBLs.Add(new jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL(kTm31lGbFDDwe0QcrjB.Wd4GNZmaAW, i));
									obj = kTm31lGbFDDwe0QcrjB.pWPGzr94Xa;
									if (!(obj is jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0))
									{
										flag = true;
									}
									else
									{
										_wLXsfX0CtM6lkRpgimf = obj as jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0;
									}
								}
							}
							if (!flag)
							{
								if (_wLXsfX0CtM6lkRpgimf != null)
								{
									obj = _wLXsfX0CtM6lkRpgimf.B550VtrALj(elementType);
								}
								if (obj == null)
								{
									if (elementType.IsByRef)
									{
										elementType = elementType.GetElementType();
									}
									if (elementType.IsValueType)
									{
										obj = Activator.CreateInstance(elementType);
										if (_wLXsfX0CtM6lkRpgimf is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)
										{
											((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)_wLXsfX0CtM6lkRpgimf).QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, obj));
										}
									}
								}
							}
							leA9Ha0oP4AaSA2idq0Array[(int)objArray.Length - 1 - i] = _wLXsfX0CtM6lkRpgimf;
							objArray[(int)objArray.Length - 1 - i] = obj;
						}
						jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE = null;
						if (pLsU0rd9OKulQRgoEBLs != null)
						{
							_p481LxdJNmdNfriwEHO = new jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO(constructorInfo, pLsU0rd9OKulQRgoEBLs);
							_r4nv1bdWw1MJmxvckeE = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.yTI90eHo3T(constructorInfo, true, _p481LxdJNmdNfriwEHO);
						}
						value = null;
						value = (_r4nv1bdWw1MJmxvckeE != null ? _r4nv1bdWw1MJmxvckeE(null, objArray) : constructorInfo.Invoke(objArray));
						for (int j = 0; j < (int)parameters.Length; j++)
						{
							if (parameters[j].ParameterType.IsByRef && (_p481LxdJNmdNfriwEHO == null || !_p481LxdJNmdNfriwEHO.vZHdE3at2i(j)))
							{
								if (leA9Ha0oP4AaSA2idq0Array[j].v790Bk1BmX())
								{
									((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)leA9Ha0oP4AaSA2idq0Array[j]).oyxGAVlfDS(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(parameters[j].ParameterType, objArray[j]));
								}
								else if (!(leA9Ha0oP4AaSA2idq0Array[j] is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP))
								{
									leA9Ha0oP4AaSA2idq0Array[j].ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(parameters[j].ParameterType, objArray[j]));
								}
								else
								{
									leA9Ha0oP4AaSA2idq0Array[j].ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(parameters[j].ParameterType.GetElementType(), objArray[j]));
								}
							}
						}
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(constructorInfo.DeclaringType, value));
						return;
					}
					case 85:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null));
						return;
					}
					case 86:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.nBW0zA6Cn1());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)(*(void*)intPtr), 7));
						return;
					}
					case 87:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (!jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).U2yxzSjQyb(_wLXsfX0CtM6lkRpgimf))
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0));
							return;
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1));
						return;
					}
					case 88:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).U2yxzSjQyb(_wLXsfX0CtM6lkRpgimf))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 89:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(int), value));
						return;
					}
					case 90:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.vxLxnN4YIU());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((uint)(*(void*)intPtr), 6));
						return;
					}
					case 91:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).endx4m7CQT(_wLXsfX0CtM6lkRpgimf))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 92:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.nBW0zA6Cn1());
						return;
					}
					case 93:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).IG7xjsK4EF(_wLXsfX0CtM6lkRpgimf))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 94:
					{
						flag = false;
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						flag = (_wLXsfX0CtM6lkRpgimf == null ? true : !_wLXsfX0CtM6lkRpgimf.qjs01aMKus());
						if (flag)
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 95:
					{
						this.Qpw9FAEf54.nws0A8A7sG();
						return;
					}
					case 96:
					{
						num1 = (int)this.d9P9klDQ9w;
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value));
						return;
					}
					case 97:
					{
						num1 = (int)this.d9P9klDQ9w;
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT _k18BcGGfvFEps11heXT1 = this.Qpw9FAEf54.nws0A8A7sG() as jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT;
						if (_k18BcGGfvFEps11heXT1 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						if (!elementType.IsValueType)
						{
							_k18BcGGfvFEps11heXT1.QhFJINNrIN(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null));
							return;
						}
						value = Activator.CreateInstance(elementType);
						_k18BcGGfvFEps11heXT1.QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value));
						return;
					}
					case 98:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.RFK0SjXY75());
						return;
					}
					case 99:
					{
						if (jyRxpEAUNlcH3bE07bK.YbZADR2iqk.Count != 0)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t(jyRxpEAUNlcH3bE07bK.YbZADR2iqk[(int)this.d9P9klDQ9w]));
							return;
						}
						module = typeof(jyRxpEAUNlcH3bE07bK).Module;
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t(module.ResolveString((int)this.d9P9klDQ9w | 1879048192)));
						return;
					}
					case 100:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.pnExQQrrXk());
						return;
					}
					case 101:
					{
						this.B9n9LCHQq0 = -3;
						if (this.Qpw9FAEf54.xLqe4PZWEH() > 0)
						{
							this.dPu9XZ7s2L = this.Qpw9FAEf54.nws0A8A7sG();
						}
						return;
					}
					case 102:
					{
						this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						return;
					}
					case 103:
					{
						num1 = (int)this.d9P9klDQ9w;
						module = typeof(jyRxpEAUNlcH3bE07bK).Module;
						value = null;
						try
						{
							value = module.ResolveType(num1);
						}
						catch
						{
							try
							{
								value = module.ResolveMethod(num1);
							}
							catch
							{
								try
								{
									value = module.ResolveField(num1);
								}
								catch
								{
									value = module.ResolveMember(num1);
								}
							}
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(value));
						return;
					}
					case 104:
					{
						num1 = (int)this.d9P9klDQ9w;
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).SetValue(_wLXsfX0CtM6lkRpgimf.B550VtrALj(elementType), _ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						return;
					}
					case 105:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.OBOxedVMZo());
						return;
					}
					case 106:
					{
						num1 = (int)this.d9P9klDQ9w;
						fieldInfo = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveField(num1);
						value = this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(fieldInfo.FieldType, fieldInfo.GetValue(value)));
						return;
					}
					case 107:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.Nnox7pcLUS());
						return;
					}
					case 108:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.YShxOlBEdt());
						return;
					}
					case 109:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.GK8x1mthyY(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 110:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.AIrxLYOPbe(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 111:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.wpEx5XwQs6());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)(*(void*)intPtr), 2));
						return;
					}
					case 112:
					{
						num1 = (int)this.d9P9klDQ9w;
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT _k18BcGGfvFEps11heXT2 = this.Qpw9FAEf54.nws0A8A7sG() as jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT;
						if (_k18BcGGfvFEps11heXT2 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						value = _k18BcGGfvFEps11heXT2.B550VtrALj(elementType);
						if (value != null)
						{
							if (elementType.IsValueType)
							{
								value = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.CS69wAKt9s(value);
							}
							_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value);
						}
						else if (!elementType.IsValueType)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null);
						}
						else
						{
							value = Activator.CreateInstance(elementType);
							_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, value);
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 114:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).C2DxgtwF4s(_wLXsfX0CtM6lkRpgimf))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 115:
					{
						jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq03 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Xkj9JVZbQF(this.Qpw9FAEf54.nws0A8A7sG());
						_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Xkj9JVZbQF(this.Qpw9FAEf54.nws0A8A7sG());
						if (_leA9Ha0oP4AaSA2idq03.JOKxmtllMB(_wLXsfX0CtM6lkRpgimf))
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1));
							return;
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0));
						return;
					}
					case 116:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.OaTxvqmDKP(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 117:
					{
						this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						this.F6n9f9x65k = true;
						return;
					}
					case 118:
					{
						arrays = (Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(arrays.Length, 5));
						return;
					}
					case 119:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).IG7xjsK4EF(_wLXsfX0CtM6lkRpgimf))
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1));
							return;
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0));
						return;
					}
					case 120:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.mZUxWFSSW6(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 121:
					{
						this.l969v4tddu(false);
						return;
					}
					case 122:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.qwAxaCXBp2());
						return;
					}
					case 123:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.KTBxI7JM1N());
						return;
					}
					case 124:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.ASAxYcksDW());
						return;
					}
					case 125:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.CLj0bGxkbn());
						return;
					}
					case 126:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.gduxhTRAky());
						return;
					}
					case 127:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).JNkxbaE9i0(_wLXsfX0CtM6lkRpgimf))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 128:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						bool flag1 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).AIWJ56fpmE(_wLXsfX0CtM6lkRpgimf);
						if (flag1)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1));
						}
						else
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0));
						}
						if (flag1)
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 129:
					{
						this.dYf9DCi0w4 = true;
						return;
					}
					case 130:
					{
						num1 = (int)this.d9P9klDQ9w;
						elementType = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						value = _wLXsfX0CtM6lkRpgimf.B550VtrALj(null);
						if (value == null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null));
							return;
						}
						if (elementType.IsAssignableFrom(value.GetType()))
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_wLXsfX0CtM6lkRpgimf);
							return;
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null));
						return;
					}
					case 131:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).wgXxNAO14B(_wLXsfX0CtM6lkRpgimf))
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 132:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.PO50N2hhDU());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)(*(void*)intPtr), 5));
						return;
					}
					case 133:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(long), value));
						return;
					}
					case 134:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.qjs01aMKus())
						{
							this.B9n9LCHQq0 = (int)this.d9P9klDQ9w - 1;
						}
						return;
					}
					case 135:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.y8Dx80UigU(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 136:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.UjQxA95UDE());
						return;
					}
					case 138:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.FEsx6tlZCe());
						return;
					}
					case 139:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.lFDxK1rVZS());
						return;
					}
					case 140:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf.uliJnV0bkk())
						{
							_wLXsfX0CtM6lkRpgimf = ((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)_wLXsfX0CtM6lkRpgimf).RFK0SjXY75();
						}
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 142:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null || _ub3yhfGU9uM2BP4kQQ41 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.vsvxZprm8I(_ub3yhfGU9uM2BP4kQQ41));
						return;
					}
					case 143:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(this.aSm9Pn8nCP[(int)this.d9P9klDQ9w]);
						return;
					}
					case 144:
					{
						num1 = (int)this.d9P9klDQ9w;
						typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveType(num1);
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						arrays = (Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps, arrays));
						return;
					}
					case 145:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(sbyte), value));
						return;
					}
					case 146:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.FscxMh0y89());
						return;
					}
					case 147:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG()).AIWJ56fpmE(_wLXsfX0CtM6lkRpgimf))
						{
							this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1));
							return;
						}
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0));
						return;
					}
					case 148:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.Fu6xtFY6Su());
						return;
					}
					case 150:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf.uliJnV0bkk())
						{
							_wLXsfX0CtM6lkRpgimf = ((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)_wLXsfX0CtM6lkRpgimf).nBW0zA6Cn1();
						}
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 151:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.gduxhTRAky());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((float)(*(void*)intPtr), 9));
						return;
					}
					case 152:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.WibxXYkaNk());
						return;
					}
					case 153:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.wLFxHSrDCX());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)(*(void*)intPtr), 10));
						return;
					}
					case 154:
					{
						_ub3yhfGU9uM2BP4kQQ4 = this.Qpw9FAEf54.nws0A8A7sG() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
						_ub3yhfGU9uM2BP4kQQ41 = this.Qpw9FAEf54.nws0A8A7sG() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
						intPtr = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.b1k9EKjicT(this.Qpw9FAEf54.nws0A8A7sG());
						if (intPtr != IntPtr.Zero)
						{
							byte jGqAzCDQNa = _ub3yhfGU9uM2BP4kQQ41.u360kVINWM().kTNGBJtJF0.JGqAzCDQNa;
							num = _ub3yhfGU9uM2BP4kQQ4.xPC0gkXCdf().kTNGBJtJF0.zaBGQHNwcU;
							jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.DXS9p70NnV(intPtr, jGqAzCDQNa, (int)num);
						}
						return;
					}
					case 155:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.lYyxrsIRV7());
						return;
					}
					case 156:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						if (_wLXsfX0CtM6lkRpgimf.uliJnV0bkk())
						{
							_wLXsfX0CtM6lkRpgimf = ((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)_wLXsfX0CtM6lkRpgimf).gduxhTRAky();
						}
						this.Qpw9FAEf54.nws0A8A7sG().mGF0P5nyg1(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 158:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.lGKxGefAaJ());
						return;
					}
					case 160:
					{
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(_wLXsfX0CtM6lkRpgimf);
						if (_wLXsfX0CtM6lkRpgimf != null && _wLXsfX0CtM6lkRpgimf.lFyJQh378A() && _ub3yhfGU9uM2BP4kQQ4 != null)
						{
							this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.Jl4xcF8KnQ());
							return;
						}
						if (_ub3yhfGU9uM2BP4kQQ4 == null || !_ub3yhfGU9uM2BP4kQQ4.v790Bk1BmX())
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						intPtr = ((jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy)_ub3yhfGU9uM2BP4kQQ4).KhkGGSdMs1();
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)(*(void*)intPtr), 4));
						return;
					}
					case 161:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(IntPtr), value));
						return;
					}
					case 162:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.cv9xPNKjLE(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 163:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						value = ((Array)this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(null)).GetValue(_ub3yhfGU9uM2BP4kQQ4.T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						this.Qpw9FAEf54.lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(typeof(short), value));
						return;
					}
					case 164:
					{
						num1 = (int)this.d9P9klDQ9w;
						fieldInfo = typeof(jyRxpEAUNlcH3bE07bK).Module.ResolveField(num1);
						value = this.Qpw9FAEf54.nws0A8A7sG().B550VtrALj(fieldInfo.FieldType);
						_wLXsfX0CtM6lkRpgimf = this.Qpw9FAEf54.nws0A8A7sG();
						obj = _wLXsfX0CtM6lkRpgimf.B550VtrALj(null);
						if (obj == null)
						{
							elementType = fieldInfo.DeclaringType;
							if (elementType.IsByRef)
							{
								elementType = elementType.GetElementType();
							}
							if (!elementType.IsValueType)
							{
								throw new NullReferenceException();
							}
							obj = Activator.CreateInstance(elementType);
							if (_wLXsfX0CtM6lkRpgimf is jyRxpEAUNlcH3bE07bK.HafCVDGmIDyKmskHSEP)
							{
								((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)_wLXsfX0CtM6lkRpgimf).QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(elementType, obj));
							}
						}
						fieldInfo.SetValue(obj, value);
						return;
					}
					case 165:
					{
						int[] numArray = (int[])this.d9P9klDQ9w;
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						b3wGtwGQYo = _ub3yhfGU9uM2BP4kQQ4.bom045C5yQ().B3wGtwGQYo.qMbGqoMUDp;
						if ((b3wGtwGQYo < 0L || _ub3yhfGU9uM2BP4kQQ4.BY4027cwoa()) && IntPtr.Size == 4)
						{
							b3wGtwGQYo = (long)((int)b3wGtwGQYo);
						}
						if (_ub3yhfGU9uM2BP4kQQ4.Eym0Y22UOo())
						{
							jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb fR14lrGIXaRSLEjVDsb = (jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb)_ub3yhfGU9uM2BP4kQQ4;
							if ((int)fR14lrGIXaRSLEjVDsb.ENkGrsAFRR == 6)
							{
								b3wGtwGQYo = (long)fR14lrGIXaRSLEjVDsb.kTNGBJtJF0.zaBGQHNwcU;
							}
						}
						if (b3wGtwGQYo < (long)((int)numArray.Length) && b3wGtwGQYo >= 0L)
						{
							this.B9n9LCHQq0 = numArray[checked((IntPtr)b3wGtwGQYo)] - 1;
						}
						return;
					}
					case 167:
					{
						intPtr = Marshal.AllocHGlobal((this.Qpw9FAEf54.nws0A8A7sG() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps);
						if (this.K0e9Vgn9Ex == null)
						{
							this.K0e9Vgn9Ex = new List<IntPtr>();
						}
						this.K0e9Vgn9Ex.Add(intPtr);
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(intPtr));
						return;
					}
					case 168:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(this.Qpw9FAEf54.gsU0l8Uviv());
						return;
					}
					case 169:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ4.W7TxCiinJ2());
						return;
					}
					case 170:
					{
						_wLXsfX0CtM6lkRpgimf = this.Xto9u3WxQY[(int)this.d9P9klDQ9w];
						this.Qpw9FAEf54.lwm0Kd30PY(_wLXsfX0CtM6lkRpgimf);
						return;
					}
					case 171:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)this.d9P9klDQ9w));
						return;
					}
					case 172:
					{
						this.Qpw9FAEf54.lwm0Kd30PY(new jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe((int)this.d9P9klDQ9w, this));
						return;
					}
					case 173:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.s2NxJDBMr7(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 174:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.QkpxwApqeH(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					case 175:
					{
						_ub3yhfGU9uM2BP4kQQ4 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						_ub3yhfGU9uM2BP4kQQ41 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.T4B9sBFTFg(this.Qpw9FAEf54.nws0A8A7sG());
						if (_ub3yhfGU9uM2BP4kQQ41 == null || _ub3yhfGU9uM2BP4kQQ4 == null)
						{
							throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
						}
						this.Qpw9FAEf54.lwm0Kd30PY(_ub3yhfGU9uM2BP4kQQ41.S9hxU3utYx(_ub3yhfGU9uM2BP4kQQ4));
						return;
					}
					default:
					{
						return;
					}
				}
			}

			private static jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 Xkj9JVZbQF(object object_0)
			{
				if (object_0.e4VxkrOKkN().nSa06LHEGl())
				{
					object obj = object_0.B550VtrALj(null);
					if (obj != null && obj.GetType().IsEnum)
					{
						Type underlyingType = Enum.GetUnderlyingType(obj.GetType());
						object obj1 = Convert.ChangeType(obj, underlyingType);
						jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.n6b98XxKvm(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(underlyingType, obj1));
						if (_leA9Ha0oP4AaSA2idq0 != null)
						{
							return _leA9Ha0oP4AaSA2idq0 as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
						}
					}
				}
				return object_0;
			}

			internal jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX xVOd3ntiEn(int int_0, Exception exception_0)
			{
				jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX jFcSR6dTBGIgDFch6vX = null;
				if (this.EIo9Uhr0DF.lwRdiOdWOb != null)
				{
					foreach (jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX eIo9Uhr0DF in this.EIo9Uhr0DF.lwRdiOdWOb)
					{
						if (eIo9Uhr0DF.Db3dClUCyb.JEqdKDjJeC != 0 || !(eIo9Uhr0DF.Db3dClUCyb.jSEdRtMtoU == exception_0.GetType()) && (!(eIo9Uhr0DF.Db3dClUCyb.jSEdRtMtoU != null) || !(eIo9Uhr0DF.Db3dClUCyb.jSEdRtMtoU.FullName == exception_0.GetType().FullName) && !(eIo9Uhr0DF.Db3dClUCyb.jSEdRtMtoU.FullName == typeof(object).FullName) && !(eIo9Uhr0DF.Db3dClUCyb.jSEdRtMtoU.FullName == typeof(Exception).FullName)) || int_0 < eIo9Uhr0DF.uHZd7cIBmK || int_0 > eIo9Uhr0DF.If6deLgLUC)
						{
							continue;
						}
						if (jFcSR6dTBGIgDFch6vX == null)
						{
							jFcSR6dTBGIgDFch6vX = eIo9Uhr0DF;
						}
						else
						{
							if (eIo9Uhr0DF.Db3dClUCyb.IhYdhLIMeS >= jFcSR6dTBGIgDFch6vX.Db3dClUCyb.IhYdhLIMeS)
							{
								continue;
							}
							jFcSR6dTBGIgDFch6vX = eIo9Uhr0DF;
						}
					}
				}
				return jFcSR6dTBGIgDFch6vX;
			}

			internal static jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht XytcO8ccp4UIZdB0W53J()
			{
				return jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.NOyh5ZccE1LWTDhOYphv;
			}

			private static jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE yAd99JKGsU(object object_0, bool bool_0, object object_1)
			{
				jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE = null;
				if (!bool_0)
				{
					if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.S0i9zt0M72.TryGetValue(object_1, out _r4nv1bdWw1MJmxvckeE))
					{
						return _r4nv1bdWw1MJmxvckeE;
					}
				}
				else if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.b6N9NW03cF.TryGetValue(object_1, out _r4nv1bdWw1MJmxvckeE))
				{
					return _r4nv1bdWw1MJmxvckeE;
				}
				MethodInfo object0 = object_0 as MethodInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object), typeof(object[]) }, typeof(jyRxpEAUNlcH3bE07bK), true);
				ILGenerator lGenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = object_0.GetParameters();
				Type[] parameterType = new Type[(int)parameters.Length];
				for (int i = 0; i < (int)parameterType.Length; i++)
				{
					if (!parameters[i].ParameterType.IsByRef)
					{
						parameterType[i] = parameters[i].ParameterType;
					}
					else
					{
						parameterType[i] = parameters[i].ParameterType.GetElementType();
					}
				}
				int length = (int)parameterType.Length;
				if (object_0.DeclaringType.IsValueType)
				{
					length++;
				}
				LocalBuilder[] localBuilderArray = new LocalBuilder[length];
				for (int j = 0; j < (int)parameterType.Length; j++)
				{
					if (!object_1.vZHdE3at2i(j))
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(parameterType[j]);
					}
					else
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(typeof(object));
					}
				}
				if (object_0.DeclaringType.IsValueType)
				{
					localBuilderArray[(int)localBuilderArray.Length - 1] = lGenerator.DeclareLocal(object_0.DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < (int)parameterType.Length; k++)
				{
					lGenerator.Emit(OpCodes.Ldarg_1);
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, k);
					lGenerator.Emit(OpCodes.Ldelem_Ref);
					if (!object_1.vZHdE3at2i(k))
					{
						if (parameterType[k].IsValueType)
						{
							lGenerator.Emit(OpCodes.Unbox_Any, parameterType[k]);
						}
						else if (parameterType[k] != typeof(object))
						{
							lGenerator.Emit(OpCodes.Castclass, parameterType[k]);
						}
					}
					lGenerator.Emit(OpCodes.Stloc, localBuilderArray[k]);
				}
				if (!object_0.IsStatic)
				{
					lGenerator.Emit(OpCodes.Ldarg_0);
					if (!object_0.DeclaringType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Castclass, object_0.DeclaringType);
					}
					else
					{
						lGenerator.Emit(OpCodes.Unbox, object_0.DeclaringType);
						lGenerator.Emit(OpCodes.Stloc, localBuilderArray[(int)localBuilderArray.Length - 1]);
						lGenerator.Emit(OpCodes.Ldloc_S, localBuilderArray[(int)localBuilderArray.Length - 1]);
					}
				}
				for (int l = 0; l < (int)parameterType.Length; l++)
				{
					if (object_1.vZHdE3at2i(l))
					{
						jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL pLsU0rd9OKulQRgoEBL = object_1.udqd8KIhcA(l);
						if (pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.IsStatic)
						{
							lGenerator.Emit(OpCodes.Ldsflda, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF);
						}
						else if (pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.DeclaringType.IsValueType)
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Unbox, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF);
						}
						else
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Castclass, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF);
						}
					}
					else if (!parameters[l].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldloca_S, localBuilderArray[l]);
					}
				}
				if (bool_0)
				{
					if (object0 != null)
					{
						lGenerator.EmitCall(OpCodes.Call, object0, null);
					}
					else
					{
						lGenerator.Emit(OpCodes.Call, object_0 as ConstructorInfo);
					}
				}
				else if (object0 != null)
				{
					lGenerator.EmitCall(OpCodes.Callvirt, object0, null);
				}
				else
				{
					lGenerator.Emit(OpCodes.Callvirt, object_0 as ConstructorInfo);
				}
				if (object0 == null || object0.ReturnType == typeof(void))
				{
					lGenerator.Emit(OpCodes.Ldnull);
				}
				else if (object0.ReturnType.IsByRef)
				{
					Type elementType = object0.ReturnType.GetElementType();
					if (!elementType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Ldind_Ref, elementType);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldobj, elementType);
					}
					if (elementType.IsValueType)
					{
						lGenerator.Emit(OpCodes.Box, elementType);
					}
				}
				else if (object0.ReturnType.IsValueType)
				{
					lGenerator.Emit(OpCodes.Box, object0.ReturnType);
				}
				for (int m = 0; m < (int)parameterType.Length; m++)
				{
					if (parameters[m].ParameterType.IsByRef)
					{
						if (!object_1.vZHdE3at2i(m))
						{
							lGenerator.Emit(OpCodes.Ldarg_1);
							jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, m);
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
							if (localBuilderArray[m].LocalType.IsValueType)
							{
								lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
							}
							lGenerator.Emit(OpCodes.Stelem_Ref);
						}
						else
						{
							jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL pLsU0rd9OKulQRgoEBL1 = object_1.udqd8KIhcA(m);
							if (!pLsU0rd9OKulQRgoEBL1.Rkdd0lrWjF.IsStatic)
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
								if (localBuilderArray[m].LocalType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
							else
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldsfld, pLsU0rd9OKulQRgoEBL1.Rkdd0lrWjF);
								if (pLsU0rd9OKulQRgoEBL1.Rkdd0lrWjF.FieldType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
						}
					}
				}
				lGenerator.Emit(OpCodes.Ret);
				jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE1 = (jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE)dynamicMethod.CreateDelegate(typeof(jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE));
				if (!bool_0)
				{
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.S0i9zt0M72.Add(object_1, _r4nv1bdWw1MJmxvckeE1);
				}
				else
				{
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.b6N9NW03cF.Add(object_1, _r4nv1bdWw1MJmxvckeE1);
				}
				return _r4nv1bdWw1MJmxvckeE1;
			}

			private static jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE yTI90eHo3T(object object_0, bool bool_0, object object_1)
			{
				jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE = null;
				if (jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.oFD05OhSIP.TryGetValue(object_1, out _r4nv1bdWw1MJmxvckeE))
				{
					return _r4nv1bdWw1MJmxvckeE;
				}
				ConstructorInfo object0 = object_0 as ConstructorInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[] { typeof(object), typeof(object[]) }, typeof(jyRxpEAUNlcH3bE07bK), true);
				ILGenerator lGenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = object_0.GetParameters();
				Type[] parameterType = new Type[(int)parameters.Length];
				for (int i = 0; i < (int)parameterType.Length; i++)
				{
					if (!parameters[i].ParameterType.IsByRef)
					{
						parameterType[i] = parameters[i].ParameterType;
					}
					else
					{
						parameterType[i] = parameters[i].ParameterType.GetElementType();
					}
				}
				int length = (int)parameterType.Length;
				if (object_0.DeclaringType.IsValueType)
				{
					length++;
				}
				LocalBuilder[] localBuilderArray = new LocalBuilder[length];
				for (int j = 0; j < (int)parameterType.Length; j++)
				{
					if (!object_1.vZHdE3at2i(j))
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(parameterType[j]);
					}
					else
					{
						localBuilderArray[j] = lGenerator.DeclareLocal(typeof(object));
					}
				}
				if (object_0.DeclaringType.IsValueType)
				{
					localBuilderArray[(int)localBuilderArray.Length - 1] = lGenerator.DeclareLocal(object_0.DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < (int)parameterType.Length; k++)
				{
					lGenerator.Emit(OpCodes.Ldarg_1);
					jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, k);
					lGenerator.Emit(OpCodes.Ldelem_Ref);
					if (!object_1.vZHdE3at2i(k))
					{
						if (parameterType[k].IsValueType)
						{
							lGenerator.Emit(OpCodes.Unbox_Any, parameterType[k]);
						}
						else if (parameterType[k] != typeof(object))
						{
							lGenerator.Emit(OpCodes.Castclass, parameterType[k]);
						}
					}
					lGenerator.Emit(OpCodes.Stloc, localBuilderArray[k]);
				}
				for (int l = 0; l < (int)parameterType.Length; l++)
				{
					if (object_1.vZHdE3at2i(l))
					{
						jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL pLsU0rd9OKulQRgoEBL = object_1.udqd8KIhcA(l);
						if (pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.IsStatic)
						{
							lGenerator.Emit(OpCodes.Ldsflda, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF);
						}
						else if (pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.DeclaringType.IsValueType)
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Unbox, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF);
						}
						else
						{
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
							lGenerator.Emit(OpCodes.Castclass, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.DeclaringType);
							lGenerator.Emit(OpCodes.Ldflda, pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF);
						}
					}
					else if (!parameters[l].ParameterType.IsByRef)
					{
						lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[l]);
					}
					else
					{
						lGenerator.Emit(OpCodes.Ldloca_S, localBuilderArray[l]);
					}
				}
				lGenerator.Emit(OpCodes.Newobj, object_0 as ConstructorInfo);
				if (object0.DeclaringType.IsValueType)
				{
					lGenerator.Emit(OpCodes.Box, object0.DeclaringType);
				}
				for (int m = 0; m < (int)parameterType.Length; m++)
				{
					if (parameters[m].ParameterType.IsByRef)
					{
						if (object_1.vZHdE3at2i(m))
						{
							jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL pLsU0rd9OKulQRgoEBL1 = object_1.udqd8KIhcA(m);
							if (pLsU0rd9OKulQRgoEBL1.Rkdd0lrWjF.IsStatic)
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldsfld, pLsU0rd9OKulQRgoEBL1.Rkdd0lrWjF);
								if (pLsU0rd9OKulQRgoEBL1.Rkdd0lrWjF.FieldType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
							else
							{
								lGenerator.Emit(OpCodes.Ldarg_1);
								jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, m);
								lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
								if (localBuilderArray[m].LocalType.IsValueType)
								{
									lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
								}
								lGenerator.Emit(OpCodes.Stelem_Ref);
							}
						}
						else
						{
							lGenerator.Emit(OpCodes.Ldarg_1);
							jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.Dxg9xmaiwx(lGenerator, m);
							lGenerator.Emit(OpCodes.Ldloc, localBuilderArray[m]);
							if (localBuilderArray[m].LocalType.IsValueType)
							{
								lGenerator.Emit(OpCodes.Box, localBuilderArray[m].LocalType);
							}
							lGenerator.Emit(OpCodes.Stelem_Ref);
						}
					}
				}
				lGenerator.Emit(OpCodes.Ret);
				jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE _r4nv1bdWw1MJmxvckeE1 = (jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE)dynamicMethod.CreateDelegate(typeof(jyRxpEAUNlcH3bE07bK.r4nv1bdWw1MJmxvckeE));
				jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht.oFD05OhSIP.Add(object_1, _r4nv1bdWw1MJmxvckeE1);
				return _r4nv1bdWw1MJmxvckeE1;
			}
		}

		private class hGLTJJGVYWsZfPi2hFw : Exception
		{
			private static jyRxpEAUNlcH3bE07bK.hGLTJJGVYWsZfPi2hFw KwAdH8c5kI28dsXLuAxv;

			public hGLTJJGVYWsZfPi2hFw(string string_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base(string_0);
			}

			internal static bool LEYes4c5fj9XJc3BfpJZ()
			{
				return jyRxpEAUNlcH3bE07bK.hGLTJJGVYWsZfPi2hFw.KwAdH8c5kI28dsXLuAxv == null;
			}

			internal static jyRxpEAUNlcH3bE07bK.hGLTJJGVYWsZfPi2hFw qr4Rotc5md2TgBg0xoJf()
			{
				return jyRxpEAUNlcH3bE07bK.hGLTJJGVYWsZfPi2hFw.KwAdH8c5kI28dsXLuAxv;
			}
		}

		[StructLayout(LayoutKind.Explicit)]
		private struct ilusFOG2jxjQj5vKi0i
		{
			[FieldOffset(0)]
			public byte e2TGMJVdcL;

			[FieldOffset(0)]
			public sbyte pRlGa80nfb;

			[FieldOffset(0)]
			public ushort A69GySGnc4;

			[FieldOffset(0)]
			public short CKTGTIjYBx;

			[FieldOffset(0)]
			public uint PORG7cnIPG;

			[FieldOffset(0)]
			public int efeGehWbf6;

			[FieldOffset(0)]
			public ulong Do4GCrshxD;

			[FieldOffset(0)]
			public long qMbGqoMUDp;
		}

		internal enum IwwR0IGZY8vgWIMSDgt : byte
		{

		}

		internal class JFcSR6dTBGIgDFch6vX
		{
			public int uHZd7cIBmK;

			public int If6deLgLUC;

			public jyRxpEAUNlcH3bE07bK.lJ4jhTdqe4dh7rLVRay Db3dClUCyb;

			internal static jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX ptDFRPccsSMk9idHHg4H;

			public JFcSR6dTBGIgDFch6vX()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal static bool GBldyDccRl4TbwDUoauN()
			{
				return jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX.ptDFRPccsSMk9idHHg4H == null;
			}

			internal static jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX R5kCqVcctOfDPKlqBxC8()
			{
				return jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX.ptDFRPccsSMk9idHHg4H;
			}
		}

		private class JNdEF4GhRwb0L16xUVW : jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4
		{
			public jyRxpEAUNlcH3bE07bK.ilusFOG2jxjQj5vKi0i B3wGtwGQYo;

			public jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND AxfGKqbagI;

			private static jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW FCZUDgc506DBhKFUGt8h;

			public JNdEF4GhRwb0L16xUVW(long long_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)2;
				this.B3wGtwGQYo.qMbGqoMUDp = long_0;
				this.AxfGKqbagI = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)7;
			}

			public JNdEF4GhRwb0L16xUVW(jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW jndEF4GhRwb0L16xUVW_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = jndEF4GhRwb0L16xUVW_0.OXE0eJU437;
				this.B3wGtwGQYo.qMbGqoMUDp = jndEF4GhRwb0L16xUVW_0.B3wGtwGQYo.qMbGqoMUDp;
				this.AxfGKqbagI = jndEF4GhRwb0L16xUVW_0.AxfGKqbagI;
			}

			public JNdEF4GhRwb0L16xUVW(long long_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)2;
				this.B3wGtwGQYo.qMbGqoMUDp = long_0;
				this.AxfGKqbagI = lDlkEeGX3ctg76JDHND_0;
			}

			public JNdEF4GhRwb0L16xUVW(ulong ulong_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)2;
				this.B3wGtwGQYo.Do4GCrshxD = ulong_0;
				this.AxfGKqbagI = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)8;
			}

			public JNdEF4GhRwb0L16xUVW(ulong ulong_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)2;
				this.B3wGtwGQYo.Do4GCrshxD = ulong_0;
				this.AxfGKqbagI = lDlkEeGX3ctg76JDHND_0;
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW aeD0jvkG0o()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.Do4GCrshxD, 8);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 afbxVgfTCY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp << (((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.efeGehWbf6 & 63));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.uliJnV0bkk())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp << (((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & 63));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 AIrxLYOPbe(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp >> (((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.efeGehWbf6 & 63));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.uliJnV0bkk())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp >> (((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & 63));
			}

			public override bool AIWJ56fpmE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.Do4GCrshxD < ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ASAxYcksDW()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((int)this.B3wGtwGQYo.qMbGqoMUDp), 5);
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (type_0 != null && type_0.IsByRef)
				{
					type_0 = type_0.GetElementType();
				}
				if (type_0 == null || type_0 == typeof(object))
				{
					switch (this.AxfGKqbagI)
					{
						case 1:
						{
							return this.B3wGtwGQYo.pRlGa80nfb;
						}
						case 2:
						{
							return this.B3wGtwGQYo.e2TGMJVdcL;
						}
						case 3:
						{
							return this.B3wGtwGQYo.CKTGTIjYBx;
						}
						case 4:
						{
							return this.B3wGtwGQYo.A69GySGnc4;
						}
						case 5:
						{
							return this.B3wGtwGQYo.efeGehWbf6;
						}
						case 6:
						{
							return this.B3wGtwGQYo.PORG7cnIPG;
						}
						case 7:
						{
							return this.B3wGtwGQYo.qMbGqoMUDp;
						}
						case 8:
						{
							return this.B3wGtwGQYo.Do4GCrshxD;
						}
						case 9:
						case 10:
						case 12:
						case 13:
						case 14:
						{
							return this.B3wGtwGQYo.qMbGqoMUDp;
						}
						case 11:
						{
							return this.ffI0XduT5O();
						}
						case 15:
						{
							return (char)this.B3wGtwGQYo.efeGehWbf6;
						}
						default:
						{
							return this.B3wGtwGQYo.qMbGqoMUDp;
						}
					}
				}
				if (type_0 == typeof(int))
				{
					return this.B3wGtwGQYo.efeGehWbf6;
				}
				if (type_0 == typeof(uint))
				{
					return this.B3wGtwGQYo.PORG7cnIPG;
				}
				if (type_0 == typeof(short))
				{
					return this.B3wGtwGQYo.CKTGTIjYBx;
				}
				if (type_0 == typeof(ushort))
				{
					return this.B3wGtwGQYo.A69GySGnc4;
				}
				if (type_0 == typeof(byte))
				{
					return this.B3wGtwGQYo.e2TGMJVdcL;
				}
				if (type_0 == typeof(sbyte))
				{
					return this.B3wGtwGQYo.pRlGa80nfb;
				}
				if (type_0 == typeof(bool))
				{
					return !this.Eme0FYs6nR();
				}
				if (type_0 == typeof(long))
				{
					return this.B3wGtwGQYo.qMbGqoMUDp;
				}
				if (type_0 == typeof(ulong))
				{
					return this.B3wGtwGQYo.Do4GCrshxD;
				}
				if (type_0 == typeof(char))
				{
					return (char)this.B3wGtwGQYo.qMbGqoMUDp;
				}
				if (!type_0.IsEnum)
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.rlgGHtmYnD(type_0);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW bom045C5yQ()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp, 7);
			}

			public override bool C2DxgtwF4s(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.qMbGqoMUDp >= ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb CLj0bGxkbn()
			{
				return this.JNO0f6Ww4D();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ctr0ZHYfwg(jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				switch (lDlkEeGX3ctg76JDHND_0)
				{
					case 1:
					{
						return this.ixd03qpXfA();
					}
					case 2:
					{
						return this.u360kVINWM();
					}
					case 3:
					{
						return this.JNO0f6Ww4D();
					}
					case 4:
					{
						return this.wDv0moVOmC();
					}
					case 5:
					{
						return this.T6x0DEWO2j();
					}
					case 6:
					{
						return this.xPC0gkXCdf();
					}
					case 7:
					{
						return this.bom045C5yQ();
					}
					case 8:
					{
						return this.aeD0jvkG0o();
					}
					case 9:
					case 10:
					case 12:
					case 13:
					case 14:
					{
						throw new Exception(4.ToString());
					}
					case 11:
					{
						return this.J2C0L5xhmC();
					}
					case 15:
					{
						return this.J8UGsocoGO();
					}
					case 16:
					{
						return this.VtI0uXXMvw();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 cv9xPNKjLE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.Do4GCrshxD % ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 D1fxFGeqb7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp | ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).D8TxDuVrlI(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.BKf0rut3Ig())
				{
					return false;
				}
				return this.B3wGtwGQYo.Do4GCrshxD != ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)_leA9Ha0oP4AaSA2idq0).B3wGtwGQYo.Do4GCrshxD;
			}

			internal static jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW e28inKc5JpsWI47P5VG9()
			{
				return jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW.FCZUDgc506DBhKFUGt8h;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				return this;
			}

			public override bool Eme0FYs6nR()
			{
				if ((int)this.AxfGKqbagI == 7)
				{
					return this.B3wGtwGQYo.qMbGqoMUDp == 0L;
				}
				return this.B3wGtwGQYo.Do4GCrshxD == 0L;
			}

			public override bool endx4m7CQT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.Do4GCrshxD >= ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ErsxxFLS44(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked(this.B3wGtwGQYo.qMbGqoMUDp - ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb F8qxT1rsi6()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((ushort)this.B3wGtwGQYo.Do4GCrshxD)), 4);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FEsx6tlZCe()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((short)this.B3wGtwGQYo.Do4GCrshxD)), 3);
			}

			public override bool ffI0XduT5O()
			{
				return !this.Eme0FYs6nR();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FscxMh0y89()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.B3wGtwGQYo.qMbGqoMUDp, 2);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy Fu6xtFY6Su()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.pnExQQrrXk().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.vxLxnN4YIU().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 gduxhTRAky()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((float)this.B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 GK8x1mthyY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.Do4GCrshxD >> (((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.efeGehWbf6 & 63));
				}
				if (!leA9Ha0oP4AaSA2idq0_0.uliJnV0bkk())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.Do4GCrshxD >> (((jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4)leA9Ha0oP4AaSA2idq0_0).T6x0DEWO2j().kTNGBJtJF0.VSLGOF3Fps & 63));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 gOuxp90V6G(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp / ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}

			public override bool IG7xjsK4EF(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.qMbGqoMUDp > ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp;
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.B3wGtwGQYo = ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo;
				this.AxfGKqbagI = ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).AxfGKqbagI;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ixd03qpXfA()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.B3wGtwGQYo.pRlGa80nfb, 1);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J2C0L5xhmC()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((!this.Eme0FYs6nR() ? 1 : 0));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J39xB0fFjG()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((int)this.B3wGtwGQYo.Do4GCrshxD)), 5);
			}

			public jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J8UGsocoGO()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.B3wGtwGQYo.pRlGa80nfb, 15);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Jl4xcF8KnQ()
			{
				return this.wDv0moVOmC();
			}

			public override bool JNkxbaE9i0(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.qMbGqoMUDp <= ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb JNO0f6Ww4D()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.B3wGtwGQYo.CKTGTIjYBx, 3);
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return ((jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.BKf0rut3Ig())
				{
					return false;
				}
				return this.B3wGtwGQYo.qMbGqoMUDp == ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)_leA9Ha0oP4AaSA2idq0).B3wGtwGQYo.qMbGqoMUDp;
			}

			internal override bool JSXxfJmewI()
			{
				return true;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb KTBxI7JM1N()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((sbyte)this.B3wGtwGQYo.Do4GCrshxD)), 1);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lFDxK1rVZS()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.lYyxrsIRV7().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.ASAxYcksDW().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LgEx00tIXr(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp - ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lGKxGefAaJ()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)((void*)(checked((uint)this.B3wGtwGQYo.Do4GCrshxD))));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LJgxESAkAG(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked(this.B3wGtwGQYo.qMbGqoMUDp * ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb LpNxocNMFW()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((short)this.B3wGtwGQYo.qMbGqoMUDp), 3);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW lYyxrsIRV7()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp, 7);
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
			}

			internal static bool MW8Dmqc5xWK7b2ilcncY()
			{
				return jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW.FCZUDgc506DBhKFUGt8h == null;
			}

			public override bool MwSxSSYZQ3(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.Do4GCrshxD > ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 mZUxWFSSW6(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.Do4GCrshxD / ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 N2YxsjFtx6()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)((float)this.B3wGtwGQYo.Do4GCrshxD));
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW nBW0zA6Cn1()
			{
				return this.bom045C5yQ();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Nnox7pcLUS()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((uint)this.B3wGtwGQYo.qMbGqoMUDp), 6);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 OaTxvqmDKP(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp + ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb OBOxedVMZo()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((uint)this.B3wGtwGQYo.Do4GCrshxD)), 6);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy PD5xRl3JtH()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.nBW0zA6Cn1().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.PO50N2hhDU().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 pEZxd6HgCc()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(-this.B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW pnExQQrrXk()
			{
				return this.aeD0jvkG0o();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb PO50N2hhDU()
			{
				return this.T6x0DEWO2j();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 q5bxim1OPw(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked(this.B3wGtwGQYo.qMbGqoMUDp + ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp));
			}

			internal override bool qjs01aMKus()
			{
				return this.ffI0XduT5O();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 QkpxwApqeH(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked(this.B3wGtwGQYo.Do4GCrshxD * ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb qwAxaCXBp2()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((void*)(checked((byte)this.B3wGtwGQYo.Do4GCrshxD)), 2);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb RFK0SjXY75()
			{
				return this.ixd03qpXfA();
			}

			internal object rlgGHtmYnD(Type type_0)
			{
				Type underlyingType = Enum.GetUnderlyingType(type_0);
				if (underlyingType == typeof(int))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.efeGehWbf6);
				}
				if (underlyingType == typeof(uint))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.PORG7cnIPG);
				}
				if (underlyingType == typeof(short))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.CKTGTIjYBx);
				}
				if (underlyingType == typeof(ushort))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.A69GySGnc4);
				}
				if (underlyingType == typeof(byte))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.e2TGMJVdcL);
				}
				if (underlyingType == typeof(sbyte))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.pRlGa80nfb);
				}
				if (underlyingType == typeof(long))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.qMbGqoMUDp);
				}
				if (underlyingType == typeof(ulong))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.Do4GCrshxD);
				}
				if (underlyingType != typeof(char))
				{
					return Enum.ToObject(type_0, this.B3wGtwGQYo.qMbGqoMUDp);
				}
				return Enum.ToObject(type_0, (ushort)this.B3wGtwGQYo.efeGehWbf6);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW rROx2jU6yR()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((void*)(checked((long)this.B3wGtwGQYo.Do4GCrshxD)), 7);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 s2NxJDBMr7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked(this.B3wGtwGQYo.Do4GCrshxD - ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD));
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 S9hxU3utYx(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp % ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 SRix9vq6s5(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked(this.B3wGtwGQYo.Do4GCrshxD + ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb T6x0DEWO2j()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.B3wGtwGQYo.efeGehWbf6, 5);
			}

			public override string ToString()
			{
				if ((int)this.AxfGKqbagI == 7)
				{
					return this.B3wGtwGQYo.qMbGqoMUDp.ToString();
				}
				return this.B3wGtwGQYo.Do4GCrshxD.ToString();
			}

			public override bool U2yxzSjQyb(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.qMbGqoMUDp < ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb u360kVINWM()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.B3wGtwGQYo.e2TGMJVdcL, 2);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy UjQxA95UDE()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.rROx2jU6yR().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.J39xB0fFjG().kTNGBJtJF0.VSLGOF3Fps);
			}

			private static jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 voRGRx7G89(object object_0)
			{
				jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 object0 = object_0 as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				if (object0 == null && object_0.lFyJQh378A())
				{
					object0 = object_0.e4VxkrOKkN() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				}
				return object0;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 vsvxZprm8I(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp ^ ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy vTfxlGJn0p()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.W7TxCiinJ2().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.Nnox7pcLUS().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 VtI0uXXMvw()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb vxLxnN4YIU()
			{
				return this.xPC0gkXCdf();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW W7TxCiinJ2()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked((ulong)this.B3wGtwGQYo.qMbGqoMUDp), 8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wDv0moVOmC()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.B3wGtwGQYo.A69GySGnc4, 4);
			}

			public override bool wgXxNAO14B(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.B3wGtwGQYo.Do4GCrshxD <= ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.Do4GCrshxD;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 WibxXYkaNk()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(~this.B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 wLFxHSrDCX()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)this.B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wpEx5XwQs6()
			{
				return this.u360kVINWM();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW xN5xqf54GS()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.Do4GCrshxD, 8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb xPC0gkXCdf()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(this.B3wGtwGQYo.PORG7cnIPG, 6);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 y8Dx80UigU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp * ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb YShxOlBEdt()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((sbyte)this.B3wGtwGQYo.qMbGqoMUDp), 1);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Yxvxyosj9C()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.B3wGtwGQYo.qMbGqoMUDp, 4);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 YygxuJKocU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BKf0rut3Ig())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(this.B3wGtwGQYo.qMbGqoMUDp & ((jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW)leA9Ha0oP4AaSA2idq0_0).B3wGtwGQYo.qMbGqoMUDp);
			}
		}

		private delegate object k0i8POdUROEZ854hSaj(object target);

		internal abstract class k18BcGGfvFEps11heXT : jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0
		{
			private static jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT NlnmANc5NWWPUeCJO04P;

			public k18BcGGfvFEps11heXT()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal abstract IntPtr aplJOYYo3O();

			internal static bool Ilihrtc5zU3F6fP1H8IO()
			{
				return jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT.NlnmANc5NWWPUeCJO04P == null;
			}

			internal override bool lBKJcRIfK8()
			{
				return true;
			}

			internal override bool lFyJQh378A()
			{
				return true;
			}

			internal static jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT p247Mrcc5vu2JUvKd5tV()
			{
				return jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT.NlnmANc5NWWPUeCJO04P;
			}

			internal abstract void QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);
		}

		internal class KTm31lGbFDDwe0QcrjB : jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT
		{
			internal FieldInfo Wd4GNZmaAW;

			internal object pWPGzr94Xa;

			internal static jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB KUliSncc68OVKUhnU4RG;

			public KTm31lGbFDDwe0QcrjB(FieldInfo fieldInfo_0, object object_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.Wd4GNZmaAW = fieldInfo_0;
				this.pWPGzr94Xa = object_0;
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)7;
			}

			internal override IntPtr aplJOYYo3O()
			{
				throw new NotImplementedException();
			}

			internal override object B550VtrALj(Type type_0)
			{
				return this.e4VxkrOKkN().B550VtrALj(type_0);
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return true;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB))
				{
					return true;
				}
				jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB leA9Ha0oP4AaSA2idq00 = (jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB)leA9Ha0oP4AaSA2idq0_0;
				if (leA9Ha0oP4AaSA2idq00.Wd4GNZmaAW != this.Wd4GNZmaAW)
				{
					return true;
				}
				if (leA9Ha0oP4AaSA2idq00.pWPGzr94Xa != this.pWPGzr94Xa)
				{
					return true;
				}
				return false;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				if (this.pWPGzr94Xa == null || !(this.pWPGzr94Xa is jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0))
				{
					return jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(this.Wd4GNZmaAW.FieldType, this.Wd4GNZmaAW.GetValue(this.pWPGzr94Xa));
				}
				return jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(this.Wd4GNZmaAW.FieldType, this.Wd4GNZmaAW.GetValue(((jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0)this.pWPGzr94Xa).B550VtrALj(null)));
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB))
				{
					this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
					return;
				}
				this.Wd4GNZmaAW = ((jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB)leA9Ha0oP4AaSA2idq0_0).Wd4GNZmaAW;
				this.pWPGzr94Xa = ((jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB)leA9Ha0oP4AaSA2idq0_0).pWPGzr94Xa;
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return false;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB))
				{
					return false;
				}
				jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB leA9Ha0oP4AaSA2idq00 = (jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB)leA9Ha0oP4AaSA2idq0_0;
				if (leA9Ha0oP4AaSA2idq00.Wd4GNZmaAW != this.Wd4GNZmaAW)
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq00.pWPGzr94Xa != this.pWPGzr94Xa)
				{
					return false;
				}
				return true;
			}

			internal override bool JSXxfJmewI()
			{
				return this.e4VxkrOKkN().JSXxfJmewI();
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
			}

			internal override void QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (this.pWPGzr94Xa == null || !(this.pWPGzr94Xa is jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0))
				{
					this.Wd4GNZmaAW.SetValue(this.pWPGzr94Xa, leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null));
					return;
				}
				this.Wd4GNZmaAW.SetValue(((jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0)this.pWPGzr94Xa).B550VtrALj(null), leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null));
			}

			internal override bool qjs01aMKus()
			{
				return this.e4VxkrOKkN().qjs01aMKus();
			}

			internal static jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB RKpHbdccBVUj4M9UG9Xo()
			{
				return jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB.KUliSncc68OVKUhnU4RG;
			}

			internal static bool xXBolpccYio23VLDyqpG()
			{
				return jyRxpEAUNlcH3bE07bK.KTm31lGbFDDwe0QcrjB.KUliSncc68OVKUhnU4RG == null;
			}
		}

		internal enum lDlkEeGX3ctg76JDHND : byte
		{

		}

		internal abstract class leA9Ha0oP4AaSA2idq0
		{
			internal jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B OXE0eJU437;

			internal static jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 FQUZnWcc1vnY2AT8M276;

			public leA9Ha0oP4AaSA2idq0()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal leA9Ha0oP4AaSA2idq0(jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B qhhuTZ0IEjH88Oi5W3B_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = qhhuTZ0IEjH88Oi5W3B_0;
			}

			internal abstract object B550VtrALj(Type type_0);

			internal bool BKf0rut3Ig()
			{
				return (int)this.OXE0eJU437 == 2;
			}

			internal bool BY4027cwoa()
			{
				return (int)this.OXE0eJU437 == 5;
			}

			internal abstract bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			internal abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN();

			internal bool Eym0Y22UOo()
			{
				return (int)this.OXE0eJU437 == 1;
			}

			private static jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 GyR07qWKtQ(object object_0)
			{
				jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 object0 = object_0 as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				if (object0 == null && object_0.lFyJQh378A())
				{
					object0 = object_0.e4VxkrOKkN() as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
				}
				return object0;
			}

			internal static jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 IcTbCOcck82hL4p66y4Q()
			{
				return jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.FQUZnWcc1vnY2AT8M276;
			}

			internal abstract void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			internal abstract bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			internal virtual bool JSXxfJmewI()
			{
				return false;
			}

			internal virtual bool lBKJcRIfK8()
			{
				return false;
			}

			internal virtual bool lFyJQh378A()
			{
				return false;
			}

			private static jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 loL0Tv9U3l(object object_0)
			{
				if (object_0 != null && object_0.GetType().IsEnum)
				{
					Type underlyingType = Enum.GetUnderlyingType(object_0.GetType());
					object obj = Convert.ChangeType(object_0, underlyingType);
					jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.GyR07qWKtQ(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(underlyingType, obj));
					if (_leA9Ha0oP4AaSA2idq0 != null)
					{
						return _leA9Ha0oP4AaSA2idq0 as jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4;
					}
				}
				return new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(object_0);
			}

			internal abstract void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			internal static bool NDdUKLcc3Ck2ujMNQB3r()
			{
				return jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.FQUZnWcc1vnY2AT8M276 == null;
			}

			internal bool nSa06LHEGl()
			{
				return (int)this.OXE0eJU437 == 0;
			}

			internal static jyRxpEAUNlcH3bE07bK.IwwR0IGZY8vgWIMSDgt ogq0aZHifW(Type type_0)
			{
				Type type0 = type_0;
				if (type0 == null)
				{
					return 18;
				}
				if (type0.IsByRef)
				{
					type0 = type0.GetElementType();
				}
				if (type0 == typeof(string))
				{
					return 14;
				}
				if (type0 == typeof(byte))
				{
					return 2;
				}
				if (type0 == typeof(sbyte))
				{
					return 1;
				}
				if (type0 == typeof(short))
				{
					return 3;
				}
				if (type0 == typeof(ushort))
				{
					return 4;
				}
				if (type0 == typeof(int))
				{
					return 5;
				}
				if (type0 == typeof(uint))
				{
					return 6;
				}
				if (type0 == typeof(long))
				{
					return 7;
				}
				if (type0 == typeof(ulong))
				{
					return 8;
				}
				if (type0 == typeof(float))
				{
					return 9;
				}
				if (type0 == typeof(double))
				{
					return 10;
				}
				if (type0 == typeof(bool))
				{
					return 11;
				}
				if (type0 == typeof(IntPtr))
				{
					return 12;
				}
				if (type0 == typeof(UIntPtr))
				{
					return 13;
				}
				if (type0 == typeof(char))
				{
					return 15;
				}
				if (type0 == typeof(object))
				{
					return 0;
				}
				if (type0.IsEnum)
				{
					return 16;
				}
				return 17;
			}

			internal bool OuT0MW1gMS()
			{
				return (int)this.OXE0eJU437 == 6;
			}

			internal abstract bool qjs01aMKus();

			internal virtual bool uliJnV0bkk()
			{
				return false;
			}

			internal bool v790Bk1BmX()
			{
				if ((int)this.OXE0eJU437 == 3)
				{
					return true;
				}
				return (int)this.OXE0eJU437 == 4;
			}

			internal static jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 Vuv0ynoAfM(Type type_0, object object_0)
			{
				jyRxpEAUNlcH3bE07bK.IwwR0IGZY8vgWIMSDgt iwwR0IGZY8vgWIMSDgt = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.ogq0aZHifW(type_0);
				jyRxpEAUNlcH3bE07bK.IwwR0IGZY8vgWIMSDgt iwwR0IGZY8vgWIMSDgt1 = (jyRxpEAUNlcH3bE07bK.IwwR0IGZY8vgWIMSDgt)18;
				if (object_0 != null)
				{
					iwwR0IGZY8vgWIMSDgt1 = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.ogq0aZHifW(object_0.GetType());
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _wLXsfX0CtM6lkRpgimf = null;
				switch (iwwR0IGZY8vgWIMSDgt)
				{
					case 0:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
						{
							_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.loL0Tv9U3l(object_0);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(object_0);
							break;
						}
					}
					case 1:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 <= 2)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 == 1)
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((sbyte)object_0, 1);
								break;
							}
							else if ((int)iwwR0IGZY8vgWIMSDgt1 == 2)
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((sbyte)((byte)object_0), 1);
								break;
							}
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 == 15)
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((sbyte)((char)object_0), 1);
								break;
							}
						}
						else if (!(bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0, 1);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1, 1);
							break;
						}
						throw new InvalidCastException();
					}
					case 2:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 <= 2)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 == 1)
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)((sbyte)object_0), 2);
								break;
							}
							else if ((int)iwwR0IGZY8vgWIMSDgt1 == 2)
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0, 2);
								break;
							}
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 == 15)
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)((char)object_0), 2);
								break;
							}
						}
						else if (!(bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0, 2);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1, 2);
							break;
						}
						throw new InvalidCastException();
					}
					case 3:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 == 3)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((short)object_0, 3);
							break;
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
							{
								throw new InvalidCastException();
							}
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((short)((char)object_0), 3);
							break;
						}
						else if ((bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1, 3);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0, 3);
							break;
						}
					}
					case 4:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 == 4)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0, 4);
							break;
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
							{
								throw new InvalidCastException();
							}
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((char)object_0, 4);
							break;
						}
						else if (!(bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0, 4);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1, 4);
							break;
						}
					}
					case 5:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 == 5)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0, 5);
							break;
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
							{
								throw new InvalidCastException();
							}
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((char)object_0, 5);
							break;
						}
						else if (!(bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0, 5);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1, 5);
							break;
						}
					}
					case 6:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 == 6)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((uint)object_0, 6);
							break;
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
							{
								throw new InvalidCastException();
							}
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((char)object_0, 6);
							break;
						}
						else if ((bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(1, 6);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(0, 6);
							break;
						}
					}
					case 7:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 == 7)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)object_0, 7);
							break;
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
							{
								throw new InvalidCastException();
							}
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)((char)object_0), 7);
							break;
						}
						else if (!(bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(0L, 7);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(1L, 7);
							break;
						}
					}
					case 8:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 == 8)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((ulong)object_0, 8);
							break;
						}
						else if ((int)iwwR0IGZY8vgWIMSDgt1 != 11)
						{
							if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
							{
								throw new InvalidCastException();
							}
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((ulong)((char)object_0), 8);
							break;
						}
						else if ((bool)object_0)
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(1L, 8);
							break;
						}
						else
						{
							_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(0L, 8);
							break;
						}
					}
					case 9:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 != 9)
						{
							throw new InvalidCastException();
						}
						_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((float)object_0);
						break;
					}
					case 10:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 != 10)
						{
							throw new InvalidCastException();
						}
						_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)object_0);
						break;
					}
					case 11:
					{
						switch (iwwR0IGZY8vgWIMSDgt1)
						{
							case 1:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((sbyte)object_0 != 0);
								break;
							}
							case 2:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((byte)object_0 != 0);
								break;
							}
							case 3:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((short)object_0 != 0);
								break;
							}
							case 4:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((ushort)object_0 != 0);
								break;
							}
							case 5:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0 != 0);
								break;
							}
							case 6:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((uint)object_0 != 0);
								break;
							}
							case 7:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((long)object_0 > 0L);
								break;
							}
							case 8:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((ulong)object_0 > 0L);
								break;
							}
							case 9:
							case 10:
							case 12:
							case 13:
							case 14:
							case 15:
							case 16:
							{
								throw new InvalidCastException();
							}
							case 11:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((bool)object_0);
								break;
							}
							case 17:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(object_0 != null);
								break;
							}
							case 18:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(false);
								break;
							}
							default:
							{
								goto case 17;
							}
						}
						break;
					}
					case 12:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 != 12)
						{
							throw new InvalidCastException();
						}
						_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((IntPtr)object_0);
						break;
					}
					case 13:
					{
						if ((int)iwwR0IGZY8vgWIMSDgt1 != 13)
						{
							throw new InvalidCastException();
						}
						_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((UIntPtr)object_0);
						break;
					}
					case 14:
					{
						_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.DSrCAE0HG6QoVKaj94t(object_0 as string);
						break;
					}
					case 15:
					{
						switch (iwwR0IGZY8vgWIMSDgt1)
						{
							case 1:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((sbyte)object_0, 15);
								break;
							}
							case 2:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0, 15);
								break;
							}
							case 3:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((short)object_0, 15);
								break;
							}
							case 4:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0, 15);
								break;
							}
							case 5:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0, 15);
								break;
							}
							case 6:
							{
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)object_0, 15);
								break;
							}
							default:
							{
								if ((int)iwwR0IGZY8vgWIMSDgt1 != 15)
								{
									throw new InvalidCastException();
								}
								_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((char)object_0, 15);
								break;
							}
						}
						break;
					}
					case 16:
					case 17:
					{
						_wLXsfX0CtM6lkRpgimf = jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.loL0Tv9U3l(object_0);
						break;
					}
					case 18:
					{
						throw new InvalidCastException();
					}
				}
				if (type_0.IsByRef)
				{
					_wLXsfX0CtM6lkRpgimf = new jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x(_wLXsfX0CtM6lkRpgimf, type_0.GetElementType());
				}
				return _wLXsfX0CtM6lkRpgimf;
			}
		}

		internal class lJ4jhTdqe4dh7rLVRay
		{
			public int IhYdhLIMeS;

			public int rnSdHXXcow;

			public byte XdIdsNZG01;

			public Type jSEdRtMtoU;

			public int DWAdt7aFtS;

			public int JEqdKDjJeC;

			private static jyRxpEAUNlcH3bE07bK.lJ4jhTdqe4dh7rLVRay G1sSAeccK0sTPC6uT4tt;

			public lJ4jhTdqe4dh7rLVRay()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal static jyRxpEAUNlcH3bE07bK.lJ4jhTdqe4dh7rLVRay iQorZEccAddGm0bD0sB3()
			{
				return jyRxpEAUNlcH3bE07bK.lJ4jhTdqe4dh7rLVRay.G1sSAeccK0sTPC6uT4tt;
			}

			internal static bool P8ldBCcclVrJpnNUnDGx()
			{
				return jyRxpEAUNlcH3bE07bK.lJ4jhTdqe4dh7rLVRay.G1sSAeccK0sTPC6uT4tt == null;
			}
		}

		internal class N9LOJKdQAsivaJfjS3x : jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT
		{
			private jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 nAtdOjwo3G;

			private Type YG6dIkcnjk;

			internal static jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x vZSpiNccaLdKjRMDPy3A;

			public N9LOJKdQAsivaJfjS3x(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0, Type type_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.nAtdOjwo3G = leA9Ha0oP4AaSA2idq0_0;
				this.YG6dIkcnjk = type_0;
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)7;
			}

			internal override IntPtr aplJOYYo3O()
			{
				throw new NotImplementedException();
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (this.nAtdOjwo3G == null)
				{
					return new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null);
				}
				if (!(type_0 == null) && !(type_0 == typeof(object)))
				{
					return this.nAtdOjwo3G.B550VtrALj(type_0);
				}
				return this.nAtdOjwo3G.B550VtrALj(this.YG6dIkcnjk);
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return true;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x))
				{
					return true;
				}
				jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x leA9Ha0oP4AaSA2idq00 = (jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x)leA9Ha0oP4AaSA2idq0_0;
				if (leA9Ha0oP4AaSA2idq00.YG6dIkcnjk != this.YG6dIkcnjk)
				{
					return true;
				}
				if (this.nAtdOjwo3G != null)
				{
					return this.nAtdOjwo3G.D8TxDuVrlI(leA9Ha0oP4AaSA2idq00.nAtdOjwo3G);
				}
				if (leA9Ha0oP4AaSA2idq00.nAtdOjwo3G == null)
				{
					return false;
				}
				return true;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				if (this.nAtdOjwo3G == null)
				{
					return new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null);
				}
				return this.nAtdOjwo3G.e4VxkrOKkN();
			}

			internal static bool gHpKBjccyinNXcicd4kL()
			{
				return jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x.vZSpiNccaLdKjRMDPy3A == null;
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x))
				{
					this.nAtdOjwo3G.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
					return;
				}
				this.YG6dIkcnjk = ((jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x)leA9Ha0oP4AaSA2idq0_0).YG6dIkcnjk;
				this.nAtdOjwo3G = ((jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x)leA9Ha0oP4AaSA2idq0_0).nAtdOjwo3G;
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return false;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x))
				{
					return false;
				}
				jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x leA9Ha0oP4AaSA2idq00 = (jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x)leA9Ha0oP4AaSA2idq0_0;
				if (leA9Ha0oP4AaSA2idq00.YG6dIkcnjk != this.YG6dIkcnjk)
				{
					return false;
				}
				if (this.nAtdOjwo3G != null)
				{
					return this.nAtdOjwo3G.JOKxmtllMB(leA9Ha0oP4AaSA2idq00.nAtdOjwo3G);
				}
				if (leA9Ha0oP4AaSA2idq00.nAtdOjwo3G != null)
				{
					return false;
				}
				return true;
			}

			internal override bool JSXxfJmewI()
			{
				return this.e4VxkrOKkN().JSXxfJmewI();
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
			}

			internal override void QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.nAtdOjwo3G = leA9Ha0oP4AaSA2idq0_0;
			}

			internal override bool qjs01aMKus()
			{
				return this.e4VxkrOKkN().qjs01aMKus();
			}

			internal static jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x TqmmAfccTx8bbPLy0dDU()
			{
				return jyRxpEAUNlcH3bE07bK.N9LOJKdQAsivaJfjS3x.vZSpiNccaLdKjRMDPy3A;
			}
		}

		private class p481LxdJNmdNfriwEHO
		{
			private List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL> hDvdwUKm3n;

			private MethodBase KJjdp9uwJj;

			internal static jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO VeVZddccxaoEjLi0XxjD;

			public p481LxdJNmdNfriwEHO(MethodBase methodBase_0, List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL> list_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				this.hDvdwUKm3n = new List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL>();
				base();
				this.hDvdwUKm3n = list_0;
				this.KJjdp9uwJj = methodBase_0;
			}

			public p481LxdJNmdNfriwEHO(MethodBase methodBase_0, jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL[] plsU0rd9OKulQRgoEBL_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				this.hDvdwUKm3n = new List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL>();
				base();
				this.hDvdwUKm3n.AddRange(plsU0rd9OKulQRgoEBL_0);
			}

			public override bool Equals(object obj)
			{
				jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO _p481LxdJNmdNfriwEHO = obj as jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO;
				if (obj == null)
				{
					return false;
				}
				if (this.KJjdp9uwJj != _p481LxdJNmdNfriwEHO.KJjdp9uwJj)
				{
					return false;
				}
				if (this.hDvdwUKm3n.Count != _p481LxdJNmdNfriwEHO.hDvdwUKm3n.Count)
				{
					return false;
				}
				for (int i = 0; i < this.hDvdwUKm3n.Count; i++)
				{
					if (this.hDvdwUKm3n[i].Rkdd0lrWjF != _p481LxdJNmdNfriwEHO.hDvdwUKm3n[i].Rkdd0lrWjF)
					{
						return false;
					}
					if (this.hDvdwUKm3n[i].g01dx5w44Z != _p481LxdJNmdNfriwEHO.hDvdwUKm3n[i].g01dx5w44Z)
					{
						return false;
					}
				}
				return true;
			}

			public override int GetHashCode()
			{
				int hashCode = this.KJjdp9uwJj.GetHashCode();
				foreach (jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL pLsU0rd9OKulQRgoEBL in this.hDvdwUKm3n)
				{
					int num = pLsU0rd9OKulQRgoEBL.Rkdd0lrWjF.GetHashCode() + pLsU0rd9OKulQRgoEBL.g01dx5w44Z;
					hashCode = (hashCode ^ num) + num;
				}
				return hashCode;
			}

			internal static bool OQSPTyccJJZBIDxMBXed()
			{
				return jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO.VeVZddccxaoEjLi0XxjD == null;
			}

			internal static jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO pwTjj4cc8ytb0t6hT183()
			{
				return jyRxpEAUNlcH3bE07bK.p481LxdJNmdNfriwEHO.VeVZddccxaoEjLi0XxjD;
			}

			public jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL udqd8KIhcA(int int_0)
			{
				jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL pLsU0rd9OKulQRgoEBL;
				List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL>.Enumerator enumerator = this.hDvdwUKm3n.GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL current = enumerator.Current;
						if (current.g01dx5w44Z != int_0)
						{
							continue;
						}
						pLsU0rd9OKulQRgoEBL = current;
						return pLsU0rd9OKulQRgoEBL;
					}
					return null;
				}
				finally
				{
					((IDisposable)enumerator).Dispose();
				}
				return pLsU0rd9OKulQRgoEBL;
			}

			public bool vZHdE3at2i(int int_0)
			{
				bool flag;
				List<jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL>.Enumerator enumerator = this.hDvdwUKm3n.GetEnumerator();
				try
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.g01dx5w44Z != int_0)
						{
							continue;
						}
						flag = true;
						return flag;
					}
					return false;
				}
				finally
				{
					((IDisposable)enumerator).Dispose();
				}
				return flag;
			}
		}

		private class PLsU0rd9OKulQRgoEBL
		{
			internal FieldInfo Rkdd0lrWjF;

			internal int g01dx5w44Z;

			internal static jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL c4U48KcciLFKOaVk70ZH;

			public PLsU0rd9OKulQRgoEBL(FieldInfo fieldInfo_0, int int_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.Rkdd0lrWjF = fieldInfo_0;
				this.g01dx5w44Z = int_0;
			}

			internal static jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL tHS2Decc0h8uTHbLnX6u()
			{
				return jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL.c4U48KcciLFKOaVk70ZH;
			}

			internal static bool wgnpVocc910efdwE1oNh()
			{
				return jyRxpEAUNlcH3bE07bK.PLsU0rd9OKulQRgoEBL.c4U48KcciLFKOaVk70ZH == null;
			}
		}

		internal enum qhhuTZ0IEjH88Oi5W3B : byte
		{

		}

		private delegate object r4nv1bdWw1MJmxvckeE(object target, object[] paramters);

		internal enum S6GrfJ0dJWwGeG1X8Er
		{

		}

		[StructLayout(LayoutKind.Explicit)]
		public struct s8RE0VANPf3vC4p7rwH
		{
			[FieldOffset(0)]
			public byte JGqAzCDQNa;

			[FieldOffset(0)]
			public sbyte YEZG58dt5p;

			[FieldOffset(0)]
			public ushort aiaGcWLrgg;

			[FieldOffset(0)]
			public short zpyGnvw2Mm;

			[FieldOffset(0)]
			public uint zaBGQHNwcU;

			[FieldOffset(0)]
			public int VSLGOF3Fps;
		}

		internal class sVb83IG1u6ZbkqvM6XP
		{
			internal jyRxpEAUNlcH3bE07bK.aZ8KWt0Osr8yQkeyDNt VGbG3kYEQE;

			internal object tECGkPNKGe;

			private static jyRxpEAUNlcH3bE07bK.sVb83IG1u6ZbkqvM6XP HBAESJc5jCMSNMUaCRW8;

			public sVb83IG1u6ZbkqvM6XP()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				this.VGbG3kYEQE = (jyRxpEAUNlcH3bE07bK.aZ8KWt0Osr8yQkeyDNt)126;
				base();
			}

			public override string ToString()
			{
				object vGbG3kYEQE = this.VGbG3kYEQE;
				if (this.tECGkPNKGe == null)
				{
					return vGbG3kYEQE.ToString();
				}
				char chr = 'H';
				return string.Concat(vGbG3kYEQE.ToString(), chr.ToString(), this.tECGkPNKGe.ToString());
			}

			internal static bool TXIr6Rc5SWo1EvmDSZPE()
			{
				return jyRxpEAUNlcH3bE07bK.sVb83IG1u6ZbkqvM6XP.HBAESJc5jCMSNMUaCRW8 == null;
			}

			internal static jyRxpEAUNlcH3bE07bK.sVb83IG1u6ZbkqvM6XP YB30XIc5bmQT6tqgH39V()
			{
				return jyRxpEAUNlcH3bE07bK.sVb83IG1u6ZbkqvM6XP.HBAESJc5jCMSNMUaCRW8;
			}
		}

		private delegate void sZZ5YWduisjjsjhW7uY(IntPtr s, IntPtr t, uint c);

		internal class Tx7DN0doIKUv6kJH77R
		{
			public int Ipad6mZeb7;

			public bool wtcdYfGjen;

			public jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND kL6dBTlsp4;

			internal static jyRxpEAUNlcH3bE07bK.Tx7DN0doIKUv6kJH77R Utiakgcc7LTl7jpc4P5S;

			public Tx7DN0doIKUv6kJH77R()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal static bool Lj0GhJccef3l2SDY6p0i()
			{
				return jyRxpEAUNlcH3bE07bK.Tx7DN0doIKUv6kJH77R.Utiakgcc7LTl7jpc4P5S == null;
			}

			internal static jyRxpEAUNlcH3bE07bK.Tx7DN0doIKUv6kJH77R Oug4WLccCBsPs8hSpATp()
			{
				return jyRxpEAUNlcH3bE07bK.Tx7DN0doIKUv6kJH77R.Utiakgcc7LTl7jpc4P5S;
			}
		}

		private abstract class ub3yhfGU9uM2BP4kQQ4 : jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0
		{
			internal static jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 V6m9SUc5pDwuhBiNFAiA;

			protected ub3yhfGU9uM2BP4kQQ4()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW aeD0jvkG0o();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 afbxVgfTCY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 AIrxLYOPbe(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract bool AIWJ56fpmE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ASAxYcksDW();

			internal static jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 BdXWQQc5UELxwqqMyxhk()
			{
				return jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4.V6m9SUc5pDwuhBiNFAiA;
			}

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW bom045C5yQ();

			public abstract bool C2DxgtwF4s(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb CLj0bGxkbn();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ctr0ZHYfwg(jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 cv9xPNKjLE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 D1fxFGeqb7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract bool Eme0FYs6nR();

			public abstract bool endx4m7CQT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ErsxxFLS44(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb F8qxT1rsi6();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FEsx6tlZCe();

			public abstract bool ffI0XduT5O();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FscxMh0y89();

			public abstract jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy Fu6xtFY6Su();

			public abstract jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 gduxhTRAky();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 GK8x1mthyY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 gOuxp90V6G(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract bool IG7xjsK4EF(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ixd03qpXfA();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J2C0L5xhmC();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J39xB0fFjG();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Jl4xcF8KnQ();

			public abstract bool JNkxbaE9i0(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb JNO0f6Ww4D();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb KTBxI7JM1N();

			public abstract jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lFDxK1rVZS();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LgEx00tIXr(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lGKxGefAaJ();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LJgxESAkAG(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb LpNxocNMFW();

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW lYyxrsIRV7();

			public abstract bool MwSxSSYZQ3(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 mZUxWFSSW6(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 N2YxsjFtx6();

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW nBW0zA6Cn1();

			internal static bool nIfxX3c5WUjqLHuGLopW()
			{
				return jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4.V6m9SUc5pDwuhBiNFAiA == null;
			}

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Nnox7pcLUS();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 OaTxvqmDKP(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb OBOxedVMZo();

			public abstract jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy PD5xRl3JtH();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 pEZxd6HgCc();

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW pnExQQrrXk();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb PO50N2hhDU();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 q5bxim1OPw(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 QkpxwApqeH(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb qwAxaCXBp2();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb RFK0SjXY75();

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW rROx2jU6yR();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 s2NxJDBMr7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 S9hxU3utYx(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 SRix9vq6s5(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb T6x0DEWO2j();

			public abstract bool U2yxzSjQyb(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb u360kVINWM();

			public abstract jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy UjQxA95UDE();

			internal override bool uliJnV0bkk()
			{
				return true;
			}

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 vsvxZprm8I(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy vTfxlGJn0p();

			public abstract jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 VtI0uXXMvw();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb vxLxnN4YIU();

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW W7TxCiinJ2();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wDv0moVOmC();

			public abstract bool wgXxNAO14B(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 WibxXYkaNk();

			public abstract jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 wLFxHSrDCX();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wpEx5XwQs6();

			public abstract jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW xN5xqf54GS();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb xPC0gkXCdf();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 y8Dx80UigU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb YShxOlBEdt();

			public abstract jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Yxvxyosj9C();

			public abstract jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 YygxuJKocU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0);
		}

		private class UZehaBGPBl166kGCJj8 : jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4
		{
			public double OLPGunv0l8;

			public jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND xpBGF8ir5r;

			private static jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 NYAkQGc5PKrSWPd1vBcZ;

			public UZehaBGPBl166kGCJj8(double double_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)5;
				this.xpBGF8ir5r = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)10;
				this.OLPGunv0l8 = double_0;
			}

			public UZehaBGPBl166kGCJj8(jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 uzehaBGPBl166kGCJj8_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = uzehaBGPBl166kGCJj8_0.OXE0eJU437;
				this.xpBGF8ir5r = uzehaBGPBl166kGCJj8_0.xpBGF8ir5r;
				this.OLPGunv0l8 = uzehaBGPBl166kGCJj8_0.OLPGunv0l8;
			}

			public UZehaBGPBl166kGCJj8(double double_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)5;
				this.OLPGunv0l8 = double_0;
				this.xpBGF8ir5r = lDlkEeGX3ctg76JDHND_0;
			}

			public UZehaBGPBl166kGCJj8(float float_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)5;
				this.OLPGunv0l8 = (double)float_0;
				this.xpBGF8ir5r = (jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND)9;
			}

			public UZehaBGPBl166kGCJj8(float float_0, jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)5;
				this.OLPGunv0l8 = (double)float_0;
				this.xpBGF8ir5r = lDlkEeGX3ctg76JDHND_0;
			}

			internal static jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 AdD4uOc5FjaN9tF2pmhI()
			{
				return jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8.NYAkQGc5PKrSWPd1vBcZ;
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW aeD0jvkG0o()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((ulong)this.OLPGunv0l8, 8);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 afbxVgfTCY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 AIrxLYOPbe(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
			}

			public override bool AIWJ56fpmE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 < ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ASAxYcksDW()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((int)this.OLPGunv0l8), 5);
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (type_0 != null && type_0.IsByRef)
				{
					type_0 = type_0.GetElementType();
				}
				if (type_0 == typeof(float))
				{
					return (float)this.OLPGunv0l8;
				}
				if (type_0 == typeof(double))
				{
					return this.OLPGunv0l8;
				}
				if (!(type_0 == null) && !(type_0 == typeof(object)) || (int)this.xpBGF8ir5r != 9)
				{
					return this.OLPGunv0l8;
				}
				return (float)this.OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW bom045C5yQ()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW((long)this.OLPGunv0l8, 7);
			}

			public override bool C2DxgtwF4s(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 >= ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb CLj0bGxkbn()
			{
				return this.JNO0f6Ww4D();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ctr0ZHYfwg(jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND lDlkEeGX3ctg76JDHND_0)
			{
				switch (lDlkEeGX3ctg76JDHND_0)
				{
					case 1:
					{
						return this.ixd03qpXfA();
					}
					case 2:
					{
						return this.u360kVINWM();
					}
					case 3:
					{
						return this.JNO0f6Ww4D();
					}
					case 4:
					{
						return this.wDv0moVOmC();
					}
					case 5:
					{
						return this.T6x0DEWO2j();
					}
					case 6:
					{
						return this.xPC0gkXCdf();
					}
					case 7:
					{
						return this.bom045C5yQ();
					}
					case 8:
					{
						return this.aeD0jvkG0o();
					}
					case 9:
					{
						return this.gduxhTRAky();
					}
					case 10:
					{
						return this.wLFxHSrDCX();
					}
					case 11:
					{
						return this.J2C0L5xhmC();
					}
					default:
					{
						throw new Exception(4.ToString());
					}
				}
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 cv9xPNKjLE(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 % ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 D1fxFGeqb7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).D8TxDuVrlI(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.BY4027cwoa())
				{
					return false;
				}
				return this.OLPGunv0l8 != ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)_leA9Ha0oP4AaSA2idq0).OLPGunv0l8;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				return this;
			}

			public override bool Eme0FYs6nR()
			{
				return this.OLPGunv0l8 == 0;
			}

			public override bool endx4m7CQT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 >= ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 ErsxxFLS44(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 - ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			internal static bool et9TjDc5ujPjFlUcxXQb()
			{
				return jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8.NYAkQGc5PKrSWPd1vBcZ == null;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb F8qxT1rsi6()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.OLPGunv0l8, 4);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FEsx6tlZCe()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((short)this.OLPGunv0l8), 3);
			}

			public override bool ffI0XduT5O()
			{
				return !this.Eme0FYs6nR();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb FscxMh0y89()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.OLPGunv0l8, 2);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy Fu6xtFY6Su()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.pnExQQrrXk().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.vxLxnN4YIU().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 gduxhTRAky()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((float)this.OLPGunv0l8, 9);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 GK8x1mthyY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 gOuxp90V6G(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 / ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override bool IG7xjsK4EF(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 > ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.OLPGunv0l8 = ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
				this.xpBGF8ir5r = ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).xpBGF8ir5r;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb ixd03qpXfA()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((sbyte)this.OLPGunv0l8, 1);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J2C0L5xhmC()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((this.Eme0FYs6nR() ? 1 : 0));
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb J39xB0fFjG()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((int)this.OLPGunv0l8), 5);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Jl4xcF8KnQ()
			{
				return this.wDv0moVOmC();
			}

			public override bool JNkxbaE9i0(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 <= ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb JNO0f6Ww4D()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((short)this.OLPGunv0l8, 3);
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.nSa06LHEGl())
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				if (!_leA9Ha0oP4AaSA2idq0.BY4027cwoa())
				{
					return false;
				}
				return this.OLPGunv0l8 == ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)_leA9Ha0oP4AaSA2idq0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb KTBxI7JM1N()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((sbyte)this.OLPGunv0l8), 1);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lFDxK1rVZS()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.lYyxrsIRV7().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.ASAxYcksDW().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LgEx00tIXr(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 - ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy lGKxGefAaJ()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.xN5xqf54GS().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.OBOxedVMZo().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 LJgxESAkAG(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 * ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb LpNxocNMFW()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((short)this.OLPGunv0l8), 3);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW lYyxrsIRV7()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked((long)this.OLPGunv0l8), 7);
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
			}

			public override bool MwSxSSYZQ3(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 > ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 mZUxWFSSW6(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 / ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 N2YxsjFtx6()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)this.OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW nBW0zA6Cn1()
			{
				return this.bom045C5yQ();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Nnox7pcLUS()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((uint)this.OLPGunv0l8), 6);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 OaTxvqmDKP(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 + ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb OBOxedVMZo()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((uint)this.OLPGunv0l8), 6);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy PD5xRl3JtH()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.nBW0zA6Cn1().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.PO50N2hhDU().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 pEZxd6HgCc()
			{
				if ((int)this.xpBGF8ir5r == 9)
				{
					return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((float)(-this.OLPGunv0l8));
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)(-this.OLPGunv0l8));
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW pnExQQrrXk()
			{
				return this.aeD0jvkG0o();
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb PO50N2hhDU()
			{
				return this.T6x0DEWO2j();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 q5bxim1OPw(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 + ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			internal override bool qjs01aMKus()
			{
				return this.ffI0XduT5O();
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 QkpxwApqeH(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 * ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb qwAxaCXBp2()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.OLPGunv0l8, 2);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb RFK0SjXY75()
			{
				return this.ixd03qpXfA();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW rROx2jU6yR()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked((long)this.OLPGunv0l8), 7);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 s2NxJDBMr7(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 - ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 S9hxU3utYx(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 % ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 SRix9vq6s5(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 + ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb T6x0DEWO2j()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.OLPGunv0l8, 5);
			}

			public override string ToString()
			{
				return this.OLPGunv0l8.ToString();
			}

			public override bool U2yxzSjQyb(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 < ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb u360kVINWM()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((byte)this.OLPGunv0l8, 2);
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy UjQxA95UDE()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.rROx2jU6yR().B3wGtwGQYo.qMbGqoMUDp);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((long)this.J39xB0fFjG().kTNGBJtJF0.VSLGOF3Fps);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 vsvxZprm8I(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
			}

			public override jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy vTfxlGJn0p()
			{
				if (IntPtr.Size == 8)
				{
					return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy(this.W7TxCiinJ2().B3wGtwGQYo.Do4GCrshxD);
				}
				return new jyRxpEAUNlcH3bE07bK.A2WrVaGlYvdxxQfYJpy((ulong)this.Nnox7pcLUS().kTNGBJtJF0.zaBGQHNwcU);
			}

			public override jyRxpEAUNlcH3bE07bK.ub3yhfGU9uM2BP4kQQ4 VtI0uXXMvw()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb vxLxnN4YIU()
			{
				return this.xPC0gkXCdf();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW W7TxCiinJ2()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked((ulong)this.OLPGunv0l8), 8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wDv0moVOmC()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((ushort)this.OLPGunv0l8, 4);
			}

			public override bool wgXxNAO14B(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return this.OLPGunv0l8 <= ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8;
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 WibxXYkaNk()
			{
				throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
			}

			public override jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8 wLFxHSrDCX()
			{
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8((double)this.OLPGunv0l8, 10);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb wpEx5XwQs6()
			{
				return this.u360kVINWM();
			}

			public override jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW xN5xqf54GS()
			{
				return new jyRxpEAUNlcH3bE07bK.JNdEF4GhRwb0L16xUVW(checked((ulong)this.OLPGunv0l8), 8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb xPC0gkXCdf()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((uint)this.OLPGunv0l8, 6);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 y8Dx80UigU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					leA9Ha0oP4AaSA2idq0_0 = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
				}
				if (!leA9Ha0oP4AaSA2idq0_0.BY4027cwoa() || !leA9Ha0oP4AaSA2idq0_0.BY4027cwoa())
				{
					throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
				}
				return new jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8(this.OLPGunv0l8 * ((jyRxpEAUNlcH3bE07bK.UZehaBGPBl166kGCJj8)leA9Ha0oP4AaSA2idq0_0).OLPGunv0l8);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb YShxOlBEdt()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb(checked((sbyte)this.OLPGunv0l8), 1);
			}

			public override jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb Yxvxyosj9C()
			{
				return new jyRxpEAUNlcH3bE07bK.FR14lrGIXaRSLEjVDsb((int)this.OLPGunv0l8, 4);
			}

			public override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 YygxuJKocU(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				throw new jyRxpEAUNlcH3bE07bK.CNf2hXGLXo0gcl4gpbD();
			}
		}

		internal class V0qZS6d5WlT8in0MwVe : jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT
		{
			private jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht ngCdcV0ZMk;

			internal int SDMdnn0NRl;

			internal static jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe RGmDQOccroQqiD5SGCsV;

			public V0qZS6d5WlT8in0MwVe(int int_0, jyRxpEAUNlcH3bE07bK.HBUrDWdFlVuC5umhXht hburDWdFlVuC5umhXht_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.ngCdcV0ZMk = hburDWdFlVuC5umhXht_0;
				this.SDMdnn0NRl = int_0;
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)7;
			}

			internal override IntPtr aplJOYYo3O()
			{
				throw new NotImplementedException();
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (this.ngCdcV0ZMk.aSm9Pn8nCP[this.SDMdnn0NRl] == null)
				{
					return null;
				}
				return this.e4VxkrOKkN().B550VtrALj(type_0);
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return true;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe))
				{
					return true;
				}
				return ((jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe)leA9Ha0oP4AaSA2idq0_0).SDMdnn0NRl != this.SDMdnn0NRl;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				if (this.ngCdcV0ZMk.aSm9Pn8nCP[this.SDMdnn0NRl] == null)
				{
					return new jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf(null);
				}
				return this.ngCdcV0ZMk.aSm9Pn8nCP[this.SDMdnn0NRl].e4VxkrOKkN();
			}

			internal static bool H5QwpPcc2W8cInxVvWdn()
			{
				return jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe.RGmDQOccroQqiD5SGCsV == null;
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe))
				{
					this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
					return;
				}
				this.ngCdcV0ZMk = ((jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe)leA9Ha0oP4AaSA2idq0_0).ngCdcV0ZMk;
				this.SDMdnn0NRl = ((jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe)leA9Ha0oP4AaSA2idq0_0).SDMdnn0NRl;
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return false;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe))
				{
					return false;
				}
				return ((jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe)leA9Ha0oP4AaSA2idq0_0).SDMdnn0NRl == this.SDMdnn0NRl;
			}

			internal override bool JSXxfJmewI()
			{
				return this.e4VxkrOKkN().JSXxfJmewI();
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
			}

			internal override void QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.ngCdcV0ZMk.aSm9Pn8nCP[this.SDMdnn0NRl] = leA9Ha0oP4AaSA2idq0_0;
			}

			internal override bool qjs01aMKus()
			{
				return this.e4VxkrOKkN().qjs01aMKus();
			}

			internal static jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe rWWys5ccMo9WTGpOll5m()
			{
				return jyRxpEAUNlcH3bE07bK.V0qZS6d5WlT8in0MwVe.RGmDQOccroQqiD5SGCsV;
			}
		}

		internal class w6jpMb0Rkw8HjOr2xos
		{
			private List<jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0> w6p0GHi1N4;

			internal static jyRxpEAUNlcH3bE07bK.w6jpMb0Rkw8HjOr2xos KF4wYcccS3WePRyR7Uq1;

			public w6jpMb0Rkw8HjOr2xos()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				this.w6p0GHi1N4 = new List<jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0>();
				base();
			}

			public void c2X0tj4ouL()
			{
				this.w6p0GHi1N4.Clear();
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 gsU0l8Uviv()
			{
				return this.w6p0GHi1N4[this.w6p0GHi1N4.Count - 1];
			}

			public void lwm0Kd30PY(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.w6p0GHi1N4.Add(leA9Ha0oP4AaSA2idq0_0);
			}

			internal static bool nd4xttccb3GaRw8F7nI9()
			{
				return jyRxpEAUNlcH3bE07bK.w6jpMb0Rkw8HjOr2xos.KF4wYcccS3WePRyR7Uq1 == null;
			}

			public jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 nws0A8A7sG()
			{
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 _leA9Ha0oP4AaSA2idq0 = this.gsU0l8Uviv();
				if (this.w6p0GHi1N4.Count != 0)
				{
					this.w6p0GHi1N4.RemoveAt(this.w6p0GHi1N4.Count - 1);
				}
				return _leA9Ha0oP4AaSA2idq0;
			}

			internal static jyRxpEAUNlcH3bE07bK.w6jpMb0Rkw8HjOr2xos sPcH1JccNWCKE2k0tswD()
			{
				return jyRxpEAUNlcH3bE07bK.w6jpMb0Rkw8HjOr2xos.KF4wYcccS3WePRyR7Uq1;
			}

			public int xLqe4PZWEH()
			{
				return this.w6p0GHi1N4.Count;
			}
		}

		private class wLXsfX0CtM6lkRpgimf : jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0
		{
			public object MYP0qhb0uR;

			public Type eMQ0hVgfFr;

			internal static jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf MwTYtgccfrnHWBZgTfUH;

			public wLXsfX0CtM6lkRpgimf()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				this(null);
			}

			public wLXsfX0CtM6lkRpgimf(object object_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base(0);
				this.MYP0qhb0uR = object_0;
				this.eMQ0hVgfFr = null;
			}

			public wLXsfX0CtM6lkRpgimf(object object_0, Type type_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base(0);
				this.MYP0qhb0uR = object_0;
				this.eMQ0hVgfFr = type_0;
			}

			internal override object B550VtrALj(Type type_0)
			{
				if (this.MYP0qhb0uR == null)
				{
					return null;
				}
				if (type_0 != null && type_0.IsByRef)
				{
					type_0 = type_0.GetElementType();
				}
				if (!(this.MYP0qhb0uR is jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0))
				{
					object mYP0qhb0uR = this.MYP0qhb0uR;
					if (mYP0qhb0uR != null && type_0 != null && mYP0qhb0uR.GetType() != type_0)
					{
						if (type_0 == typeof(RuntimeFieldHandle) && mYP0qhb0uR is FieldInfo)
						{
							mYP0qhb0uR = ((FieldInfo)mYP0qhb0uR).FieldHandle;
						}
						else if (type_0 == typeof(RuntimeTypeHandle) && mYP0qhb0uR is Type)
						{
							mYP0qhb0uR = ((Type)mYP0qhb0uR).TypeHandle;
						}
						else if (type_0 == typeof(RuntimeMethodHandle) && mYP0qhb0uR is MethodBase)
						{
							mYP0qhb0uR = ((MethodBase)mYP0qhb0uR).MethodHandle;
						}
					}
					return mYP0qhb0uR;
				}
				if (this.eMQ0hVgfFr != null)
				{
					return ((jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0)this.MYP0qhb0uR).B550VtrALj(this.eMQ0hVgfFr);
				}
				object fieldHandle = ((jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0)this.MYP0qhb0uR).B550VtrALj(type_0);
				if (fieldHandle != null && type_0 != null && fieldHandle.GetType() != type_0)
				{
					if (type_0 == typeof(RuntimeFieldHandle) && fieldHandle is FieldInfo)
					{
						fieldHandle = ((FieldInfo)fieldHandle).FieldHandle;
					}
					else if (type_0 == typeof(RuntimeTypeHandle) && fieldHandle is Type)
					{
						fieldHandle = ((Type)fieldHandle).TypeHandle;
					}
					else if (type_0 == typeof(RuntimeMethodHandle) && fieldHandle is MethodBase)
					{
						fieldHandle = ((MethodBase)fieldHandle).MethodHandle;
					}
				}
				return fieldHandle;
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).D8TxDuVrlI(this);
				}
				return this.B550VtrALj(null) != leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null);
			}

			internal static jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf DcBJfZccDeDG81W4NHD6()
			{
				return jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf.MwTYtgccfrnHWBZgTfUH;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 mYP0qhb0uR = this.MYP0qhb0uR as jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0;
				if (mYP0qhb0uR == null)
				{
					return this;
				}
				return mYP0qhb0uR.e4VxkrOKkN();
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf))
				{
					this.MYP0qhb0uR = leA9Ha0oP4AaSA2idq0_0.e4VxkrOKkN();
					return;
				}
				this.MYP0qhb0uR = ((jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf)leA9Ha0oP4AaSA2idq0_0).MYP0qhb0uR;
				this.eMQ0hVgfFr = ((jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf)leA9Ha0oP4AaSA2idq0_0).eMQ0hVgfFr;
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return ((jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT)leA9Ha0oP4AaSA2idq0_0).JOKxmtllMB(this);
				}
				return this.B550VtrALj(null) == leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null);
			}

			internal static bool KkS97jccmpUElF0501Ml()
			{
				return jyRxpEAUNlcH3bE07bK.wLXsfX0CtM6lkRpgimf.MwTYtgccfrnHWBZgTfUH == null;
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.ik90UsF9KT(leA9Ha0oP4AaSA2idq0_0);
			}

			internal override bool qjs01aMKus()
			{
				if (this.MYP0qhb0uR == null)
				{
					return false;
				}
				jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 mYP0qhb0uR = this.MYP0qhb0uR as jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0;
				if (mYP0qhb0uR == null)
				{
					return true;
				}
				if (mYP0qhb0uR.B550VtrALj(null) == null)
				{
					return false;
				}
				return true;
			}

			public override string ToString()
			{
				if (this.MYP0qhb0uR != null)
				{
					return this.MYP0qhb0uR.ToString();
				}
				return 5.ToString();
			}
		}

		internal class wW9tbTG4GPRu8lthc4n : jyRxpEAUNlcH3bE07bK.k18BcGGfvFEps11heXT
		{
			private Array opTGjGDWgA;

			internal int gV4GSDf5wQ;

			private static jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n R3IqgVccOFtIcT2VMmUA;

			public wW9tbTG4GPRu8lthc4n(int int_0, Array array_0)
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
				this.opTGjGDWgA = array_0;
				this.gV4GSDf5wQ = int_0;
				this.OXE0eJU437 = (jyRxpEAUNlcH3bE07bK.qhhuTZ0IEjH88Oi5W3B)7;
			}

			internal override IntPtr aplJOYYo3O()
			{
				throw new NotImplementedException();
			}

			internal override object B550VtrALj(Type type_0)
			{
				return this.e4VxkrOKkN().B550VtrALj(type_0);
			}

			internal static jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n CyGL2uccoWTtNFZ5xWFM()
			{
				return jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n.R3IqgVccOFtIcT2VMmUA;
			}

			internal override bool D8TxDuVrlI(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return true;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n))
				{
					return true;
				}
				jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n leA9Ha0oP4AaSA2idq00 = (jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n)leA9Ha0oP4AaSA2idq0_0;
				if (leA9Ha0oP4AaSA2idq00.gV4GSDf5wQ != this.gV4GSDf5wQ)
				{
					return true;
				}
				if (leA9Ha0oP4AaSA2idq00.opTGjGDWgA != this.opTGjGDWgA)
				{
					return true;
				}
				return false;
			}

			internal override jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 e4VxkrOKkN()
			{
				return jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0.Vuv0ynoAfM(this.opTGjGDWgA.GetType().GetElementType(), this.opTGjGDWgA.GetValue(this.gV4GSDf5wQ));
			}

			internal override void ik90UsF9KT(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n))
				{
					this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
					return;
				}
				this.opTGjGDWgA = ((jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n)leA9Ha0oP4AaSA2idq0_0).opTGjGDWgA;
				this.gV4GSDf5wQ = ((jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n)leA9Ha0oP4AaSA2idq0_0).gV4GSDf5wQ;
			}

			internal override bool JOKxmtllMB(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				if (!leA9Ha0oP4AaSA2idq0_0.lFyJQh378A())
				{
					return false;
				}
				if (!(leA9Ha0oP4AaSA2idq0_0 is jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n))
				{
					return false;
				}
				jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n leA9Ha0oP4AaSA2idq00 = (jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n)leA9Ha0oP4AaSA2idq0_0;
				if (leA9Ha0oP4AaSA2idq00.gV4GSDf5wQ != this.gV4GSDf5wQ)
				{
					return false;
				}
				if (leA9Ha0oP4AaSA2idq00.opTGjGDWgA != this.opTGjGDWgA)
				{
					return false;
				}
				return true;
			}

			internal override bool JSXxfJmewI()
			{
				return this.e4VxkrOKkN().JSXxfJmewI();
			}

			internal override void mGF0P5nyg1(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.QhFJINNrIN(leA9Ha0oP4AaSA2idq0_0);
			}

			internal override void QhFJINNrIN(jyRxpEAUNlcH3bE07bK.leA9Ha0oP4AaSA2idq0 leA9Ha0oP4AaSA2idq0_0)
			{
				this.opTGjGDWgA.SetValue(leA9Ha0oP4AaSA2idq0_0.B550VtrALj(null), this.gV4GSDf5wQ);
			}

			internal override bool qjs01aMKus()
			{
				return this.e4VxkrOKkN().qjs01aMKus();
			}

			internal static bool TZaxVEccIleqhviyCVNi()
			{
				return jyRxpEAUNlcH3bE07bK.wW9tbTG4GPRu8lthc4n.R3IqgVccOFtIcT2VMmUA == null;
			}
		}

		internal class xiiVHYdrh2Wy4l9H8wq
		{
			public int jDtd2sGqaF;

			public jyRxpEAUNlcH3bE07bK.lDlkEeGX3ctg76JDHND CltdMTgipO;

			public bool FHadayiPnr;

			public Type CnUdyuU2r4;

			internal static jyRxpEAUNlcH3bE07bK.xiiVHYdrh2Wy4l9H8wq IUITficcqGKVxZFqeX8R;

			public xiiVHYdrh2Wy4l9H8wq()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				this.CnUdyuU2r4 = typeof(object);
				base();
			}

			internal static jyRxpEAUNlcH3bE07bK.xiiVHYdrh2Wy4l9H8wq q4fwRFccHl43JM2JgQja()
			{
				return jyRxpEAUNlcH3bE07bK.xiiVHYdrh2Wy4l9H8wq.IUITficcqGKVxZFqeX8R;
			}

			internal static bool QM1pthcchRA4gjJYvXd8()
			{
				return jyRxpEAUNlcH3bE07bK.xiiVHYdrh2Wy4l9H8wq.IUITficcqGKVxZFqeX8R == null;
			}
		}

		internal class XUXO9Mdl6GFc6JhHJhK
		{
			internal MethodBase d3JdACOT1O;

			internal List<jyRxpEAUNlcH3bE07bK.sVb83IG1u6ZbkqvM6XP> kiSdGj4IZJ;

			internal jyRxpEAUNlcH3bE07bK.Tx7DN0doIKUv6kJH77R[] r2IddyNrH5;

			internal List<jyRxpEAUNlcH3bE07bK.xiiVHYdrh2Wy4l9H8wq> wYNdvFYKwB;

			internal List<jyRxpEAUNlcH3bE07bK.JFcSR6dTBGIgDFch6vX> lwRdiOdWOb;

			internal static jyRxpEAUNlcH3bE07bK.XUXO9Mdl6GFc6JhHJhK p8sU3VccGH1QGePNHVoq;

			public XUXO9Mdl6GFc6JhHJhK()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal static bool fZBIpTccdgWFfB4Xi6lq()
			{
				return jyRxpEAUNlcH3bE07bK.XUXO9Mdl6GFc6JhHJhK.p8sU3VccGH1QGePNHVoq == null;
			}

			internal static jyRxpEAUNlcH3bE07bK.XUXO9Mdl6GFc6JhHJhK LIthabccvBSFgq8yxK6p()
			{
				return jyRxpEAUNlcH3bE07bK.XUXO9Mdl6GFc6JhHJhK.p8sU3VccGH1QGePNHVoq;
			}
		}
	}
}