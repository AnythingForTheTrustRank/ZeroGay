using b3eD5DgJPcASx0xfHYB;
using System;
using System.IO;

internal delegate object ca92rdRDGVVJioK3Y0S(object , Stream );