using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using Il2CppSystem.IO;
using Il2CppSystem.Runtime.Serialization.Formatters.Binary;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnhollowerBaseLib;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;

namespace U6ZnilcmrKLw7x02H01
{
	internal class gU1eyRcfYqUNIwZLSO5
	{
		private static gU1eyRcfYqUNIwZLSO5 b2VFrefhGvqfl0VoBbw;

		public gU1eyRcfYqUNIwZLSO5()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static H2rW5mczcybwEmUZw6i BEKcNjH8g8<H2rW5mczcybwEmUZw6i>(object object_0)
		{
			H2rW5mczcybwEmUZw6i h2rW5mczcybwEmUZw6i;
			if (object_0 != null)
			{
				Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				h2rW5mczcybwEmUZw6i = (H2rW5mczcybwEmUZw6i)binaryFormatter.Deserialize(new Il2CppSystem.IO.MemoryStream(object_0));
			}
			else
			{
				h2rW5mczcybwEmUZw6i = default(H2rW5mczcybwEmUZw6i);
			}
			return h2rW5mczcybwEmUZw6i;
		}

		public static byte[] cLIcDYSg0X(int int_0)
		{
			System.Random random = new System.Random();
			byte[] numArray = new byte[int_0 * 1024];
			random.NextBytes(numArray);
			return numArray;
		}

		public static byte[] DkNc4vKGWB(object object_0)
		{
			byte[] array;
			if (object_0 == null)
			{
				array = null;
			}
			else
			{
				Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new Il2CppSystem.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				Il2CppSystem.IO.MemoryStream memoryStream = new Il2CppSystem.IO.MemoryStream();
				binaryFormatter.Serialize(memoryStream, object_0);
				array = memoryStream.ToArray();
			}
			return array;
		}

		internal static gU1eyRcfYqUNIwZLSO5 e3ib2PfsJnu1k7Ym02G()
		{
			return gU1eyRcfYqUNIwZLSO5.b2VFrefhGvqfl0VoBbw;
		}

		internal static bool E776k8fH1Z7rT7jc1pX()
		{
			return gU1eyRcfYqUNIwZLSO5.b2VFrefhGvqfl0VoBbw == null;
		}

		public static Qx2srFnQMpovaCWTgLX JdTnnlvSDJ<Qx2srFnQMpovaCWTgLX>(object object_0)
		{
			return gU1eyRcfYqUNIwZLSO5.BEKcNjH8g8<Qx2srFnQMpovaCWTgLX>(gU1eyRcfYqUNIwZLSO5.mHAcjB1xb6(object_0));
		}

		public static h4tZ4fcbY7GXg4gldkq Kg6cSdxScx<h4tZ4fcbY7GXg4gldkq>(object object_0)
		{
			h4tZ4fcbY7GXg4gldkq _h4tZ4fcbY7GXg4gldkq;
			if (object_0 != null)
			{
				System.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream(object_0))
				{
					_h4tZ4fcbY7GXg4gldkq = (h4tZ4fcbY7GXg4gldkq)binaryFormatter.Deserialize(memoryStream);
				}
			}
			else
			{
				_h4tZ4fcbY7GXg4gldkq = default(h4tZ4fcbY7GXg4gldkq);
			}
			return _h4tZ4fcbY7GXg4gldkq;
		}

		public static byte[] mHAcjB1xb6(object object_0)
		{
			byte[] array;
			if (object_0 == null)
			{
				array = null;
			}
			else
			{
				System.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
				binaryFormatter.Serialize(memoryStream, object_0);
				array = memoryStream.ToArray();
			}
			return array;
		}

		public static UnityEngine.Object NqYcgJoJgv(object object_0)
		{
			Il2CppStructArray<byte> il2CppStructArray = new Il2CppStructArray<byte>((long)((int)object_0.Length));
			object_0.CopyTo(il2CppStructArray, 0);
			return new UnityEngine.Object((new Il2CppSystem.Object(il2CppStructArray.get_Pointer())).get_Pointer());
		}

		public static xTQvAyncT310id3adAh zRvn5sKK2m<xTQvAyncT310id3adAh>(object object_0)
		{
			return gU1eyRcfYqUNIwZLSO5.Kg6cSdxScx<xTQvAyncT310id3adAh>(gU1eyRcfYqUNIwZLSO5.DkNc4vKGWB(object_0));
		}
	}
}