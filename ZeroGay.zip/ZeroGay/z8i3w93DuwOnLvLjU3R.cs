using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Array z8i3w93DuwOnLvLjU3R(Type type_0, int int_0);