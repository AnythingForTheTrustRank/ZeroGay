using AksgHVKH9UOXlBDvRpO;
using System;
using VRC;

internal delegate SimpleAvatarPedestal KGX8lRpOMYP5UeShCds(object object_0);