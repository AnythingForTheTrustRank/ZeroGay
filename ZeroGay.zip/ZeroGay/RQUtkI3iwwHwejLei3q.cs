using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate ulong RQUtkI3iwwHwejLei3q(ref UIntPtr uintptr_0);