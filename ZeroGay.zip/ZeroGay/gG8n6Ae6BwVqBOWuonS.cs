using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void gG8n6Ae6BwVqBOWuonS(object , TextAnchor );