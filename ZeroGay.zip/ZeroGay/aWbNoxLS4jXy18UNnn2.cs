using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string aWbNoxLS4jXy18UNnn2(ref double );