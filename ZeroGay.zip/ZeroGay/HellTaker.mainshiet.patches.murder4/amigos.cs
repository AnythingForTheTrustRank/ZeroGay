using AksgHVKH9UOXlBDvRpO;
using System;
using X7IetPATbOXxq4U7Vmy;

namespace HellTaker.mainshiet.patches.murder4
{
	public class amigos
	{
		public static bool assignimposter;

		internal static amigos h5j8chm5XE7I9wQAQhJ;

		public amigos()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static amigos OKp6Hcmn7e7W04qd5Ru()
		{
			return amigos.h5j8chm5XE7I9wQAQhJ;
		}

		internal static bool VeTrtxmcLTbLFTpssgw()
		{
			return amigos.h5j8chm5XE7I9wQAQhJ == null;
		}
	}
}