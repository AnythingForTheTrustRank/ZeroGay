using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;

namespace HellTaker.mainshiet.patches.murder4
{
	public class amigos
	{
		public static bool assignimposter;

		internal static amigos mn8UOfdIJ4tkCEUR7pY;

		public amigos()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static amigos e3DQtHdti5T4vROeell()
		{
			return amigos.mn8UOfdIJ4tkCEUR7pY;
		}

		internal static bool RhuW07d6EwDwYoIqVK6()
		{
			return amigos.mn8UOfdIJ4tkCEUR7pY == null;
		}
	}
}