using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using X7IetPATbOXxq4U7Vmy;

namespace HellTaker.mainshiet.patches.murder4
{
	public class Murder4
	{
		public static string WORLDID;

		public static bool PatreonEnforcer;

		public static bool collectcluesBUTTON;

		public static bool carrysnakeboxTOGGLE;

		internal static Murder4 t51m9umQ39otMJChp7C;

		static Murder4()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			Murder4.WORLDID = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
			Murder4.PatreonEnforcer = false;
			Murder4.collectcluesBUTTON = false;
			Murder4.carrysnakeboxTOGGLE = false;
		}

		public Murder4()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static IEnumerator carrysnakebox(bool state)
		{
			while (true)
			{
				if (Murder4.carrysnakeboxTOGGLE)
				{
					while (Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f)
					{
						GameObject gameObject = GameObject.Find("Game Logic/Snakes/SnakeDispenser");
						gameObject.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18));
						yield return new WaitForSeconds(0.01f);
						gameObject = null;
					}
					while (Input.GetKeyDown(323))
					{
						GameObject gameObject1 = GameObject.Find("Game Logic/Snakes/SnakeDispenser");
						gameObject1.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18));
						yield return new WaitForSeconds(0.01f);
						gameObject1 = null;
					}
				}
				yield return new WaitForSeconds(0.001f);
			}
		}

		public static IEnumerator ClueCollectorLegit(bool state)
		{
			while (true)
			{
				if (Murder4.Inworld() && Murder4.collectcluesBUTTON)
				{
					GameObject gameObject = GameObject.Find("Game Logic/Clues/Clue (photograph)");
					if (gameObject != null)
					{
						gameObject.GetComponent<UdonBehaviour>().Interact();
					}
					else
					{
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject1 = GameObject.Find("Game Logic/Clues/Clue (notebook)");
					if (gameObject1 == null)
					{
					}
					else
					{
						gameObject1.GetComponent<UdonBehaviour>().Interact();
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject2 = GameObject.Find("Game Logic/Clues/Clue (locket)");
					if (gameObject2 != null)
					{
						gameObject2.GetComponent<UdonBehaviour>().Interact();
					}
					else
					{
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject3 = GameObject.Find("Game Logic/Clues/Clue (pocketwatch)");
					if (gameObject3 == null)
					{
					}
					else
					{
						gameObject3.GetComponent<UdonBehaviour>().Interact();
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject4 = GameObject.Find("Game Logic/Clues/Clue (postcard)");
					if (gameObject4 == null)
					{
					}
					else
					{
						gameObject4.GetComponent<UdonBehaviour>().Interact();
					}
					yield return new WaitForSeconds(1f);
					Murder4.collectcluesBUTTON = false;
				}
				yield return new WaitForSeconds(1f);
			}
		}

		public static bool Inworld()
		{
			bool flag;
			flag = (RoomManager.Method_Internal_Static_get_String_0().Contains(Murder4.WORLDID) ? true : false);
			return flag;
		}

		internal static bool MlGmPMmOvwhQ2a6ccUp()
		{
			return Murder4.t51m9umQ39otMJChp7C == null;
		}

		public static IEnumerator PatreonSync(bool state)
		{
			bool flag;
			while (true)
			{
				if (Murder4.Inworld() && Murder4.PatreonEnforcer)
				{
					List<VRCPickup> vRCPickups = new List<VRCPickup>()
					{
						GameObject.Find("Game Logic/Weapons/Revolver").GetComponent<VRCPickup>()
					};
					List<VRCPickup> vRCPickups1 = vRCPickups;
					yield return new WaitForSeconds(0.1f);
					GameObject gameObject = GameObject.Find("Game Logic/Weapons/Revolver");
					GameObject gameObject1 = GameObject.Find("Game Logic/Weapons/Revolver/Patron skin sound");
					foreach (VRCPickup vRCPickup in vRCPickups1)
					{
						flag = (!vRCPickup.get_IsHeld() ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup.get_gameObject()));
						if (flag)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "PatronSkin", null, false);
						}
					}
					vRCPickups1 = null;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		internal static Murder4 qee8NCmIHDBZErsKcFq()
		{
			return Murder4.t51m9umQ39otMJChp7C;
		}
	}
}