using b3eD5DgJPcASx0xfHYB;
using gpd3oZtw5qhYneWRlWY;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;

namespace HellTaker.mainshiet.patches.murder4
{
	public class Murder4
	{
		public static string WORLDID;

		public static bool PatreonEnforcer;

		public static bool collectcluesBUTTON;

		public static bool carrysnakeboxTOGGLE;

		private static Murder4 WONWdZdQer1uShSp0Vw;

		static Murder4()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			Murder4.WORLDID = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
			Murder4.PatreonEnforcer = false;
			Murder4.collectcluesBUTTON = false;
			Murder4.carrysnakeboxTOGGLE = false;
		}

		public Murder4()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static IEnumerator carrysnakebox(bool state)
		{
			while (true)
			{
				if (Murder4.carrysnakeboxTOGGLE)
				{
					while (Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f)
					{
						GameObject gameObject = GameObject.Find("Game Logic/Snakes/SnakeDispenser");
						gameObject.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18));
						yield return new WaitForSeconds(0.01f);
						gameObject = null;
					}
					while (Input.GetKeyDown(323))
					{
						GameObject gameObject1 = GameObject.Find("Game Logic/Snakes/SnakeDispenser");
						gameObject1.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18));
						yield return new WaitForSeconds(0.01f);
						gameObject1 = null;
					}
				}
				yield return new WaitForSeconds(0.001f);
			}
		}

		internal static Murder4 CddmGedNLKrguh5VuJx()
		{
			return Murder4.WONWdZdQer1uShSp0Vw;
		}

		public static IEnumerator ClueCollectorLegit(bool state)
		{
			while (true)
			{
				if (Murder4.Inworld() && Murder4.collectcluesBUTTON)
				{
					GameObject gameObject = GameObject.Find("Game Logic/Clues/Clue (photograph)");
					if (gameObject == null)
					{
					}
					else
					{
						gameObject.GetComponent<UdonBehaviour>().Interact();
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject1 = GameObject.Find("Game Logic/Clues/Clue (notebook)");
					if (gameObject1 != null)
					{
						gameObject1.GetComponent<UdonBehaviour>().Interact();
					}
					else
					{
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject2 = GameObject.Find("Game Logic/Clues/Clue (locket)");
					if (gameObject2 != null)
					{
						gameObject2.GetComponent<UdonBehaviour>().Interact();
					}
					else
					{
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject3 = GameObject.Find("Game Logic/Clues/Clue (pocketwatch)");
					if (gameObject3 != null)
					{
						gameObject3.GetComponent<UdonBehaviour>().Interact();
					}
					else
					{
					}
					yield return new WaitForSeconds(1f);
					GameObject gameObject4 = GameObject.Find("Game Logic/Clues/Clue (postcard)");
					if (gameObject4 == null)
					{
					}
					else
					{
						gameObject4.GetComponent<UdonBehaviour>().Interact();
					}
					yield return new WaitForSeconds(1f);
					Murder4.collectcluesBUTTON = false;
				}
				yield return new WaitForSeconds(1f);
			}
		}

		internal static bool cVWEJKdwWVEDRjPX3f2()
		{
			return Murder4.WONWdZdQer1uShSp0Vw == null;
		}

		public static bool Inworld()
		{
			bool flag;
			flag = (RoomManager.Method_Internal_Static_get_String_0().Contains(Murder4.WORLDID) ? true : false);
			return flag;
		}

		public static IEnumerator PatreonSync(bool state)
		{
			while (true)
			{
				if (Murder4.Inworld() && Murder4.PatreonEnforcer)
				{
					List<VRCPickup> vRCPickups = new List<VRCPickup>()
					{
						GameObject.Find("Game Logic/Weapons/Revolver").GetComponent<VRCPickup>()
					};
					List<VRCPickup> vRCPickups1 = vRCPickups;
					yield return new WaitForSeconds(0.1f);
					GameObject gameObject = GameObject.Find("Game Logic/Weapons/Revolver");
					GameObject gameObject1 = GameObject.Find("Game Logic/Weapons/Revolver/Patron skin sound");
					foreach (VRCPickup vRCPickup in vRCPickups1)
					{
						if (vRCPickup.get_IsHeld() && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "PatronSkin", null, false);
						}
					}
					vRCPickups1 = null;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}
	}
}