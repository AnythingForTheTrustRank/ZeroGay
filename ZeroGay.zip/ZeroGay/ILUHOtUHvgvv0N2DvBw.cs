using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Quaternion ILUHOtUHvgvv0N2DvBw(Vector3 vector3_0);