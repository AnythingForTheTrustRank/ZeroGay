using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void qTTDsyeNcjPtheAvNUL(object , Font );