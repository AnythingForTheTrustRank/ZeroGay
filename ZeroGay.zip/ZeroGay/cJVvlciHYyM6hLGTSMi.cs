using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using System;
using UnityEngine;

internal delegate UnityEngine.Object cJVvlciHYyM6hLGTSMi(object , string , Il2CppSystem.Type );