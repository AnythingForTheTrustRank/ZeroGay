using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void Wc6QnSuo9CiCC3wHcsl(string string_0, string string_1);