using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine.SceneManagement;

internal delegate Scene n2S2UniMWaitt4YGAKp();