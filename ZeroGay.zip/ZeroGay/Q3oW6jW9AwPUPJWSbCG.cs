using AksgHVKH9UOXlBDvRpO;
using System;
using System.Globalization;

internal delegate int Q3oW6jW9AwPUPJWSbCG(string string_0, NumberStyles numberStyles_0);