using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void d402rW1R3UWYHgHOAhe(object object_0, object object_1, object object_2);