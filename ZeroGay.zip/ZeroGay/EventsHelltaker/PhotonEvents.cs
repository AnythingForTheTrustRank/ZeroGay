using b3eD5DgJPcASx0xfHYB;
using ExitGames.Client.Photon;
using Il2CppSystem;
using Photon.Pun;
using Photon.Realtime;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;
using yoigTak5mMDlpfs5Dum;

namespace EventsHelltaker
{
	public class PhotonEvents
	{
		public static bool KillQuesties;

		public static float Counter;

		public static bool Lagger;

		public static bool Earrape;

		public static bool Desyncer;

		public static bool UspeakDesync;

		public static bool event209;

		internal static PhotonEvents YgU80QdhblGJ2kD5fr1;

		public PhotonEvents()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static IEnumerator EarrapeEvent()
		{
			return new PhotonEvents.<EarrapeEvent>d__6(0);
		}

		public static IEnumerator EventLagger9()
		{
			return new PhotonEvents.<EventLagger9>d__9(0);
		}

		internal static PhotonEvents g6V9OMdTBBEmeXLVvlH()
		{
			return PhotonEvents.YgU80QdhblGJ2kD5fr1;
		}

		public static void OpRaiseEvent(byte code, object customObject, Photon.Realtime.RaiseEventOptions RaiseEventOptions, SendOptions sendOptions)
		{
			Il2CppSystem.Object obj = Ub7mwBkJ0gxOHiWrCdb.l7188lYESg<Il2CppSystem.Object>(customObject);
			PhotonNetwork.Method_Private_Static_Boolean_Byte_Object_RaiseEventOptions_SendOptions_0(code, obj, RaiseEventOptions, sendOptions);
		}

		internal static bool tGNse4dU59J412bGq2O()
		{
			return PhotonEvents.YgU80QdhblGJ2kD5fr1 == null;
		}
	}
}