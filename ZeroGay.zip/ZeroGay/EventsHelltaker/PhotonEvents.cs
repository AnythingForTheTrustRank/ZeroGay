using AksgHVKH9UOXlBDvRpO;
using ExitGames.Client.Photon;
using Il2CppSystem;
using MelonLoader;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using U6ZnilcmrKLw7x02H01;
using UnityEngine;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;

namespace EventsHelltaker
{
	public class PhotonEvents
	{
		public static bool KillQuesties;

		public static float Counter;

		public static bool Lagger;

		public static bool Earrape;

		public static bool Desyncer;

		public static bool UspeakDesync;

		public static bool event209;

		private static PhotonEvents mqmeZ3mBqCqNf4kNnmP;

		public PhotonEvents()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static IEnumerator EarrapeEvent()
		{
			byte[] numArray = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 187, 134, 59, 0, 248, 125, 232, 192, 92, 160, 82, 254, 48, 228, 30, 187, 149, 196, 177, 215, 140, 223, 127, 209, 66, 60, 0, 226, 53, 180, 176, 97, 104, 4, 248, 238, 195, 134, 44, 185, 182, 68, 94, 114, 205, 181, 150, 56, 232, 126, 247, 155, 123, 172, 108, 98, 80, 56, 113, 89, 160, 134, 221 };
			Buffer.BlockCopy(BitConverter.GetBytes(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().Method_Public_get_VRCPlayerApi_0().get_playerId()), 0, numArray, 0, 4);
			while (PhotonEvents.Earrape)
			{
				Buffer.BlockCopy(BitConverter.GetBytes(PhotonNetwork.get_field_Public_Static_LoadBalancingClient_0().get_field_Private_LoadBalancingPeer_0().get_ServerTimeInMilliSeconds()), 0, numArray, 4, 4);
				byte[] numArray1 = numArray;
				RaiseEventOptions raiseEventOption = new RaiseEventOptions();
				raiseEventOption.set_field_Public_ReceiverGroup_0(0);
				raiseEventOption.set_field_Public_EventCaching_0(0);
				PhotonEvents.OpRaiseEvent(1, numArray1, raiseEventOption, new SendOptions());
				yield return new WaitForSeconds(0.03f);
			}
		}

		public static IEnumerator EventLagger9()
		{
			return new PhotonEvents.<EventLagger9>d__9(0);
		}

		public static void OpRaiseEvent(byte code, object customObject, Photon.Realtime.RaiseEventOptions RaiseEventOptions, SendOptions sendOptions)
		{
			Il2CppSystem.Object obj = gU1eyRcfYqUNIwZLSO5.JdTnnlvSDJ<Il2CppSystem.Object>(customObject);
			PhotonNetwork.Method_Private_Static_Boolean_Byte_Object_RaiseEventOptions_SendOptions_0(code, obj, RaiseEventOptions, sendOptions);
		}

		internal static PhotonEvents tU1bxNm2w87ASL9OsTA()
		{
			return PhotonEvents.mqmeZ3mBqCqNf4kNnmP;
		}

		internal static bool XQUbkrmr2SE6L7IAygu()
		{
			return PhotonEvents.mqmeZ3mBqCqNf4kNnmP == null;
		}
	}
}