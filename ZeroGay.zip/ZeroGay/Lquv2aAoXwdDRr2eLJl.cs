using b3eD5DgJPcASx0xfHYB;
using System;
using System.Runtime.CompilerServices;

internal delegate void Lquv2aAoXwdDRr2eLJl(ref AsyncTaskMethodBuilder , Exception );