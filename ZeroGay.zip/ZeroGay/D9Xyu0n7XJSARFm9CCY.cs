using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void D9Xyu0n7XJSARFm9CCY(object , float );