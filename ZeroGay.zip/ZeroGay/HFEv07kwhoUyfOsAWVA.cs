using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;
using System.Reflection.Emit;

internal delegate void HFEv07kwhoUyfOsAWVA(object object_0, OpCode opCode_0, FieldInfo fieldInfo_0);