using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void QcnpU0VwMGvxyOvD7LS(object , object , object );