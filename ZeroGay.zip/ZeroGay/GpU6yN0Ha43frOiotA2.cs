using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate bool GpU6yN0Ha43frOiotA2(Il2CppStructArray<Plane> , Bounds );