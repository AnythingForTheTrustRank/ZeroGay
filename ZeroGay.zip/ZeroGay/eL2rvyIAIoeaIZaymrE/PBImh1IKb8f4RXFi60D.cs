using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;

namespace eL2rvyIAIoeaIZaymrE
{
	internal class PBImh1IKb8f4RXFi60D
	{
		public static bool JnfI5KOiUI;

		public static bool msyId214mQ;

		public static bool O0IIojHrW8;

		public static bool zbgIm8KnRS;

		public static float HvlID2tEBS;

		public static float URdIc03mkX;

		public static float H7vIyomQMK;

		public static float raKIEp2Pim;

		public static bool uJXIzcVFys;

		internal static PBImh1IKb8f4RXFi60D bwe6ZedYjjcsj0BBohm;

		static PBImh1IKb8f4RXFi60D()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			PBImh1IKb8f4RXFi60D.JnfI5KOiUI = false;
			PBImh1IKb8f4RXFi60D.msyId214mQ = false;
			PBImh1IKb8f4RXFi60D.O0IIojHrW8 = false;
			PBImh1IKb8f4RXFi60D.zbgIm8KnRS = false;
			PBImh1IKb8f4RXFi60D.HvlID2tEBS = 16f;
			PBImh1IKb8f4RXFi60D.URdIc03mkX = 8f;
			PBImh1IKb8f4RXFi60D.H7vIyomQMK = 8f;
			PBImh1IKb8f4RXFi60D.raKIEp2Pim = 6f;
			PBImh1IKb8f4RXFi60D.uJXIzcVFys = false;
		}

		public PBImh1IKb8f4RXFi60D()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static void fi9IJLUieS(bool u0020)
		{
			if (PBImh1IKb8f4RXFi60D.zbgIm8KnRS)
			{
				Networking.get_LocalPlayer().SetJumpImpulse(PBImh1IKb8f4RXFi60D.H7vIyomQMK);
			}
			else
			{
				Networking.get_LocalPlayer().SetJumpImpulse(3f);
			}
		}

		internal static PBImh1IKb8f4RXFi60D GH0sskdOp5Fc6Ce5pYa()
		{
			return PBImh1IKb8f4RXFi60D.bwe6ZedYjjcsj0BBohm;
		}

		public static IEnumerator MfsIVEJWb5(bool u0020)
		{
			while (true)
			{
				if (PBImh1IKb8f4RXFi60D.uJXIzcVFys && VRCInputManager.Method_Public_Static_VRCInput_String_0("Jump").Method_Public_get_Boolean_3() && !Networking.get_LocalPlayer().IsPlayerGrounded())
				{
					Vector3 jumpImpulse = Networking.get_LocalPlayer().GetVelocity();
					jumpImpulse.y = Networking.get_LocalPlayer().GetJumpImpulse();
					Networking.get_LocalPlayer().SetVelocity(jumpImpulse);
					jumpImpulse = new Vector3();
				}
				yield return new WaitForSeconds(0.01f);
			}
		}

		internal static bool pJyCTPdXTOAcj41KrCd()
		{
			return PBImh1IKb8f4RXFi60D.bwe6ZedYjjcsj0BBohm == null;
		}

		internal static void UniILlQ2vv(bool u0020)
		{
			if (PBImh1IKb8f4RXFi60D.O0IIojHrW8)
			{
				Networking.get_LocalPlayer().SetWalkSpeed(PBImh1IKb8f4RXFi60D.URdIc03mkX);
				Networking.get_LocalPlayer().SetRunSpeed(PBImh1IKb8f4RXFi60D.HvlID2tEBS);
				Networking.get_LocalPlayer().SetStrafeSpeed(PBImh1IKb8f4RXFi60D.URdIc03mkX);
			}
			else
			{
				Networking.get_LocalPlayer().SetWalkSpeed(2f);
				Networking.get_LocalPlayer().SetRunSpeed(4f);
				Networking.get_LocalPlayer().SetStrafeSpeed(2f);
			}
		}
	}
}