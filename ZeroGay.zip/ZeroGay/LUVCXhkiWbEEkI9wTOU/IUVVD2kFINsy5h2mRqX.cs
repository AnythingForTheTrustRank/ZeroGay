using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Windows.Forms;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using VRC.UI;

namespace LUVCXhkiWbEEkI9wTOU
{
	internal class IUVVD2kFINsy5h2mRqX
	{
		private static IUVVD2kFINsy5h2mRqX ap66FG5G81Z73kWJJjO;

		public IUVVD2kFINsy5h2mRqX()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool cyZ4IY53fnUHufjTRhL()
		{
			return IUVVD2kFINsy5h2mRqX.ap66FG5G81Z73kWJJjO == null;
		}

		internal static IUVVD2kFINsy5h2mRqX Fq6d0T59fIZeVfy2X8k()
		{
			return IUVVD2kFINsy5h2mRqX.ap66FG5G81Z73kWJJjO;
		}

		internal static void L2UkRnjcV4(object u0020)
		{
			PageAvatar component = GameObject.Find("Screens").get_transform().Find("Avatar").GetComponent<PageAvatar>();
			SimpleAvatarPedestal fieldPublicSimpleAvatarPedestal0 = component.get_field_Public_SimpleAvatarPedestal_0();
			ApiAvatar apiAvatar = new ApiAvatar();
			apiAvatar.set_id(u0020);
			fieldPublicSimpleAvatarPedestal0.set_field_Internal_ApiAvatar_0(apiAvatar);
			component.ChangeToSelectedAvatar();
		}

		internal static string PUPkpMX8m7()
		{
			string text;
			if (Clipboard.ContainsText())
			{
				text = Clipboard.GetText();
			}
			else
			{
				text = null;
			}
			return text;
		}

		internal static void SPwkr0eD46(object u0020)
		{
			if (Clipboard.ContainsText())
			{
				Clipboard.Clear();
				Clipboard.SetText(u0020);
			}
			else
			{
				Clipboard.SetText(u0020);
			}
		}

		public static bool YZXk0vxmlL(object u0020)
		{
			bool flag;
			if (!Networking.GoToRoom(u0020))
			{
				string[] strArrays = u0020.Split(new char[] { ':' });
				if ((int)strArrays.Length != 2)
				{
					flag = false;
					return flag;
				}
				(new PortalInternal()).Method_Private_Void_String_String_PDM_0(strArrays[0], strArrays[1]);
			}
			flag = true;
			return flag;
		}
	}
}