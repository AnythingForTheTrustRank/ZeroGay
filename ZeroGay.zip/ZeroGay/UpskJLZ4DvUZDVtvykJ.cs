using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void UpskJLZ4DvUZDVtvykJ(object , Vector3 );