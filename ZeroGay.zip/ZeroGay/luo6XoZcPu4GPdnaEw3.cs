using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.Rendering;

internal delegate void luo6XoZcPu4GPdnaEw3(object object_0, ReflectionProbeMode reflectionProbeMode_0);