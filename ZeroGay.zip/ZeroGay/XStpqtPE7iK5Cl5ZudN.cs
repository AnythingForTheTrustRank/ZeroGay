using AksgHVKH9UOXlBDvRpO;
using System;
using System.IO;

internal delegate FileStream XStpqtPE7iK5Cl5ZudN(string string_0);