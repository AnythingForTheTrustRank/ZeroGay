using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void JgPgJpZH5Grvnub7CXP(object object_0, ParticleSystemGradientMode particleSystemGradientMode_0);