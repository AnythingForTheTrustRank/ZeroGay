using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int utsUQaJtIh1yBmHeQTy(object object_0, int int_0, int int_1);