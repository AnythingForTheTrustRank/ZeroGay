using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate USpeaker VDE3AIAwsI6JmsZXuTy(object );