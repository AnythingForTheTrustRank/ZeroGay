using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.UI.Elements;

internal delegate MenuStateController iNAWUNXqtBFrBM7hw3y(object object_0);