using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate bool g29Dj8jAQb1Fl1whxKi(object );