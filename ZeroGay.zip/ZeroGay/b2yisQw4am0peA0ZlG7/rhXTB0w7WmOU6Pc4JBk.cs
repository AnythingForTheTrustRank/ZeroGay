using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;

namespace b2yisQw4am0peA0ZlG7
{
	internal class rhXTB0w7WmOU6Pc4JBk : MonoBehaviour
	{
		public static bool tS9w66wU7T;

		public static float rglwtf7Pb6;

		private static rhXTB0w7WmOU6Pc4JBk VLU0ovoKR0BqEQfhsma;

		public rhXTB0w7WmOU6Pc4JBk(IntPtr u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base(u0020);
		}

		internal static rhXTB0w7WmOU6Pc4JBk apgvOtoVMRoUYe4LFN5()
		{
			return rhXTB0w7WmOU6Pc4JBk.VLU0ovoKR0BqEQfhsma;
		}

		internal static void EUfwIKxx9B(Vector3 u0020)
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array[i].get_gameObject());
					array[i].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					array[i].get_transform().set_position(u0020);
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(vRCPickupArray[j].get_gameObject());
					vRCPickupArray[j].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					vRCPickupArray[j].get_transform().set_position(u0020);
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array1[k].get_gameObject());
					array1[k].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					array1[k].get_transform().set_position(u0020);
				}
			}
		}

		internal static bool l6Fv9LoAhBiJpEsiStU()
		{
			return rhXTB0w7WmOU6Pc4JBk.VLU0ovoKR0BqEQfhsma == null;
		}

		private void OnCollisionEnter(Collision collision)
		{
			if (!collision.get_transform().get_name().Contains("VRCPlayer"))
			{
				foreach (ContactPoint contact in collision.get_contacts())
				{
					if (!rhXTB0w7WmOU6Pc4JBk.tS9w66wU7T)
					{
						continue;
					}
					Vector3 vector3 = new Vector3(contact.get_point().x, contact.get_point().y, contact.get_point().z);
					rhXTB0w7WmOU6Pc4JBk.EUfwIKxx9B(vector3);
				}
			}
		}

		private void OnCollisionExit(Collision other)
		{
		}

		private void OnDestroy()
		{
			rhXTB0w7WmOU6Pc4JBk.tS9w66wU7T = false;
		}

		public void OnDisable()
		{
			rhXTB0w7WmOU6Pc4JBk.tS9w66wU7T = false;
		}

		public void OnEnable()
		{
			rhXTB0w7WmOU6Pc4JBk.tS9w66wU7T = false;
		}

		public void Start()
		{
		}

		public void Update()
		{
			if (base.get_gameObject().GetComponent<VRCSDK2.VRC_Pickup>().get_IsHeld())
			{
				rhXTB0w7WmOU6Pc4JBk.tS9w66wU7T = true;
			}
			if (rhXTB0w7WmOU6Pc4JBk.tS9w66wU7T)
			{
				base.get_gameObject().GetComponent<Rigidbody>().set_useGravity(true);
				base.get_gameObject().GetComponent<BoxCollider>().set_isTrigger(false);
			}
			rhXTB0w7WmOU6Pc4JBk.rglwtf7Pb6 = 0f;
		}
	}
}