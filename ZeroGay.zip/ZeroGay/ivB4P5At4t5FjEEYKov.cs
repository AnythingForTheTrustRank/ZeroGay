using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void ivB4P5At4t5FjEEYKov(float );