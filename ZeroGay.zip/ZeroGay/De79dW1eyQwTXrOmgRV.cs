using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate bool De79dW1eyQwTXrOmgRV(object , string , StringComparison );