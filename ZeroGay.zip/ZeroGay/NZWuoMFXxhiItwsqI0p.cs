using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate AsyncVoidMethodBuilder NZWuoMFXxhiItwsqI0p();