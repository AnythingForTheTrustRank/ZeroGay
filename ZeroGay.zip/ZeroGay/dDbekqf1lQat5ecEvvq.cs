using b3eD5DgJPcASx0xfHYB;
using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

internal delegate Task dDbekqf1lQat5ecEvvq(ref AsyncTaskMethodBuilder );