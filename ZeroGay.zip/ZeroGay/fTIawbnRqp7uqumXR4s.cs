using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate byte[] fTIawbnRqp7uqumXR4s(object , string );