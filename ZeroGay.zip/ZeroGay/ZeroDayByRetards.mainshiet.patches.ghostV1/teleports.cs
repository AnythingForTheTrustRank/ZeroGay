using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC.Udon;
using X7IetPATbOXxq4U7Vmy;

namespace ZeroDayByRetards.mainshiet.patches.ghostV1
{
	public class teleports
	{
		public static bool tpcal;

		public static bool tplmg;

		public static bool tpriotshield;

		public static bool tpcal2;

		public static bool tpriotshield2;

		public static bool wallbangBAD;

		public static bool TPLMG1;

		public static bool TPLMG2;

		public static string WORLDID;

		public static bool tpshot;

		public static bool tpshot2;

		public static bool tpvector;

		public static bool tpvector2;

		public static bool MP7tp;

		public static bool MP7tp2;

		internal static teleports lT4TnamDwSQ9i5Oibgn;

		static teleports()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			teleports.tpcal = false;
			teleports.tplmg = false;
			teleports.tpriotshield = false;
			teleports.tpcal2 = false;
			teleports.tpriotshield2 = false;
			teleports.wallbangBAD = false;
			teleports.TPLMG1 = false;
			teleports.TPLMG2 = false;
			teleports.WORLDID = "wrld_0ec97c4f-1e84-4a3a-9e3a-fa3075b6c56d";
			teleports.tpshot = false;
			teleports.tpshot2 = false;
			teleports.tpvector = false;
			teleports.tpvector2 = false;
			teleports.MP7tp = false;
			teleports.MP7tp2 = false;
		}

		public teleports()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static bool Inworld()
		{
			bool flag;
			flag = (!RoomManager.Method_Internal_Static_get_String_0().Contains(teleports.WORLDID) ? false : true);
			return flag;
		}

		internal static bool Knlblumg0gwjWUcBcYS()
		{
			return teleports.lT4TnamDwSQ9i5Oibgn == null;
		}

		internal static teleports qNiG2bm4N19q6MBoIhv()
		{
			return teleports.lT4TnamDwSQ9i5Oibgn;
		}

		public static IEnumerator tpcal50(bool state)
		{
			while (true)
			{
				if (teleports.tpcal)
				{
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(new Vector3(33.9723f, 4.8675f, 536.806f));
					GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107");
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Net_SpawnObject", null, false);
					GameObject gameObject1 = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
					gameObject1.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
					teleports.tpcal = false;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static IEnumerator tpMP7(bool state)
		{
			while (true)
			{
				if (teleports.MP7tp)
				{
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(new Vector3(33.9723f, 4.8675f, 536.806f));
					GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_MP7/RewardA_MP7/T2-MP7");
					GameObject gameObject1 = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "OpenLockBox", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Net_SpawnObject", null, false);
					teleports.MP7tp = false;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static IEnumerator tpRS(bool state)
		{
			while (true)
			{
				if (teleports.tpriotshield)
				{
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(new Vector3(33.9723f, 4.8675f, 536.806f));
					GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward_RiotShield/RewardC_RiotShield");
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Net_SpawnObject", null, false);
					GameObject gameObject1 = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
					gameObject1.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
					teleports.tpriotshield = false;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static IEnumerator tpshotty(bool state)
		{
			while (true)
			{
				if (teleports.tpshot)
				{
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(new Vector3(33.9723f, 4.8675f, 536.806f));
					GameObject gameObject = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem/Rewards/Reward _Shotgun/RewardB_Shotgun");
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Net_SpawnObject", null, false);
					GameObject gameObject1 = GameObject.Find("PoliceStation_A/RoomParts/1F/DocumentRoom/Cabinets/Closet_A-01/LootBoxSystem");
					gameObject1.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
					teleports.tpshot = false;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static IEnumerator tpvect(bool state)
		{
			return new teleports.<tpvect>d__18(0)
			{
				state = state
			};
		}

		public static IEnumerator wallbang(bool state)
		{
			while (true)
			{
				if (teleports.Inworld())
				{
					if (teleports.wallbangBAD)
					{
						GameObject.Find("PoliceStation/Base/Walls").set_active(false);
					}
					else
					{
						GameObject.Find("PoliceStation/Base/Walls").set_active(true);
					}
				}
				yield return new WaitForSeconds(1f);
			}
		}
	}
}