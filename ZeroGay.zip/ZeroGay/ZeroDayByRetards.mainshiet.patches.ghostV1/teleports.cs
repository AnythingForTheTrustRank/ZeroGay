using b3eD5DgJPcASx0xfHYB;
using gpd3oZtw5qhYneWRlWY;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.Udon;

namespace ZeroDayByRetards.mainshiet.patches.ghostV1
{
	public class teleports
	{
		public static bool tpcal;

		public static bool tplmg;

		public static bool tpriotshield;

		public static bool tpcal2;

		public static bool tpriotshield2;

		public static bool wallbangBAD;

		public static bool TPLMG1;

		public static bool TPLMG2;

		public static string WORLDID;

		public static bool tpshot;

		public static bool tpshot2;

		public static bool tpvector;

		public static bool tpvector2;

		public static bool MP7tp;

		public static bool MP7tp2;

		internal static teleports fJ6VT7dm8Nu7NFY7tTZ;

		static teleports()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			teleports.tpcal = false;
			teleports.tplmg = false;
			teleports.tpriotshield = false;
			teleports.tpcal2 = false;
			teleports.tpriotshield2 = false;
			teleports.wallbangBAD = false;
			teleports.TPLMG1 = false;
			teleports.TPLMG2 = false;
			teleports.WORLDID = "wrld_0ec97c4f-1e84-4a3a-9e3a-fa3075b6c56d";
			teleports.tpshot = false;
			teleports.tpshot2 = false;
			teleports.tpvector = false;
			teleports.tpvector2 = false;
			teleports.MP7tp = false;
			teleports.MP7tp2 = false;
		}

		public teleports()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static teleports h4AvN2dcAL2g3URYmrF()
		{
			return teleports.fJ6VT7dm8Nu7NFY7tTZ;
		}

		public static bool Inworld()
		{
			bool flag;
			flag = (!RoomManager.Method_Internal_Static_get_String_0().Contains(teleports.WORLDID) ? false : true);
			return flag;
		}

		internal static bool jSEFiVdDQb2YYgCgx6p()
		{
			return teleports.fJ6VT7dm8Nu7NFY7tTZ == null;
		}

		public static IEnumerator tpcal50(bool state)
		{
			return new teleports.<tpcal50>d__8(0)
			{
				state = state
			};
		}

		public static IEnumerator tpMP7(bool state)
		{
			while (true)
			{
				if (teleports.MP7tp)
				{
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(new Vector3(0.0614f, -0.005f, 503.5013f));
					GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem/Rewards/Reward_MP7/RewardA_MP7/T2-MP7");
					GameObject gameObject1 = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "OpenLockBox", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Net_SpawnObject", null, false);
					teleports.MP7tp = false;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static IEnumerator tpRS(bool state)
		{
			while (true)
			{
				if (teleports.tpriotshield)
				{
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(new Vector3(0.0614f, -0.005f, 503.5013f));
					GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem/Rewards/Reward_RiotShield/RewardC_RiotShield");
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Net_SpawnObject", null, false);
					GameObject gameObject1 = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
					gameObject1.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
					teleports.tpriotshield = false;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static IEnumerator tpshotty(bool state)
		{
			return new teleports.<tpshotty>d__15(0)
			{
				state = state
			};
		}

		public static IEnumerator tpvect(bool state)
		{
			while (true)
			{
				if (teleports.tpvector)
				{
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(new Vector3(0.0614f, -0.005f, 503.5013f));
					GameObject gameObject = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector");
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Net_SpawnObject", null, false);
					GameObject gameObject1 = GameObject.Find("House/Functions/LockBox/LootBoxCloset (9)/LootBoxSystem");
					gameObject1.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OpenLockBox");
					teleports.tpvector = false;
					gameObject = null;
					gameObject1 = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		public static IEnumerator wallbang(bool state)
		{
			while (true)
			{
				if (teleports.Inworld())
				{
					if (teleports.wallbangBAD)
					{
						GameObject.Find("PoliceStation/Base/Walls").set_active(false);
					}
					else
					{
						GameObject.Find("PoliceStation/Base/Walls").set_active(true);
					}
				}
				yield return new WaitForSeconds(1f);
			}
		}
	}
}