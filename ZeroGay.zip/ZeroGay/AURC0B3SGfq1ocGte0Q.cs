using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool AURC0B3SGfq1ocGte0Q(object object_0, Type type_0);