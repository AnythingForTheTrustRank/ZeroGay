using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate GameObject seJ6DhptDh2KKHY8Nyv(PrimitiveType );