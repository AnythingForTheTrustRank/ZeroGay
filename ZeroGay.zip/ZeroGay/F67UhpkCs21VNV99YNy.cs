using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection.Emit;

internal delegate void F67UhpkCs21VNV99YNy(object object_0, OpCode opCode_0, Type type_0);