using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate RuntimeFieldHandle pjoZVSkLjmsKi9Ai22X(object object_0);