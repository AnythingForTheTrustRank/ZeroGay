using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.UI;

internal delegate float kT5wocFq2ffRd5JNTe5(ref ColorBlock colorBlock_0);