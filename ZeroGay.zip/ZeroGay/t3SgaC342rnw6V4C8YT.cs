using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate FieldInfo t3SgaC342rnw6V4C8YT(object object_0, int int_0);