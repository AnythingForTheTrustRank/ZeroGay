using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using UnityEngine.Networking;

internal delegate Texture2D enEbNiZ8JNddyvixd5Q(UnityWebRequest unityWebRequest_0);