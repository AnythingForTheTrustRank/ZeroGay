using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate string NKPZYni69bELqSNfTr1(GameObject );