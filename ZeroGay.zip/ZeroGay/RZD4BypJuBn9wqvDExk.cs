using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCWebSocketsManager RZD4BypJuBn9wqvDExk();