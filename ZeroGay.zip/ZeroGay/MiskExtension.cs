using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using UnhollowerRuntimeLib.XrefScans;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.XR;
using VRC.Core;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;

public static class MiskExtension
{
	internal static MiskExtension KN41CXfI3VCsI4wKrEt;

	internal static string a6GcrSGMAm(this object object_0)
	{
		return object_0.get_field_Public_String_1();
	}

	internal static bool ANrUIUfoicmYVnYXMC2()
	{
		return MiskExtension.KN41CXfI3VCsI4wKrEt == null;
	}

	public static T Cast<T>(this object o)
	{
		return (T)o;
	}

	public static bool checkXref(this MethodBase m, string match)
	{
		bool flag;
		try
		{
			flag = XrefScanner.XrefScan(m).Any<XrefInstance>((XrefInstance instance) => (instance.Type != null || instance.ReadAsObject() == null ? false : instance.ReadAsObject().ToString().Equals(match, StringComparison.OrdinalIgnoreCase)));
			return flag;
		}
		catch
		{
		}
		flag = false;
		return flag;
	}

	public static void EnterPortal(this PortalInternal Instance, string WorldID, string InstanceID)
	{
		Instance.Method_Private_Void_String_String_PDM_0(WorldID, InstanceID);
	}

	internal static bool F76cawAg07()
	{
		return Assembly.GetExecutingAssembly().GetType("Notorious") != null;
	}

	public static GameObject GetUniqueGameObject(string name)
	{
		GameObject gameObject;
		Scene activeScene = SceneManager.GetActiveScene();
		GameObject[] array = activeScene.GetRootGameObjects().ToArray<GameObject>();
		int num = 0;
		while (true)
		{
			if (num >= (int)array.Length)
			{
				gameObject = null;
				break;
			}
			else if (Networking.GetUniqueName(array[num]) == name)
			{
				gameObject = array[num];
				break;
			}
			else
			{
				num++;
			}
		}
		return gameObject;
	}

	internal static bool hFRc2DHSbe(this object object_0)
	{
		return object_0.get_field_Private_Boolean_0();
	}

	[Obsolete("This Doenst always works -Day <3")]
	public static bool IsCurrentWorldUdon()
	{
		return RoomManager.get_field_Internal_Static_ApiWorld_0().get_tags().Contains("Udon");
	}

	public static bool IsHeld(this GameObject go)
	{
		bool flag;
		if (go == null)
		{
			flag = false;
		}
		else
		{
			VRC_Pickup componentInParent = go.GetComponentInParent<VRC_Pickup>();
			flag = (componentInParent == null ? false : componentInParent.get_IsHeld());
		}
		return flag;
	}

	public static bool IsInVR()
	{
		return XRDevice.get_isPresent();
	}

	public static bool IsMine(this GameObject go)
	{
		return Networking.IsOwner(go);
	}

	public static bool IsPickup(this GameObject go)
	{
		return (go != null ? go.GetComponentInParent<VRC_Pickup>() != null : false);
	}

	public static bool IsPlayer(this GameObject go)
	{
		return (go != null ? go.GetComponentInParent<VRCPlayer>() != null : false);
	}

	public static bool IsReady(this GameObject go)
	{
		return Networking.IsObjectReady(go);
	}

	public static bool IsVisible(this GameObject go)
	{
		return go.GetComponentsInChildren<Renderer>().Any<Renderer>((Renderer r) => (!(r != null) || !r.get_enabled() ? false : r.get_isVisible()));
	}

	public static bool IsVisibleLocally(this GameObject go)
	{
		return (Utils.VRCVrCamera == null ? false : go.IsVisibleTo(Utils.VRCVrCamera.get_field_Public_Camera_0()));
	}

	public static bool IsVisibleTo(this GameObject go, Camera camera)
	{
		bool flag;
		if (camera != null)
		{
			foreach (Renderer renderer in 
				from r in go.GetComponentsInChildren<Renderer>()
				where (r == null ? false : r.get_enabled())
				select r)
			{
				if (!GeometryUtility.TestPlanesAABB(GeometryUtility.CalculateFrustumPlanes(camera), renderer.get_bounds()))
				{
					continue;
				}
				flag = true;
				return flag;
			}
			flag = false;
		}
		else
		{
			flag = false;
		}
		return flag;
	}

	internal static string pjFcBsnrYX(this object object_0)
	{
		return object_0.get_field_Public_String_0();
	}

	internal static Sprite qNVcyVKuZk(this object object_0)
	{
		Sprite sprite;
		if (string.IsNullOrEmpty(object_0))
		{
			sprite = null;
		}
		else
		{
			byte[] numArray = File.ReadAllBytes(object_0);
			if ((numArray == null ? true : numArray.Length == 0))
			{
				sprite = null;
			}
			else
			{
				Texture2D texture2D = new Texture2D(2, 2);
				if (!Il2CppImageConversionManager.LoadImage(texture2D, numArray))
				{
					sprite = null;
				}
				else
				{
					Rect rect = new Rect(0f, 0f, (float)texture2D.get_width(), (float)texture2D.get_height());
					Vector2 vector2 = new Vector2(0.5f, 0.5f);
					Vector4 vector4 = new Vector4();
					Sprite sprite1 = Sprite.CreateSprite(texture2D, rect, vector2, 100f, 0, 0, vector4, false);
					Sprite sprite2 = sprite1;
					sprite2.set_hideFlags(sprite2.get_hideFlags() | 32);
					sprite = sprite1;
				}
			}
		}
		return sprite;
	}

	public static void SetToolTipBasedOnToggle(this UiTooltip tooltip)
	{
		UiToggleButton componentInChildren = tooltip.get_gameObject().GetComponentInChildren<UiToggleButton>();
		if ((componentInChildren == null ? false : !string.IsNullOrEmpty(tooltip.a6GcrSGMAm())))
		{
			string str = (componentInChildren.get_field_Public_Boolean_0() ? tooltip.pjFcBsnrYX() : tooltip.a6GcrSGMAm());
			if (TooltipManager.get_field_Private_Static_Text_0() != null)
			{
				TooltipManager.Method_Public_Static_Void_String_0(str);
			}
			if (tooltip.W2JcYN7dDU() != null)
			{
				tooltip.W2JcYN7dDU().set_text(str);
			}
		}
	}

	public static System.Collections.Generic.List<System.Collections.Generic.List<T>> SplitIntoChunks<T>(System.Collections.Generic.List<T> list, int chunkSize)
	{
		if (chunkSize <= 0)
		{
			throw new ArgumentException("chunkSize must be greater than 0.");
		}
		System.Collections.Generic.List<System.Collections.Generic.List<T>> lists = new System.Collections.Generic.List<System.Collections.Generic.List<T>>();
		for (int i = 0; i < list.Count; i += chunkSize)
		{
			lists.Add(list.GetRange(i, (list.Count - i > chunkSize ? chunkSize : list.Count - i)));
		}
		return lists;
	}

	public static System.Collections.Generic.List<System.Collections.Generic.List<T>> SplitList<T>(this System.Collections.Generic.List<T> Instance, int Count)
	{
		System.Collections.Generic.List<System.Collections.Generic.List<T>> lists = new System.Collections.Generic.List<System.Collections.Generic.List<T>>();
		int count = Instance.Count / Count;
		for (int i = 0; i < count; i++)
		{
			lists[Count * i].AddRange(Instance.GetRange(i * Count, Count));
		}
		Console.WriteLine(string.Format("List Count: {0} | Count: {1} | Splits: {2}", Instance.Count, Count, Count));
		return lists;
	}

	public static void Start(this IEnumerator e)
	{
		MelonCoroutines.Start(e);
	}

	internal static bool UoFcMqnyyJ(this object object_0, string string_0 = null, string string_1 = null)
	{
		bool flag;
		string name;
		bool flag1 = false;
		foreach (XrefInstance xrefInstance in XrefScanner.XrefScan(object_0))
		{
			if (xrefInstance.Type != 1)
			{
				continue;
			}
			MethodBase methodBase = xrefInstance.TryResolve();
			if (methodBase == null)
			{
				continue;
			}
			if (!string.IsNullOrEmpty(string_0))
			{
				flag1 = (string.IsNullOrEmpty(methodBase.Name) ? false : methodBase.Name.IndexOf(string_0, StringComparison.OrdinalIgnoreCase) >= 0);
			}
			if (!string.IsNullOrEmpty(string_1))
			{
				System.Type reflectedType = methodBase.ReflectedType;
				if (reflectedType != null)
				{
					name = reflectedType.Name;
				}
				else
				{
					name = null;
				}
				flag1 = (!string.IsNullOrEmpty(name) ? methodBase.ReflectedType.Name.IndexOf(string_1, StringComparison.OrdinalIgnoreCase) >= 0 : false);
			}
			if (!flag1)
			{
				continue;
			}
			flag = true;
			return flag;
		}
		flag = false;
		return flag;
	}

	internal static Text W2JcYN7dDU(this object object_0)
	{
		return object_0.get_field_Public_Text_0();
	}

	public static bool XRefScanForGlobal(this MethodBase methodBase, string searchTerm, bool ignoreCase = true)
	{
		bool flag;
		if (string.IsNullOrEmpty(searchTerm))
		{
			MelonLogger.Error(string.Format("XRefScanForGlobal \"{0}\" has an empty searchTerm. Returning false", methodBase));
			flag = false;
		}
		else
		{
			flag = XrefScanner.XrefScan(methodBase).Any<XrefInstance>((XrefInstance xref) => {
				int num;
				int num1;
				if (xref.Type == 0)
				{
					Il2CppSystem.Object obj = xref.ReadAsObject();
					if (obj != null)
					{
						if (obj.ToString().IndexOf(searchTerm, (!ignoreCase ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase)) < 0)
						{
							goto Label1;
						}
						num1 = 1;
						goto Label0;
					}
				Label1:
					num1 = 0;
				Label0:
					num = num1;
				}
				else
				{
					num = 0;
				}
				return (byte)num != 0;
			});
		}
		return flag;
	}

	public static int XRefScanMethodCount(this MethodBase methodBase, string methodName = null, string parentType = null, bool ignoreCase = true)
	{
		int num;
		if ((!string.IsNullOrEmpty(methodName) ? true : !string.IsNullOrEmpty(parentType)))
		{
			num = XrefScanner.XrefScan(methodBase).Count<XrefInstance>((XrefInstance xref) => {
				bool flag;
				string name;
				if (xref.Type != 1)
				{
					flag = false;
				}
				else
				{
					bool flag1 = false;
					MethodBase methodBase1 = xref.TryResolve();
					if (methodBase1 == null)
					{
						flag = false;
					}
					else
					{
						if (!string.IsNullOrEmpty(methodName))
						{
							flag1 = (string.IsNullOrEmpty(methodBase1.Name) ? false : methodBase1.Name.IndexOf(methodName, (!ignoreCase ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase)) >= 0);
						}
						if (!string.IsNullOrEmpty(parentType))
						{
							System.Type reflectedType = methodBase1.ReflectedType;
							if (reflectedType != null)
							{
								name = reflectedType.Name;
							}
							else
							{
								name = null;
							}
							flag1 = (!string.IsNullOrEmpty(name) ? methodBase1.ReflectedType.Name.IndexOf(parentType, (ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)) >= 0 : false);
						}
						flag = flag1;
					}
				}
				return flag;
			});
		}
		else
		{
			MelonLogger.Error(string.Format("XRefScanMethodCount \"{0}\" has all null/empty parameters. Returning -1", methodBase));
			num = -1;
		}
		return num;
	}

	internal static MiskExtension YoapKff6hhtkq1yx1e1()
	{
		return MiskExtension.KN41CXfI3VCsI4wKrEt;
	}
}