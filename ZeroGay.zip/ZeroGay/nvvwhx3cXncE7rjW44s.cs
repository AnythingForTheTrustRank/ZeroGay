using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object nvvwhx3cXncE7rjW44s(Type type_0, int int_0);