using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;

namespace kU2HUHwUTYxPATQ17MW
{
	internal class fxTgUnwhYhYpJGMgKT3 : MonoBehaviour
	{
		public static bool bt8wvm2hev;

		public static float LKIwaZT8QN;

		internal static fxTgUnwhYhYpJGMgKT3 V4vrTJodHsyQRFd4Y8F;

		public fxTgUnwhYhYpJGMgKT3(IntPtr u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base(u0020);
		}

		internal static void I31wTYa4QQ(Vector3 u0020)
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array[i].get_gameObject());
					array[i].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					array[i].get_transform().set_position(u0020);
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(vRCPickupArray[j].get_gameObject());
					vRCPickupArray[j].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					vRCPickupArray[j].get_transform().set_position(u0020);
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array1[k].get_gameObject());
					array1[k].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					array1[k].get_transform().set_position(u0020);
				}
			}
		}

		private void OnCollisionEnter(Collision collision)
		{
			if (!collision.get_transform().get_name().Contains("VRCPlayer"))
			{
				foreach (ContactPoint contact in collision.get_contacts())
				{
					if (!fxTgUnwhYhYpJGMgKT3.bt8wvm2hev)
					{
						continue;
					}
					Vector3 vector3 = new Vector3(contact.get_point().x, contact.get_point().y, contact.get_point().z);
					fxTgUnwhYhYpJGMgKT3.I31wTYa4QQ(vector3);
					UnityEngine.Object.Destroy(base.get_gameObject());
				}
			}
		}

		private void OnCollisionExit(Collision other)
		{
		}

		private void OnDestroy()
		{
			fxTgUnwhYhYpJGMgKT3.bt8wvm2hev = false;
		}

		public void OnDisable()
		{
			fxTgUnwhYhYpJGMgKT3.bt8wvm2hev = false;
		}

		public void OnEnable()
		{
			fxTgUnwhYhYpJGMgKT3.bt8wvm2hev = false;
		}

		internal static fxTgUnwhYhYpJGMgKT3 qMZQ7KomFoWNZvyB4nR()
		{
			return fxTgUnwhYhYpJGMgKT3.V4vrTJodHsyQRFd4Y8F;
		}

		public void Start()
		{
		}

		public void Update()
		{
			if (base.get_gameObject().GetComponent<VRCSDK2.VRC_Pickup>().get_IsHeld())
			{
				fxTgUnwhYhYpJGMgKT3.bt8wvm2hev = true;
			}
			if (fxTgUnwhYhYpJGMgKT3.bt8wvm2hev)
			{
				base.get_gameObject().GetComponent<Rigidbody>().set_useGravity(true);
				base.get_gameObject().GetComponent<BoxCollider>().set_isTrigger(false);
			}
			fxTgUnwhYhYpJGMgKT3.LKIwaZT8QN = 0f;
		}

		internal static bool wwOtEjoo6rQYrM1RLnI()
		{
			return fxTgUnwhYhYpJGMgKT3.V4vrTJodHsyQRFd4Y8F == null;
		}
	}
}