using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int KOqShAWxmHHAvii8CvW(float float_0);