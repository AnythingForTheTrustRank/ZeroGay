using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;

internal delegate MethodInfo uqhm5DpJ9K7KRRUyOB5(object , string );