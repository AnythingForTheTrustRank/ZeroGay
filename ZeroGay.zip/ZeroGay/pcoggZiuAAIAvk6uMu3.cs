using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate bool pcoggZiuAAIAvk6uMu3();