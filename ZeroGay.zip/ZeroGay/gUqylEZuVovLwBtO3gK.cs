using b3eD5DgJPcASx0xfHYB;
using System;
using VRC;

internal delegate PlayerManager gUqylEZuVovLwBtO3gK();