using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCUiManager dfQlR2JjYfcLyAE6g7H();