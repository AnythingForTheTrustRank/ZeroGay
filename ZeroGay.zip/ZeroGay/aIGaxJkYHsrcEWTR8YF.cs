using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate IntPtr aIGaxJkYHsrcEWTR8YF(int int_0);