using b3eD5DgJPcASx0xfHYB;
using Photon.Realtime;
using System;

internal delegate LoadBalancingPeer TQvnwV1zV7Er5ndi49v(object );