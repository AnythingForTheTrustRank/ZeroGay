using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using UnityEngine;
using VRC.Udon;
using X7IetPATbOXxq4U7Vmy;

namespace Alqs2GMPu53mmvBlefn
{
	internal class ws9MqgMUXbRcPl5QsbL
	{
		private static ws9MqgMUXbRcPl5QsbL uhpxBHmPyymKrqlAGGt;

		public ws9MqgMUXbRcPl5QsbL()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool iMWLVmmuC0wRHN0jgVs()
		{
			return ws9MqgMUXbRcPl5QsbL.uhpxBHmPyymKrqlAGGt == null;
		}

		public static void UgFMuDSnlj()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Udon"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "_TeleportToBedroomOutside1");
			}
		}

		internal static ws9MqgMUXbRcPl5QsbL vupfbqmFKZo95IpY5Pc()
		{
			return ws9MqgMUXbRcPl5QsbL.uhpxBHmPyymKrqlAGGt;
		}
	}
}