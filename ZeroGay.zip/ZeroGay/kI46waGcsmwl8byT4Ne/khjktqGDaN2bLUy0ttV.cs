using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace kI46waGcsmwl8byT4Ne
{
	internal class khjktqGDaN2bLUy0ttV
	{
		private static khjktqGDaN2bLUy0ttV B6xAXC5gXd5bT85ZYj8;

		public khjktqGDaN2bLUy0ttV(string u0020, MethodBase u0020, HarmonyMethod u0020, HarmonyMethod u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.wdDGz4pi2Z(u0020);
			this.XYV38A8fDY(u0020);
			this.LYv33JZXcY(u0020);
			this.TOV3Mkt5TK(u0020);
		}

		internal static bool bgFLWg5Wax0eYmWFBVk()
		{
			return khjktqGDaN2bLUy0ttV.B6xAXC5gXd5bT85ZYj8 == null;
		}

		public void lXAGyRUegD()
		{
			string name;
			string str;
			try
			{
				Harmony harmony = new Harmony(this.dMdGEWgbSf());
				harmony.Patch(this.WEA3kHB6fm(), this.PEi3GUFc1p(), this.poC3sk4sap(), null, null, null);
				string[] fullName = new string[] { "[Patches] Patching ", this.WEA3kHB6fm().DeclaringType.FullName, ".", this.WEA3kHB6fm().Name, " | with ", null, null };
				HarmonyMethod harmonyMethod = this.PEi3GUFc1p();
				string[] strArrays = fullName;
				if (harmonyMethod == null)
				{
					name = null;
				}
				else
				{
					name = harmonyMethod.method.Name;
				}
				strArrays[5] = name;
				HarmonyMethod harmonyMethod1 = this.poC3sk4sap();
				string[] strArrays1 = fullName;
				if (harmonyMethod1 == null)
				{
					str = null;
				}
				else
				{
					str = harmonyMethod1.method.Name;
				}
				strArrays1[6] = str;
				MelonLogger.Log(string.Concat(fullName), new object[] { false, ConsoleColor.White });
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				MelonLogger.Error(string.Concat(new string[] { "Error in AttemptPatch! - ", exception.Message, " From:AttemptPatch ", exception.Source, " - Stack:AttemptPatch ", exception.StackTrace }));
			}
		}

		internal static khjktqGDaN2bLUy0ttV Vgehgk5uj7La2hGEnnR()
		{
			return khjktqGDaN2bLUy0ttV.B6xAXC5gXd5bT85ZYj8;
		}
	}
}