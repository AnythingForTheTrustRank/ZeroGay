using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using Il2CppSystem.IO;
using System;

internal delegate Il2CppSystem.Object Q9fTNORyZ3vWkMmdcMr(object , Stream );