using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate Il2CppStructArray<ContactPoint> kHNMuLF6VTakfbbad6e(object object_0);