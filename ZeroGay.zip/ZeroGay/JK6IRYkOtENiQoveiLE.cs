using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate RuntimeMethodHandle JK6IRYkOtENiQoveiLE(object object_0);