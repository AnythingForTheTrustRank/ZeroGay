using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using m4amehrzBZcmRlV97Pi;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC;
using VRC.DataModel;
using VRC.UI.Elements.Menus;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class murdinteract
	{
		internal static murdinteract fbSXktgRSmwunVRfKqs;

		public murdinteract()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool BdG8YQgtTmQxyroTiYS()
		{
			return murdinteract.fbSXktgRSmwunVRfKqs == null;
		}

		internal static murdinteract lIXH3rgK4j41ZA9RfEu()
		{
			return murdinteract.fbSXktgRSmwunVRfKqs;
		}

		public static void StartMurdInteract()
		{
			QMNestedButton qMNestedButton = MainMenuLol.murderinteract;
			QMNestedButton qMNestedButton1 = qMNestedButton;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton1, 1f, 0f, "Assign Bystander", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Bystander]", ConsoleColor.Magenta));
				string str = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(componentsInChild.get_gameObject(), "SyncAssignB", j25MPyacibgF0kcPwHe.rjYaCVqqPo, false);
				}
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton2 = qMNestedButton;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton2, 1f, 1f, "Assign Murderer", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Murderer]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(componentsInChild.get_gameObject(), "SyncAssignM", j25MPyacibgF0kcPwHe.rjYaCVqqPo, false);
				}
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton3 = qMNestedButton;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton3, 1f, 2f, "Kill Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill Player]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				foreach (Transform transform in new List<Transform>()
				{
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (0)"),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (1)"),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (2)"),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (3)"),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (4)"),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (5)")
				})
				{
					Transform transform1 = transform;
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
					transform1.get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position());
				}
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton4 = qMNestedButton;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton4, 1f, 3f, "Revive Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Revive Player]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(componentsInChild.get_gameObject(), "SyncAssignB", j25MPyacibgF0kcPwHe.rjYaCVqqPo, false);
				}
			}, "", nullable4, nullable, false);
			QMNestedButton qMNestedButton5 = qMNestedButton;
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(qMNestedButton5, 2f, 0f, "Give Revolver", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Give Rev]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				A6yTqvrNqfGTNPs86pr.tk12MOoQc1();
			}, "", nullable5, nullable, false);
			QMNestedButton qMNestedButton6 = qMNestedButton;
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(qMNestedButton6, 2f, 1f, "Give Luger", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Give Luger]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				A6yTqvrNqfGTNPs86pr.Muh2yovhg5();
			}, "", nullable6, nullable, false);
			QMNestedButton qMNestedButton7 = qMNestedButton;
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(qMNestedButton7, 2f, 2f, "Give Shotgun", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Give Shotgun]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				A6yTqvrNqfGTNPs86pr.c9I27QcJbN();
			}, "", nullable7, nullable, false);
			QMNestedButton qMNestedButton8 = qMNestedButton;
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(qMNestedButton8, 2f, 3f, "Give Frag", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Give Frag]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				A6yTqvrNqfGTNPs86pr.qMC2TwOdJf();
			}, "", nullable8, nullable, false);
			QMNestedButton qMNestedButton9 = qMNestedButton;
			nullable = null;
			Color? nullable9 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton8 = new QMSingleButton(qMNestedButton9, 3f, 0f, "Give Smoke", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Give Smoke]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				A6yTqvrNqfGTNPs86pr.qPy2Ht8rjy();
			}, "", nullable9, nullable, false);
			QMNestedButton qMNestedButton10 = qMNestedButton;
			nullable = null;
			Color? nullable10 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton9 = new QMSingleButton(qMNestedButton10, 3f, 1f, "Give Knife", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Give Knife]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				A6yTqvrNqfGTNPs86pr.I2R2aRINo6();
			}, "", nullable10, nullable, false);
			QMNestedButton qMNestedButton11 = qMNestedButton;
			nullable = null;
			Color? nullable11 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton10 = new QMSingleButton(qMNestedButton11, 3f, 2f, "Give Trap", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Give Trap]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				A6yTqvrNqfGTNPs86pr.TlU2sq1snA();
			}, "", nullable11, nullable, false);
		}
	}
}