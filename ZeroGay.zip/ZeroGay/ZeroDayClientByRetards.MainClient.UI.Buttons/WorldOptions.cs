using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.Core;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class WorldOptions
	{
		internal static WorldOptions weLTC0mAQk3tiqMyRcy;

		public WorldOptions()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static WorldOptions Cu8A5FmLHj61pPHeih6()
		{
			return WorldOptions.weLTC0mAQk3tiqMyRcy;
		}

		internal static bool R5J5ILmVKExXDkVvBCP()
		{
			return WorldOptions.weLTC0mAQk3tiqMyRcy == null;
		}

		public static void StartWorldOptions()
		{
			QMNestedButton qMNestedButton = MainMenuLol.worldsmenu;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "Rejoin Current World", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Rejoin]", ConsoleColor.Magenta));
				VRCFlowManager.Method_Public_Static_VRCFlowManager_PDM_0().Method_Public_Void_String_WorldTransitionInfo_Action_1_String_Boolean_0(string.Concat(RoomManager.get_field_Internal_Static_ApiWorld_0().get_id(), ":", RoomManager.get_field_Internal_Static_ApiWorldInstance_0().get_instanceId()), null, null, true);
			}, "", nullable1, nullable, false);
		}
	}
}