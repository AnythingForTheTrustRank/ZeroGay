using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.Core;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class WorldOptions
	{
		private static WorldOptions RYct8PgwcQKBFNGGFXj;

		public WorldOptions()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool GkPAjAgpYLL2TKqdKgZ()
		{
			return WorldOptions.RYct8PgwcQKBFNGGFXj == null;
		}

		public static void StartWorldOptions()
		{
			QMNestedButton qMNestedButton = MainMenuLol.worldsmenu;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "Rejoin Current World", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Rejoin]", ConsoleColor.Magenta));
				VRCFlowManager.Method_Public_Static_VRCFlowManager_PDM_0().Method_Public_Void_String_WorldTransitionInfo_Action_1_String_Boolean_0(string.Concat(RoomManager.get_field_Internal_Static_ApiWorld_0().get_id(), ":", RoomManager.get_field_Internal_Static_ApiWorldInstance_0().get_instanceId()), null, null, true);
			}, "", nullable1, nullable, false);
		}

		internal static WorldOptions t9fXqAgWOhtk1rOAnmV()
		{
			return WorldOptions.RYct8PgwcQKBFNGGFXj;
		}
	}
}