using a1f9Fk6X8PqG43BDAy2;
using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using gpd3oZtw5qhYneWRlWY;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using smF1Y5I6LTUafkXI2oF;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.Udon;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class murder
	{
		private static GameObject UXcwuM6MEF;

		public static QMNestedButton page2;

		public static bool KillAuraRight;

		public static bool KillAuraLeft;

		public static object BoopDeathCor;

		private static murder tPatXZmO6EnuesESPDc;

		public murder()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static IEnumerator InfiniteRevolvere()
		{
			return new murder.<InfiniteRevolvere>d__2(0);
		}

		internal static murder RjQtGTmP8tE8nTLrggT()
		{
			return murder.tPatXZmO6EnuesESPDc;
		}

		public static IEnumerator ShowMurdererOnNamePlate()
		{
			int num1 = 0;
			int num = 0;
			Transform[] transformArray = Resources.FindObjectsOfTypeAll<Transform>();
			GameObject _gameObject = null;
			for (int i1 = 0; i1 < (int)transformArray.Length; i1 = num1)
			{
				if (transformArray[i1].get_gameObject().get_name().Equals("Murderer Name"))
				{
					_gameObject = transformArray[i1].get_gameObject();
				}
				num1 = i1 + 1;
			}
			UnityEngine.Object.Destroy(murder.UXcwuM6MEF);
			while (true)
			{
				Player[] playerArray = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
				for (int j = 0; j < (int)playerArray.Length; j = num)
				{
					while (playerArray[j].Method_Internal_get_APIUser_0() == null)
					{
						yield return null;
					}
					if (playerArray[j].Method_Internal_get_APIUser_0().get_displayName().Equals(_gameObject.GetComponent<Text>().get_text()))
					{
						UnityEngine.Object.Destroy(murder.UXcwuM6MEF);
						murder.UXcwuM6MEF = UnityEngine.Object.Instantiate<Transform>(playerArray[j].get_gameObject().get_transform().Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container/Name")).get_gameObject();
						murder.UXcwuM6MEF.GetComponent<TextMeshProUGUI>().set_text("Murderer");
						murder.UXcwuM6MEF.get_transform().set_parent(playerArray[j].get_gameObject().get_transform().Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").get_gameObject().get_transform());
						murder.UXcwuM6MEF.get_transform().set_localPosition(playerArray[j].get_gameObject().get_transform().Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").get_gameObject().get_transform().get_localPosition());
						murder.UXcwuM6MEF.get_transform().set_localRotation(playerArray[j].get_gameObject().get_transform().Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").get_gameObject().get_transform().get_localRotation());
						murder.UXcwuM6MEF.get_transform().set_localScale(playerArray[j].get_gameObject().get_transform().Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Text Container").get_gameObject().get_transform().get_localScale());
						murder.UXcwuM6MEF.GetComponent<TextMeshProUGUI>().set_color(Color.get_red());
						while (playerArray[j].Method_Internal_get_APIUser_0().get_displayName().Equals(_gameObject.GetComponent<Text>().get_text()))
						{
							yield return null;
						}
						yield return null;
					}
					num = j + 1;
				}
				yield return new WaitForSeconds(2f);
				playerArray = null;
			}
		}

		public static void StartMurder()
		{
			QMNestedButton qMNestedButton = MainMenuLol.murder;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "TP REVOLVER", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [TP REV]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				K1DG5hII2XIwO8UAXTv.DtGIhfQ8Fv();
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton1 = MainMenuLol.murder;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton1, 1f, 1f, "TP LUGER", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [TP LUGER]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				K1DG5hII2XIwO8UAXTv.gZwITMxtxV();
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton2 = MainMenuLol.murder;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton2, 1f, 2f, "TP SHOTUN", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [TP SHOTGUN]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				K1DG5hII2XIwO8UAXTv.EgsIaAtBhK();
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton3 = MainMenuLol.murder;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton3, 1f, 3f, "TP FRAG", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [TP FRAG]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				K1DG5hII2XIwO8UAXTv.WhqIvSKdep();
			}, "", nullable4, nullable, false);
			QMNestedButton qMNestedButton4 = MainMenuLol.murder;
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(qMNestedButton4, 2f, 0f, "TP SMOKE", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [TP SMOKE]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				K1DG5hII2XIwO8UAXTv.SGNIBuT31y();
			}, "", nullable5, nullable, false);
			QMNestedButton qMNestedButton5 = MainMenuLol.murder;
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(qMNestedButton5, 2f, 1f, "TP KNIFE", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [TP KNIFE]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				K1DG5hII2XIwO8UAXTv.J1SIUnUWwj();
			}, "", nullable6, nullable, false);
			QMNestedButton qMNestedButton6 = MainMenuLol.murder;
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(qMNestedButton6, 2f, 2f, "TP TRAP", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [TP TRAP]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic"), "OnPlayerUnlockedClues", null, false);
				K1DG5hII2XIwO8UAXTv.gToIPYLI5I();
			}, "", nullable7, nullable, false);
			QMNestedButton qMNestedButton7 = MainMenuLol.murder;
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(qMNestedButton7, 2f, 3f, "Show Murd \n On Plates", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Show Murd]", ConsoleColor.Magenta));
				MelonCoroutines.Start(murder.ShowMurdererOnNamePlate());
			}, "", nullable8, nullable, false);
			QMNestedButton qMNestedButton8 = MainMenuLol.murder;
			nullable = null;
			Color? nullable9 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton8 = new QMSingleButton(qMNestedButton8, 3f, 0f, "FFA (BREAKS GAME)", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [FFA]", ConsoleColor.Magenta));
				List<GameObject> gameObjects = new List<GameObject>()
				{
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (0)").get_gameObject(),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (1)").get_gameObject(),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (2)").get_gameObject(),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (3)").get_gameObject(),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (4)").get_gameObject(),
					GameObject.Find("Game Logic").get_transform().Find("Weapons/Knife (5)").get_gameObject()
				};
				(new GameObject()).get_transform().set_position(new Vector3(0.455f, 0.504f, 115f));
				MelonCoroutines.Start(QdA6prtQJZNe9CGe8IK.idqtCg9iJH());
			}, "", nullable9, nullable, false);
			QMNestedButton qMNestedButton9 = MainMenuLol.murder;
			nullable = null;
			Color? nullable10 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton9 = new QMSingleButton(qMNestedButton9, 3f, 1f, "Become Bystander ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Become Bystander]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(APIUser.get_CurrentUser().get_id());
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncAssignB", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, " ", nullable10, nullable, false);
			QMNestedButton qMNestedButton10 = MainMenuLol.murder;
			nullable = null;
			Color? nullable11 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton10 = new QMSingleButton(qMNestedButton10, 3f, 2f, "Become Murderer", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Become Murderer]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(APIUser.get_CurrentUser().get_id());
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncAssignM", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, " ", nullable11, nullable, false);
			QMNestedButton qMNestedButton11 = MainMenuLol.murder;
			nullable = null;
			Color? nullable12 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton11 = new QMSingleButton(qMNestedButton11, 3f, 3f, "OP GUNS", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [OP GUNS]", ConsoleColor.Magenta));
				GameObject.Find("Game Logic/Weapons/Revolver/Recoil Anim/Recoil/Laser Sight").set_active(true);
				GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(GameObject.Find("Game Logic/Weapons/Revolver/Recoil Anim/Recoil/Laser Sight"));
				GameObject gameObject1 = UnityEngine.Object.Instantiate<GameObject>(GameObject.Find("Game Logic/Weapons/Revolver/Recoil Anim/Recoil/Laser Sight"));
				gameObject.get_transform().set_parent(GameObject.Find("Game Logic/Weapons/Unlockables/Luger (0)/Recoil Anim/Recoil").get_transform());
				gameObject1.get_transform().set_parent(GameObject.Find("Game Logic/Weapons/Unlockables/Shotgun (0)/Recoil Anim/Recoil").get_transform());
			}, "", nullable12, nullable, false);
			QMNestedButton qMNestedButton12 = MainMenuLol.murder;
			nullable = null;
			Color? nullable13 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton12 = new QMSingleButton(qMNestedButton12, 4f, 0f, "Turn Lights ON", () => {
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (0)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchUp", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (1)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchUp", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (2)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchUp", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (3)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchUp", null, false);
			}, "ToolTip Text", nullable13, nullable, false);
			QMNestedButton qMNestedButton13 = MainMenuLol.murder;
			nullable = null;
			Color? nullable14 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton13 = new QMSingleButton(qMNestedButton13, 4f, 1f, "Turn Lights OFF", () => {
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (0)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchDown", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (1)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchDown", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (2)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchDown", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("Game Logic/Switch Boxes/Switchbox (3)").GetComponent<UdonBehaviour>().get_gameObject(), "SwitchDown", null, false);
			}, " ", nullable14, nullable, false);
			QMNestedButton qMNestedButton14 = MainMenuLol.murder;
			nullable = null;
			Color? nullable15 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton14 = new QMSingleButton(qMNestedButton14, 4f, 2f, "Abort", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Abort]", ConsoleColor.Magenta));
				LoV9yY6YR91Q6ZGX4wt.Abort();
			}, "", nullable15, nullable, false);
			murder.page2 = new QMNestedButton(MainMenuLol.murder, "Page 2 ->", 4f, 3f, "", "Murder Page 2");
			QMNestedButton qMNestedButton15 = murder.page2;
			nullable = null;
			Color? nullable16 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton15 = new QMSingleButton(qMNestedButton15, 1f, 0f, "Start", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Start]", ConsoleColor.Magenta));
				LoV9yY6YR91Q6ZGX4wt.Start();
			}, "", nullable16, nullable, false);
			QMNestedButton qMNestedButton16 = murder.page2;
			nullable = null;
			Color? nullable17 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton16 = new QMSingleButton(qMNestedButton16, 1f, 1f, "Blind All", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Blind All]", ConsoleColor.Magenta));
				LoV9yY6YR91Q6ZGX4wt.Glf6FSYZpJ();
			}, "", nullable17, nullable, false);
			QMNestedButton qMNestedButton17 = murder.page2;
			nullable = null;
			Color? nullable18 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton17 = new QMSingleButton(qMNestedButton17, 1f, 2f, "Kill All", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill All]", ConsoleColor.Magenta));
				LoV9yY6YR91Q6ZGX4wt.eoo6lvHWT5();
			}, "", nullable18, nullable, false);
			QMNestedButton qMNestedButton18 = murder.page2;
			nullable = null;
			Color? nullable19 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton18 = new QMSingleButton(qMNestedButton18, 1f, 3f, "Murderer \n Win", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Murderer Win]", ConsoleColor.Magenta));
				LoV9yY6YR91Q6ZGX4wt.kOB6iyFSMM();
			}, "", nullable19, nullable, false);
			QMNestedButton qMNestedButton19 = murder.page2;
			nullable = null;
			Color? nullable20 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton19 = new QMSingleButton(qMNestedButton19, 2f, 0f, "Bystanders \n Win", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Bystanders Win]", ConsoleColor.Magenta));
				LoV9yY6YR91Q6ZGX4wt.wsy60T6aLP();
			}, "", nullable20, nullable, false);
			QMNestedButton qMNestedButton20 = murder.page2;
			nullable = null;
			Color? nullable21 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton20 = new QMSingleButton(qMNestedButton20, 2f, 1f, "LOCK DOORS", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Lock Doors]", ConsoleColor.Magenta));
				foreach (Transform transform in new List<Transform>()
				{
					GameObject.Find("Door").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (3)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (4)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (5)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (6)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (7)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (15)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (16)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (8)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (13)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (17)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (18)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (19)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (20)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (21)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (22)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (23)").get_transform().Find("Door Anim/Hinge/Interact lock"),
					GameObject.Find("Door (14)").get_transform().Find("Door Anim/Hinge/Interact lock")
				})
				{
					transform.GetComponent<UdonBehaviour>().Interact();
				}
			}, "", nullable21, nullable, false);
			QMNestedButton qMNestedButton21 = murder.page2;
			nullable = null;
			Color? nullable22 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton21 = new QMSingleButton(qMNestedButton21, 2f, 2f, "UNLOCK DOORS", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Unlock Doors]", ConsoleColor.Magenta));
				foreach (Transform transform in new List<Transform>()
				{
					GameObject.Find("Door").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (3)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (4)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (5)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (6)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (7)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (15)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (16)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (8)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (13)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (17)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (18)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (19)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (20)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (21)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (22)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (23)").get_transform().Find("Door Anim/Hinge/Interact shove"),
					GameObject.Find("Door (14)").get_transform().Find("Door Anim/Hinge/Interact shove")
				})
				{
					transform.GetComponent<UdonBehaviour>().Interact();
					transform.GetComponent<UdonBehaviour>().Interact();
					transform.GetComponent<UdonBehaviour>().Interact();
					transform.GetComponent<UdonBehaviour>().Interact();
				}
			}, "", nullable22, nullable, false);
			QMNestedButton qMNestedButton22 = murder.page2;
			nullable = null;
			Color? nullable23 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton22 = new QMSingleButton(qMNestedButton22, 2f, 3f, "OPEN DOORS", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Open Doors]", ConsoleColor.Magenta));
				foreach (Transform transform in new List<Transform>()
				{
					GameObject.Find("Door").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (3)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (4)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (5)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (6)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (7)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (15)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (16)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (8)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (13)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (17)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (18)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (19)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (20)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (21)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (22)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (23)").get_transform().Find("Door Anim/Hinge/Interact open"),
					GameObject.Find("Door (14)").get_transform().Find("Door Anim/Hinge/Interact open")
				})
				{
					transform.GetComponent<UdonBehaviour>().Interact();
				}
			}, "", nullable23, nullable, false);
			QMNestedButton qMNestedButton23 = murder.page2;
			nullable = null;
			Color? nullable24 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton23 = new QMSingleButton(qMNestedButton23, 2f, 3f, "CLOSE DOORS", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Close Doors]", ConsoleColor.Magenta));
				foreach (Transform transform in new List<Transform>()
				{
					GameObject.Find("Door").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (3)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (4)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (5)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (6)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (7)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (15)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (16)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (8)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (13)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (17)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (18)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (19)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (20)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (21)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (22)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (23)").get_transform().Find("Door Anim/Hinge/Interact close"),
					GameObject.Find("Door (14)").get_transform().Find("Door Anim/Hinge/Interact close")
				})
				{
					transform.GetComponent<UdonBehaviour>().Interact();
				}
			}, "", nullable24, nullable, false);
			QMNestedButton qMNestedButton24 = murder.page2;
			nullable = null;
			Color? nullable25 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton24 = new QMSingleButton(qMNestedButton24, 3f, 0f, "Infinite Ammo", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Infinite Ammo]", ConsoleColor.Magenta));
				MelonCoroutines.Start(murder.InfiniteRevolvere());
			}, "", nullable25, nullable, false);
			QMToggleButton qMToggleButton = new QMToggleButton(murder.page2, 3f, 1f, "No Kill Screen", () => {
				MelonCoroutines.Start(murder.ANgwW3wEFN());
				MainConfigSettings.Instance.NoBlindKillScreen = true;
				MainConfigSettings.Instance.SfuQjPNsy4();
			}, () => {
			}, "", false);
			QMToggleButton qMToggleButton1 = new QMToggleButton(murder.page2, 3f, 2f, "Kill Aura", () => murder.BoopDeathCor = MelonCoroutines.Start(murder.TouchOfDeath()), () => MelonCoroutines.Stop(murder.BoopDeathCor), "", false);
			QMToggleButton qMToggleButton2 = new QMToggleButton(murder.page2, 3f, 3f, "Kill Aura Right Hand", () => {
				murder.KillAuraRight = true;
				murder.KillAuraLeft = false;
			}, () => murder.KillAuraRight = false, "", murder.KillAuraRight);
			QMToggleButton qMToggleButton3 = new QMToggleButton(murder.page2, 4f, 0f, "Kill Aura Left Hand", () => {
				murder.KillAuraRight = false;
				murder.KillAuraLeft = true;
			}, () => murder.KillAuraLeft = false, "", murder.KillAuraLeft);
		}

		public static IEnumerator TouchOfDeath()
		{
			int num1 = 0;
			int num = 0;
			VRCHandGrasper[] vRCHandGrasperArray = UnityEngine.Object.FindObjectsOfType<VRCHandGrasper>();
			bool flag = false;
			while (true)
			{
				yield return new WaitForSeconds(0.1f);
				if (murder.KillAuraLeft)
				{
					if (Input.GetAxis("Oculus_CrossPlatform_PrimaryIndexTrigger") > 0f)
					{
						float single = 999f;
						Player player = null;
						Player[] playerArray = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
						for (int i1 = 0; i1 < (int)playerArray.Length; i1 = num1)
						{
							if (Vector3.Distance(playerArray[i1].get_gameObject().get_transform().get_position(), vRCHandGrasperArray[1].get_gameObject().get_transform().get_position()) < single && !playerArray[i1].get_gameObject().get_name().Contains("Local"))
							{
								single = Vector3.Distance(playerArray[i1].get_gameObject().get_transform().get_position(), vRCHandGrasperArray[1].get_gameObject().get_transform().get_position());
								player = playerArray[i1];
							}
							num1 = i1 + 1;
						}
						int num2 = 0;
						while (num2 < 24)
						{
							string str = string.Concat("Player Node (", num2.ToString(), ")");
							string str1 = string.Concat("Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (", num2.ToString(), ")/Player Name Text");
							if (GameObject.Find(str1).GetComponent<Text>().get_text().Equals(player.Method_Internal_get_APIUser_0().get_displayName()))
							{
								UdonBehaviour component = GameObject.Find(str).GetComponent<UdonBehaviour>();
								component.SendCustomNetworkEvent(0, "SyncKill");
								component = null;
							}
							num2 = num2 + 1;
							str = null;
							str1 = null;
						}
						flag = true;
						player = null;
						playerArray = null;
					}
					else if (vRCHandGrasperArray[1].get_field_Internal_VRCInput_1().get_field_Public_Single_0() == 0f)
					{
						flag = false;
					}
					yield return null;
				}
				if (murder.KillAuraRight)
				{
					if (Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f)
					{
						float single1 = 999f;
						Player player1 = null;
						Player[] playerArray1 = PlayerManager.Method_Public_Static_get_PlayerManager_0().Method_Public_get_ArrayOf_Player_0();
						for (int j = 0; j < (int)playerArray1.Length; j = num)
						{
							if (Vector3.Distance(playerArray1[j].get_gameObject().get_transform().get_position(), vRCHandGrasperArray[1].get_gameObject().get_transform().get_position()) < single1 && !playerArray1[j].get_gameObject().get_name().Contains("Local"))
							{
								single1 = Vector3.Distance(playerArray1[j].get_gameObject().get_transform().get_position(), vRCHandGrasperArray[1].get_gameObject().get_transform().get_position());
								player1 = playerArray1[j];
							}
							num = j + 1;
						}
						int num3 = 0;
						while (num3 < 24)
						{
							string str2 = string.Concat("Player Node (", num3.ToString(), ")");
							string str3 = string.Concat("Game Logic/Game Canvas/Game In Progress/Player List/Player List Group/Player Entry (", num3.ToString(), ")/Player Name Text");
							if (GameObject.Find(str3).GetComponent<Text>().get_text().Equals(player1.Method_Internal_get_APIUser_0().get_displayName()))
							{
								UdonBehaviour udonBehaviour = GameObject.Find(str2).GetComponent<UdonBehaviour>();
								udonBehaviour.SendCustomNetworkEvent(0, "SyncKill");
								udonBehaviour = null;
							}
							num3 = num3 + 1;
							str2 = null;
							str3 = null;
						}
						flag = true;
						player1 = null;
						playerArray1 = null;
					}
					else if (vRCHandGrasperArray[1].get_field_Internal_VRCInput_1().get_field_Public_Single_0() == 0f)
					{
						flag = false;
					}
					yield return null;
				}
			}
		}

		internal static bool ycJKYAmBc5ivIQTivPR()
		{
			return murder.tPatXZmO6EnuesESPDc == null;
		}
	}
}