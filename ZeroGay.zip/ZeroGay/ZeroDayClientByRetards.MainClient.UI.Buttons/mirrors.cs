using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using System;
using System.Runtime.CompilerServices;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class mirrors
	{
		internal static mirrors sNbwQBgeSDG6qu8X1jf;

		public mirrors()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static mirrors a8sUUegq2Y9Nmie5EUs()
		{
			return mirrors.sNbwQBgeSDG6qu8X1jf;
		}

		internal static bool Fqbo9bgCYU87U39Y7v1()
		{
			return mirrors.sNbwQBgeSDG6qu8X1jf == null;
		}

		public static void StartMirror()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.mirrors, 1f, 0f, "Mirror", () => PortableMirror.vrGOVWV7RC(true), () => PortableMirror.vrGOVWV7RC(false), "Mirror monkey...", false);
		}
	}
}