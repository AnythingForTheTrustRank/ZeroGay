using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class mirrors
	{
		internal static mirrors J6yDEmmSR98ncqf7gu5;

		public mirrors()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool IftIXjmYXbNTdDsZe9N()
		{
			return mirrors.J6yDEmmSR98ncqf7gu5 == null;
		}

		internal static mirrors S8j1psmXK7d4su8IWSV()
		{
			return mirrors.J6yDEmmSR98ncqf7gu5;
		}

		public static void StartMirror()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.mirrors, 1f, 0f, "Mirror", () => PortableMirror.tI0G1ri0db(true), () => PortableMirror.tI0G1ri0db(false), "Mirror monkey...", false);
		}
	}
}