using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC.DataModel;
using VRC.UI.Elements.Menus;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class amonginteract
	{
		private static amonginteract nY7DEWDZHksEhYZxIKY;

		public amonginteract()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static amonginteract nUVA58DLMbrWKU4q6h4()
		{
			return amonginteract.nY7DEWDZHksEhYZxIKY;
		}

		public static void StartAmongInteract()
		{
			QMNestedButton qMNestedButton = MainMenuLol.amonginteract;
			QMNestedButton qMNestedButton1 = qMNestedButton;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton1, 1f, 0f, "Assign Crewmate", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Crewmate]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(componentsInChild.get_gameObject(), "SyncAssignB", j25MPyacibgF0kcPwHe.rjYaCVqqPo, false);
				}
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton2 = qMNestedButton;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton2, 1f, 1f, "Assign Imposter", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Imposter]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(componentsInChild.get_gameObject(), "SyncAssignM", j25MPyacibgF0kcPwHe.rjYaCVqqPo, false);
				}
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton3 = qMNestedButton;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton3, 1f, 2f, "Vote Out", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Vote Out]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(componentsInChild.get_gameObject(), "SyncVotedOut", j25MPyacibgF0kcPwHe.rjYaCVqqPo, false);
				}
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton4 = qMNestedButton;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton4, 1f, 3f, "Kill Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill Player]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(componentsInChild.get_gameObject(), "SyncKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, false);
				}
			}, "", nullable4, nullable, false);
		}

		internal static bool VB8nW4DVqIedmGQK7ls()
		{
			return amonginteract.nY7DEWDZHksEhYZxIKY == null;
		}
	}
}