using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using gpd3oZtw5qhYneWRlWY;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.DataModel;
using VRC.UI.Elements.Menus;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class amonginteract
	{
		private static amonginteract DyKZbcoDGpjvyTIjR6R;

		public amonginteract()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool Sb1mUfocVeOVQKps7kJ()
		{
			return amonginteract.DyKZbcoDGpjvyTIjR6R == null;
		}

		public static void StartAmongInteract()
		{
			QMNestedButton qMNestedButton = MainMenuLol.amonginteract;
			QMNestedButton qMNestedButton1 = qMNestedButton;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton1, 1f, 0f, "Assign Crewmate", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Crewmate]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncAssignB", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton2 = qMNestedButton;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton2, 1f, 1f, "Assign Imposter", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Imposter]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncAssignM", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton3 = qMNestedButton;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton3, 1f, 2f, "Vote Out", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Vote Out]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncVotedOut", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton4 = qMNestedButton;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton4, 1f, 3f, "Kill Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill Player]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(str);
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, "", nullable4, nullable, false);
		}

		internal static amonginteract tc3i21oypT3ZYHom8ik()
		{
			return amonginteract.DyKZbcoDGpjvyTIjR6R;
		}
	}
}