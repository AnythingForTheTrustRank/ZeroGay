using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class speed
	{
		internal static speed moOoeimnPQWQIJcg2C7;

		public speed()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool Bgx9y5mexmfZtUUnQNM()
		{
			return speed.moOoeimnPQWQIJcg2C7 == null;
		}

		public static void StartSpeed()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Speed, 1f, 0f, "Speed Modifiers", () => ZeroDayMain.SpeedMods = true, () => {
				ZeroDayMain.SpeedMods = false;
				Networking.get_LocalPlayer().SetWalkSpeed(2f);
				Networking.get_LocalPlayer().SetRunSpeed(4f);
				Networking.get_LocalPlayer().SetStrafeSpeed(2f);
			}, "  ", false);
			QMNestedButton speed = MainMenuLol.Speed;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(speed, 2f, 0f, "Run: ", () => {
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton = MainMenuLol.Speed;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton, 3f, 0f, "Walk: ", () => {
			}, "", nullable2, nullable, false);
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(MainMenuLol.Speed, 1f, 1f, "+5 speed", () => {
				ZeroDayMain.RunSpeed += 5f;
				ZeroDayMain.WalkSpeed += 5f;
				qMSingleButton.SetButtonText(string.Format("Run: [{0}]", ZeroDayMain.RunSpeed));
				qMSingleButton1.SetButtonText(string.Format("Walk: [{0}]", ZeroDayMain.WalkSpeed));
			}, "", nullable3, nullable, false);
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(MainMenuLol.Speed, 1f, 2f, "+3 speed", () => {
				ZeroDayMain.RunSpeed += 3f;
				ZeroDayMain.WalkSpeed += 3f;
				qMSingleButton.SetButtonText(string.Format("Run: [{0}]", ZeroDayMain.RunSpeed));
				qMSingleButton1.SetButtonText(string.Format("Walk: [{0}]", ZeroDayMain.WalkSpeed));
			}, "", nullable4, nullable, false);
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(MainMenuLol.Speed, 1f, 3f, "+1 speed ", () => {
				ZeroDayMain.RunSpeed += 1f;
				ZeroDayMain.WalkSpeed += 1f;
				qMSingleButton.SetButtonText(string.Format("Run: [{0}]", ZeroDayMain.RunSpeed));
				qMSingleButton1.SetButtonText(string.Format("Walk: [{0}]", ZeroDayMain.WalkSpeed));
			}, "", nullable5, nullable, false);
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(MainMenuLol.Speed, 4f, 1f, "-5 speed", () => {
				ZeroDayMain.RunSpeed -= 5f;
				ZeroDayMain.WalkSpeed -= 5f;
				qMSingleButton.SetButtonText(string.Format("Run: [{0}]", ZeroDayMain.RunSpeed));
				qMSingleButton1.SetButtonText(string.Format("Walk: [{0}]", ZeroDayMain.WalkSpeed));
			}, "", nullable6, nullable, false);
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(MainMenuLol.Speed, 4f, 2f, "-3 speed", () => {
				ZeroDayMain.RunSpeed -= 3f;
				ZeroDayMain.WalkSpeed -= 3f;
				qMSingleButton.SetButtonText(string.Format("Run: [{0}]", ZeroDayMain.RunSpeed));
				qMSingleButton1.SetButtonText(string.Format("Walk: [{0}]", ZeroDayMain.WalkSpeed));
			}, "", nullable7, nullable, false);
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(MainMenuLol.Speed, 4f, 3f, "-1 speed ", () => {
				ZeroDayMain.RunSpeed -= 1f;
				ZeroDayMain.WalkSpeed -= 1f;
				qMSingleButton.SetButtonText(string.Format("Run: [{0}]", ZeroDayMain.RunSpeed));
				qMSingleButton1.SetButtonText(string.Format("Walk: [{0}]", ZeroDayMain.WalkSpeed));
			}, "", nullable8, nullable, false);
		}

		internal static speed vdvJ4MmfXFSvF8NgAoS()
		{
			return speed.moOoeimnPQWQIJcg2C7;
		}
	}
}