using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using gpd3oZtw5qhYneWRlWY;
using krgLWAtP5LbLB3HiTbh;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.Udon;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;
using ZeroDayByRetards.mainshiet.patches.ghostV1;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class ghost
	{
		private static ghost rj2UdvmtXhwfxYkh8A6;

		public ghost()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static ghost mjV4cimwoY9tec5LBcq()
		{
			return ghost.rj2UdvmtXhwfxYkh8A6;
		}

		public static void StartGhost()
		{
			QMNestedButton ghostV17 = MainMenuLol.GhostV17;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(ghostV17, 1f, 0f, "Ghost Win", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Ghost Win]", ConsoleColor.Magenta));
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("LobbyManager"))
					{
						continue;
					}
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_GhostWin");
				}
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton, 1f, 1f, "Human Win", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Human Win]", ConsoleColor.Magenta));
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("LobbyManager"))
					{
						continue;
					}
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_HumanWin");
				}
			}, "", nullable2, nullable, false);
			QMNestedButton ghostV171 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(ghostV171, 1f, 3f, "Max Currency", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Max Currency]", ConsoleColor.Magenta));
				GameObject gameObject = GameObject.Find("GameManager");
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", null, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", null, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", null, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", null, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", null, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", null, true);
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton1 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton1, 2f, 0f, "Kill All", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill All]", ConsoleColor.Magenta));
				GameObject gameObject = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject/DamageSync");
				GameObject gameObject1 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (1)/DamageSync");
				GameObject gameObject2 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (2)/DamageSync");
				GameObject gameObject3 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (3)/DamageSync");
				GameObject gameObject4 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (4)/DamageSync");
				GameObject gameObject5 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (5)/DamageSync");
				GameObject gameObject6 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (6)/DamageSync");
				GameObject gameObject7 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (7)/DamageSync");
				GameObject gameObject8 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (8)/DamageSync");
				GameObject gameObject9 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (9)/DamageSync");
				GameObject gameObject10 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (10)/DamageSync");
				GameObject gameObject11 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (11)/DamageSync");
				GameObject gameObject12 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (12)/DamageSync");
				GameObject gameObject13 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (13)/DamageSync");
				GameObject gameObject14 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (14)/DamageSync");
				GameObject gameObject15 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (15)/DamageSync");
				GameObject gameObject16 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (16)/DamageSync");
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject2, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject4, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject5, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject6, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject7, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject8, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject9, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject10, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject11, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject12, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject13, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject14, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject15, "BackStabDamage", null, false);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject16, "BackStabDamage", null, false);
			}, "", nullable4, nullable, false);
			QMNestedButton ghostV172 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(ghostV172, 2f, 1f, "Everyone Suspicious", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Everyone Suspicious]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(GameObject.Find("GameManager"), "OnInnocentKill", null, false);
			}, "", nullable5, nullable, false);
			QMNestedButton qMNestedButton2 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(qMNestedButton2, 2f, 2f, "Spawn 50. Cal", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Spawn 50. Cal]", ConsoleColor.Magenta));
				teleports.tpcal = true;
			}, "", nullable6, nullable, false);
			QMNestedButton ghostV173 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(ghostV173, 2f, 3f, "Spawn RiotShield", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Spawn Riotshield]", ConsoleColor.Magenta));
				teleports.tpriotshield = true;
			}, "", nullable7, nullable, false);
			QMNestedButton qMNestedButton3 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(qMNestedButton3, 3f, 0f, "Spawn Shotgun", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Spawn Shotgun]", ConsoleColor.Magenta));
				teleports.tpshot = true;
			}, "", nullable8, nullable, false);
			QMNestedButton ghostV174 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable9 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton8 = new QMSingleButton(ghostV174, 3f, 1f, "Spawn Vector", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Vector]", ConsoleColor.Magenta));
				teleports.tpvector = true;
			}, "", nullable9, nullable, false);
			QMNestedButton qMNestedButton4 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable10 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton9 = new QMSingleButton(qMNestedButton4, 3f, 2f, "Spawn MP7", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Spawn MP7]", ConsoleColor.Magenta));
				teleports.MP7tp = true;
			}, "", nullable10, nullable, false);
			QMNestedButton ghostV175 = MainMenuLol.GhostV17;
			nullable = null;
			Color? nullable11 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton10 = new QMSingleButton(ghostV175, 3f, 3f, "Collect All Keys", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Collect All Keys]", ConsoleColor.Magenta));
				KarRCCtBsS2xtE1uWcw.x1OQsd8Zaj = true;
			}, "", nullable11, nullable, false);
		}

		internal static bool Tf6ZyumQ8IAKJwDiPx7()
		{
			return ghost.rj2UdvmtXhwfxYkh8A6 == null;
		}
	}
}