using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using gpd3oZtw5qhYneWRlWY;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.DataModel;
using VRC.UI.Elements.Menus;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class ghostinteract
	{
		internal static ghostinteract DNPmgNmNLcWrWrOVERs;

		public ghostinteract()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static ghostinteract onXt3Nm2E1Yvqq9JKnD()
		{
			return ghostinteract.DNPmgNmNLcWrWrOVERs;
		}

		internal static bool P0EAIAmCrEUFGFb3hnV()
		{
			return ghostinteract.DNPmgNmNLcWrWrOVERs == null;
		}

		public static void StartGhost()
		{
			QMNestedButton qMNestedButton = MainMenuLol.ghostinteract;
			QMNestedButton qMNestedButton1 = qMNestedButton;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton1, 1f, 0f, "Kill Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill Player]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(str);
				GameObject gameObject = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject/DamageSync");
				GameObject gameObject1 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (1)/DamageSync");
				GameObject gameObject2 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (2)/DamageSync");
				GameObject gameObject3 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (3)/DamageSync");
				GameObject gameObject4 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (4)/DamageSync");
				GameObject gameObject5 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (5)/DamageSync");
				GameObject gameObject6 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (6)/DamageSync");
				GameObject gameObject7 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (7)/DamageSync");
				GameObject gameObject8 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (8)/DamageSync");
				GameObject gameObject9 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (9)/DamageSync");
				GameObject gameObject10 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (10)/DamageSync");
				GameObject gameObject11 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (11)/DamageSync");
				GameObject gameObject12 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (12)/DamageSync");
				GameObject gameObject13 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (13)/DamageSync");
				GameObject gameObject14 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (14)/DamageSync");
				GameObject gameObject15 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (15)/DamageSync");
				GameObject gameObject16 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (16)/DamageSync");
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject2, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject4, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject5, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject6, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject7, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject8, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject9, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject10, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject11, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject12, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject13, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject14, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject15, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject16, "BackStabDamage", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton2 = qMNestedButton;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton2, 1f, 1f, "Assign Max Currency", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Max Currency]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(str);
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("GameManager"))
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "OnSuspiciousKill", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, true);
				}
			}, "", nullable2, nullable, false);
		}
	}
}