using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC.DataModel;
using VRC.UI.Elements.Menus;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class ghostinteract
	{
		private static ghostinteract YhhE6PgIP6LANoUKGqI;

		public ghostinteract()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool mpHtQpgogRDNnJsqNqC()
		{
			return ghostinteract.YhhE6PgIP6LANoUKGqI == null;
		}

		public static void StartGhost()
		{
			QMNestedButton qMNestedButton = MainMenuLol.ghostinteract;
			QMNestedButton qMNestedButton1 = qMNestedButton;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton1, 1f, 0f, "Kill Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill Player]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				GameObject gameObject = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject/DamageSync");
				GameObject gameObject1 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (1)/DamageSync");
				GameObject gameObject2 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (2)/DamageSync");
				GameObject gameObject3 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (3)/DamageSync");
				GameObject gameObject4 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (4)/DamageSync");
				GameObject gameObject5 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (5)/DamageSync");
				GameObject gameObject6 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (6)/DamageSync");
				GameObject gameObject7 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (7)/DamageSync");
				GameObject gameObject8 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (8)/DamageSync");
				GameObject gameObject9 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (9)/DamageSync");
				GameObject gameObject10 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (10)/DamageSync");
				GameObject gameObject11 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (11)/DamageSync");
				GameObject gameObject12 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (12)/DamageSync");
				GameObject gameObject13 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (13)/DamageSync");
				GameObject gameObject14 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (14)/DamageSync");
				GameObject gameObject15 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (15)/DamageSync");
				GameObject gameObject16 = GameObject.Find("GameManager/PlayerObjectList/Human/PlayerCharacterObject (16)/DamageSync");
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject2, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject4, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject5, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject6, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject7, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject8, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject9, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject10, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject11, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject12, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject13, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject14, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject15, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject16, "BackStabDamage", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton2 = qMNestedButton;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton2, 1f, 1f, "Assign Max Currency", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Assign Max Currency]", ConsoleColor.Magenta));
				string str = GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				GameObject.Find("/UserInterface").get_transform().Find("Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_gameObject().GetComponent<SelectedUserMenuQM>().get_field_Private_IUser_0().Method_Public_Abstract_Virtual_New_get_String_0();
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(str);
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("GameManager"))
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "OnSuspiciousKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "OnSuspiciousKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "OnSuspiciousKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "OnSuspiciousKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "OnSuspiciousKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "OnSuspiciousKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "OnSuspiciousKill", j25MPyacibgF0kcPwHe.rjYaCVqqPo, true);
				}
			}, "", nullable2, nullable, false);
		}

		internal static ghostinteract VntkcPg6YLr1V9Sn7RX()
		{
			return ghostinteract.YhhE6PgIP6LANoUKGqI;
		}
	}
}