using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using C2NmTt6c7EcPo9p0lXu;
using gpd3oZtw5qhYneWRlWY;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.Core;
using VRC.Udon;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class amongus
	{
		public static QMNestedButton page2;

		internal static amongus GLvWA8oETePv81U4p5J;

		public amongus()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool Bnr54Coz99s79Us84w3()
		{
			return amongus.GLvWA8oETePv81U4p5J == null;
		}

		internal static amongus HCum73mq9LS5KEH1Pom()
		{
			return amongus.GLvWA8oETePv81U4p5J;
		}

		public static void StartAmigos()
		{
			QMNestedButton qMNestedButton = MainMenuLol.amongus;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 1f, "Sabotage All", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Sabotage All]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.m456E5Kjaw();
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton1 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton1, 1f, 2f, "Sabotage Doors", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Sabotage Doors]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.A5t6z2jWHw();
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton2 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton2, 1f, 3f, "Sabotage Reactor", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Sabotage Reactor]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.mZktHp1iSE();
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton3 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton3, 2f, 0f, "Sabotage Lights", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Sabotage Lights]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.nvjtkHedvh();
			}, "", nullable4, nullable, false);
			QMNestedButton qMNestedButton4 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(qMNestedButton4, 2f, 1f, "Sabotage Oxygen", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Sabotage Oxygen]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.HevtGXwNvM();
			}, "", nullable5, nullable, false);
			QMNestedButton qMNestedButton5 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(qMNestedButton5, 2f, 2f, "Repair All", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Repair All]", ConsoleColor.Magenta));
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("Game Logic"))
					{
						continue;
					}
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairLights");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairReactor");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairOxygenA");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairOxygenB");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairOxygen");
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncRepairComms");
				}
			}, "", nullable6, nullable, false);
			QMNestedButton qMNestedButton6 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(qMNestedButton6, 2f, 3f, "Become Crew", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Become Crew]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(APIUser.get_CurrentUser().get_id());
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncAssignB", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, "", nullable7, nullable, false);
			QMNestedButton qMNestedButton7 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(qMNestedButton7, 3f, 0f, "Become Imposter", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Become Imposter]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(APIUser.get_CurrentUser().get_id());
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncAssignM", QdA6prtQJZNe9CGe8IK.RIbtOqTLrt, false);
				}
			}, "", nullable8, nullable, false);
			QMNestedButton qMNestedButton8 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable9 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton8 = new QMSingleButton(qMNestedButton8, 3f, 1f, "Abort", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Abort]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.Abort();
			}, "", nullable9, nullable, false);
			QMNestedButton qMNestedButton9 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable10 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton9 = new QMSingleButton(qMNestedButton9, 3f, 2f, "Start", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Start]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.Start();
			}, "", nullable10, nullable, false);
			QMNestedButton qMNestedButton10 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable11 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton10 = new QMSingleButton(qMNestedButton10, 3f, 3f, "Crewmates \n Win", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Crewmates Win]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.iTCt4QejIL();
			}, "", nullable11, nullable, false);
			QMNestedButton qMNestedButton11 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable12 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton11 = new QMSingleButton(qMNestedButton11, 4f, 0f, "Imposters \n Win", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Imposters Win]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.boAt7ClLc8();
			}, "", nullable12, nullable, false);
			QMNestedButton qMNestedButton12 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable13 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton12 = new QMSingleButton(qMNestedButton12, 4f, 1f, "Vote Out All", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Vote All]", ConsoleColor.Magenta));
				GameObject gameObject = GameObject.Find("Player Nodes");
				foreach (Transform componentsInChild in gameObject.GetComponentsInChildren<Transform>())
				{
					if (componentsInChild.get_name() == gameObject.get_name())
					{
						continue;
					}
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(componentsInChild.get_gameObject(), "SyncVotedOut", null, false);
				}
			}, "", nullable13, nullable, false);
			QMNestedButton qMNestedButton13 = MainMenuLol.amongus;
			nullable = null;
			Color? nullable14 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton13 = new QMSingleButton(qMNestedButton13, 4f, 2f, "Kill All", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Kill All]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.XqwtIp7Rgc();
			}, "", nullable14, nullable, false);
			amongus.page2 = new QMNestedButton(MainMenuLol.amongus, "Page 2 ->", 4f, 3f, "", "Among Us Page 2");
			QMNestedButton qMNestedButton14 = amongus.page2;
			nullable = null;
			Color? nullable15 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton14 = new QMSingleButton(qMNestedButton14, 1f, 0f, "Complete Tasks", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Complete Tasks]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.Vsrt9PPvtr();
			}, "", nullable15, nullable, false);
			QMNestedButton qMNestedButton15 = amongus.page2;
			nullable = null;
			Color? nullable16 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton15 = new QMSingleButton(qMNestedButton15, 1f, 1f, "Emergency Meeting", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Emergency Meeting]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.GgwtMMPE5P();
			}, "", nullable16, nullable, false);
			QMNestedButton qMNestedButton16 = amongus.page2;
			nullable = null;
			Color? nullable17 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton16 = new QMSingleButton(qMNestedButton16, 1f, 2f, "Skip Vote", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Skip Vote]", ConsoleColor.Magenta));
				ESjP9x6DeMXH5ll0XwX.Yc2tsKPewN();
			}, "", nullable17, nullable, false);
		}
	}
}