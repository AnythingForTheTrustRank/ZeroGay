using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using MelonLoader;
using RjT7emc7tqaURbFlcDX;
using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using WrcIXrcwhnWSCvhNdmR;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class utilsinteract
	{
		private static utilsinteract SiVnFDgJHtipk5qwoNV;

		public utilsinteract()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool aSsu48g8mHOVwSA5euw()
		{
			return utilsinteract.SiVnFDgJHtipk5qwoNV == null;
		}

		internal static utilsinteract iIHiFIgEUALKKkhRD3E()
		{
			return utilsinteract.SiVnFDgJHtipk5qwoNV;
		}

		public static void StartUtilsInteract()
		{
			QMNestedButton qMNestedButton = MainMenuLol.utilitiesselecteduser;
			QMNestedButton qMNestedButton1 = qMNestedButton;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton1, 1f, 0f, "Orbit Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Orbit Player]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.orbitPlayer = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton2 = qMNestedButton;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton2, 1f, 1f, "Sit On Head ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Sit On Head]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonHead = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton3 = qMNestedButton;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton3, 1f, 2f, "Sit On R Shoulder ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [R Shoulder]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonRightshoulder = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton4 = qMNestedButton;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton4, 1f, 3f, "Sit On L Shoulder ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [L Shoulder]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonLeftshoulder = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable4, nullable, false);
			QMNestedButton qMNestedButton5 = qMNestedButton;
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(qMNestedButton5, 2f, 0f, "Sit On L Foot", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [L Foot]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonLeftfeet = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable5, nullable, false);
			QMNestedButton qMNestedButton6 = qMNestedButton;
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(qMNestedButton6, 2f, 1f, "Sit On R Foot ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [R Foot]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonRightfeet = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable6, nullable, false);
			QMNestedButton qMNestedButton7 = qMNestedButton;
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(qMNestedButton7, 2f, 2f, "Sit On R Hand ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [R Hand]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonRightHand = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable7, nullable, false);
			QMNestedButton qMNestedButton8 = qMNestedButton;
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(qMNestedButton8, 2f, 3f, "Sit On L Hand ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [L Hand]", ConsoleColor.Magenta));
				j25MPyacibgF0kcPwHe.wxlaQSaVUP(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Internal_get_VRCPlayer_0().Method_Public_get_ApiAvatar_0().get_id());
				ZeroDayMain.SitonLeftHand = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable8, nullable, false);
			QMNestedButton qMNestedButton9 = qMNestedButton;
			nullable = null;
			Color? nullable9 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton8 = new QMSingleButton(qMNestedButton9, 3f, 0f, "Force Clone ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Force Clone]", ConsoleColor.Magenta));
				Player player = mDXrgOcTInjaUDi52SW.jLAceWeXcv();
				string _id = player.Method_Internal_get_VRCPlayer_0().Method_Public_get_ApiAvatar_0().get_id();
				if (player.Method_Internal_get_VRCPlayer_0().Method_Public_get_ApiAvatar_0().get_releaseStatus() == "private")
				{
					MelonLogger.Log("!!!YOU CANT CLONE A PRIVATE AVATAR!!!");
				}
				else
				{
					MelonLogger.Log(string.Concat("Force Cloning avatar with ID: ", _id));
					kgKUrIcEPBwAPoxP1pT.TnGcWa5fMd(_id);
				}
			}, "", nullable9, nullable, false);
			QMNestedButton qMNestedButton10 = qMNestedButton;
			nullable = null;
			Color? nullable10 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton9 = new QMSingleButton(qMNestedButton10, 3f, 1f, "Copy Avatar Info ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Copy A-info]", ConsoleColor.Magenta));
				string[] _name = new string[] { "Name Of Avatar : ", mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_name(), "\nName Of Author : ", mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_authorName(), "\nRelease Status : ", mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_releaseStatus(), "\nSupported Platforms : ", null, null, null, null, null, null, null, null, null };
				_name[7] = mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_supportedPlatforms().ToString();
				_name[8] = "\nAvatar Id : ";
				_name[9] = mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_id();
				_name[10] = "\nAsset Url : ";
				_name[11] = mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_assetUrl();
				_name[12] = "\nImage Url : ";
				_name[13] = mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_imageUrl();
				_name[14] = "\nAuthor iD : ";
				_name[15] = mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_authorId();
				string str = string.Concat(_name);
				kgKUrIcEPBwAPoxP1pT.dd6cPeiylZ(str);
				MelonLogger.Log(string.Concat("Info Copied: \n", str));
			}, "", nullable10, nullable, false);
			QMNestedButton qMNestedButton11 = qMNestedButton;
			nullable = null;
			Color? nullable11 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton10 = new QMSingleButton(qMNestedButton11, 3f, 2f, "Download VRCA ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Download VRCA]", ConsoleColor.Magenta));
				Process.Start(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_assetUrl());
				Process.Start(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_imageUrl());
				MelonLogger.Log(string.Concat("Avatar Asset url : ", mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_assetUrl()));
				MelonLogger.Log(string.Concat("Avatar Image url : ", mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_imageUrl()));
			}, "", nullable11, nullable, false);
			QMNestedButton qMNestedButton12 = qMNestedButton;
			nullable = null;
			Color? nullable12 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton11 = new QMSingleButton(qMNestedButton12, 3f, 3f, "Copy A-ID ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Copy A-ID]", ConsoleColor.Magenta));
				kgKUrIcEPBwAPoxP1pT.dd6cPeiylZ(mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_id());
				MelonLogger.Log(string.Concat("Avatar id is : ", mDXrgOcTInjaUDi52SW.jLAceWeXcv().Method_Public_get_ApiAvatar_0().get_id()));
			}, "", nullable12, nullable, false);
		}
	}
}