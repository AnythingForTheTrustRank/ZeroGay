using b3eD5DgJPcASx0xfHYB;
using BBagbqkNIJ3q0STpvuq;
using Blaze.API.QM;
using gpd3oZtw5qhYneWRlWY;
using LUVCXhkiWbEEkI9wTOU;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class utilsinteract
	{
		private static utilsinteract dVF2gimxxWRlvMDZY2X;

		public utilsinteract()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool gP6W1Lm1Rirkp9lHrhm()
		{
			return utilsinteract.dVF2gimxxWRlvMDZY2X == null;
		}

		internal static utilsinteract LhdwX7mK920vIRWZpD2()
		{
			return utilsinteract.dVF2gimxxWRlvMDZY2X;
		}

		public static void StartUtilsInteract()
		{
			QMNestedButton qMNestedButton = MainMenuLol.utilitiesselecteduser;
			QMNestedButton qMNestedButton1 = qMNestedButton;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton1, 1f, 0f, "Orbit Player", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Orbit Player]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.orbitPlayer = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton2 = qMNestedButton;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton2, 1f, 1f, "Sit On Head ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Sit On Head]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonHead = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton3 = qMNestedButton;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton3, 1f, 2f, "Sit On R Shoulder ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [R Shoulder]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonRightshoulder = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton4 = qMNestedButton;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton4, 1f, 3f, "Sit On L Shoulder ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [L Shoulder]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonLeftshoulder = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable4, nullable, false);
			QMNestedButton qMNestedButton5 = qMNestedButton;
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(qMNestedButton5, 2f, 0f, "Sit On L Foot", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [L Foot]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonLeftfeet = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable5, nullable, false);
			QMNestedButton qMNestedButton6 = qMNestedButton;
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(qMNestedButton6, 2f, 1f, "Sit On R Foot ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [R Foot]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonRightfeet = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable6, nullable, false);
			QMNestedButton qMNestedButton7 = qMNestedButton;
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(qMNestedButton7, 2f, 2f, "Sit On R Hand ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [R Hand]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_APIUser_0().get_id());
				ZeroDayMain.SitonRightHand = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable7, nullable, false);
			QMNestedButton qMNestedButton8 = qMNestedButton;
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(qMNestedButton8, 2f, 3f, "Sit On L Hand ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [L Hand]", ConsoleColor.Magenta));
				QdA6prtQJZNe9CGe8IK.YuvtNeYvOM(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Internal_get_VRCPlayer_0().Method_Public_get_ApiAvatar_0().get_id());
				ZeroDayMain.SitonLeftHand = true;
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
				Physics.set_gravity(new Vector3(0f, 0f, 0f));
			}, "", nullable8, nullable, false);
			QMNestedButton qMNestedButton9 = qMNestedButton;
			nullable = null;
			Color? nullable9 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton8 = new QMSingleButton(qMNestedButton9, 3f, 0f, "Force Clone ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Force Clone]", ConsoleColor.Magenta));
				Player player = j7Ipg1kwBirUGgO7rnG.B0okC2vDkL();
				string _id = player.Method_Internal_get_VRCPlayer_0().Method_Public_get_ApiAvatar_0().get_id();
				if (player.Method_Internal_get_VRCPlayer_0().Method_Public_get_ApiAvatar_0().get_releaseStatus() != "private")
				{
					MelonLogger.Log(string.Concat("Force Cloning avatar with ID: ", _id));
					IUVVD2kFINsy5h2mRqX.L2UkRnjcV4(_id);
				}
				else
				{
					MelonLogger.Log("!!!YOU CANT CLONE A PRIVATE AVATAR!!!");
				}
			}, "", nullable9, nullable, false);
			QMNestedButton qMNestedButton10 = qMNestedButton;
			nullable = null;
			Color? nullable10 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton9 = new QMSingleButton(qMNestedButton10, 3f, 1f, "Copy Avatar Info ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Copy A-info]", ConsoleColor.Magenta));
				string[] _name = new string[] { "Name Of Avatar : ", j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_name(), "\nName Of Author : ", j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_authorName(), "\nRelease Status : ", j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_releaseStatus(), "\nSupported Platforms : ", null, null, null, null, null, null, null, null, null };
				_name[7] = j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_supportedPlatforms().ToString();
				_name[8] = "\nAvatar Id : ";
				_name[9] = j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_id();
				_name[10] = "\nAsset Url : ";
				_name[11] = j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_assetUrl();
				_name[12] = "\nImage Url : ";
				_name[13] = j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_imageUrl();
				_name[14] = "\nAuthor iD : ";
				_name[15] = j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_authorId();
				string str = string.Concat(_name);
				IUVVD2kFINsy5h2mRqX.SPwkr0eD46(str);
				MelonLogger.Log(string.Concat("Info Copied: \n", str));
			}, "", nullable10, nullable, false);
			QMNestedButton qMNestedButton11 = qMNestedButton;
			nullable = null;
			Color? nullable11 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton10 = new QMSingleButton(qMNestedButton11, 3f, 2f, "Download VRCA ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Download VRCA]", ConsoleColor.Magenta));
				Process.Start(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_assetUrl());
				Process.Start(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_imageUrl());
				MelonLogger.Log(string.Concat("Avatar Asset url : ", j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_assetUrl()));
				MelonLogger.Log(string.Concat("Avatar Image url : ", j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_imageUrl()));
			}, "", nullable11, nullable, false);
			QMNestedButton qMNestedButton12 = qMNestedButton;
			nullable = null;
			Color? nullable12 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton11 = new QMSingleButton(qMNestedButton12, 3f, 3f, "Copy A-ID ", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Copy A-ID]", ConsoleColor.Magenta));
				IUVVD2kFINsy5h2mRqX.SPwkr0eD46(j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_id());
				MelonLogger.Log(string.Concat("Avatar id is : ", j7Ipg1kwBirUGgO7rnG.B0okC2vDkL().Method_Public_get_ApiAvatar_0().get_id()));
			}, "", nullable12, nullable, false);
		}
	}
}