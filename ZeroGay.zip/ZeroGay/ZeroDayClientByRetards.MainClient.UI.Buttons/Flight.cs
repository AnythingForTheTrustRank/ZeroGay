using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using MelonLoader;
using QQvuud280hKNN3PPqgR;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class Flight
	{
		public static object flycor;

		internal static Flight Go8pUhDSX7lv7R92PA8;

		public Flight()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool db0hPBDbVcm7xNDRIL8()
		{
			return Flight.Go8pUhDSX7lv7R92PA8 == null;
		}

		public static IEnumerator Fly()
		{
			return new Flight.<Fly>d__0(0);
		}

		public static void StartFlight()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Flight, 1f, 0f, "FLY", () => {
				Flight.flycor = MelonCoroutines.Start(Flight.Fly());
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
			}, () => {
				MelonCoroutines.Stop(Flight.flycor);
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(true);
			}, "", false);
			QMNestedButton flight = MainMenuLol.Flight;
			string str = string.Format("Speed: [{0}]", bUqSA52JHZYZDdqgmrb.HDL2VCgmq2);
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(flight, 2f, 0f, str, () => {
			}, "", nullable1, nullable, false);
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(MainMenuLol.Flight, 1f, 1f, "+5 speed", () => {
				bUqSA52JHZYZDdqgmrb.HDL2VCgmq2 += 5f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", bUqSA52JHZYZDdqgmrb.HDL2VCgmq2));
			}, "", nullable2, nullable, false);
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(MainMenuLol.Flight, 1f, 2f, "+3 speed", () => {
				bUqSA52JHZYZDdqgmrb.HDL2VCgmq2 += 3f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", bUqSA52JHZYZDdqgmrb.HDL2VCgmq2));
			}, "", nullable3, nullable, false);
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(MainMenuLol.Flight, 1f, 3f, "+1", () => {
				bUqSA52JHZYZDdqgmrb.HDL2VCgmq2 += 1f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", bUqSA52JHZYZDdqgmrb.HDL2VCgmq2));
			}, "", nullable4, nullable, false);
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(MainMenuLol.Flight, 4f, 1f, "-5 speed", () => {
				bUqSA52JHZYZDdqgmrb.HDL2VCgmq2 -= 5f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", bUqSA52JHZYZDdqgmrb.HDL2VCgmq2));
			}, "", nullable5, nullable, false);
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(MainMenuLol.Flight, 4f, 2f, "-3 speed", () => {
				bUqSA52JHZYZDdqgmrb.HDL2VCgmq2 -= 3f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", bUqSA52JHZYZDdqgmrb.HDL2VCgmq2));
			}, "", nullable6, nullable, false);
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(MainMenuLol.Flight, 4f, 3f, "-1 speed", () => {
				bUqSA52JHZYZDdqgmrb.HDL2VCgmq2 -= 1f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", bUqSA52JHZYZDdqgmrb.HDL2VCgmq2));
			}, "", nullable7, nullable, false);
		}

		internal static Flight UR5eIiDNx1w4w0aKMt3()
		{
			return Flight.Go8pUhDSX7lv7R92PA8;
		}
	}
}