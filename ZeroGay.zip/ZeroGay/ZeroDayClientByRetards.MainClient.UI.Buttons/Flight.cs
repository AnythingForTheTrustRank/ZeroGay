using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using eL2rvyIAIoeaIZaymrE;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class Flight
	{
		public static object flycor;

		private static Flight aF8sZ2mscwFN59Qai6R;

		public Flight()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static IEnumerator Fly()
		{
			while (true)
			{
				if (Input.GetKey(101) && VRCPlayer.get_field_Internal_Static_VRCPlayer_0() != null)
				{
					Transform _transform = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
					_transform.set_position(_transform.get_position() + new Vector3(0f, PBImh1IKb8f4RXFi60D.raKIEp2Pim * Time.get_deltaTime(), 0f));
				}
				if (Input.GetKey(113) && VRCPlayer.get_field_Internal_Static_VRCPlayer_0() != null)
				{
					Transform transform = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
					transform.set_position(transform.get_position() - new Vector3(0f, PBImh1IKb8f4RXFi60D.raKIEp2Pim * Time.get_deltaTime(), 0f));
				}
				if (Input.GetKey(119) && VRCPlayer.get_field_Internal_Static_VRCPlayer_0() != null)
				{
					Transform _transform1 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
					_transform1.set_position(_transform1.get_position() + ((VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform().get_forward() * PBImh1IKb8f4RXFi60D.raKIEp2Pim) * Time.get_deltaTime()));
				}
				if (Input.GetKey(115) && VRCPlayer.get_field_Internal_Static_VRCPlayer_0() != null)
				{
					Transform transform1 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
					transform1.set_position(transform1.get_position() - ((VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform().get_forward() * PBImh1IKb8f4RXFi60D.raKIEp2Pim) * Time.get_deltaTime()));
				}
				if (Input.GetKey(97) && VRCPlayer.get_field_Internal_Static_VRCPlayer_0() != null)
				{
					Transform _transform2 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
					_transform2.set_position(_transform2.get_position() - ((VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform().get_right() * PBImh1IKb8f4RXFi60D.raKIEp2Pim) * Time.get_deltaTime()));
				}
				if (Input.GetKey(100) && VRCPlayer.get_field_Internal_Static_VRCPlayer_0() != null)
				{
					Transform transform2 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
					transform2.set_position(transform2.get_position() + ((VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform().get_right() * PBImh1IKb8f4RXFi60D.raKIEp2Pim) * Time.get_deltaTime()));
				}
				if (Networking.get_LocalPlayer().IsUserInVR())
				{
					if (Input.GetAxis("Vertical") != 0f)
					{
						Transform _transform3 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
						_transform3.set_position(_transform3.get_position() + (((VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform().get_forward() * Input.GetAxis("Vertical")) * PBImh1IKb8f4RXFi60D.raKIEp2Pim) * Time.get_deltaTime()));
					}
					if (Input.GetAxis("Horizontal") != 0f)
					{
						Transform transform3 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
						transform3.set_position(transform3.get_position() + (((VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform().get_right() * Input.GetAxis("Horizontal")) * PBImh1IKb8f4RXFi60D.raKIEp2Pim) * Time.get_deltaTime()));
					}
					if (Input.GetAxis("Oculus_CrossPlatform_SecondaryThumbstickVertical") != 0f)
					{
						Transform _transform4 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().get_transform();
						_transform4.set_position(_transform4.get_position() + new Vector3(0f, PBImh1IKb8f4RXFi60D.raKIEp2Pim * Time.get_deltaTime() * Input.GetAxis("Oculus_CrossPlatform_SecondaryThumbstickVertical"), 0f));
					}
				}
				Networking.get_LocalPlayer().SetVelocity(Vector3.get_zero());
				yield return null;
			}
		}

		internal static bool inCswBmMogmHTUSPFVp()
		{
			return Flight.aF8sZ2mscwFN59Qai6R == null;
		}

		public static void StartFlight()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Flight, 1f, 0f, "FLY", () => {
				Flight.flycor = MelonCoroutines.Start(Flight.Fly());
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(false);
			}, () => {
				MelonCoroutines.Stop(Flight.flycor);
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(true);
			}, "", false);
			QMNestedButton flight = MainMenuLol.Flight;
			string str = string.Format("Speed: [{0}]", PBImh1IKb8f4RXFi60D.raKIEp2Pim);
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(flight, 2f, 0f, str, () => {
			}, "", nullable1, nullable, false);
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(MainMenuLol.Flight, 1f, 1f, "+5 speed", () => {
				PBImh1IKb8f4RXFi60D.raKIEp2Pim += 5f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", PBImh1IKb8f4RXFi60D.raKIEp2Pim));
			}, "", nullable2, nullable, false);
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(MainMenuLol.Flight, 1f, 2f, "+3 speed", () => {
				PBImh1IKb8f4RXFi60D.raKIEp2Pim += 3f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", PBImh1IKb8f4RXFi60D.raKIEp2Pim));
			}, "", nullable3, nullable, false);
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(MainMenuLol.Flight, 1f, 3f, "+1", () => {
				PBImh1IKb8f4RXFi60D.raKIEp2Pim += 1f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", PBImh1IKb8f4RXFi60D.raKIEp2Pim));
			}, "", nullable4, nullable, false);
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(MainMenuLol.Flight, 4f, 1f, "-5 speed", () => {
				PBImh1IKb8f4RXFi60D.raKIEp2Pim -= 5f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", PBImh1IKb8f4RXFi60D.raKIEp2Pim));
			}, "", nullable5, nullable, false);
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(MainMenuLol.Flight, 4f, 2f, "-3 speed", () => {
				PBImh1IKb8f4RXFi60D.raKIEp2Pim -= 3f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", PBImh1IKb8f4RXFi60D.raKIEp2Pim));
			}, "", nullable6, nullable, false);
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(MainMenuLol.Flight, 4f, 3f, "-1 speed", () => {
				PBImh1IKb8f4RXFi60D.raKIEp2Pim -= 1f;
				qMSingleButton.SetButtonText(string.Format("Speed: [{0}]", PBImh1IKb8f4RXFi60D.raKIEp2Pim));
			}, "", nullable7, nullable, false);
		}

		internal static Flight vMFiY4m7nA5VO3cY8b8()
		{
			return Flight.aF8sZ2mscwFN59Qai6R;
		}
	}
}