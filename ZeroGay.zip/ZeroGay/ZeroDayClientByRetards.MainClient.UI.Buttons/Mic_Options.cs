using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class Mic_Options
	{
		private static Mic_Options gKIYeGgyNI3cZvrlPGD;

		public Mic_Options()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static Mic_Options brRHkCg7w862L37O0gb()
		{
			return Mic_Options.gKIYeGgyNI3cZvrlPGD;
		}

		public static void StartMicOptions()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.MicOptions, 1f, 0f, "Loud Mic", () => USpeaker.set_field_Internal_Static_Single_1(float.MaxValue), () => USpeaker.set_field_Internal_Static_Single_1(1f), "", false);
			QMNestedButton micOptions = MainMenuLol.MicOptions;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(micOptions, 1f, 1f, "8k Bitrate", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [8K]", ConsoleColor.Magenta));
				Utils.CurrentUser.Method_Public_get_USpeaker_0().set_field_Public_BitRate_0(0);
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton = MainMenuLol.MicOptions;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton, 1f, 2f, "16k Bitrate", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [16K]", ConsoleColor.Magenta));
				Utils.CurrentUser.Method_Public_get_USpeaker_0().set_field_Public_BitRate_0(2);
			}, "", nullable2, nullable, false);
			QMNestedButton micOptions1 = MainMenuLol.MicOptions;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(micOptions1, 1f, 3f, "18k Bitrate", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [18K]", ConsoleColor.Magenta));
				Utils.CurrentUser.Method_Public_get_USpeaker_0().set_field_Public_BitRate_0(3);
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton1 = MainMenuLol.MicOptions;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton1, 2f, 0f, "24k Bitrate", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [24K]", ConsoleColor.Magenta));
				Utils.CurrentUser.Method_Public_get_USpeaker_0().set_field_Public_BitRate_0(5);
			}, "", nullable4, nullable, false);
		}

		internal static bool x7Z75xgTRcahOJ46BS1()
		{
			return Mic_Options.gKIYeGgyNI3cZvrlPGD == null;
		}
	}
}