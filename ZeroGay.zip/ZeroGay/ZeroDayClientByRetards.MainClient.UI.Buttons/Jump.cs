using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using QQvuud280hKNN3PPqgR;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class Jump
	{
		internal static Jump p08S6CgYB0tLM3XvXHP;

		public Jump()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool K87iXOgB5s2p7eLyaDP()
		{
			return Jump.p08S6CgYB0tLM3XvXHP == null;
		}

		public static void StartJump()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Jump, 1f, 0f, "Infinite Jump", () => bUqSA52JHZYZDdqgmrb.T0d2LirjRQ = true, () => bUqSA52JHZYZDdqgmrb.T0d2LirjRQ = false, "  ", false);
			QMNestedButton jump = MainMenuLol.Jump;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(jump, 1f, 1f, "Force Jump", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Force Jump]", ConsoleColor.Magenta));
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
			}, "", nullable1, nullable, false);
		}

		internal static Jump stbmN8gr30WS21RGm6Q()
		{
			return Jump.p08S6CgYB0tLM3XvXHP;
		}
	}
}