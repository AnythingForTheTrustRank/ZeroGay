using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using eL2rvyIAIoeaIZaymrE;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class Jump
	{
		private static Jump BGWmSImbL1LFEFwu7qm;

		public Jump()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static Jump LW7JATmUNVHEG0qGJMI()
		{
			return Jump.BGWmSImbL1LFEFwu7qm;
		}

		public static void StartJump()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Jump, 1f, 0f, "Infinite Jump", () => PBImh1IKb8f4RXFi60D.uJXIzcVFys = true, () => PBImh1IKb8f4RXFi60D.uJXIzcVFys = false, "  ", false);
			QMNestedButton jump = MainMenuLol.Jump;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(jump, 1f, 1f, "Force Jump", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Force Jump]", ConsoleColor.Magenta));
				Networking.get_LocalPlayer().SetJumpImpulse(4f);
			}, "", nullable1, nullable, false);
		}

		internal static bool swV2U0mh8xHSHvdtxdu()
		{
			return Jump.BGWmSImbL1LFEFwu7qm == null;
		}
	}
}