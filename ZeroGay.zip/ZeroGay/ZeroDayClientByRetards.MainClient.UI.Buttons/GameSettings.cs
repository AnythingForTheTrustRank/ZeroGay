using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using Il2CppSystem.Diagnostics;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class GameSettings
	{
		internal static GameSettings NUbyP2DzM0NldT5fFNY;

		public GameSettings()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static GameSettings McwSqogcRlqnH0FDERj()
		{
			return GameSettings.NUbyP2DzM0NldT5fFNY;
		}

		public static void StartGameSettings()
		{
			QMNestedButton qMNestedButton = MainMenuLol.gamesetting;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "Exit Game", () => Process.GetCurrentProcess().Kill(), "", nullable1, nullable, false);
			QMNestedButton qMNestedButton1 = MainMenuLol.gamesetting;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton1, 1f, 1f, "Unlimit FPS", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Unlimit FPS]", ConsoleColor.Magenta));
				Application.set_targetFrameRate(999);
			}, "", nullable2, nullable, false);
		}

		internal static bool VYKhvHg56LPOkU1QtoP()
		{
			return GameSettings.NUbyP2DzM0NldT5fFNY == null;
		}
	}
}