using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using Il2CppSystem.Diagnostics;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class GameSettings
	{
		internal static GameSettings XuYM8em4Rm9nYQ8PgTA;

		public GameSettings()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool AkNjfdmIobCudUIKXsi()
		{
			return GameSettings.XuYM8em4Rm9nYQ8PgTA == null;
		}

		internal static GameSettings dHyiHYm61fZpNQ8IOmL()
		{
			return GameSettings.XuYM8em4Rm9nYQ8PgTA;
		}

		public static void StartGameSettings()
		{
			QMNestedButton qMNestedButton = MainMenuLol.gamesetting;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "Exit Game", () => Process.GetCurrentProcess().Kill(), "", nullable1, nullable, false);
			QMNestedButton qMNestedButton1 = MainMenuLol.gamesetting;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton1, 1f, 1f, "Unlimit FPS", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Unlimit FPS]", ConsoleColor.Magenta));
				Application.set_targetFrameRate(999);
			}, "", nullable2, nullable, false);
		}
	}
}