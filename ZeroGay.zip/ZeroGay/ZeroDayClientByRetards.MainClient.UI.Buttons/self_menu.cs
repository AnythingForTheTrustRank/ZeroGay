using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class self_menu
	{
		public static List<GameObject> AllClones;

		private static self_menu l3whMDmR1Emu7vVuEj1;

		static self_menu()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			self_menu.AllClones = new List<GameObject>();
		}

		public self_menu()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static self_menu gdWevjmrXyiQVWxmIMJ()
		{
			return self_menu.l3whMDmR1Emu7vVuEj1;
		}

		internal static bool OuhSfOmppuLNr1am7jg()
		{
			return self_menu.l3whMDmR1Emu7vVuEj1 == null;
		}

		public static void StartSelfMenu()
		{
			QMNestedButton qMNestedButton = MainMenuLol.selfmenu;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "Clone Self", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Clone Self]", ConsoleColor.Magenta));
				GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().Method_Public_get_VRCAvatarManager_0().get_field_Private_GameObject_0(), null, true);
				Animator component = gameObject.GetComponent<Animator>();
				if (component != null && component.get_isHuman())
				{
					Transform boneTransform = component.GetBoneTransform(10);
					if (boneTransform != null)
					{
						boneTransform.set_localScale(Vector3.get_one());
					}
				}
				gameObject.set_name("Cloned");
				component.set_enabled(false);
				gameObject.GetComponent<FullBodyBipedIK>().set_enabled(false);
				gameObject.GetComponent<LimbIK>().set_enabled(false);
				gameObject.GetComponent<VRIK>().set_enabled(false);
				gameObject.GetComponent<LookTargetController>().set_enabled(false);
				gameObject.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position());
				gameObject.get_transform().set_rotation(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_rotation());
				self_menu.AllClones.Add(gameObject);
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton1 = MainMenuLol.selfmenu;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton1, 1f, 1f, "Destroy All Clone(s)", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Destroy All Clone(s)]", ConsoleColor.Magenta));
				List<GameObject>.Enumerator enumerator = self_menu.AllClones.GetEnumerator();
				while (enumerator.MoveNext())
				{
					UnityEngine.Object.Destroy(enumerator.get_Current());
				}
			}, "", nullable2, nullable, false);
		}
	}
}