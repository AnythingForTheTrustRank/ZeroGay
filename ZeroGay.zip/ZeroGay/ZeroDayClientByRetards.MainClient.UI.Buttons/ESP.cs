using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using MelonLoader;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class ESP
	{
		public static QMNestedButton firendspage;

		public static QMNestedButton otherspage;

		internal static ESP ag96EEDg8cFyvab7Ue9;

		public ESP()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool M2ydr3D4ST0im8YbN7c()
		{
			return ESP.ag96EEDg8cFyvab7Ue9 == null;
		}

		public static void StartESP()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Esp, 1f, 0f, "Pickups Esp", () => {
				MelonCoroutines.Start(Esp.togglepickupsesp());
				MainConfigSettings.Instance.PickupsESP = true;
				MainConfigSettings.Instance.BpCys1iF5G();
			}, () => {
				MainConfigSettings.Instance.PickupsESP = false;
				MainConfigSettings.Instance.BpCys1iF5G();
			}, "", MainConfigSettings.Instance.PickupsESP);
			QMToggleButton qMToggleButton1 = new QMToggleButton(MainMenuLol.Esp, 1f, 1f, "Player Esp", () => {
				Esp.ToggleESP(true);
				MainConfigSettings.Instance.PlayerESP = true;
				MainConfigSettings.Instance.BpCys1iF5G();
			}, () => {
				Esp.ToggleESP(false);
				MainConfigSettings.Instance.PlayerESP = false;
				MainConfigSettings.Instance.BpCys1iF5G();
			}, "", MainConfigSettings.Instance.PlayerESP);
			ESP.firendspage = new QMNestedButton(MainMenuLol.Esp, "Friends -> ", 4f, 3f, "", "Friends Highlights");
			ESP.otherspage = new QMNestedButton(MainMenuLol.Esp, "others -> ", 3f, 3f, "", "Friends Highlights");
			QMNestedButton qMNestedButton = ESP.firendspage;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "Red", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Red]", ConsoleColor.Magenta));
				Esp._friendsHighlights.set_highlightColor(Color.get_red());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable1, nullable, false);
			QMNestedButton qMNestedButton1 = ESP.firendspage;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton1, 1f, 1f, "Blue", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Blue]", ConsoleColor.Magenta));
				Esp._friendsHighlights.set_highlightColor(Color.get_blue());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable2, nullable, false);
			QMNestedButton qMNestedButton2 = ESP.firendspage;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton2, 1f, 2f, "Cyan", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Cyan]", ConsoleColor.Magenta));
				Esp._friendsHighlights.set_highlightColor(Color.get_cyan());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable3, nullable, false);
			QMNestedButton qMNestedButton3 = ESP.firendspage;
			nullable = null;
			Color? nullable4 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton3 = new QMSingleButton(qMNestedButton3, 1f, 3f, "Green", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Green]", ConsoleColor.Magenta));
				Esp._friendsHighlights.set_highlightColor(Color.get_green());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable4, nullable, false);
			QMNestedButton qMNestedButton4 = ESP.firendspage;
			nullable = null;
			Color? nullable5 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton4 = new QMSingleButton(qMNestedButton4, 2f, 0f, "Magenta", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Magenta]", ConsoleColor.Magenta));
				Esp._friendsHighlights.set_highlightColor(Color.get_magenta());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable5, nullable, false);
			QMNestedButton qMNestedButton5 = ESP.firendspage;
			nullable = null;
			Color? nullable6 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton5 = new QMSingleButton(qMNestedButton5, 2f, 1f, "White", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [White]", ConsoleColor.Magenta));
				Esp._friendsHighlights.set_highlightColor(Color.get_white());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable6, nullable, false);
			QMNestedButton qMNestedButton6 = ESP.firendspage;
			nullable = null;
			Color? nullable7 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton6 = new QMSingleButton(qMNestedButton6, 2f, 2f, "Yellow", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Yellow]", ConsoleColor.Magenta));
				Esp._friendsHighlights.set_highlightColor(Color.get_yellow());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable7, nullable, false);
			QMNestedButton qMNestedButton7 = ESP.otherspage;
			nullable = null;
			Color? nullable8 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton7 = new QMSingleButton(qMNestedButton7, 1f, 0f, "Red", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Red]", ConsoleColor.Magenta));
				Esp._othersHighlights.set_highlightColor(Color.get_red());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable8, nullable, false);
			QMNestedButton qMNestedButton8 = ESP.otherspage;
			nullable = null;
			Color? nullable9 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton8 = new QMSingleButton(qMNestedButton8, 1f, 1f, "Blue", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Blue]", ConsoleColor.Magenta));
				Esp._othersHighlights.set_highlightColor(Color.get_blue());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable9, nullable, false);
			QMNestedButton qMNestedButton9 = ESP.otherspage;
			nullable = null;
			Color? nullable10 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton9 = new QMSingleButton(qMNestedButton9, 1f, 2f, "Cyan", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Cyan]", ConsoleColor.Magenta));
				Esp._othersHighlights.set_highlightColor(Color.get_cyan());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable10, nullable, false);
			QMNestedButton qMNestedButton10 = ESP.otherspage;
			nullable = null;
			Color? nullable11 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton10 = new QMSingleButton(qMNestedButton10, 1f, 3f, "Green", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Green]", ConsoleColor.Magenta));
				Esp._othersHighlights.set_highlightColor(Color.get_green());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable11, nullable, false);
			QMNestedButton qMNestedButton11 = ESP.otherspage;
			nullable = null;
			Color? nullable12 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton11 = new QMSingleButton(qMNestedButton11, 2f, 0f, "Magenta", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Magenta]", ConsoleColor.Magenta));
				Esp._othersHighlights.set_highlightColor(Color.get_magenta());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable12, nullable, false);
			QMNestedButton qMNestedButton12 = ESP.otherspage;
			nullable = null;
			Color? nullable13 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton12 = new QMSingleButton(qMNestedButton12, 2f, 1f, "White", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [White]", ConsoleColor.Magenta));
				Esp._othersHighlights.set_highlightColor(Color.get_white());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable13, nullable, false);
			QMNestedButton qMNestedButton13 = ESP.otherspage;
			nullable = null;
			Color? nullable14 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton13 = new QMSingleButton(qMNestedButton13, 2f, 2f, "Yellow", () => {
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Pressed On [Yellow]", ConsoleColor.Magenta));
				Esp._othersHighlights.set_highlightColor(Color.get_yellow());
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}, "", nullable14, nullable, false);
		}

		internal static ESP t9LNMFDjFnhodMS8LiD()
		{
			return ESP.ag96EEDg8cFyvab7Ue9;
		}
	}
}