using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class Loggers
	{
		internal static Loggers CTqygUmTGUDydLwYUL9;

		public Loggers()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static Loggers h1QvFAma313VgEXBPqV()
		{
			return Loggers.CTqygUmTGUDydLwYUL9;
		}

		public static void StartLoggers()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Loggers, 1f, 0f, "Log JOIN/LEAVE", () => {
				MainConfigSettings.Instance.joinleavelogger = true;
				MainConfigSettings.Instance.SfuQjPNsy4();
			}, () => {
				MainConfigSettings.Instance.joinleavelogger = false;
				MainConfigSettings.Instance.SfuQjPNsy4();
			}, "", MainConfigSettings.Instance.joinleavelogger);
		}

		internal static bool Tq1DUemvn5sBMeNR8fZ()
		{
			return Loggers.CTqygUmTGUDydLwYUL9 == null;
		}
	}
}