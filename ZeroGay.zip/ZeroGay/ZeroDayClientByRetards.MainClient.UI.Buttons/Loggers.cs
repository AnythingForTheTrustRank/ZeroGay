using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using System;
using System.Runtime.CompilerServices;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayClientByRetards.MainClient.UI.Buttons
{
	public class Loggers
	{
		private static Loggers Me6E6rg2cwMxTyljrng;

		public Loggers()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static Loggers LZZwP4gaoSksIeGd6XI()
		{
			return Loggers.Me6E6rg2cwMxTyljrng;
		}

		public static void StartLoggers()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(MainMenuLol.Loggers, 1f, 0f, "Log JOIN/LEAVE", () => {
				MainConfigSettings.Instance.joinleavelogger = true;
				MainConfigSettings.Instance.BpCys1iF5G();
			}, () => {
				MainConfigSettings.Instance.joinleavelogger = false;
				MainConfigSettings.Instance.BpCys1iF5G();
			}, "", MainConfigSettings.Instance.joinleavelogger);
		}

		internal static bool yAkhqRgMDA3SnOEOR7M()
		{
			return Loggers.Me6E6rg2cwMxTyljrng == null;
		}
	}
}