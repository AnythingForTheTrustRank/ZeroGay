using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using OD9m6O9bemNUx4rutsX;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC.Networking;

namespace eXbAoq9vaQvv94p1KtX
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class M3Erbc9T5Ws4s3HVPE2
	{
		private static M3Erbc9T5Ws4s3HVPE2 D7mJ7T5zruDiYmDFkB8;

		public M3Erbc9T5Ws4s3HVPE2()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool BKgBSwdqtGsecjDJMfv()
		{
			return M3Erbc9T5Ws4s3HVPE2.D7mJ7T5zruDiYmDFkB8 == null;
		}

		internal static M3Erbc9T5Ws4s3HVPE2 PJMkr8dkVSj7V3cRACi()
		{
			return M3Erbc9T5Ws4s3HVPE2.D7mJ7T5zruDiYmDFkB8;
		}

		public static bool y4s9aVvupi(ref string u0020, object u0020)
		{
			bool flag;
			if (eoiOZ192r1eDKM8RS8c.lgw9UORmhE)
			{
				flag = (u0020 == "BackStabDamage" ? false : true);
			}
			else
			{
				flag = true;
			}
			return flag;
		}
	}
}