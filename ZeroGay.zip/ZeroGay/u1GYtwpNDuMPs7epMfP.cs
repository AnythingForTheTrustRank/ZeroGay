using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Quaternion u1GYtwpNDuMPs7epMfP(object );