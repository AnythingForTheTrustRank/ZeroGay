using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.DataModel;

internal delegate IUser v8cIHGUmSIG3fysBqsB(object object_0);