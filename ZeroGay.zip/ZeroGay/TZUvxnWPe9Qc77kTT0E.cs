using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Quaternion TZUvxnWPe9Qc77kTT0E(object object_0);