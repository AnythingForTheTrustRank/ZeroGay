using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void Ksc0Y7LrQFtmp41wcj1(IntPtr );