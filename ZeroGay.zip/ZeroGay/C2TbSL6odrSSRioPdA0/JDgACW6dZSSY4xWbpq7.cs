using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using VRC.Udon;

namespace C2TbSL6odrSSRioPdA0
{
	internal class JDgACW6dZSSY4xWbpq7
	{
		private static JDgACW6dZSSY4xWbpq7 E0npM5deEvL7sE7jKDO;

		public JDgACW6dZSSY4xWbpq7()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static JDgACW6dZSSY4xWbpq7 ah9qTBdx1hTCiIY7C1h()
		{
			return JDgACW6dZSSY4xWbpq7.E0npM5deEvL7sE7jKDO;
		}

		public static void gUY6mjkIbj()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Udon"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "_TeleportToBedroomOutside1");
			}
		}

		internal static bool l6DMWSdf0OOvbalIfxv()
		{
			return JDgACW6dZSSY4xWbpq7.E0npM5deEvL7sE7jKDO == null;
		}
	}
}