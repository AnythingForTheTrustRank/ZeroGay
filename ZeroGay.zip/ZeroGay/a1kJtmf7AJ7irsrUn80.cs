using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Sprite a1kJtmf7AJ7irsrUn80(object );