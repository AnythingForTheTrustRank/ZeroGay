using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate AsyncTaskMethodBuilder E8kDyjFVhpMeguJybI2();