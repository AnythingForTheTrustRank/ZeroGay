using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void I0PFW0ufKdf2aITk3X9(object object_0, Vector3 vector3_0, Vector3 vector3_1, float float_0);