using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object NmYdb3VE0NrsXDYYHuh(Type , short );