using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void qaSUqSWg9ZM2F8AIpFf(ref LayerMask layerMask_0, int int_0);