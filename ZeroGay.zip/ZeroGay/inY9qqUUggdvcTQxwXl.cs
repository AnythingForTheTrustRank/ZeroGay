using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using VRC.SDKBase;

internal delegate void inY9qqUUggdvcTQxwXl(VRCPlayerApi vrcplayerApi_0, GameObject gameObject_0);