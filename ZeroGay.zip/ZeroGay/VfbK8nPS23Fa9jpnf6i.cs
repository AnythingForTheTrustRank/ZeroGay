using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void VfbK8nPS23Fa9jpnf6i(object object_0, string string_0, Color color_0);