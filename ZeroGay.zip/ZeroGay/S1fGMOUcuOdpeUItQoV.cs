using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string S1fGMOUcuOdpeUItQoV(string[] string_0);