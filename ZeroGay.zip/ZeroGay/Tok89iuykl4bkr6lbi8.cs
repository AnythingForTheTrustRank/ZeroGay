using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void Tok89iuykl4bkr6lbi8(object object_0, Transform transform_0, bool bool_0);