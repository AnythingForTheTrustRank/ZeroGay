using b3eD5DgJPcASx0xfHYB;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace AjKJNiNP8wHEZ5OOJcB
{
	internal class sMmqZTNBUlpd2Adbntk
	{
		public GameObject EIINAdQR29;

		public Text pZeNVi4A6H;

		private static sMmqZTNBUlpd2Adbntk JCcefkDQCTrMXaVkrM5;

		public sMmqZTNBUlpd2Adbntk(sMmqZTNBUlpd2Adbntk.M1nIarghQmoOh2pDVOS u0020, string u0020, float u0020, float u0020, string u0020, Action u0020, float u0020 = 1f, float u0020 = 1f)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.k28NlWZxka(u0020, yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find(u0020), u0020, u0020, u0020, u0020, u0020, u0020);
		}

		public sMmqZTNBUlpd2Adbntk(sMmqZTNBUlpd2Adbntk.M1nIarghQmoOh2pDVOS u0020, Transform u0020, float u0020, float u0020, string u0020, Action u0020, float u0020 = 1f, float u0020 = 1f)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.k28NlWZxka(u0020, u0020, u0020, u0020, u0020, u0020, u0020, u0020);
		}

		public void aOiN0I9o2L(bool u0020)
		{
			this.EIINAdQR29.SetActive(u0020);
		}

		public void bwONjAplh3(bool u0020)
		{
			this.EIINAdQR29.GetComponent<Button>().set_interactable(u0020);
		}

		public void eAdNF4FuoV(Vector2 u0020)
		{
			this.EIINAdQR29.GetComponent<RectTransform>().set_anchoredPosition(u0020);
		}

		public void fcaNrm2CmW(Sprite u0020)
		{
			this.EIINAdQR29.GetComponentInChildren<Image>().set_sprite(u0020);
		}

		public void fnKNnZUoCV(Color u0020)
		{
			ColorBlock _colors = this.EIINAdQR29.GetComponent<Button>().get_colors();
			ColorBlock colorBlock = new ColorBlock();
			colorBlock.set_colorMultiplier(_colors.get_colorMultiplier());
			colorBlock.set_disabledColor(_colors.get_disabledColor());
			colorBlock.set_fadeDuration(_colors.get_fadeDuration());
			colorBlock.set_highlightedColor(u0020);
			colorBlock.set_normalColor(u0020);
			colorBlock.set_pressedColor(_colors.get_pressedColor());
			this.EIINAdQR29.GetComponent<Button>().set_colors(colorBlock);
		}

		internal static bool HgfouMDw2A8GLx9eUTW()
		{
			return sMmqZTNBUlpd2Adbntk.JCcefkDQCTrMXaVkrM5 == null;
		}

		public Text HRXNRnE8eT()
		{
			return this.pZeNVi4A6H;
		}

		private void k28NlWZxka(sMmqZTNBUlpd2Adbntk.M1nIarghQmoOh2pDVOS u0020, Transform u0020, float u0020, float u0020, string u0020, Action u0020, float u0020, float u0020)
		{
			switch (u0020)
			{
				case 0:
				{
					this.EIINAdQR29 = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find("Social/UserProfileAndStatusSection/Status/EditStatusButton").get_gameObject(), u0020);
					this.pZeNVi4A6H = this.EIINAdQR29.get_transform().Find("Text").GetComponent<Text>();
					this.pZeNVi4A6H.get_transform().SetAsLastSibling();
					break;
				}
				case 1:
				{
					this.EIINAdQR29 = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find("Avatar/Change Button").get_gameObject(), u0020);
					this.pZeNVi4A6H = this.EIINAdQR29.get_transform().Find("Label").GetComponent<Text>();
					break;
				}
				case 2:
				{
					this.EIINAdQR29 = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find("Settings/Footer/Exit").get_gameObject(), u0020);
					this.pZeNVi4A6H = this.EIINAdQR29.get_transform().Find("Text").GetComponent<Text>();
					break;
				}
				case 3:
				{
					this.EIINAdQR29 = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find("WorldInfo/WorldButtons/PortalButton").get_gameObject(), u0020);
					this.pZeNVi4A6H = this.EIINAdQR29.get_transform().Find("Text").GetComponent<Text>();
					break;
				}
				default:
				{
					this.EIINAdQR29 = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find("Social/UserProfileAndStatusSection/Status/EditStatusButton").get_gameObject(), u0020);
					this.pZeNVi4A6H = this.EIINAdQR29.get_transform().Find("Text").GetComponent<Text>();
					break;
				}
			}
			this.EIINAdQR29.set_name(string.Format("{0}-SMButton-{1}", "WTFBlaze", yLWOmZwmRqSychwym35.Fn2N9KXqf1()));
			ColorBlock _colors = this.EIINAdQR29.GetComponent<Button>().get_colors();
			Button component = this.EIINAdQR29.GetComponent<Button>();
			ColorBlock colorBlock = new ColorBlock();
			colorBlock.set_colorMultiplier(_colors.get_colorMultiplier());
			colorBlock.set_disabledColor(_colors.get_disabledColor());
			colorBlock.set_fadeDuration(_colors.get_fadeDuration());
			colorBlock.set_highlightedColor(_colors.get_highlightedColor());
			colorBlock.set_normalColor(_colors.get_normalColor());
			colorBlock.set_selectedColor(_colors.get_normalColor());
			colorBlock.set_pressedColor(_colors.get_pressedColor());
			component.set_colors(colorBlock);
			this.EIINAdQR29.GetComponent<Button>().set_onClick(new Button.ButtonClickedEvent());
			this.EIINAdQR29.GetComponent<Button>().get_onClick().AddListener(u0020);
			this.EIINAdQR29.get_transform().set_localScale(new Vector3(1f, 1f, 1f));
			RectTransform rectTransform = this.EIINAdQR29.GetComponent<RectTransform>();
			rectTransform.set_sizeDelta(rectTransform.get_sizeDelta() / new Vector2(u0020, u0020));
			this.w5xNZ7KCJ2(u0020);
			this.eAdNF4FuoV(new Vector2(u0020, u0020));
			this.pZeNVi4A6H.set_color(Color.get_white());
			vBMVdGwfepiujjMKYNt.YN3w5jqh7o.Add(this);
		}

		internal static sMmqZTNBUlpd2Adbntk Mklj61DNR9x4tvKdGny()
		{
			return sMmqZTNBUlpd2Adbntk.JCcefkDQCTrMXaVkrM5;
		}

		public void OcUNx6NdXc(string u0020)
		{
			Material material = new Material(this.EIINAdQR29.GetComponentInChildren<Image>().get_material());
			material.set_shader(Shader.Find(u0020));
			this.EIINAdQR29.get_gameObject().GetComponentInChildren<Image>().set_material(material);
		}

		public Texture2D OJVN1lZFcI()
		{
			Texture2D texture2D = new Texture2D(this.EIINAdQR29.get_gameObject().GetComponent<Image>().get_mainTexture().get_width(), this.EIINAdQR29.get_gameObject().GetComponent<Image>().get_mainTexture().get_height(), 4, false);
			return texture2D;
		}

		private async Task Q30NfTrEZE(Image u0020, string u0020)
		{
			Sprite sprite;
			UnityWebRequest texture = UnityWebRequestTexture.GetTexture(u0020);
			UnityWebRequestAsyncOperation unityWebRequestAsyncOperation = texture.SendWebRequest();
			while (!unityWebRequestAsyncOperation.get_isDone())
			{
				await Task.Delay(33);
			}
			if (!texture.get_isNetworkError() && !texture.get_isHttpError())
			{
				sprite = Sprite.CreateSprite(DownloadHandlerTexture.GetContent(texture), new Rect(0f, 0f, (float)DownloadHandlerTexture.GetContent(texture).get_width(), (float)DownloadHandlerTexture.GetContent(texture).get_height()), Vector2.get_zero(), 100000f, 1000, 0, Vector4.get_zero(), false);
				u0020.set_sprite(sprite);
				u0020.set_color(Color.get_white());
				DownloadHandlerTexture.GetContent(texture);
			}
			texture = null;
			unityWebRequestAsyncOperation = null;
			sprite = null;
		}

		public GameObject RFTNpFDyRM()
		{
			return this.EIINAdQR29;
		}

		public void uq7NK02CHk(bool u0020)
		{
			this.EIINAdQR29.GetComponentInChildren<Image>().set_enabled(u0020);
		}

		public void Vq8NiJTwNh(Color u0020)
		{
			this.EIINAdQR29.GetComponentInChildren<Image>().set_color(u0020);
		}

		public void w5xNZ7KCJ2(string u0020)
		{
			this.pZeNVi4A6H.set_supportRichText(true);
			this.pZeNVi4A6H.set_text(u0020);
		}

		public async void w6jNeJa3ZL(string u0020)
		{
			sMmqZTNBUlpd2Adbntk.<SetImage>d__14 variable = null;
			AsyncVoidMethodBuilder asyncVoidMethodBuilder = AsyncVoidMethodBuilder.Create();
			asyncVoidMethodBuilder.Start<sMmqZTNBUlpd2Adbntk.<SetImage>d__14>(ref variable);
		}

		public enum M1nIarghQmoOh2pDVOS
		{

		}
	}
}