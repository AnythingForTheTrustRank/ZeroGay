using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.UI;

internal delegate Text X2GK1KEUDegY0Q1gvts();