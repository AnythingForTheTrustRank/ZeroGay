using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Core;

internal delegate ApiWorldInstance QhUlEHPxwZM8Kt0Eyx3();