using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate void Lnx5jq1c1l3saI4Rd99(ref AsyncTaskMethodBuilder asyncTaskMethodBuilder_0, Exception exception_0);