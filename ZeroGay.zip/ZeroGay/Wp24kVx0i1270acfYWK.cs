using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate RectTransform Wp24kVx0i1270acfYWK(object );