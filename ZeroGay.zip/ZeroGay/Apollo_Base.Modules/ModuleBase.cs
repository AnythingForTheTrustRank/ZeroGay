using Area51.Events;
using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using VRC;
using ZeroDayAPI;

namespace Apollo_Base.Modules
{
	public abstract class ModuleBase
	{
		internal static ModuleBase rhCqSA5OgusT5F1hoqy;

		protected ModuleBase()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static ModuleBase exWjHe5PFnRpTJqFcNx()
		{
			return ModuleBase.rhCqSA5OgusT5F1hoqy;
		}

		public virtual void HudInitialized()
		{
		}

		public virtual void OnGUI()
		{
		}

		public virtual void OnStart()
		{
			ZeroDayMain.Instance.OnAssetBundleLoadEventArray = ZeroDayMain.Instance.OnAssetBundleLoadEvents.ToArray();
		}

		public void OnUiInit()
		{
		}

		public virtual void OnUpdate()
		{
		}

		public virtual void PlayerJoined(Player player)
		{
		}

		public virtual void PlayerLeft(Player player)
		{
		}

		public virtual void QuickMenuInitialized()
		{
		}

		internal static bool QvLAvK5BAGsFJQpdU0A()
		{
			return ModuleBase.rhCqSA5OgusT5F1hoqy == null;
		}

		public virtual void SceneInitialized(int buildIndex, string sceneName)
		{
		}

		public virtual void SceneLoaded(int buildIndex, string sceneName)
		{
		}

		public virtual void SceneUnloaded(int buildIndex, string sceneName)
		{
		}

		public virtual void SocialMenuInitialized()
		{
		}

		public abstract void Start();
	}
}