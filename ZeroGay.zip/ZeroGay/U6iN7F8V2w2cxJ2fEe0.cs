using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void U6iN7F8V2w2cxJ2fEe0(UnityEngine.Object object_0);