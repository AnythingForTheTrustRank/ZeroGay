using AksgHVKH9UOXlBDvRpO;
using System;
using TMPro;

internal delegate void nGwvviXMQxWjpViEKCF(object object_0, TextAlignmentOptions textAlignmentOptions_0);