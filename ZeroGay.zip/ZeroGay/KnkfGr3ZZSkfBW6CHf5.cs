using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate bool KnkfGr3ZZSkfBW6CHf5(FieldInfo fieldInfo_0, FieldInfo fieldInfo_1);