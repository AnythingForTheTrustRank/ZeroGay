using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace KXsrfv838576XC2bCZx
{
	internal class MWNRsi8GYTaTweXXZ8t
	{
		public static string VhZ8I7QCiA;

		public static string Vi5860sNj6;

		public static string zvB8tTDitn;

		public static string RcY8QvaAtE;

		public static bool I748wh8ayC;

		public static bool Rng8NHcdvn;

		public static bool Yxl8CFaRfy;

		public static bool Kqu82a2psG;

		public static bool epi8b4kn4j;

		public static bool WaQ8hO49xf;

		public static bool hI08UwyyF7;

		public static bool RaP8TaYpZe;

		public static bool Lna8vPUAiT;

		public static bool De88acDBJG;

		public static bool oDW8gFeY59;

		public static bool IyG8WVuZkF;

		public static bool tbQ8uH49gv;

		public static bool aLA8SfrStH;

		public static bool gqq8Yat8l4;

		public static bool nMA8XrPkPY;

		public static bool we38OWOTrJ;

		public static string Gca8Bjie04;

		public static string Tba8PDfU7c;

		public static Color hch8lCsVvA;

		public static Color JOc8jgShSe;

		public static bool JfY8ZpbxQW;

		public static bool xqU8FfY5xC;

		public static bool jTo8i1kX2K;

		public static bool eBm80w8tXa;

		public static bool WQV8RiYbXK;

		public static bool zNZ8pqVoVp;

		public static bool C7s8rO8UZj;

		public static bool KPW8ngHkIs;

		public static bool RSC8eXinwN;

		public static bool MhS8fp6UC1;

		public static bool fZB8xRES0x;

		public static bool kmw81U1b89;

		public static int fRC8KS0sTf;

		public static bool gaa8AJmST7;

		public static bool r9Q8VkokAl;

		public static bool xPZ8LD7gA9;

		public static bool Jlg8JISId5;

		public static bool hoj85c9FfE;

		public static bool qEQ8d0MVZD;

		public static bool PiE8o3Vbbf;

		public static bool Ger8mkfRpd;

		public static bool wTA8DgFg7W;

		public static bool pNo8ctBSOV;

		public static bool thN8y2oxZA;

		public static bool FPv8EcQbQB;

		public static bool eUY8zlymLA;

		public static bool uXOHqCbxg2;

		public static bool IGNHk76ajb;

		public static bool bYqH8yBYxF;

		public static bool oybHHdNZJc;

		public static bool pflHG7Lb8A;

		public static bool lt5H3LxneR;

		public static bool n41H9XHiXM;

		public static bool OqwHsLGDJU;

		public static bool KOoHMEj5VM;

		public static bool ExKH7VH42F;

		public static bool YNNH4J6rvG;

		public static float yMXHIf2uyW;

		public static bool EhNH6we2kR;

		public static bool dPEHtNlN15;

		public static bool i27HQDpHjk;

		public static bool kEWHwCg8eW;

		public static bool Q5MHN6GDew;

		public static bool f5KHCsEeW9;

		public static bool IG2H2Tel5J;

		public static bool ifoHb60Pu5;

		public static float XnhHhGHslH;

		public static bool NfMHUb7Qcd;

		public static bool PpNHTUiSoN;

		public static bool VZUHvpxvLG;

		public static bool tPjHaujTYS;

		public static bool DrWHgOqjpe;

		public static bool Lm0HW6M5Il;

		public static bool eaMHuW9rdf;

		public static bool rHIHSCWVgn;

		public static bool XxRHYbw5XP;

		public static bool v9KHXEfKVt;

		public static bool kPIHON31dq;

		public static bool F4pHBYV5SK;

		public static bool KIPHP4Owa2;

		public static bool xYLHl2IPEa;

		public static bool lSxHjjWZuV;

		public static bool gcIHZbisJt;

		public static bool WkeHFWghtA;

		public static bool wtpHiaCDtW;

		public static bool DwfH0emPW5;

		public static bool gTkHRAhluI;

		public static bool PsrHpvZbqL;

		public static bool cr7HrV3M5G;

		public static bool EKUHn4F5c4;

		public static bool kHhHestTl0;

		public static bool z7PHfQUDXB;

		public static bool zAYHxm6yFK;

		public static bool hPHH1DVki2;

		public static bool GkqHK0NoG7;

		public static bool TsNHAutPGv;

		public static bool d95HVrjZdt;

		public static bool hOrHLAAdrb;

		public static bool F95HJAp3mW;

		public static bool RnDH59UoxV;

		public static bool I7lHd3Vfl6;

		public static bool t4ZHo3mxlC;

		public static bool RPgHmqnM3c;

		public static bool od0HDehGD1;

		public static bool N2HHclaIHj;

		public static bool y3nHyyQ1r4;

		public static bool xXrHEwgBDR;

		public static bool Sf5Hzp489E;

		public static bool FEYGqIQCmg;

		public static bool mfuGkurCkS;

		public static bool Cm6G86qNHh;

		public static bool zh8GHBfpn0;

		public static bool eM3GGSWiWD;

		public static bool BJGG33O0CE;

		public static bool GYvG9Ctjpc;

		public static bool MMtGsMCUUY;

		public static bool CeGGMrEemX;

		public static bool cVfG7qhspf;

		public static bool zF8G4Gc12I;

		public static bool JaUGIdEGVA;

		public static bool iAqG6gw145;

		public static bool qy9GtZVlMn;

		public static bool zjFGQlQltd;

		public static bool yvaGwdLhcj;

		public static bool gJBGNhjdEr;

		public static bool GG4GCVQ0mP;

		public static bool rMhG2w95nu;

		public static bool AqqGbSXCeM;

		public static bool Av4GhN3Ema;

		public static bool HsYGUuyLGq;

		public static bool uIWGTi76Mr;

		public static float N0lGvZLQ1o;

		public static bool M9MGa2aMRa;

		public static float SHnGgc3PGw;

		public static float jPQGW1kXdY;

		public static bool adUGuiIT1W;

		public static bool CVSGSA1GtX;

		public static bool WO7GY7rFSm;

		public static bool K2sGX5G6fF;

		public static bool bv3GODfSAb;

		public static bool RTiGBTTtHl;

		public static bool kYlGPd9yhf;

		public static bool Xt8GlNKG6V;

		public static bool GwyGje2Zpr;

		public static bool CloGZJJfLp;

		public static float VkWGFrUWSi;

		public static float ExgGiXN3F6;

		public static bool w3iG0gKZKI;

		public static bool JEZGRXfY0B;

		public static bool vr5Gpx6I9C;

		public static bool I6HGrXZtmQ;

		public static bool i4uGnUkq0K;

		public static Vector3 SBdGeinQmp;

		public static Dictionary<string, MWNRsi8GYTaTweXXZ8t.THCYgn2XNL0598uehC0> essGfCCKuJ;

		internal static MWNRsi8GYTaTweXXZ8t kZ3mW65N2gceWYj86FB;

		static MWNRsi8GYTaTweXXZ8t()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			MWNRsi8GYTaTweXXZ8t.VhZ8I7QCiA = "avtr_999";
			MWNRsi8GYTaTweXXZ8t.Vi5860sNj6 = "avtr_999";
			MWNRsi8GYTaTweXXZ8t.zvB8tTDitn = "avtr_999";
			MWNRsi8GYTaTweXXZ8t.RcY8QvaAtE = "avtr_999";
			MWNRsi8GYTaTweXXZ8t.I748wh8ayC = false;
			MWNRsi8GYTaTweXXZ8t.Rng8NHcdvn = false;
			MWNRsi8GYTaTweXXZ8t.Yxl8CFaRfy = false;
			MWNRsi8GYTaTweXXZ8t.Kqu82a2psG = false;
			MWNRsi8GYTaTweXXZ8t.epi8b4kn4j = false;
			MWNRsi8GYTaTweXXZ8t.WaQ8hO49xf = false;
			MWNRsi8GYTaTweXXZ8t.hI08UwyyF7 = false;
			MWNRsi8GYTaTweXXZ8t.RaP8TaYpZe = false;
			MWNRsi8GYTaTweXXZ8t.Lna8vPUAiT = false;
			MWNRsi8GYTaTweXXZ8t.De88acDBJG = false;
			MWNRsi8GYTaTweXXZ8t.oDW8gFeY59 = false;
			MWNRsi8GYTaTweXXZ8t.IyG8WVuZkF = false;
			MWNRsi8GYTaTweXXZ8t.tbQ8uH49gv = false;
			MWNRsi8GYTaTweXXZ8t.aLA8SfrStH = false;
			MWNRsi8GYTaTweXXZ8t.gqq8Yat8l4 = false;
			MWNRsi8GYTaTweXXZ8t.nMA8XrPkPY = false;
			MWNRsi8GYTaTweXXZ8t.we38OWOTrJ = false;
			MWNRsi8GYTaTweXXZ8t.Gca8Bjie04 = "#6a00ff";
			MWNRsi8GYTaTweXXZ8t.Tba8PDfU7c = "#ff0055";
			MWNRsi8GYTaTweXXZ8t.JfY8ZpbxQW = false;
			MWNRsi8GYTaTweXXZ8t.xqU8FfY5xC = false;
			MWNRsi8GYTaTweXXZ8t.jTo8i1kX2K = false;
			MWNRsi8GYTaTweXXZ8t.eBm80w8tXa = false;
			MWNRsi8GYTaTweXXZ8t.WQV8RiYbXK = false;
			MWNRsi8GYTaTweXXZ8t.zNZ8pqVoVp = false;
			MWNRsi8GYTaTweXXZ8t.C7s8rO8UZj = false;
			MWNRsi8GYTaTweXXZ8t.KPW8ngHkIs = false;
			MWNRsi8GYTaTweXXZ8t.RSC8eXinwN = false;
			MWNRsi8GYTaTweXXZ8t.MhS8fp6UC1 = false;
			MWNRsi8GYTaTweXXZ8t.fZB8xRES0x = false;
			MWNRsi8GYTaTweXXZ8t.kmw81U1b89 = false;
			MWNRsi8GYTaTweXXZ8t.fRC8KS0sTf = 0;
			MWNRsi8GYTaTweXXZ8t.gaa8AJmST7 = false;
			MWNRsi8GYTaTweXXZ8t.r9Q8VkokAl = false;
			MWNRsi8GYTaTweXXZ8t.xPZ8LD7gA9 = false;
			MWNRsi8GYTaTweXXZ8t.Jlg8JISId5 = false;
			MWNRsi8GYTaTweXXZ8t.hoj85c9FfE = false;
			MWNRsi8GYTaTweXXZ8t.qEQ8d0MVZD = false;
			MWNRsi8GYTaTweXXZ8t.PiE8o3Vbbf = false;
			MWNRsi8GYTaTweXXZ8t.Ger8mkfRpd = false;
			MWNRsi8GYTaTweXXZ8t.wTA8DgFg7W = false;
			MWNRsi8GYTaTweXXZ8t.pNo8ctBSOV = false;
			MWNRsi8GYTaTweXXZ8t.thN8y2oxZA = false;
			MWNRsi8GYTaTweXXZ8t.FPv8EcQbQB = false;
			MWNRsi8GYTaTweXXZ8t.eUY8zlymLA = false;
			MWNRsi8GYTaTweXXZ8t.uXOHqCbxg2 = false;
			MWNRsi8GYTaTweXXZ8t.IGNHk76ajb = false;
			MWNRsi8GYTaTweXXZ8t.bYqH8yBYxF = false;
			MWNRsi8GYTaTweXXZ8t.oybHHdNZJc = false;
			MWNRsi8GYTaTweXXZ8t.pflHG7Lb8A = false;
			MWNRsi8GYTaTweXXZ8t.lt5H3LxneR = false;
			MWNRsi8GYTaTweXXZ8t.n41H9XHiXM = false;
			MWNRsi8GYTaTweXXZ8t.OqwHsLGDJU = false;
			MWNRsi8GYTaTweXXZ8t.KOoHMEj5VM = false;
			MWNRsi8GYTaTweXXZ8t.ExKH7VH42F = false;
			MWNRsi8GYTaTweXXZ8t.YNNH4J6rvG = false;
			MWNRsi8GYTaTweXXZ8t.yMXHIf2uyW = 0f;
			MWNRsi8GYTaTweXXZ8t.EhNH6we2kR = false;
			MWNRsi8GYTaTweXXZ8t.dPEHtNlN15 = false;
			MWNRsi8GYTaTweXXZ8t.i27HQDpHjk = false;
			MWNRsi8GYTaTweXXZ8t.kEWHwCg8eW = false;
			MWNRsi8GYTaTweXXZ8t.Q5MHN6GDew = false;
			MWNRsi8GYTaTweXXZ8t.f5KHCsEeW9 = false;
			MWNRsi8GYTaTweXXZ8t.IG2H2Tel5J = true;
			MWNRsi8GYTaTweXXZ8t.ifoHb60Pu5 = false;
			MWNRsi8GYTaTweXXZ8t.XnhHhGHslH = 7f;
			MWNRsi8GYTaTweXXZ8t.NfMHUb7Qcd = false;
			MWNRsi8GYTaTweXXZ8t.PpNHTUiSoN = false;
			MWNRsi8GYTaTweXXZ8t.VZUHvpxvLG = false;
			MWNRsi8GYTaTweXXZ8t.tPjHaujTYS = false;
			MWNRsi8GYTaTweXXZ8t.DrWHgOqjpe = false;
			MWNRsi8GYTaTweXXZ8t.Lm0HW6M5Il = false;
			MWNRsi8GYTaTweXXZ8t.eaMHuW9rdf = false;
			MWNRsi8GYTaTweXXZ8t.rHIHSCWVgn = false;
			MWNRsi8GYTaTweXXZ8t.XxRHYbw5XP = false;
			MWNRsi8GYTaTweXXZ8t.v9KHXEfKVt = false;
			MWNRsi8GYTaTweXXZ8t.kPIHON31dq = false;
			MWNRsi8GYTaTweXXZ8t.F4pHBYV5SK = false;
			MWNRsi8GYTaTweXXZ8t.KIPHP4Owa2 = false;
			MWNRsi8GYTaTweXXZ8t.xYLHl2IPEa = false;
			MWNRsi8GYTaTweXXZ8t.lSxHjjWZuV = false;
			MWNRsi8GYTaTweXXZ8t.gcIHZbisJt = false;
			MWNRsi8GYTaTweXXZ8t.WkeHFWghtA = false;
			MWNRsi8GYTaTweXXZ8t.wtpHiaCDtW = true;
			MWNRsi8GYTaTweXXZ8t.DwfH0emPW5 = false;
			MWNRsi8GYTaTweXXZ8t.gTkHRAhluI = false;
			MWNRsi8GYTaTweXXZ8t.PsrHpvZbqL = true;
			MWNRsi8GYTaTweXXZ8t.cr7HrV3M5G = false;
			MWNRsi8GYTaTweXXZ8t.EKUHn4F5c4 = false;
			MWNRsi8GYTaTweXXZ8t.kHhHestTl0 = false;
			MWNRsi8GYTaTweXXZ8t.z7PHfQUDXB = false;
			MWNRsi8GYTaTweXXZ8t.zAYHxm6yFK = false;
			MWNRsi8GYTaTweXXZ8t.hPHH1DVki2 = false;
			MWNRsi8GYTaTweXXZ8t.GkqHK0NoG7 = false;
			MWNRsi8GYTaTweXXZ8t.TsNHAutPGv = false;
			MWNRsi8GYTaTweXXZ8t.d95HVrjZdt = false;
			MWNRsi8GYTaTweXXZ8t.hOrHLAAdrb = false;
			MWNRsi8GYTaTweXXZ8t.F95HJAp3mW = false;
			MWNRsi8GYTaTweXXZ8t.RnDH59UoxV = true;
			MWNRsi8GYTaTweXXZ8t.I7lHd3Vfl6 = true;
			MWNRsi8GYTaTweXXZ8t.t4ZHo3mxlC = true;
			MWNRsi8GYTaTweXXZ8t.RPgHmqnM3c = true;
			MWNRsi8GYTaTweXXZ8t.od0HDehGD1 = true;
			MWNRsi8GYTaTweXXZ8t.N2HHclaIHj = false;
			MWNRsi8GYTaTweXXZ8t.y3nHyyQ1r4 = false;
			MWNRsi8GYTaTweXXZ8t.xXrHEwgBDR = true;
			MWNRsi8GYTaTweXXZ8t.Sf5Hzp489E = true;
			MWNRsi8GYTaTweXXZ8t.FEYGqIQCmg = false;
			MWNRsi8GYTaTweXXZ8t.mfuGkurCkS = true;
			MWNRsi8GYTaTweXXZ8t.Cm6G86qNHh = false;
			MWNRsi8GYTaTweXXZ8t.zh8GHBfpn0 = true;
			MWNRsi8GYTaTweXXZ8t.eM3GGSWiWD = false;
			MWNRsi8GYTaTweXXZ8t.BJGG33O0CE = true;
			MWNRsi8GYTaTweXXZ8t.GYvG9Ctjpc = false;
			MWNRsi8GYTaTweXXZ8t.MMtGsMCUUY = true;
			MWNRsi8GYTaTweXXZ8t.CeGGMrEemX = false;
			MWNRsi8GYTaTweXXZ8t.cVfG7qhspf = false;
			MWNRsi8GYTaTweXXZ8t.zF8G4Gc12I = true;
			MWNRsi8GYTaTweXXZ8t.JaUGIdEGVA = false;
			MWNRsi8GYTaTweXXZ8t.iAqG6gw145 = false;
			MWNRsi8GYTaTweXXZ8t.qy9GtZVlMn = false;
			MWNRsi8GYTaTweXXZ8t.zjFGQlQltd = false;
			MWNRsi8GYTaTweXXZ8t.yvaGwdLhcj = false;
			MWNRsi8GYTaTweXXZ8t.gJBGNhjdEr = false;
			MWNRsi8GYTaTweXXZ8t.GG4GCVQ0mP = false;
			MWNRsi8GYTaTweXXZ8t.rMhG2w95nu = false;
			MWNRsi8GYTaTweXXZ8t.AqqGbSXCeM = true;
			MWNRsi8GYTaTweXXZ8t.Av4GhN3Ema = false;
			MWNRsi8GYTaTweXXZ8t.HsYGUuyLGq = false;
			MWNRsi8GYTaTweXXZ8t.uIWGTi76Mr = true;
			MWNRsi8GYTaTweXXZ8t.N0lGvZLQ1o = 5f;
			MWNRsi8GYTaTweXXZ8t.M9MGa2aMRa = false;
			MWNRsi8GYTaTweXXZ8t.SHnGgc3PGw = 5f;
			MWNRsi8GYTaTweXXZ8t.jPQGW1kXdY = 4f;
			MWNRsi8GYTaTweXXZ8t.adUGuiIT1W = false;
			MWNRsi8GYTaTweXXZ8t.CVSGSA1GtX = false;
			MWNRsi8GYTaTweXXZ8t.WO7GY7rFSm = false;
			MWNRsi8GYTaTweXXZ8t.K2sGX5G6fF = false;
			MWNRsi8GYTaTweXXZ8t.bv3GODfSAb = false;
			MWNRsi8GYTaTweXXZ8t.RTiGBTTtHl = false;
			MWNRsi8GYTaTweXXZ8t.kYlGPd9yhf = false;
			MWNRsi8GYTaTweXXZ8t.Xt8GlNKG6V = true;
			MWNRsi8GYTaTweXXZ8t.GwyGje2Zpr = false;
			MWNRsi8GYTaTweXXZ8t.CloGZJJfLp = false;
			MWNRsi8GYTaTweXXZ8t.vr5Gpx6I9C = false;
			MWNRsi8GYTaTweXXZ8t.I6HGrXZtmQ = false;
			MWNRsi8GYTaTweXXZ8t.i4uGnUkq0K = false;
		}

		public MWNRsi8GYTaTweXXZ8t()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static MWNRsi8GYTaTweXXZ8t CQ1gX252GTiXthngYua()
		{
			return MWNRsi8GYTaTweXXZ8t.kZ3mW65N2gceWYj86FB;
		}

		public static Color ElE84MW3vo()
		{
			return MWNRsi8GYTaTweXXZ8t.qYy8sgh346(MWNRsi8GYTaTweXXZ8t.Tba8PDfU7c);
		}

		public static void lUL89rxAoM()
		{
			MWNRsi8GYTaTweXXZ8t.SBdGeinQmp = Physics.get_gravity();
		}

		public static Color Ol687gEOM8()
		{
			return MWNRsi8GYTaTweXXZ8t.qYy8sgh346(MWNRsi8GYTaTweXXZ8t.Gca8Bjie04);
		}

		public static string QS08M3hJX1(Color u0020, bool u0020 = false)
		{
			int num = Convert.ToInt32(u0020.r * 255f);
			int num1 = Convert.ToInt32(u0020.g * 255f);
			int num2 = Convert.ToInt32(u0020.b * 255f);
			string str = num2.ToString("X2");
			string str1 = string.Concat(num.ToString("X2"), num1.ToString("X2"), str);
			if (u0020)
			{
				str1 = string.Concat("#", str1);
			}
			return str1;
		}

		public static Color qYy8sgh346(object u0020)
		{
			if (u0020.IndexOf('#') != -1)
			{
				u0020 = u0020.Replace("#", "");
			}
			float single = (float)int.Parse(u0020.Substring(0, 2), NumberStyles.AllowHexSpecifier) / 255f;
			float single1 = (float)int.Parse(u0020.Substring(2, 2), NumberStyles.AllowHexSpecifier) / 255f;
			float single2 = (float)int.Parse(u0020.Substring(4, 2), NumberStyles.AllowHexSpecifier) / 255f;
			return new Color(single, single1, single2);
		}

		internal static bool ujUimf5CZ3LgNq7W7lQ()
		{
			return MWNRsi8GYTaTweXXZ8t.kZ3mW65N2gceWYj86FB == null;
		}

		public class THCYgn2XNL0598uehC0
		{
			public KeyValuePair<Vector3, Quaternion> uSy2OfcXq0;

			public KeyValuePair<Vector3, Quaternion> TAN2BJUl4V;

			public KeyValuePair<Vector3, Quaternion> oxR2PQVGKO;

			private static MWNRsi8GYTaTweXXZ8t.THCYgn2XNL0598uehC0 UHGVRJcwQ3am8yNtatw;

			public THCYgn2XNL0598uehC0()
			{
				i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
				Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
				base();
			}

			internal static MWNRsi8GYTaTweXXZ8t.THCYgn2XNL0598uehC0 aSnZIMcCZ18aRRe0HLQ()
			{
				return MWNRsi8GYTaTweXXZ8t.THCYgn2XNL0598uehC0.UHGVRJcwQ3am8yNtatw;
			}

			internal static bool GAcDOgcNEWplH3khoCj()
			{
				return MWNRsi8GYTaTweXXZ8t.THCYgn2XNL0598uehC0.UHGVRJcwQ3am8yNtatw == null;
			}
		}
	}
}