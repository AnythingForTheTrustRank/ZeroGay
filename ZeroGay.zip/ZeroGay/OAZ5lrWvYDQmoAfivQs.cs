using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string OAZ5lrWvYDQmoAfivQs(object object_0, int int_0, int int_1);