using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection.Emit;

internal delegate void QOruREJPRtMgvslAB5r(object , OpCode , sbyte );