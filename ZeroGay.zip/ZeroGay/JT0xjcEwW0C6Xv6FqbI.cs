using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate string JT0xjcEwW0C6Xv6FqbI(GameObject gameObject_0);