using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void WMYXlDWjFYAyFk47oAa(object object_0, LayerMask layerMask_0);