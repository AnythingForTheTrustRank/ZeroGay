using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void j3jky3VWaGatvkbJNnM(object object_0, AudioClip audioClip_0);