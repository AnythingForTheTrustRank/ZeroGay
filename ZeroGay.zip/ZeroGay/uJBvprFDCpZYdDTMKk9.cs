using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Texture uJBvprFDCpZYdDTMKk9(object object_0);