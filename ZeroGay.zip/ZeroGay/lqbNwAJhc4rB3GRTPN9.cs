using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate bool lqbNwAJhc4rB3GRTPN9(UnityEngine.Object object_0, UnityEngine.Object object_1);