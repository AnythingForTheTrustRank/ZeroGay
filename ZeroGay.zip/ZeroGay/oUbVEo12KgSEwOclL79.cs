using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void oUbVEo12KgSEwOclL79(object , ParticleSystemGradientMode );