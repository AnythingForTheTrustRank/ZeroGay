using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC.Networking;

namespace OD9m6O9bemNUx4rutsX
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class eoiOZ192r1eDKM8RS8c
	{
		public static bool lgw9UORmhE;

		internal static eoiOZ192r1eDKM8RS8c elVwYW5c6VGPt1DDApE;

		public eoiOZ192r1eDKM8RS8c()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static eoiOZ192r1eDKM8RS8c IG2gUL5EPPym3mdPIcq()
		{
			return eoiOZ192r1eDKM8RS8c.elVwYW5c6VGPt1DDApE;
		}

		internal static bool NWlTc15yvZeYxmZNXG7()
		{
			return eoiOZ192r1eDKM8RS8c.elVwYW5c6VGPt1DDApE == null;
		}

		public static bool vQD9hyqxX0(ref string u0020, object u0020)
		{
			bool flag;
			if (eoiOZ192r1eDKM8RS8c.lgw9UORmhE)
			{
				flag = (!u0020.Contains("HitDamage") ? true : false);
			}
			else
			{
				flag = true;
			}
			return flag;
		}
	}
}