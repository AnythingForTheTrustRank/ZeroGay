using a1f9Fk6X8PqG43BDAy2;
using b3eD5DgJPcASx0xfHYB;
using gpd3oZtw5qhYneWRlWY;
using Il2CppSystem.Collections.Generic;
using KXsrfv838576XC2bCZx;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;

namespace smF1Y5I6LTUafkXI2oF
{
	internal class K1DG5hII2XIwO8UAXTv
	{
		public static bool SsNI0nMVU5;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup> xNyIRFmlmG;

		public static Il2CppSystem.Collections.Generic.List<VRCObjectSync> XsQIpVfyWt;

		public static bool gIbIrJux1S;

		public static bool cLAInl3j2w;

		public static bool XLTIeGB4cE;

		public static bool pwBIftRhcT;

		public static bool Ds8IxM2LFq;

		public static bool CS0I1Dk1Mu;

		private static K1DG5hII2XIwO8UAXTv i1vuIrdW3QE90XOZEEo;

		static K1DG5hII2XIwO8UAXTv()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			K1DG5hII2XIwO8UAXTv.SsNI0nMVU5 = false;
			K1DG5hII2XIwO8UAXTv.xNyIRFmlmG = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup>();
			K1DG5hII2XIwO8UAXTv.XsQIpVfyWt = new Il2CppSystem.Collections.Generic.List<VRCObjectSync>();
			K1DG5hII2XIwO8UAXTv.cLAInl3j2w = false;
			K1DG5hII2XIwO8UAXTv.XLTIeGB4cE = false;
			K1DG5hII2XIwO8UAXTv.pwBIftRhcT = false;
			K1DG5hII2XIwO8UAXTv.Ds8IxM2LFq = false;
			K1DG5hII2XIwO8UAXTv.CS0I1Dk1Mu = false;
		}

		public K1DG5hII2XIwO8UAXTv()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static void BYyISss25N()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Frag (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void ClVIjKx5A5()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Bear Trap (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void DtGIhfQ8Fv()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Revolver")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void EgsIaAtBhK()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Shotgun (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static GameObject[] eHxIQC0dau()
		{
			return SceneManager.GetActiveScene().GetRootGameObjects();
		}

		public static void FnLIgKsx6O()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Revolver")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void gToIPYLI5I()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Bear Trap (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void Gw9IWSyl9k()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Knife (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void gZwITMxtxV()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Luger (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static bool ibsypNduiiet0oUp1mQ()
		{
			return K1DG5hII2XIwO8UAXTv.i1vuIrdW3QE90XOZEEo == null;
		}

		public static void J1SIUnUWwj()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Knife (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static K1DG5hII2XIwO8UAXTv kk9uiddSUTVvUjk4OCf()
		{
			return K1DG5hII2XIwO8UAXTv.i1vuIrdW3QE90XOZEEo;
		}

		public static void KnhIOBSfFX(bool u0020)
		{
			foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
			{
				vRCPickup.set_pickupable(true);
				vRCPickup.set_DisallowTheft(false);
			}
		}

		public static void mf3IYuvr2L()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Shotgun (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static void nP4IiMh67U()
		{
			foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
			{
				Networking.get_LocalPlayer().TakeOwnership(vRCPickup.get_gameObject());
				vRCPickup.get_transform().set_localPosition(new Vector3(0f, -100000f, 0f));
			}
		}

		public static IEnumerator oNJICf3juh(bool u0020)
		{
			while (true)
			{
				if (MWNRsi8GYTaTweXXZ8t.Lna8vPUAiT)
				{
					foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
					{
						vRCPickup.set_pickupable(true);
					}
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					yield return new WaitForSeconds(0.1f);
				}
			}
		}

		public static void oUIIuyUNdR()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Luger (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static void q6WIFhpPLg()
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array[i].get_gameObject());
					array[i].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform = array[i].get_transform();
					_transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(vRCPickupArray[j].get_gameObject());
					vRCPickupArray[j].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform transform = vRCPickupArray[j].get_transform();
					transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array1[k].get_gameObject());
					array1[k].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform1 = array1[k].get_transform();
					_transform1.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
		}

		public static void QhnIbsr12b(object u0020)
		{
			foreach (Player array in PlayerManager.Method_Public_Static_get_PlayerManager_0().get_field_Private_List_1_Player_0().ToArray())
			{
				!(array.get_field_Private_APIUser_0().get_id() == u0020);
			}
		}

		internal static void rtMI2fA7xL()
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					array[i].set_DisallowTheft(false);
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					vRCPickupArray[j].set_DisallowTheft(false);
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					array1[k].set_DisallowTheft(false);
				}
			}
		}

		public static IEnumerator rv8ItpRCVG()
		{
			return new K1DG5hII2XIwO8UAXTv.<DIO>d__9(0);
		}

		public static void SGNIBuT31y()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Smoke (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static void uBtIZ8FYIF()
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array[i].get_gameObject());
					array[i].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform = array[i].get_transform();
					_transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(vRCPickupArray[j].get_gameObject());
					vRCPickupArray[j].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform transform = vRCPickupArray[j].get_transform();
					transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array1[k].get_gameObject());
					array1[k].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform1 = array1[k].get_transform();
					_transform1.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
		}

		public static IEnumerator Up6IwfaAMY(bool u0020)
		{
			while (true)
			{
				if (MWNRsi8GYTaTweXXZ8t.nMA8XrPkPY)
				{
					foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
					{
						vRCPickup.set_proximity(1E+08f);
					}
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					yield return new WaitForSeconds(0.1f);
				}
			}
		}

		public static void WhqIvSKdep()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Frag (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void wmUIXKpUnY()
		{
			while (K1DG5hII2XIwO8UAXTv.pwBIftRhcT)
			{
				Thread.Sleep(70);
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("Game Logic"))
					{
						continue;
					}
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAssingB");
				}
			}
		}

		public static IEnumerator xr2INtCefN(bool u0020)
		{
			while (true)
			{
				if (MWNRsi8GYTaTweXXZ8t.jTo8i1kX2K)
				{
					foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
					{
						vRCPickup.set_DisallowTheft(false);
					}
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					yield return new WaitForSeconds(0.1f);
				}
			}
		}

		public static void yes()
		{
			if (LoV9yY6YR91Q6ZGX4wt.asg6VuKDgL)
			{
				GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(false);
				GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(false);
				GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(false);
			}
			else
			{
				GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(true);
				GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(true);
				GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(true);
			}
		}

		public static void zxsIlqXPsp()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "Smoke (0)")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}
	}
}