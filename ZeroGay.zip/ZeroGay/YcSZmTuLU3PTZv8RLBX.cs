using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate float YcSZmTuLU3PTZv8RLBX();