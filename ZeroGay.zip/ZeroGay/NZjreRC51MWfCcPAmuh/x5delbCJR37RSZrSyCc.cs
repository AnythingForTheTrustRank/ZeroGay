using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace NZjreRC51MWfCcPAmuh
{
	internal class x5delbCJR37RSZrSyCc
	{
		protected GameObject zy1CEqMerT;

		protected GameObject WcRCzw8P62;

		protected Slider LaH2qnP2Ll;

		protected Text ll42k92m19;

		protected float osB28lB22i;

		protected float Ylv2HQ8Fly;

		protected float l9b2GSAP73;

		internal static x5delbCJR37RSZrSyCc JgTvjADpiLkNI78XWir;

		public x5delbCJR37RSZrSyCc(QMNestedButton u0020, float u0020, float u0020, string u0020, float u0020, float u0020, float u0020, Action<float> u0020, Color? u0020 = null)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.tJUCdmAnR9(u0020.GetMenuObject().get_transform(), u0020, u0020, u0020, u0020, u0020, u0020, u0020, u0020);
		}

		public x5delbCJR37RSZrSyCc(Transform u0020, float u0020, float u0020, string u0020, float u0020, float u0020, float u0020, Action<float> u0020, Color? u0020 = null)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.tJUCdmAnR9(u0020, u0020, u0020, u0020, u0020, u0020, u0020, u0020, u0020);
		}

		internal static bool aB6i1mDrupHpLg1nO1X()
		{
			return x5delbCJR37RSZrSyCc.JgTvjADpiLkNI78XWir == null;
		}

		public void dvtCoUn5xx(Vector2 u0020)
		{
			this.zy1CEqMerT.GetComponent<RectTransform>().set_anchoredPosition(u0020);
		}

		public void hFYCDt3vwR(Color u0020)
		{
			this.ll42k92m19.set_color(u0020);
		}

		public void jhrCmrDp0b(string u0020)
		{
			this.ll42k92m19.set_text(u0020);
		}

		public GameObject lkjCyJ6YJj()
		{
			return this.zy1CEqMerT;
		}

		internal static x5delbCJR37RSZrSyCc reALIlDnDBNKTlaSLOV()
		{
			return x5delbCJR37RSZrSyCc.JgTvjADpiLkNI78XWir;
		}

		private void tJUCdmAnR9(Transform u0020, float u0020, float u0020, string u0020, float u0020, float u0020, float u0020, Action<float> u0020, Color? u0020 = null)
		{
			this.zy1CEqMerT = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.dlsNkO5BD8(), u0020);
			this.zy1CEqMerT.get_transform().set_localScale(new Vector3(1f, 1f, 1f));
			this.zy1CEqMerT.set_name(string.Format("{0}-QMSlider-{1}", "WTFBlaze", yLWOmZwmRqSychwym35.Fn2N9KXqf1()));
			this.WcRCzw8P62 = UnityEngine.Object.Instantiate<GameObject>(GameObject.Find("UserInterface/MenuContent/Screens/Settings/AudioDevicePanel/LevelText"), this.zy1CEqMerT.get_transform());
			this.WcRCzw8P62.set_name("QMSlider-Label");
			this.WcRCzw8P62.get_transform().set_localScale(new Vector3(1f, 1f, 1f));
			this.WcRCzw8P62.GetComponent<RectTransform>().set_sizeDelta(new Vector2(360f, 50f));
			this.WcRCzw8P62.GetComponent<RectTransform>().set_anchoredPosition(new Vector2(10.4f, 55f));
			this.WcRCzw8P62.AddComponent<Button>().get_onClick().AddListener(new Action(() => {
			}));
			this.LaH2qnP2Ll = this.zy1CEqMerT.GetComponent<Slider>();
			this.LaH2qnP2Ll.set_wholeNumbers(false);
			this.LaH2qnP2Ll.set_onValueChanged(new Slider.SliderEvent());
			this.LaH2qnP2Ll.get_onValueChanged().AddListener(u0020);
			this.LaH2qnP2Ll.get_onValueChanged().AddListener(new Action<float>((float f) => this.zy1CEqMerT.get_transform().Find("Fill Area/Label").GetComponent<Text>().set_text(string.Format("{0}%", this.LaH2qnP2Ll.get_value() / u0020 * 100f))));
			this.ll42k92m19 = this.WcRCzw8P62.GetComponent<Text>();
			this.ll42k92m19.set_resizeTextForBestFit(false);
			if (u0020.HasValue)
			{
				this.hFYCDt3vwR(u0020.Value);
			}
			this.dvtCoUn5xx(new Vector2(u0020, u0020));
			this.jhrCmrDp0b(u0020);
			this.waLCcvldWx(u0020, u0020, this.l9b2GSAP73);
			vBMVdGwfepiujjMKYNt.i7fwLLlON4.Add(this);
		}

		public void waLCcvldWx(float u0020, float u0020, float u0020)
		{
			this.osB28lB22i = u0020;
			this.Ylv2HQ8Fly = u0020;
			this.l9b2GSAP73 = u0020;
			this.LaH2qnP2Ll.set_minValue(this.osB28lB22i);
			this.LaH2qnP2Ll.set_maxValue(this.Ylv2HQ8Fly);
			this.LaH2qnP2Ll.set_value(this.l9b2GSAP73);
		}
	}
}