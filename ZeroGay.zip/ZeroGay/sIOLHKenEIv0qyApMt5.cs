using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Vector3 sIOLHKenEIv0qyApMt5(object , HumanBodyBones );