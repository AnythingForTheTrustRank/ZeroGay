using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object ixEYubkFb6VdXZgGw0R(object object_0, Type type_0);