using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using VRC;

internal delegate Il2CppReferenceArray<Player> xfFJRgucL1ImjEga94G(object object_0);