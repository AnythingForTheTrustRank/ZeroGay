using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector3 kRBOlJpgKMAVBypwLGO(Vector3 vector3_0, Vector3 vector3_1);