using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object daUIhd3Qh9CUGASDJfR(Type type_0, uint uint_0);