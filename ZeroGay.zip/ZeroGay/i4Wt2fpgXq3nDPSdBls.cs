using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Shader i4Wt2fpgXq3nDPSdBls(string );