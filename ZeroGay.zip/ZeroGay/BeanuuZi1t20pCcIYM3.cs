using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.Networking;

internal delegate UnityWebRequestAsyncOperation BeanuuZi1t20pCcIYM3(object object_0);