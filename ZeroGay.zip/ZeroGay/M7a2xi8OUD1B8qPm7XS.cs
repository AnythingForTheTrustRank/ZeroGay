using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Core;

internal delegate APIUser M7a2xi8OUD1B8qPm7XS(object object_0);