using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate MonoBehaviour1PrivateObInPrInBoInInInInUnique qm77rspdCW2RqUuvkR0();