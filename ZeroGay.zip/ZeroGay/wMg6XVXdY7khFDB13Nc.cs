using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using VRC.UI.Elements;

internal delegate Il2CppReferenceArray<UIPage> wMg6XVXdY7khFDB13Nc(object object_0);