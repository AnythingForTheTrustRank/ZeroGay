using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string[] HLKSQfPVFKcrAuu0VdG(string string_0);