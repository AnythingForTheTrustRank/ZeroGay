using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void ohoY0WPmcn5c9NDaOen(string string_0, byte[] byte_0);