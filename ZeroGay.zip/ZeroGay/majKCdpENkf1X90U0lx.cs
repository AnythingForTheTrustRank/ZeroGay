using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Quaternion majKCdpENkf1X90U0lx(Vector3 );