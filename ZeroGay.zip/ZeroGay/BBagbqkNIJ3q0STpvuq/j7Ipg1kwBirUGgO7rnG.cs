using b3eD5DgJPcASx0xfHYB;
using BestHTTP;
using DW6c39Q48fhvTF5jMI;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using TMPro;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using VRC.Udon;

namespace BBagbqkNIJ3q0STpvuq
{
	internal static class j7Ipg1kwBirUGgO7rnG
	{
		internal static System.Collections.Generic.List<string> VOWkjdCKLi;

		private static System.Collections.Generic.List<GameObject> yxfkZxUrj3;

		internal static j7Ipg1kwBirUGgO7rnG gg1i6y5kTXcDZNPYuS7;

		static j7Ipg1kwBirUGgO7rnG()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			j7Ipg1kwBirUGgO7rnG.VOWkjdCKLi = new System.Collections.Generic.List<string>();
			j7Ipg1kwBirUGgO7rnG.yxfkZxUrj3 = new System.Collections.Generic.List<GameObject>();
		}

		internal static Player B0okC2vDkL()
		{
			Player player;
			string _text = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local/ScrollRect/Viewport/VerticalLayoutGroup/UserProfile_Compact/PanelBG/Info/Text_Username_NonFriend").GetComponent<TextMeshProUGUI>().get_text();
			Il2CppSystem.Collections.Generic.List<Player>.Enumerator enumerator = PlayerManager.get_field_Private_Static_PlayerManager_0().get_field_Private_List_1_Player_0().GetEnumerator();
			while (true)
			{
				if (!enumerator.MoveNext())
				{
					player = null;
					break;
				}
				else
				{
					Player _current = enumerator.get_current();
					if (_current.Method_Public_get_VRCPlayerApi_0().get_displayName() == _text)
					{
						player = _current;
						break;
					}
				}
			}
			return player;
		}

		public static void Cy3kTPrUD8(object u0020)
		{
			string str = string.Concat("user/", u0020, "/friendRequest");
			ApiDictContainer apiDictContainer = new ApiDictContainer(new string[0]);
			j7Ipg1kwBirUGgO7rnG.kJHkvNfxbA(str, 2, apiDictContainer, true, null);
		}

		internal static void E1vkSvs3JQ(object u0020, bool u0020)
		{
			if (HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() != null)
			{
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(u0020, u0020);
			}
		}

		internal static bool eL1FDP580cdW0sagkMN()
		{
			return j7Ipg1kwBirUGgO7rnG.gg1i6y5kTXcDZNPYuS7 == null;
		}

		internal static void fHVkWpZoKk(bool u0020)
		{
			Il2CppArrayBase<VRC_Trigger> il2CppArrayBase = Resources.FindObjectsOfTypeAll<VRC_Trigger>();
			Il2CppArrayBase<UdonBehaviour> il2CppArrayBase1 = Resources.FindObjectsOfTypeAll<UdonBehaviour>();
			foreach (VRC_Trigger vRCTrigger in il2CppArrayBase)
			{
				if (vRCTrigger == null || vRCTrigger.get_gameObject() == null || !vRCTrigger.get_gameObject().get_active() || vRCTrigger.get_name().Contains("ViewFinder") || HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null)
				{
					continue;
				}
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(vRCTrigger.GetComponentInChildren<MeshRenderer>(), u0020);
			}
			foreach (UdonBehaviour udonBehaviour in il2CppArrayBase1)
			{
				if (udonBehaviour == null || udonBehaviour.get_gameObject() == null || !udonBehaviour.get_gameObject().get_active() || udonBehaviour.get_name().Contains("ViewFinder") || HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null || !udonBehaviour.get__eventTable().System_Collections_IDictionary_Contains("_interact"))
				{
					continue;
				}
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(udonBehaviour.GetComponentInChildren<MeshRenderer>(), u0020);
			}
		}

		internal static void gdQkgIe7Fj(bool u0020)
		{
			foreach (VRC_Pickup vRCPickup in Resources.FindObjectsOfTypeAll<VRC_Pickup>())
			{
				if (vRCPickup == null || vRCPickup.get_gameObject() == null || !vRCPickup.get_gameObject().get_active() || !vRCPickup.get_enabled() || !vRCPickup.get_pickupable() || vRCPickup.get_name().Contains("ViewFinder") || HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() == null)
				{
					continue;
				}
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(vRCPickup.GetComponentInChildren<MeshRenderer>(), u0020);
			}
		}

		internal static void kJHkvNfxbA(object u0020, HTTPMethods u0020, ApiContainer u0020 = null, bool u0020 = true, Il2CppSystem.Collections.Generic.Dictionary<string, Il2CppSystem.Object> u0020 = null)
		{
			API.SendRequest(u0020, u0020, u0020, u0020, true, u0020, 3600f, 2, null, null);
		}

		public static Il2CppSystem.Collections.Generic.List<Player> KyTkU6BMGi()
		{
			return PlayerManager.get_field_Private_Static_PlayerManager_0().get_field_Private_List_1_Player_0();
		}

		internal static void n0ZkbhdsH0()
		{
			j7Ipg1kwBirUGgO7rnG.xkekhqX5x8();
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().HideScreen("POPUP");
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().Method_Public_Virtual_New_Void_Boolean_0(false);
		}

		internal static j7Ipg1kwBirUGgO7rnG Nt8qcn5HInamyuRdta0()
		{
			return j7Ipg1kwBirUGgO7rnG.gg1i6y5kTXcDZNPYuS7;
		}

		internal static void Q4ek2yUodH(object u0020, Color? u0020)
		{
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_Text_0().set_color(u0020.Value);
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Private_List_1_String_0().Add(string.Concat("[Late Night]\n", u0020));
		}

		internal static VRCPlayer s5QkYRroxn()
		{
			return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
		}

		internal static PlayerManager sMnkaaddiQ()
		{
			return PlayerManager.Method_Public_Static_get_PlayerManager_0();
		}

		internal static void vVYkumWPUy(bool u0020)
		{
			GameObject[] gameObjectArray = GameObject.FindGameObjectsWithTag("Player");
			for (int i = 0; i < (int)gameObjectArray.Length; i++)
			{
				if (!(gameObjectArray[i] == null) && gameObjectArray[i].get_transform().Find("SelectRegion"))
				{
					Renderer component = gameObjectArray[i].get_transform().Find("SelectRegion").GetComponent<Renderer>();
					if (component != null)
					{
						j7Ipg1kwBirUGgO7rnG.E1vkSvs3JQ(component, u0020);
					}
				}
			}
		}

		internal static void xkekhqX5x8()
		{
			// 
			// Current member / type: System.Void BBagbqkNIJ3q0STpvuq.j7Ipg1kwBirUGgO7rnG::xkekhqX5x8()
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void xkekhqX5x8()
			// 
			// Index was out of range. Must be non-negative and less than the size of the collection.
			// Parameter name: index
			//    at System.ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument argument, ExceptionResource resource)
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 184
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 118
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 56
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static Il2CppSystem.Collections.Generic.List<Player> yi9kX3Ox5s()
		{
			return XxV353tthuCn4bdLyG.mLSUv9tiG().get_field_Private_List_1_Player_0();
		}
	}
}