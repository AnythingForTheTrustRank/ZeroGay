using AksgHVKH9UOXlBDvRpO;
using System;
using VRC;

internal delegate Player FWDqv9Prqa2HMHvvhve(object object_0);