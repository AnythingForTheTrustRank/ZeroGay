using AksgHVKH9UOXlBDvRpO;
using H265BlIi2sW2Qc3cqB8;
using HarmonyLib;
using System;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace h94ldvIJ0xBVWwjdupP
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class a4P2wXIxUaTCF1KH0Dj
	{
		internal static a4P2wXIxUaTCF1KH0Dj gxcSjKf3Jyie7Os8JDA;

		public a4P2wXIxUaTCF1KH0Dj()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static bool OkBI8llxs6(ref string string_0, object object_0)
		{
			bool flag;
			if (!TRfUrNIv9gICnHInO1k.gPeI0EYTL8)
			{
				flag = true;
			}
			else
			{
				flag = (string_0 != "BackStabDamage" ? true : false);
			}
			return flag;
		}

		internal static a4P2wXIxUaTCF1KH0Dj ty32nBffhA6rODqf8cN()
		{
			return a4P2wXIxUaTCF1KH0Dj.gxcSjKf3Jyie7Os8JDA;
		}

		internal static bool yos10qfkctjI0oDD4Mb()
		{
			return a4P2wXIxUaTCF1KH0Dj.gxcSjKf3Jyie7Os8JDA == null;
		}
	}
}