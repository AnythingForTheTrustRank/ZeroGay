using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void VD5d93EAQkvbMyhSnMx(object object_0, HideFlags hideFlags_0);