using b3eD5DgJPcASx0xfHYB;
using I2.Loc;
using KXsrfv838576XC2bCZx;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace hg32mdSwjyUKxB06tQ
{
	internal class PFkqXMuodBMin29BhG
	{
		internal static PFkqXMuodBMin29BhG S8VqN8JdJZtLBb0Siwd;

		public PFkqXMuodBMin29BhG()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static IEnumerator FIpYgfmgc()
		{
			if (!VRCPlayer.get_field_Internal_Static_VRCPlayer_0())
			{
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/TitleText").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/Rectangle").set_active(false);
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/Rectangle/Panel").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/InputField").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/ButtonLeft").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/ButtonLeft/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/ButtonRight").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/ButtonRight/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Popups/InputPopup/InputField/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").set_active(false);
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonAboutUs (1)").set_active(false);
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/VRChatButtonLogin").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/StoreButtonLogin (1)").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/VRChatButtonLogin/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/StoreButtonLogin (1)/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/ButtonCreate").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/VRChat_LOGO (1)").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextLoginWith").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextWelcome").GetComponent<Text>().set_m_Text("ZeroDay.");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextWelcome").GetComponent<Text>().set_text("ZeroDay.");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextWelcome").GetComponent<Localize>().Method_Public_set_Void_String_PDM_1("ZeroDay.");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextWelcome").GetComponent<Localize>().set_field_Public_String_2("ZeroDay.");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextWelcome").GetComponent<Localize>().set_field_Public_String_0("ZeroDay.");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextWelcome").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/TextWelcome").GetComponent<Text>().set_text("ZeroDay.");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/TextWelcome").GetComponent<Text>().set_m_Text("ZeroDay\t.");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/TextWelcome").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/VRChat_LOGO (1)").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonAboutUs").set_active(false);
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/Panel").set_active(false);
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/Text").GetComponent<Text>().set_m_Text("Login (VRCHAT)");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/Text").GetComponent<Text>().set_text("Login (VRCHAT)");
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/InputFieldPassword").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/InputFieldUser").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/InputFieldPassword/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/BoxLogin/InputFieldUser/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonBack (1)").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonDone (1)").GetComponent<Image>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonBack (1)/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/LoginUserPass/ButtonDone (1)/Text").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Image").set_active(false);
				GameObject.Find("UserInterface/MenuContent/Screens/Authentication/StoreLoginPrompt/TextOr").GetComponent<Text>().set_color(new Color(0.4157f, 0f, 1f, 1f));
				GameObject.Find("UserInterface/LoadingBackground_TealGradient_Music/SkyCube_Baked").set_active(false);
				MeshRenderer component = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM/SCREEN/mainFrame").GetComponent<MeshRenderer>();
				Light light = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)/Point light").GetComponent<Light>();
				ReflectionProbe reflectionProbe = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_Lighting (1)/Reflection Probe").GetComponent<ReflectionProbe>();
				while (component == null)
				{
					yield return null;
				}
				while (light == null)
				{
					yield return null;
				}
				while (reflectionProbe == null)
				{
					yield return null;
				}
				reflectionProbe.set_mode(1);
				reflectionProbe.set_backgroundColor(new Color(0.4006691f, 0f, 1f, 0f));
				MeshRenderer meshRenderer = component;
				Material material = new Material(Shader.Find("Standard"));
				Material material1 = material;
				meshRenderer.set_material(material);
				Material material2 = material1;
				component.get_material().set_color(Color.get_black());
				component.get_material().SetFloat("_Metallic", 1f);
				component.get_material().SetFloat("_SmoothnessTextureChar", 1f);
				light.set_color(Color.get_white());
				ParticleSystem particleSystem = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystem>();
				ParticleSystemRenderer particleSystemRenderer = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystemRenderer>();
				while (particleSystem == null)
				{
					yield return null;
				}
				while (particleSystemRenderer == null)
				{
					yield return null;
				}
				particleSystem.get_gameObject().SetActive(false);
				Transform _transform = particleSystem.get_gameObject().get_transform();
				_transform.set_position(_transform.get_position() - new Vector3(0f, 5f, 0f));
				ParticleSystemRenderer particleSystemRenderer1 = particleSystemRenderer;
				Material material3 = new Material(Shader.Find("UI/Default"));
				material3.set_color(Color.get_white());
				material1 = material3;
				particleSystemRenderer1.set_trailMaterial(material3);
				Material material4 = material1;
				particleSystemRenderer.get_material().set_color(Color.get_white());
				particleSystem.get_trails().set_enabled(true);
				particleSystem.get_trails().set_mode(0);
				particleSystem.get_trails().set_ratio(1f);
				particleSystem.get_trails().set_lifetime(0.04f);
				particleSystem.get_trails().set_minVertexDistance(0f);
				particleSystem.get_trails().set_worldSpace(false);
				particleSystem.get_trails().set_dieWithParticles(true);
				particleSystem.get_trails().set_textureMode(0);
				particleSystem.get_trails().set_sizeAffectsWidth(true);
				particleSystem.get_trails().set_sizeAffectsLifetime(false);
				particleSystem.get_trails().set_inheritParticleColor(false);
				particleSystem.get_trails().set_colorOverLifetime(Color.get_white());
				particleSystem.get_trails().set_widthOverTrail(0.1f);
				particleSystem.get_trails().set_colorOverTrail(new Color(0.02987278f, 0f, 0.3962264f, 0.5f));
				particleSystem.get_shape().set_scale(new Vector3(1f, 1f, 1.82f));
				particleSystem.get_main().get_startColor().set_mode(0);
				particleSystem.get_colorOverLifetime().set_enabled(false);
				particleSystem.get_main().set_prewarm(false);
				particleSystem.set_playOnAwake(true);
				particleSystem.set_startColor(new Color(1f, 0f, 0.282353f, 1f));
				particleSystem.get_noise().set_frequency(1f);
				particleSystem.get_noise().set_strength(0.5f);
				particleSystem.set_maxParticles(250);
				particleSystem.get_gameObject().SetActive(true);
				GameObject gameObject = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_CloseParticles");
				while (gameObject == null)
				{
					yield return null;
				}
				gameObject.GetComponent<ParticleSystem>().set_startColor(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo());
				GameObject gameObject1 = GameObject.Find("/UserInterface/LoadingBackground_TealGradient_Music/_FX_ParticleBubbles/FX_floor");
				while (gameObject1 == null)
				{
					yield return null;
				}
				gameObject1.GetComponent<ParticleSystem>().set_startColor(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo());
				ParticleSystem component1 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystem>();
				ParticleSystemRenderer component2 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_snow").GetComponent<ParticleSystemRenderer>();
				while (component1 == null)
				{
					yield return null;
				}
				while (component2 == null)
				{
					yield return null;
				}
				component1.get_gameObject().SetActive(false);
				Transform transform = component1.get_gameObject().get_transform();
				transform.set_position(transform.get_position() - new Vector3(0f, 5f, 0f));
				material4.set_color(Color.get_white());
				component2.set_trailMaterial(material4);
				component2.get_material().set_color(Color.get_white());
				Sprite sprite = new Sprite();
				UnityWebRequest texture = UnityWebRequestTexture.GetTexture("https://i.imgur.com/79KdVND.png");
				yield return texture.SendWebRequest();
				if (texture.get_isNetworkError() || texture.get_isHttpError())
				{
					MelonLogger.LogError(texture.get_error());
				}
				else
				{
					Texture2D content = DownloadHandlerTexture.GetContent(texture);
					particleSystem.GetComponent<ParticleSystemRenderer>().get_material().set_mainTexture(content);
					particleSystemRenderer.GetComponent<ParticleSystemRenderer>().get_material().set_mainTexture(content);
					component1.GetComponent<ParticleSystemRenderer>().get_material().set_mainTexture(content);
					component2.GetComponent<ParticleSystemRenderer>().get_material().set_mainTexture(content);
					particleSystem.set_startSize(1f);
					component1.set_startSize(1f);
					content = null;
				}
				component1.get_trails().set_enabled(true);
				component1.get_trails().set_mode(0);
				component1.get_trails().set_ratio(1f);
				component1.get_trails().set_lifetime(0.04f);
				component1.get_trails().set_minVertexDistance(0f);
				component1.get_trails().set_worldSpace(false);
				component1.get_trails().set_dieWithParticles(true);
				component1.get_trails().set_textureMode(0);
				component1.get_trails().set_sizeAffectsWidth(true);
				component1.get_trails().set_sizeAffectsLifetime(false);
				component1.get_trails().set_inheritParticleColor(false);
				component1.get_trails().set_colorOverLifetime(Color.get_white());
				component1.get_trails().set_widthOverTrail(0.1f);
				component1.get_trails().set_colorOverTrail(new Color(0.02987278f, 0f, 0.3962264f, 0.5f));
				component1.get_shape().set_scale(new Vector3(1f, 1f, 1.82f));
				component1.get_main().get_startColor().set_mode(0);
				component1.get_colorOverLifetime().set_enabled(false);
				component1.get_main().set_prewarm(false);
				component1.set_playOnAwake(true);
				component1.set_startColor(new Color(1f, 0f, 0.282353f, 1f));
				component1.get_noise().set_frequency(1f);
				component1.get_noise().set_strength(0.5f);
				component1.set_maxParticles(250);
				component1.get_gameObject().SetActive(true);
				GameObject gameObject2 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_CloseParticles");
				while (gameObject2 == null)
				{
					yield return null;
				}
				gameObject2.GetComponent<ParticleSystem>().set_startColor(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo());
				GameObject gameObject3 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_floor");
				while (gameObject3 == null)
				{
					yield return null;
				}
				gameObject3.GetComponent<ParticleSystem>().set_startColor(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo());
				Image image = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements/LOADING_BAR_BG").GetComponent<Image>();
				while (image == null)
				{
					yield return null;
				}
				image.set_color(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo());
				Image image1 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Loading Elements/LOADING_BAR").GetComponent<Image>();
				while (image1 == null)
				{
					yield return null;
				}
				image1.set_color(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo() * 5f);
				Image image2 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Panel_Backdrop").GetComponent<Image>();
				while (image2 == null)
				{
					yield return null;
				}
				image2.set_color(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo() * 5f);
				Image component3 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Right").GetComponent<Image>();
				while (component3 == null)
				{
					yield return null;
				}
				component3.set_color(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo() * 5f);
				Image image3 = GameObject.Find("/UserInterface/MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/Decoration_Left").GetComponent<Image>();
				while (image3 == null)
				{
					yield return null;
				}
				image3.set_color(MWNRsi8GYTaTweXXZ8t.ElE84MW3vo() * 5f);
				component = null;
				light = null;
				reflectionProbe = null;
				material2 = null;
				particleSystem = null;
				particleSystemRenderer = null;
				material4 = null;
				gameObject = null;
				gameObject1 = null;
				component1 = null;
				component2 = null;
				texture = null;
				gameObject2 = null;
				gameObject3 = null;
				image = null;
				image1 = null;
				image2 = null;
				component3 = null;
				image3 = null;
			}
		}

		internal static PFkqXMuodBMin29BhG jo563gJm2FZUfj7hR6J()
		{
			return PFkqXMuodBMin29BhG.S8VqN8JdJZtLBb0Siwd;
		}

		internal static bool kj14WfJoOEve21NUTBM()
		{
			return PFkqXMuodBMin29BhG.S8VqN8JdJZtLBb0Siwd == null;
		}
	}
}