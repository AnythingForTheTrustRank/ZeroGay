using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void H61KOKuArO9eoJAIgxE(object object_0, Font font_0);