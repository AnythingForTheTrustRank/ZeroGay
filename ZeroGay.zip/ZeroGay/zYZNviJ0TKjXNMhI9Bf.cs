using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate int zYZNviJ0TKjXNMhI9Bf(ref int , int );