using AksgHVKH9UOXlBDvRpO;
using System;
using System.Diagnostics;

internal delegate Process Uv9V1aLZ3tthfWRo2U7(string string_0);