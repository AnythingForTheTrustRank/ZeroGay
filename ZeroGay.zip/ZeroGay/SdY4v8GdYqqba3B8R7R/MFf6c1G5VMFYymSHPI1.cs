using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC.Networking;

namespace SdY4v8GdYqqba3B8R7R
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class MFf6c1G5VMFYymSHPI1
	{
		public static bool IxtGmtMPZs;

		private static MFf6c1G5VMFYymSHPI1 hFP6ZI5THL1FD72SMj3;

		public MFf6c1G5VMFYymSHPI1()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool cjiXbx5vp0uhy72Ftpt()
		{
			return MFf6c1G5VMFYymSHPI1.hFP6ZI5THL1FD72SMj3 == null;
		}

		public static bool gaJGoys8xx(ref string u0020, object u0020)
		{
			bool flag;
			if (!MFf6c1G5VMFYymSHPI1.IxtGmtMPZs)
			{
				flag = true;
			}
			else
			{
				flag = (u0020 != "SyncPenalty" ? true : false);
			}
			return flag;
		}

		internal static MFf6c1G5VMFYymSHPI1 oKxO5M5a1ZEk61hHLut()
		{
			return MFf6c1G5VMFYymSHPI1.hFP6ZI5THL1FD72SMj3;
		}
	}
}