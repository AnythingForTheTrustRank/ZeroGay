using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using System;

internal delegate Il2CppSystem.Type dKSlj0ppWiwwrd9SIp5(object object_0);