using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;

internal delegate Il2CppStructArray<byte> t6MVKOWevUinHeIm0Lp(object object_0);