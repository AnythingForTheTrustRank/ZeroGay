using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections;

internal delegate object XHBIYn8nrY80UWh2rMW(IEnumerator ienumerator_0);