using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate AssetBundle BrPGB2ERQa3VkbJy7N2(Il2CppStructArray<byte> il2CppStructArray_0, uint uint_0);