using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;

namespace WkLLRbyE9Wil4KNEe11
{
	internal class cmFAXby8sKuqHARyc1s : MonoBehaviour
	{
		public static bool wvAyW01U8O;

		public static float VL2yU3107F;

		internal static cmFAXby8sKuqHARyc1s LcEjY8DWvLl4iY2LEaI;

		public cmFAXby8sKuqHARyc1s(IntPtr intptr_0)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base(intptr_0);
		}

		internal static GameObject[] bMLypkfLqM()
		{
			return SceneManager.GetActiveScene().GetRootGameObjects();
		}

		internal static bool ECgXupDUBEiUNb0cQCB()
		{
			return cmFAXby8sKuqHARyc1s.LcEjY8DWvLl4iY2LEaI == null;
		}

		internal static cmFAXby8sKuqHARyc1s l7paOODPsB9ZBGS0Y3H()
		{
			return cmFAXby8sKuqHARyc1s.LcEjY8DWvLl4iY2LEaI;
		}

		internal static GameObject LRaywKefiJ()
		{
			GameObject gameObject;
			GameObject[] gameObjectArray = cmFAXby8sKuqHARyc1s.bMLypkfLqM();
			int num = 0;
			while (true)
			{
				if (num < (int)gameObjectArray.Length)
				{
					GameObject gameObject1 = gameObjectArray[num];
					if (gameObject1.get_name().StartsWith("VRCPlayer[Local]"))
					{
						gameObject = gameObject1;
						break;
					}
					else
					{
						num++;
					}
				}
				else
				{
					gameObject = new GameObject();
					break;
				}
			}
			return gameObject;
		}

		private void OnCollisionEnter(Collision collision)
		{
			if (!collision.get_transform().get_name().Contains("VRCPlayer"))
			{
				foreach (ContactPoint contact in collision.get_contacts())
				{
					if (!cmFAXby8sKuqHARyc1s.wvAyW01U8O)
					{
						continue;
					}
					Vector3 vector3 = new Vector3(contact.get_point().x, contact.get_point().y, contact.get_point().z);
					cmFAXby8sKuqHARyc1s.LRaywKefiJ().get_transform().set_position(vector3);
					UnityEngine.Object.Destroy(base.get_gameObject());
				}
			}
		}

		private void OnCollisionExit(Collision other)
		{
		}

		private void OnDestroy()
		{
			cmFAXby8sKuqHARyc1s.wvAyW01U8O = false;
		}

		public void OnDisable()
		{
			cmFAXby8sKuqHARyc1s.wvAyW01U8O = false;
		}

		public void OnEnable()
		{
			cmFAXby8sKuqHARyc1s.wvAyW01U8O = false;
		}

		public void Start()
		{
		}

		public void Update()
		{
			if (base.get_gameObject().GetComponent<VRC_Pickup>().get_IsHeld())
			{
				cmFAXby8sKuqHARyc1s.wvAyW01U8O = true;
			}
			if (cmFAXby8sKuqHARyc1s.wvAyW01U8O)
			{
				base.get_gameObject().GetComponent<Rigidbody>().set_useGravity(true);
				base.get_gameObject().GetComponent<BoxCollider>().set_isTrigger(false);
			}
			cmFAXby8sKuqHARyc1s.VL2yU3107F = 0f;
		}
	}
}