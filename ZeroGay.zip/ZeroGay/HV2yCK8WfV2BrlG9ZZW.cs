using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int HV2yCK8WfV2BrlG9ZZW(object object_0);