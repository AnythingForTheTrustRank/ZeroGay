using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string oedtNHwXg0LY4WR3uYS(string string_0, string string_1, string string_2);