using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate byte p2bkqIF88EtfrKB6Lhk(object );