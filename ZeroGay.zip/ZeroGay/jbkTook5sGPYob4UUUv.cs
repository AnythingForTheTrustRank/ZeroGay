using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object jbkTook5sGPYob4UUUv(Type type_0);