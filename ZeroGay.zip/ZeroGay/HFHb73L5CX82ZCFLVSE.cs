using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.SDKBase;

internal delegate void HFHb73L5CX82ZCFLVSE(object object_0, VRCPlayerApi vrcplayerApi_0);