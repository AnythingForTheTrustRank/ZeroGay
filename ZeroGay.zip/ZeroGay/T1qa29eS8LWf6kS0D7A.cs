using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate VRCInput T1qa29eS8LWf6kS0D7A(string );