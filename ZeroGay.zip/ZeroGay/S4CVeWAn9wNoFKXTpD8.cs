using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using System;

internal delegate void S4CVeWAn9wNoFKXTpD8(object , string , WorldTransitionInfo , Il2CppSystem.Action<string> , bool );