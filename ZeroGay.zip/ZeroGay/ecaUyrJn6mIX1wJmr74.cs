using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate RuntimeTypeHandle ecaUyrJn6mIX1wJmr74(object );