using b3eD5DgJPcASx0xfHYB;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;
using VRC.UI.Elements;

namespace Blaze.API.QM
{
	public class QMNestedButton
	{
		protected string btnQMLoc;

		protected GameObject MenuObject;

		protected TextMeshProUGUI MenuTitleText;

		protected UIPage MenuPage;

		protected bool IsMenuRoot;

		protected GameObject BackButton;

		protected QMSingleButton MainButton;

		protected string MenuName;

		internal static QMNestedButton ow4xPWDByrj79HOCDjr;

		public QMNestedButton(QMNestedButton location, string btnText, float posX, float posY, string toolTipText, string menuTitle)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.btnQMLoc = location.GetMenuName();
			this.wxaCg6rWxL(false, btnText, posX, posY, toolTipText, menuTitle);
		}

		public QMNestedButton(string location, string btnText, float posX, float posY, string toolTipText, string menuTitle)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.btnQMLoc = location;
			this.wxaCg6rWxL(location.StartsWith("Menu_"), btnText, posX, posY, toolTipText, menuTitle);
		}

		public void CloseMe()
		{
			this.MenuPage.Method_Public_Virtual_New_Void_0();
		}

		public GameObject GetBackButton()
		{
			return this.BackButton;
		}

		public QMSingleButton GetMainButton()
		{
			return this.MainButton;
		}

		public string GetMenuName()
		{
			return this.MenuName;
		}

		public GameObject GetMenuObject()
		{
			return this.MenuObject;
		}

		internal static QMNestedButton HcJeq4DllPW1HpwjGEr()
		{
			return QMNestedButton.ow4xPWDByrj79HOCDjr;
		}

		public void OpenMe()
		{
			yLWOmZwmRqSychwym35.KWIwcIFxsB().Method_Public_get_MenuStateController_0().Method_Public_Void_String_UIContext_Boolean_0(this.MenuPage.get_field_Public_String_0(), null, false);
		}

		private void wxaCg6rWxL(bool u0020, string u0020, float u0020, float u0020, string u0020, string u0020)
		{
			QMNestedButton.<>c__DisplayClass10_0 variable = null;
			this.MenuName = string.Format("{0}-Menu-{1}", "WTFBlaze", yLWOmZwmRqSychwym35.Fn2N9KXqf1());
			this.MenuObject = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.z1twzw6Ggk(), yLWOmZwmRqSychwym35.z1twzw6Ggk().get_transform().get_parent());
			this.MenuObject.set_name(this.MenuName);
			this.MenuObject.SetActive(false);
			UnityEngine.Object.DestroyImmediate(this.MenuObject.GetComponent<LaunchPadQMMenu>());
			this.MenuPage = this.MenuObject.AddComponent<UIPage>();
			this.MenuPage.set_field_Public_String_0(this.MenuName);
			this.MenuPage.set_field_Private_Boolean_1(true);
			this.MenuPage.set_field_Private_MenuStateController_0(yLWOmZwmRqSychwym35.KWIwcIFxsB().Method_Public_get_MenuStateController_0());
			this.MenuPage.set_field_Private_List_1_UIPage_0(new Il2CppSystem.Collections.Generic.List<UIPage>());
			this.MenuPage.get_field_Private_List_1_UIPage_0().Add(this.MenuPage);
			yLWOmZwmRqSychwym35.KWIwcIFxsB().Method_Public_get_MenuStateController_0().get_field_Private_Dictionary_2_String_UIPage_0().Add(this.MenuName, this.MenuPage);
			if (u0020)
			{
				System.Collections.Generic.List<UIPage> list = yLWOmZwmRqSychwym35.KWIwcIFxsB().Method_Public_get_MenuStateController_0().get_field_Public_ArrayOf_UIPage_0().ToList<UIPage>();
				list.Add(this.MenuPage);
				yLWOmZwmRqSychwym35.KWIwcIFxsB().Method_Public_get_MenuStateController_0().set_field_Public_ArrayOf_UIPage_0(list.ToArray());
			}
			this.MenuObject.get_transform().Find("ScrollRect/Viewport/VerticalLayoutGroup").AUyNsBTZDb();
			this.MenuTitleText = this.MenuObject.GetComponentInChildren<TextMeshProUGUI>(true);
			this.MenuTitleText.set_text(u0020);
			this.IsMenuRoot = u0020;
			this.BackButton = this.MenuObject.get_transform().GetChild(0).Find("LeftItemContainer/Button_Back").get_gameObject();
			this.BackButton.SetActive(true);
			this.BackButton.GetComponentInChildren<Button>().set_onClick(new Button.ButtonClickedEvent());
			this.BackButton.GetComponentInChildren<Button>().get_onClick().AddListener(new Action(() => {
				if (!u0020)
				{
					this.MenuPage.Method_Protected_Virtual_New_Void_0();
				}
				else if (this.btnQMLoc.StartsWith("Menu_"))
				{
					yLWOmZwmRqSychwym35.KWIwcIFxsB().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0(string.Concat("QuickMenu", this.btnQMLoc.Remove(0, 5)), false);
				}
				else
				{
					yLWOmZwmRqSychwym35.KWIwcIFxsB().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0(this.btnQMLoc, false);
				}
			}));
			this.MenuObject.get_transform().GetChild(0).Find("RightItemContainer/Button_QM_Expand").get_gameObject().SetActive(false);
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			this.MainButton = new QMSingleButton(this.btnQMLoc, u0020, u0020, string.Concat("<color=#7400FF>", u0020, "</color>"), new Action(this.OpenMe), u0020, nullable1, nullable, false);
			for (int i = 0; i < this.MenuObject.get_transform().get_childCount(); i++)
			{
				if (this.MenuObject.get_transform().GetChild(i).get_name() != "Header_H1" && this.MenuObject.get_transform().GetChild(i).get_name() != "ScrollRect")
				{
					UnityEngine.Object.Destroy(this.MenuObject.get_transform().GetChild(i).get_gameObject());
				}
			}
			UnityEngine.Object.Destroy(this.MainButton.GetGameObject().GetComponent<StyleElement>());
			this.MainButton.GetGameObject().get_transform().Find("Background").GetComponent<Image>().set_sprite(null);
			MelonCoroutines.Start(variable.VnAgTjll7d());
			vBMVdGwfepiujjMKYNt.gfvwKWKX27.Add(this);
		}

		internal static bool YG8ZQjDPewA5Y5TOD43()
		{
			return QMNestedButton.ow4xPWDByrj79HOCDjr == null;
		}
	}
}