using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using tj5E7kTcTdevpjQ41CC;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;
using VRC.UI.Elements;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.QM
{
	public class QMNestedButton
	{
		protected string btnQMLoc;

		protected GameObject MenuObject;

		protected TextMeshProUGUI MenuTitleText;

		protected UIPage MenuPage;

		protected bool IsMenuRoot;

		protected GameObject BackButton;

		protected QMSingleButton MainButton;

		protected string MenuName;

		private static QMNestedButton VOjy8C4TLnGoqBsfWfo;

		public QMNestedButton(QMNestedButton location, string btnText, float posX, float posY, string toolTipText, string menuTitle)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.btnQMLoc = location.GetMenuName();
			this.lC17iE6SG1(false, btnText, posX, posY, toolTipText, menuTitle);
		}

		public QMNestedButton(string location, string btnText, float posX, float posY, string toolTipText, string menuTitle)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.btnQMLoc = location;
			this.lC17iE6SG1(location.StartsWith("Menu_"), btnText, posX, posY, toolTipText, menuTitle);
		}

		public void CloseMe()
		{
			this.MenuPage.Method_Public_Virtual_New_Void_0();
		}

		public GameObject GetBackButton()
		{
			return this.BackButton;
		}

		public QMSingleButton GetMainButton()
		{
			return this.MainButton;
		}

		public string GetMenuName()
		{
			return this.MenuName;
		}

		public GameObject GetMenuObject()
		{
			return this.MenuObject;
		}

		internal static QMNestedButton hZPvra4e6l6JOJe9RU7()
		{
			return QMNestedButton.VOjy8C4TLnGoqBsfWfo;
		}

		internal static bool KZRORA47Y13ovXZPt3N()
		{
			return QMNestedButton.VOjy8C4TLnGoqBsfWfo == null;
		}

		private void lC17iE6SG1(bool bool_0, string string_0, float float_0, float float_1, string string_1, string string_2)
		{
			QMNestedButton.<>c__DisplayClass10_0 variable = null;
			this.MenuName = string.Format("{0}-Menu-{1}", "WTFBlaze", x5iKdsT53msph4ugL7v.accTMUKvyj());
			this.MenuObject = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.adPTIt3N6U(), x5iKdsT53msph4ugL7v.adPTIt3N6U().get_transform().get_parent());
			this.MenuObject.set_name(this.MenuName);
			this.MenuObject.SetActive(false);
			UnityEngine.Object.DestroyImmediate(this.MenuObject.GetComponent<LaunchPadQMMenu>());
			this.MenuPage = this.MenuObject.AddComponent<UIPage>();
			this.MenuPage.set_field_Public_String_0(this.MenuName);
			this.MenuPage.set_field_Private_Boolean_1(true);
			this.MenuPage.set_field_Private_MenuStateController_0(x5iKdsT53msph4ugL7v.lcQTnhPaXn().Method_Public_get_MenuStateController_0());
			this.MenuPage.set_field_Private_List_1_UIPage_0(new Il2CppSystem.Collections.Generic.List<UIPage>());
			this.MenuPage.get_field_Private_List_1_UIPage_0().Add(this.MenuPage);
			x5iKdsT53msph4ugL7v.lcQTnhPaXn().Method_Public_get_MenuStateController_0().get_field_Private_Dictionary_2_String_UIPage_0().Add(this.MenuName, this.MenuPage);
			if (bool_0)
			{
				System.Collections.Generic.List<UIPage> list = x5iKdsT53msph4ugL7v.lcQTnhPaXn().Method_Public_get_MenuStateController_0().get_field_Public_ArrayOf_UIPage_0().ToList<UIPage>();
				list.Add(this.MenuPage);
				x5iKdsT53msph4ugL7v.lcQTnhPaXn().Method_Public_get_MenuStateController_0().set_field_Public_ArrayOf_UIPage_0(list.ToArray());
			}
			this.MenuObject.get_transform().Find("ScrollRect/Viewport/VerticalLayoutGroup").eAFTapGNgO();
			this.MenuTitleText = this.MenuObject.GetComponentInChildren<TextMeshProUGUI>(true);
			this.MenuTitleText.set_text(string_2);
			this.IsMenuRoot = bool_0;
			this.BackButton = this.MenuObject.get_transform().GetChild(0).Find("LeftItemContainer/Button_Back").get_gameObject();
			this.BackButton.SetActive(true);
			this.BackButton.GetComponentInChildren<Button>().set_onClick(new Button.ButtonClickedEvent());
			this.BackButton.GetComponentInChildren<Button>().get_onClick().AddListener(new Action(() => {
				if (!bool_0)
				{
					this.MenuPage.Method_Protected_Virtual_New_Void_0();
				}
				else if (!this.btnQMLoc.StartsWith("Menu_"))
				{
					x5iKdsT53msph4ugL7v.lcQTnhPaXn().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0(this.btnQMLoc, false);
				}
				else
				{
					x5iKdsT53msph4ugL7v.lcQTnhPaXn().Method_Public_get_MenuStateController_0().Method_Public_Void_String_Boolean_0(string.Concat("QuickMenu", this.btnQMLoc.Remove(0, 5)), false);
				}
			}));
			this.MenuObject.get_transform().GetChild(0).Find("RightItemContainer/Button_QM_Expand").get_gameObject().SetActive(false);
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			this.MainButton = new QMSingleButton(this.btnQMLoc, float_0, float_1, string.Concat("<color=#7400FF>", string_0, "</color>"), new Action(this.OpenMe), string_1, nullable1, nullable, false);
			for (int i = 0; i < this.MenuObject.get_transform().get_childCount(); i++)
			{
				if ((this.MenuObject.get_transform().GetChild(i).get_name() != "Header_H1" ? this.MenuObject.get_transform().GetChild(i).get_name() != "ScrollRect" : false))
				{
					UnityEngine.Object.Destroy(this.MenuObject.get_transform().GetChild(i).get_gameObject());
				}
			}
			UnityEngine.Object.Destroy(this.MainButton.GetGameObject().GetComponent<StyleElement>());
			this.MainButton.GetGameObject().get_transform().Find("Background").GetComponent<Image>().set_sprite(null);
			MelonCoroutines.Start(variable.mHdtmNM8FO());
			UUyEqSykY4SKTrGkSI9.UdByDTInVW.Add(this);
		}

		public void OpenMe()
		{
			x5iKdsT53msph4ugL7v.lcQTnhPaXn().Method_Public_get_MenuStateController_0().Method_Public_Void_String_UIContext_Boolean_0(this.MenuPage.get_field_Public_String_0(), null, false);
		}
	}
}