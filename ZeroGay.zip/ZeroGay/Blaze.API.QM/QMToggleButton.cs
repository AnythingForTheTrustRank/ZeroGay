using b3eD5DgJPcASx0xfHYB;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace Blaze.API.QM
{
	public class QMToggleButton : QMButtonBase
	{
		protected TextMeshProUGUI btnTextComp;

		protected Button btnComp;

		protected Image btnImageComp;

		protected bool currentState;

		protected Action OnAction;

		protected Action OffAction;

		private static QMToggleButton pQDgJUDecOfxi85NcSa;

		public QMToggleButton(QMNestedButton location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.btnQMLoc = location.GetMenuName();
			this.KOb2301qNj(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		public QMToggleButton(string location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.btnQMLoc = location;
			this.KOb2301qNj(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		public void ClickMe()
		{
			this.I8Z29jf7PM();
		}

		public bool GetCurrentState()
		{
			return this.currentState;
		}

		private void I8Z29jf7PM()
		{
			this.currentState = !this.currentState;
			Sprite sprite = (this.currentState ? yLWOmZwmRqSychwym35.svgNGwaoi4() : yLWOmZwmRqSychwym35.NBXN3wbHYn());
			this.btnImageComp.set_sprite(sprite);
			this.btnImageComp.set_overrideSprite(sprite);
			if (this.currentState)
			{
				this.OnAction();
			}
			else
			{
				this.OffAction();
			}
		}

		private void KOb2301qNj(float u0020, float u0020, string u0020, Action u0020, Action u0020, string u0020, bool u0020)
		{
			this.btnType = "ToggleButton";
			this.button = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.oBOwEBOhW7(), GameObject.Find(string.Concat("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/", this.btnQMLoc)).get_transform(), true);
			this.button.set_name(string.Format("{0}-{1}-{2}", "WTFBlaze", this.btnType, yLWOmZwmRqSychwym35.Fn2N9KXqf1()));
			this.button.GetComponent<RectTransform>().set_sizeDelta(new Vector2(200f, 176f));
			this.button.GetComponent<RectTransform>().set_anchoredPosition(new Vector2(-68f, 796f));
			this.btnTextComp = this.button.GetComponentInChildren<TextMeshProUGUI>(true);
			this.btnComp = this.button.GetComponentInChildren<Button>(true);
			this.btnComp.set_onClick(new Button.ButtonClickedEvent());
			this.btnComp.get_onClick().AddListener(new Action(this.I8Z29jf7PM));
			this.btnImageComp = this.button.get_transform().Find("Icon").GetComponentInChildren<Image>(true);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			base.SetLocation(u0020, u0020);
			this.SetButtonText(string.Concat("<color=#7400FF>", u0020, "</color>"));
			this.SetButtonActions(u0020, u0020);
			base.SetToolTip(u0020);
			base.SetActive(true);
			this.currentState = u0020;
			Sprite sprite = (this.currentState ? yLWOmZwmRqSychwym35.svgNGwaoi4() : yLWOmZwmRqSychwym35.NBXN3wbHYn());
			this.btnImageComp.set_sprite(sprite);
			this.btnImageComp.set_overrideSprite(sprite);
			UnityEngine.Object.Destroy(this.button.get_gameObject().GetComponent<StyleElement>());
			MelonCoroutines.Start(this.zJc2s3GuHS());
			vBMVdGwfepiujjMKYNt.vXLwAhaFOE.Add(this);
		}

		internal static bool O2eACvDfUNVTUsZLr8u()
		{
			return QMToggleButton.pQDgJUDecOfxi85NcSa == null;
		}

		internal static QMToggleButton RujglSDxAsoNcK3Hktw()
		{
			return QMToggleButton.pQDgJUDecOfxi85NcSa;
		}

		public void SetButtonActions(Action onAction, Action offAction)
		{
			this.OnAction = onAction;
			this.OffAction = offAction;
		}

		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().set_text(buttonText);
		}

		public void SetToggleState(bool newState, bool shouldInvoke = false)
		{
			try
			{
				Sprite sprite = (newState ? yLWOmZwmRqSychwym35.svgNGwaoi4() : yLWOmZwmRqSychwym35.NBXN3wbHYn());
				this.btnImageComp.set_sprite(sprite);
				this.btnImageComp.set_overrideSprite(sprite);
				if (shouldInvoke)
				{
					if (!newState)
					{
						this.OffAction();
					}
					else
					{
						this.OnAction();
					}
				}
			}
			catch
			{
			}
		}
	}
}