using AksgHVKH9UOXlBDvRpO;
using MelonLoader;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using tj5E7kTcTdevpjQ41CC;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.QM
{
	public class QMToggleButton : QMButtonBase
	{
		protected TextMeshProUGUI btnTextComp;

		protected Button btnComp;

		protected Image btnImageComp;

		protected bool currentState;

		protected Action OnAction;

		protected Action OffAction;

		private static QMToggleButton dbPst84Ayfa5koPjWtr;

		public QMToggleButton(QMNestedButton location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.btnQMLoc = location.GetMenuName();
			this.g3Ke2boRR5(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		public QMToggleButton(string location, float btnXPos, float btnYPos, string btnText, Action onAction, Action offAction, string btnToolTip, bool defaultState = false)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.btnQMLoc = location;
			this.g3Ke2boRR5(btnXPos, btnYPos, btnText, onAction, offAction, btnToolTip, defaultState);
		}

		internal static bool bgA09S4GiaBfwRHysvb()
		{
			return QMToggleButton.dbPst84Ayfa5koPjWtr == null;
		}

		public void ClickMe()
		{
			this.xb2eMWlMJE();
		}

		private void g3Ke2boRR5(float float_0, float float_1, string string_0, Action action_0, Action action_1, string string_1, bool bool_0)
		{
			this.btnType = "ToggleButton";
			this.button = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.KZmTOk2LMU(), GameObject.Find(string.Concat("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/", this.btnQMLoc)).get_transform(), true);
			this.button.set_name(string.Format("{0}-{1}-{2}", "WTFBlaze", this.btnType, x5iKdsT53msph4ugL7v.accTMUKvyj()));
			this.button.GetComponent<RectTransform>().set_sizeDelta(new Vector2(200f, 176f));
			this.button.GetComponent<RectTransform>().set_anchoredPosition(new Vector2(-68f, 796f));
			this.btnTextComp = this.button.GetComponentInChildren<TextMeshProUGUI>(true);
			this.btnComp = this.button.GetComponentInChildren<Button>(true);
			this.btnComp.set_onClick(new Button.ButtonClickedEvent());
			this.btnComp.get_onClick().AddListener(new Action(this.xb2eMWlMJE));
			this.btnImageComp = this.button.get_transform().Find("Icon").GetComponentInChildren<Image>(true);
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			base.SetLocation(float_0, float_1);
			this.SetButtonText(string.Concat("<color=#7400FF>", string_0, "</color>"));
			this.SetButtonActions(action_0, action_1);
			base.SetToolTip(string_1);
			base.SetActive(true);
			this.currentState = bool_0;
			Sprite sprite = (this.currentState ? x5iKdsT53msph4ugL7v.dZgTrfwTya() : x5iKdsT53msph4ugL7v.Kl0T2DM75U());
			this.btnImageComp.set_sprite(sprite);
			this.btnImageComp.set_overrideSprite(sprite);
			UnityEngine.Object.Destroy(this.button.get_gameObject().GetComponent<StyleElement>());
			MelonCoroutines.Start(this.Gn3eaWmXrE());
			UUyEqSykY4SKTrGkSI9.vqFygGdLuS.Add(this);
		}

		public bool GetCurrentState()
		{
			return this.currentState;
		}

		public void SetButtonActions(Action onAction, Action offAction)
		{
			this.OnAction = onAction;
			this.OffAction = offAction;
		}

		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().set_text(buttonText);
		}

		public void SetToggleState(bool newState, bool shouldInvoke = false)
		{
			try
			{
				Sprite sprite = (!newState ? x5iKdsT53msph4ugL7v.Kl0T2DM75U() : x5iKdsT53msph4ugL7v.dZgTrfwTya());
				this.btnImageComp.set_sprite(sprite);
				this.btnImageComp.set_overrideSprite(sprite);
				if (shouldInvoke)
				{
					if (!newState)
					{
						this.OffAction();
					}
					else
					{
						this.OnAction();
					}
				}
			}
			catch
			{
			}
		}

		internal static QMToggleButton uFRy2g4d7DFa1fONapZ()
		{
			return QMToggleButton.dbPst84Ayfa5koPjWtr;
		}

		private void xb2eMWlMJE()
		{
			this.currentState = !this.currentState;
			Sprite sprite = (!this.currentState ? x5iKdsT53msph4ugL7v.Kl0T2DM75U() : x5iKdsT53msph4ugL7v.dZgTrfwTya());
			this.btnImageComp.set_sprite(sprite);
			this.btnImageComp.set_overrideSprite(sprite);
			if (!this.currentState)
			{
				this.OffAction();
			}
			else
			{
				this.OnAction();
			}
		}
	}
}