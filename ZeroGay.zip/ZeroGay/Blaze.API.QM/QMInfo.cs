using AksgHVKH9UOXlBDvRpO;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections.Generic;
using tj5E7kTcTdevpjQ41CC;
using UnityEngine;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.QM
{
	public class QMInfo
	{
		public GameObject InfoObject;

		public Text InfoText;

		public Image InfoBackground;

		internal static QMInfo oen4fV4BEwtwMcC4DvF;

		public QMInfo(Transform location, float PosX, float PosY, float SizeX, float SizeY, string PanelText)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.PWA7quuOcD(location, PosX, PosY, SizeX, SizeY, PanelText);
		}

		public QMInfo(QMNestedButton location, float PosX, float PosY, float SizeX, float SizeY, string PanelText)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.PWA7quuOcD(location.GetMenuObject().get_transform(), PosX, PosY, SizeX, SizeY, PanelText);
		}

		internal static bool JOyAbo4rkNHHUpP9RRM()
		{
			return QMInfo.oen4fV4BEwtwMcC4DvF == null;
		}

		private void PWA7quuOcD(Transform transform_0, float float_0, float float_1, float float_2, float float_3, string string_0)
		{
			this.InfoObject = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.F8fTogOgTD(), transform_0);
			this.InfoObject.set_name(string.Format("InfoPanel-{0}", x5iKdsT53msph4ugL7v.accTMUKvyj()));
			this.InfoText = this.InfoObject.GetComponentInChildren<Text>();
			this.InfoBackground = this.InfoObject.GetComponentInChildren<Image>();
			this.SetSize(new Vector2(float_2, float_3));
			this.SetLocation(new Vector3(float_0, float_1, 1f));
			this.SetText(string_0);
			UUyEqSykY4SKTrGkSI9.ahWy4JnWQS.Add(this);
		}

		public void SetActive(bool state)
		{
			this.InfoObject.SetActive(state);
		}

		public void SetLocation(Vector3 location)
		{
			this.InfoObject.GetComponent<RectTransform>().set_anchoredPosition(location);
		}

		public void SetSize(Vector2 size)
		{
			this.InfoObject.GetComponent<RectTransform>().set_sizeDelta(size);
			this.InfoObject.get_transform().Find("Text").GetComponent<RectTransform>().set_sizeDelta(new Vector2(-25f, 0f));
		}

		public void SetText(string text)
		{
			this.InfoText.set_text(text);
		}

		public void SetTextColor(Color newColor)
		{
			this.InfoText.set_color(newColor);
		}

		internal static QMInfo SnH5YW42R94r0JvnXye()
		{
			return QMInfo.oen4fV4BEwtwMcC4DvF;
		}

		public void ToggleBackground(bool state)
		{
			this.InfoObject.GetComponentInChildren<Image>().set_enabled(state);
		}
	}
}