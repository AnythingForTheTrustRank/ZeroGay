using b3eD5DgJPcASx0xfHYB;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Blaze.API.QM
{
	public class QMInfo
	{
		public GameObject InfoObject;

		public Text InfoText;

		public Image InfoBackground;

		internal static QMInfo yhO3rnDWqAtnfdfcTEC;

		public QMInfo(Transform location, float PosX, float PosY, float SizeX, float SizeY, string PanelText)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.NOfCteIAe1(location, PosX, PosY, SizeX, SizeY, PanelText);
		}

		public QMInfo(QMNestedButton location, float PosX, float PosY, float SizeX, float SizeY, string PanelText)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.NOfCteIAe1(location.GetMenuObject().get_transform(), PosX, PosY, SizeX, SizeY, PanelText);
		}

		private void NOfCteIAe1(Transform u0020, float u0020, float u0020, float u0020, float u0020, string u0020)
		{
			this.InfoObject = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.hkkNqIMM7Q(), u0020);
			this.InfoObject.set_name(string.Format("InfoPanel-{0}", yLWOmZwmRqSychwym35.Fn2N9KXqf1()));
			this.InfoText = this.InfoObject.GetComponentInChildren<Text>();
			this.InfoBackground = this.InfoObject.GetComponentInChildren<Image>();
			this.SetSize(new Vector2(u0020, u0020));
			this.SetLocation(new Vector3(u0020, u0020, 1f));
			this.SetText(u0020);
			vBMVdGwfepiujjMKYNt.exVwVhMLsF.Add(this);
		}

		internal static bool QgJEXbDu7h5X9YUbY52()
		{
			return QMInfo.yhO3rnDWqAtnfdfcTEC == null;
		}

		public void SetActive(bool state)
		{
			this.InfoObject.SetActive(state);
		}

		public void SetLocation(Vector3 location)
		{
			this.InfoObject.GetComponent<RectTransform>().set_anchoredPosition(location);
		}

		public void SetSize(Vector2 size)
		{
			this.InfoObject.GetComponent<RectTransform>().set_sizeDelta(size);
			this.InfoObject.get_transform().Find("Text").GetComponent<RectTransform>().set_sizeDelta(new Vector2(-25f, 0f));
		}

		public void SetText(string text)
		{
			this.InfoText.set_text(text);
		}

		public void SetTextColor(Color newColor)
		{
			this.InfoText.set_color(newColor);
		}

		public void ToggleBackground(bool state)
		{
			this.InfoObject.GetComponentInChildren<Image>().set_enabled(state);
		}

		internal static QMInfo VAVNrKDS4I5dk26sub6()
		{
			return QMInfo.yhO3rnDWqAtnfdfcTEC;
		}
	}
}