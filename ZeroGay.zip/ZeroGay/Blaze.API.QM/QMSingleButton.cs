using b3eD5DgJPcASx0xfHYB;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using TMPro;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;
using ZeroDayAPI.Buttons;

namespace Blaze.API.QM
{
	public class QMSingleButton : QMButtonBase
	{
		private static QMSingleButton UepNRyDiOrAS9BmFoyB;

		public QMSingleButton(QMNestedButton btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.btnQMLoc = btnMenu.GetMenuName();
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.WuECVItyfD(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor);
			if (halfBtn)
			{
				RectTransform componentInChildren = this.button.GetComponentInChildren<RectTransform>();
				componentInChildren.set_sizeDelta(componentInChildren.get_sizeDelta() / new Vector2(1f, 2f));
				this.button.GetComponentInChildren<TextMeshProUGUI>().get_rectTransform().set_anchoredPosition(new Vector2(0f, 22f));
			}
		}

		public QMSingleButton(string btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.btnQMLoc = btnMenu;
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.WuECVItyfD(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor);
			if (halfBtn)
			{
				RectTransform componentInChildren = this.button.GetComponentInChildren<RectTransform>();
				componentInChildren.set_sizeDelta(componentInChildren.get_sizeDelta() / new Vector2(1f, 2f));
				this.button.GetComponentInChildren<TextMeshProUGUI>().get_rectTransform().set_anchoredPosition(new Vector2(0f, 22f));
			}
		}

		internal override void BWbl9OOT2q(Color buttonBackgroundColor, bool save = true)
		{
			this.button.GetComponentInChildren<Image>().set_color(buttonBackgroundColor);
		}

		public void ClickMe()
		{
			this.button.GetComponent<Button>().get_onClick().Invoke();
		}

		internal static QMSingleButton NfNFSXDR2s4cWorbCiY()
		{
			return QMSingleButton.UepNRyDiOrAS9BmFoyB;
		}

		internal static bool o7032KD0A4cx2cwsOo5()
		{
			return QMSingleButton.UepNRyDiOrAS9BmFoyB == null;
		}

		internal override void OlBls75fDj(Color buttonTextColor, bool save = true)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().SetOutlineColor(buttonTextColor);
			if (save)
			{
				this.OrigText = buttonTextColor;
			}
		}

		public void SetAction(Action buttonAction)
		{
			this.button.GetComponent<Button>().set_onClick(new Button.ButtonClickedEvent());
			if (buttonAction != null)
			{
				this.button.GetComponent<Button>().get_onClick().AddListener(DelegateSupport.ConvertDelegate<UnityAction>(buttonAction));
			}
		}

		public void SetBackgroundImage(Sprite newImg)
		{
			this.button.get_transform().Find("Background").GetComponent<Image>().set_sprite(newImg);
			this.button.get_transform().Find("Background").GetComponent<Image>().set_overrideSprite(newImg);
		}

		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().set_text(buttonText);
		}

		protected internal void WuECVItyfD(float u0020, float u0020, string u0020, Action u0020, string u0020, Color? u0020 = null, Color? u0020 = null)
		{
			this.btnType = "SingleButton";
			this.button = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.oBOwEBOhW7(), GameObject.Find(string.Concat("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/", this.btnQMLoc)).get_transform(), true);
			this.button.set_name(string.Format("{0}-{1}-{2}", "WTFBlaze", this.btnType, yLWOmZwmRqSychwym35.Fn2N9KXqf1()));
			this.button.GetComponentInChildren<TextMeshProUGUI>().set_fontSize(30f);
			this.button.GetComponent<RectTransform>().set_sizeDelta(new Vector2(200f, 176f));
			this.button.GetComponent<RectTransform>().set_anchoredPosition(new Vector2(-68f, 796f));
			this.button.get_transform().Find("Icon").GetComponentInChildren<Image>().get_gameObject().SetActive(false);
			RectTransform _rectTransform = this.button.GetComponentInChildren<TextMeshProUGUI>().get_rectTransform();
			_rectTransform.set_anchoredPosition(_rectTransform.get_anchoredPosition() + new Vector2(0f, 50f));
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			base.SetLocation(u0020, u0020);
			this.SetButtonText(string.Concat("<color=#7400FF>", u0020, "</color>"));
			base.SetToolTip(u0020);
			this.SetAction(u0020);
			if (!u0020.HasValue)
			{
				this.OrigBackground = this.button.GetComponentInChildren<Image>().get_color();
			}
			else
			{
				this.BWbl9OOT2q(u0020.Value, true);
			}
			if (!u0020.HasValue)
			{
				this.OrigText = this.button.GetComponentInChildren<TextMeshProUGUI>().get_color();
			}
			else
			{
				this.OlBls75fDj(u0020.Value, true);
			}
			base.SetActive(true);
			UnityEngine.Object.Destroy(this.button.get_gameObject().GetComponent<StyleElement>());
			this.button.get_gameObject().get_transform().Find("Background").GetComponent<Image>().set_sprite(null);
			MelonCoroutines.Start(this.VFuCLPKvae());
			vBMVdGwfepiujjMKYNt.sxLw14qwWP.Add(this);
		}
	}
}