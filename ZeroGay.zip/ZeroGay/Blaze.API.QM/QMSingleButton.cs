using AksgHVKH9UOXlBDvRpO;
using MelonLoader;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using tj5E7kTcTdevpjQ41CC;
using TMPro;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.QM
{
	public class QMSingleButton : QMButtonBase
	{
		internal static QMSingleButton XeZL7R4H1FhjWvJxcl9;

		public QMSingleButton(QMNestedButton btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.btnQMLoc = btnMenu.GetMenuName();
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.r7k74Ga535(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor);
			if (halfBtn)
			{
				RectTransform componentInChildren = this.button.GetComponentInChildren<RectTransform>();
				componentInChildren.set_sizeDelta(componentInChildren.get_sizeDelta() / new Vector2(1f, 2f));
				this.button.GetComponentInChildren<TextMeshProUGUI>().get_rectTransform().set_anchoredPosition(new Vector2(0f, 22f));
			}
		}

		public QMSingleButton(string btnMenu, float btnXLocation, float btnYLocation, string btnText, Action btnAction, string btnToolTip, Color? btnBackgroundColor = null, Color? btnTextColor = null, bool halfBtn = false)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.btnQMLoc = btnMenu;
			if (halfBtn)
			{
				btnYLocation -= 0.21f;
			}
			this.r7k74Ga535(btnXLocation, btnYLocation, btnText, btnAction, btnToolTip, btnBackgroundColor, btnTextColor);
			if (halfBtn)
			{
				RectTransform componentInChildren = this.button.GetComponentInChildren<RectTransform>();
				componentInChildren.set_sizeDelta(componentInChildren.get_sizeDelta() / new Vector2(1f, 2f));
				this.button.GetComponentInChildren<TextMeshProUGUI>().get_rectTransform().set_anchoredPosition(new Vector2(0f, 22f));
			}
		}

		public void ClickMe()
		{
			this.button.GetComponent<Button>().get_onClick().Invoke();
		}

		internal static QMSingleButton Cuhj0C4RpPrKPL6f5QX()
		{
			return QMSingleButton.XeZL7R4H1FhjWvJxcl9;
		}

		internal override void ic300YjffL(Color buttonTextColor, bool save = true)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().SetOutlineColor(buttonTextColor);
			if (save)
			{
				this.OrigText = buttonTextColor;
			}
		}

		internal override void kAZ09SfmPJ(Color buttonBackgroundColor, bool save = true)
		{
			this.button.GetComponentInChildren<Image>().set_color(buttonBackgroundColor);
		}

		protected internal void r7k74Ga535(float float_0, float float_1, string string_0, Action action_0, string string_1, Color? nullable_0 = null, Color? nullable_1 = null)
		{
			this.btnType = "SingleButton";
			this.button = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.KZmTOk2LMU(), GameObject.Find(string.Concat("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/", this.btnQMLoc)).get_transform(), true);
			this.button.set_name(string.Format("{0}-{1}-{2}", "WTFBlaze", this.btnType, x5iKdsT53msph4ugL7v.accTMUKvyj()));
			this.button.GetComponentInChildren<TextMeshProUGUI>().set_fontSize(30f);
			this.button.GetComponent<RectTransform>().set_sizeDelta(new Vector2(200f, 176f));
			this.button.GetComponent<RectTransform>().set_anchoredPosition(new Vector2(-68f, 796f));
			this.button.get_transform().Find("Icon").GetComponentInChildren<Image>().get_gameObject().SetActive(false);
			RectTransform _rectTransform = this.button.GetComponentInChildren<TextMeshProUGUI>().get_rectTransform();
			_rectTransform.set_anchoredPosition(_rectTransform.get_anchoredPosition() + new Vector2(0f, 50f));
			this.initShift[0] = 0;
			this.initShift[1] = 0;
			base.SetLocation(float_0, float_1);
			this.SetButtonText(string.Concat("<color=#7400FF>", string_0, "</color>"));
			base.SetToolTip(string_1);
			this.SetAction(action_0);
			if (!nullable_0.HasValue)
			{
				this.OrigBackground = this.button.GetComponentInChildren<Image>().get_color();
			}
			else
			{
				this.kAZ09SfmPJ(nullable_0.Value, true);
			}
			if (!nullable_1.HasValue)
			{
				this.OrigText = this.button.GetComponentInChildren<TextMeshProUGUI>().get_color();
			}
			else
			{
				this.ic300YjffL(nullable_1.Value, true);
			}
			base.SetActive(true);
			UnityEngine.Object.Destroy(this.button.get_gameObject().GetComponent<StyleElement>());
			this.button.get_gameObject().get_transform().Find("Background").GetComponent<Image>().set_sprite(null);
			MelonCoroutines.Start(this.Txf7j6uUKw());
			UUyEqSykY4SKTrGkSI9.f2uymf0idQ.Add(this);
		}

		public void SetAction(Action buttonAction)
		{
			this.button.GetComponent<Button>().set_onClick(new Button.ButtonClickedEvent());
			if (buttonAction != null)
			{
				this.button.GetComponent<Button>().get_onClick().AddListener(DelegateSupport.ConvertDelegate<UnityAction>(buttonAction));
			}
		}

		public void SetBackgroundImage(Sprite newImg)
		{
			this.button.get_transform().Find("Background").GetComponent<Image>().set_sprite(newImg);
			this.button.get_transform().Find("Background").GetComponent<Image>().set_overrideSprite(newImg);
		}

		public void SetButtonText(string buttonText)
		{
			this.button.GetComponentInChildren<TextMeshProUGUI>().set_text(buttonText);
		}

		internal static bool XvSl154sNqrqxPq6fZU()
		{
			return QMSingleButton.XeZL7R4H1FhjWvJxcl9 == null;
		}
	}
}