using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using UnityEngine;
using VRC.UI.Elements.Tooltips;

namespace Blaze.API.QM
{
	public class QMButtonBase
	{
		protected GameObject button;

		protected string btnQMLoc;

		protected string btnType;

		protected string btnTag;

		protected int[] initShift;

		protected Color OrigBackground;

		protected Color OrigText;

		private static QMButtonBase vk9mF6DvgI6xAqvsFXv;

		public QMButtonBase()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.initShift = new int[2];
			base();
		}

		internal virtual void BWbl9OOT2q(Color buttonBackgroundColor, bool save = true)
		{
		}

		public void DestroyMe()
		{
			try
			{
				UnityEngine.Object.Destroy(this.button);
			}
			catch
			{
			}
		}

		internal static bool f7C1UfDagY5pXEhOocR()
		{
			return QMButtonBase.vk9mF6DvgI6xAqvsFXv == null;
		}

		public GameObject GetGameObject()
		{
			return this.button;
		}

		internal virtual void OlBls75fDj(Color buttonTextColor, bool save = true)
		{
		}

		internal static QMButtonBase ReurIgDgjamkC4b5PKR()
		{
			return QMButtonBase.vk9mF6DvgI6xAqvsFXv;
		}

		public void SetActive(bool state)
		{
			this.button.get_gameObject().SetActive(state);
		}

		public void SetLocation(float buttonXLoc, float buttonYLoc)
		{
			RectTransform component = this.button.GetComponent<RectTransform>();
			component.set_anchoredPosition(component.get_anchoredPosition() + (Vector2.get_right() * (232f * (buttonXLoc + (float)this.initShift[0]))));
			RectTransform rectTransform = this.button.GetComponent<RectTransform>();
			rectTransform.set_anchoredPosition(rectTransform.get_anchoredPosition() + (Vector2.get_down() * (210f * (buttonYLoc + (float)this.initShift[1]))));
		}

		public void SetToolTip(string buttonToolTip)
		{
			this.button.GetComponent<UiTooltip>().set_field_Public_String_0(buttonToolTip);
			this.button.GetComponent<UiTooltip>().set_field_Public_String_1(buttonToolTip);
		}
	}
}