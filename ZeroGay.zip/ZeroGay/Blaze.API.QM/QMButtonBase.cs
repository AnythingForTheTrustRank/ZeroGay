using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using VRC.UI.Elements.Tooltips;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.QM
{
	public class QMButtonBase
	{
		protected GameObject button;

		protected string btnQMLoc;

		protected string btnType;

		protected string btnTag;

		protected int[] initShift;

		protected Color OrigBackground;

		protected Color OrigText;

		private static QMButtonBase MfrqdD4oCpOxayPRh3W;

		public QMButtonBase()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.initShift = new int[2];
			base();
		}

		public void DestroyMe()
		{
			try
			{
				UnityEngine.Object.Destroy(this.button);
			}
			catch
			{
			}
		}

		public GameObject GetGameObject()
		{
			return this.button;
		}

		internal virtual void ic300YjffL(Color buttonTextColor, bool save = true)
		{
		}

		internal virtual void kAZ09SfmPJ(Color buttonBackgroundColor, bool save = true)
		{
		}

		internal static bool QHvBih462lcfpJZ0c9X()
		{
			return QMButtonBase.MfrqdD4oCpOxayPRh3W == null;
		}

		internal static QMButtonBase RNndh04YY5bEWYHkISq()
		{
			return QMButtonBase.MfrqdD4oCpOxayPRh3W;
		}

		public void SetActive(bool state)
		{
			this.button.get_gameObject().SetActive(state);
		}

		public void SetLocation(float buttonXLoc, float buttonYLoc)
		{
			RectTransform component = this.button.GetComponent<RectTransform>();
			component.set_anchoredPosition(component.get_anchoredPosition() + (Vector2.get_right() * (232f * (buttonXLoc + (float)this.initShift[0]))));
			RectTransform rectTransform = this.button.GetComponent<RectTransform>();
			rectTransform.set_anchoredPosition(rectTransform.get_anchoredPosition() + (Vector2.get_down() * (210f * (buttonYLoc + (float)this.initShift[1]))));
		}

		public void SetToolTip(string buttonToolTip)
		{
			this.button.GetComponent<UiTooltip>().set_field_Public_String_0(buttonToolTip);
			this.button.GetComponent<UiTooltip>().set_field_Public_String_1(buttonToolTip);
		}
	}
}