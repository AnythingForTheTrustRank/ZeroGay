using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector3 uTRGIquDtle1SIPRgq5(object object_0, HumanBodyBones humanBodyBones_0);