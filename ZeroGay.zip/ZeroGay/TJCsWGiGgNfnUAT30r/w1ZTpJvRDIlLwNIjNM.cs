using AksgHVKH9UOXlBDvRpO;
using Eqv7LToAbLvrOaViH5d;
using Eviction;
using Harmony;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;

namespace TJCsWGiGgNfnUAT30r
{
	internal static class w1ZTpJvRDIlLwNIjNM
	{
		public static HarmonyInstance e7g1LHhHH;

		private static Sprite Js23FSdmu;

		private static AssetBundle tFxk4jMHV;

		private static Material hZCfVUWyP;

		private static Sprite JgLmLox27;

		public static Color yc1DbFcgG;

		public static Color v5igXcdTS;

		public static Color u7W4fZ9b4;

		public static Color KTgjlN7Eh;

		public static Color jiJSILKhX;

		public static Color itibNwEM6;

		public static Color BhdNmoCso;

		public static Color zfhzXq9tT;

		public static Color or9c5CPyD8;

		private static System.Collections.Generic.List<string> s0HccWJSnm;

		public static Texture2D JwUcnwtUQg;

		public static System.Collections.Generic.List<string> JNFcQW4JAc;

		public static System.Collections.Generic.List<GameObject> GsRcOya3YC;

		private static byte m4ucI8Y6rf;

		private static byte OMUcoGgS0h;

		private static int Gurc6qlDQM;

		internal static w1ZTpJvRDIlLwNIjNM YrlXTBfnnLW9THtlbN4;

		static w1ZTpJvRDIlLwNIjNM()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			w1ZTpJvRDIlLwNIjNM.yc1DbFcgG = new Color(Pu10qtoliOmmFTiu0Nu.Hla6bukjUA(), Pu10qtoliOmmFTiu0Nu.YbrY5eikQR(), Pu10qtoliOmmFTiu0Nu.s6IYQVJPrL());
			w1ZTpJvRDIlLwNIjNM.v5igXcdTS = new Color(0.3f, 1f, 1f);
			w1ZTpJvRDIlLwNIjNM.u7W4fZ9b4 = new Color(Pu10qtoliOmmFTiu0Nu.VVR63R3I1n(), Pu10qtoliOmmFTiu0Nu.gZ06mXAfgs(), Pu10qtoliOmmFTiu0Nu.mS864ugcqW());
			w1ZTpJvRDIlLwNIjNM.KTgjlN7Eh = new Color(Pu10qtoliOmmFTiu0Nu.bQYYtdxtRY(), Pu10qtoliOmmFTiu0Nu.J3WYAymVuw(), Pu10qtoliOmmFTiu0Nu.W55YvW5JaL());
			w1ZTpJvRDIlLwNIjNM.jiJSILKhX = new Color(Pu10qtoliOmmFTiu0Nu.QT1YoIxNS6(), Pu10qtoliOmmFTiu0Nu.bq4YBboJ7q(), Pu10qtoliOmmFTiu0Nu.MDUYMZrID4());
			w1ZTpJvRDIlLwNIjNM.itibNwEM6 = new Color(Pu10qtoliOmmFTiu0Nu.eouYT4wd2V(), Pu10qtoliOmmFTiu0Nu.FO1YCCPdOW(), Pu10qtoliOmmFTiu0Nu.AsiYHeqB8R());
			w1ZTpJvRDIlLwNIjNM.BhdNmoCso = new Color(Pu10qtoliOmmFTiu0Nu.AeT6UCjM7p(), Pu10qtoliOmmFTiu0Nu.cT26FRCghl(), Pu10qtoliOmmFTiu0Nu.MXR6VRea84());
			w1ZTpJvRDIlLwNIjNM.zfhzXq9tT = new Color(Pu10qtoliOmmFTiu0Nu.Lt46yv7XRf(), Pu10qtoliOmmFTiu0Nu.Dm66eGB3Bj(), 0f);
			w1ZTpJvRDIlLwNIjNM.or9c5CPyD8 = new Color(0.9f, 0f, 0.75f);
			w1ZTpJvRDIlLwNIjNM.s0HccWJSnm = new System.Collections.Generic.List<string>();
			w1ZTpJvRDIlLwNIjNM.JNFcQW4JAc = new System.Collections.Generic.List<string>()
			{
				"Admin",
				"VIP",
				"Standard"
			};
			w1ZTpJvRDIlLwNIjNM.GsRcOya3YC = new System.Collections.Generic.List<GameObject>();
			w1ZTpJvRDIlLwNIjNM.Gurc6qlDQM = 0;
		}

		internal static void B4AFtfubD(int int_0, object object_0, object object_1, Color color_0, object object_2)
		{
			Transform transform;
			Transform transform1 = object_1.Find(string.Format("EvolveTags:{0}", int_0));
			if (transform1 != null)
			{
				transform1.get_gameObject().SetActive(true);
				transform = transform1.Find("Trust Text");
			}
			else
			{
				transform = w1ZTpJvRDIlLwNIjNM.nq4PaVUNT(object_0, int_0);
			}
			TextMeshProUGUI component = transform.GetComponent<TextMeshProUGUI>();
			transform1.GetComponent<ImageThreeSlice>().set_color(color_0);
			component.set_color(color_0);
			component.set_richText(true);
			component.set_text(object_2);
		}

		public static void bv7Xp0TK6(object object_0)
		{
			Nameplate component = object_0.get_gameObject().GetComponent<Nameplate>();
			if (component != null)
			{
				component.Reset();
			}
			if ((w1ZTpJvRDIlLwNIjNM.Js23FSdmu == null ? false : component != null))
			{
				ImageThreeSlice imageThreeSlouse = component.NameBackground.GetComponent<ImageThreeSlice>();
				if (imageThreeSlouse != null)
				{
					imageThreeSlouse.set__sprite(w1ZTpJvRDIlLwNIjNM.Js23FSdmu);
				}
			}
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			w1ZTpJvRDIlLwNIjNM.UVUZlBqkd(component, new Color?(Color.get_white()), new Color?(Color.get_white()), nullable1, nullable, true, false);
		}

		public static short cn0wjG78s(this object object_0)
		{
			return object_0.Method_Public_get_PlayerNet_0().get_field_Private_Int16_0();
		}

		public static IEnumerator gme8IvpZE()
		{
			// 
			// Current member / type: System.Collections.IEnumerator TJCsWGiGgNfnUAT30r.w1ZTpJvRDIlLwNIjNM::gme8IvpZE()
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Collections.IEnumerator gme8IvpZE()
			// 
			// Index was out of range. Must be non-negative and less than the size of the collection.
			// Parameter name: index
			//    at System.ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument argument, ExceptionResource resource)
			//    at ..(Int32 ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RemoveCompilerOptimizationsStep.cs:line 364
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RemoveCompilerOptimizationsStep.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RemoveCompilerOptimizationsStep.cs:line 55
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext ,  , Func`2 , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 104
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext , & ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 139
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 134
			//    at ..Match( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 49
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 20
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public static int gtfWJOkre(this object object_0)
		{
			int num;
			num = (object_0.Method_Public_get_PlayerNet_0().Method_Public_get_Byte_0() != 0 ? (int)(1000f / (float)object_0.Method_Public_get_PlayerNet_0().Method_Public_get_Byte_0()) : 0);
			return num;
		}

		public static string H6aJfkp8M(this object object_0)
		{
			string str;
			bool flag;
			bool flag1;
			if (object_0.get_tags().Contains("Evolved"))
			{
				str = "Evolved";
			}
			else if ((!object_0.get_hasModerationPowers() ? object_0.get_tags().Contains("admin_moderator") : true))
			{
				str = "Moderator";
			}
			else if ((!object_0.get_hasSuperPowers() ? !object_0.get_tags().Contains("admin_") : false))
			{
				if (object_0.get_hasVIPAccess())
				{
					flag = true;
				}
				else
				{
					flag = (!object_0.get_tags().Contains("system_legend") || !object_0.get_tags().Contains("system_trust_legend") ? false : object_0.get_tags().Contains("system_trust_trusted"));
				}
				if (!flag)
				{
					if (!object_0.get_hasLegendTrustLevel())
					{
						flag1 = (!object_0.get_tags().Contains("system_trust_legend") ? false : object_0.get_tags().Contains("system_trust_trusted"));
					}
					else
					{
						flag1 = true;
					}
					if (flag1)
					{
						str = "Veteran";
					}
					else if (object_0.get_hasVeteranTrustLevel())
					{
						str = "Trusted";
					}
					else if (object_0.get_hasTrustedTrustLevel())
					{
						str = "Known";
					}
					else if (object_0.get_hasKnownTrustLevel())
					{
						str = "User";
					}
					else if ((object_0.get_hasBasicTrustLevel() ? true : object_0.get_isNewUser()))
					{
						str = "New User";
					}
					else if (object_0.get_hasNegativeTrustLevel())
					{
						str = "NegativeTrust";
					}
					else
					{
						str = (object_0.get_hasVeryNegativeTrustLevel() ? "VeryNegativeTrust" : "Visitor");
					}
				}
				else
				{
					str = "Legend";
				}
			}
			else
			{
				str = "Admin";
			}
			return str;
		}

		public static string k0jp93e94(this object object_0)
		{
			string str;
			if (object_0.gtfWJOkre() < 80)
			{
				str = (object_0.gtfWJOkre() > 80 || object_0.gtfWJOkre() < 30 ? "<color=red>" : "<color=#FF7000>");
			}
			else
			{
				str = "<color=#59D365>";
			}
			string str1 = str;
			string str2 = string.Format("{0}{1}</color>", str1, object_0.gtfWJOkre());
			return str2;
		}

		public static string kyqEfC1vV(this object object_0)
		{
			string str;
			if (object_0.cn0wjG78s() > 75)
			{
				str = (object_0.cn0wjG78s() < 75 || object_0.cn0wjG78s() > 150 ? "<color=red>" : "<color=#FF7000>");
			}
			else
			{
				str = "<color=#59D365>";
			}
			string str1 = str;
			string str2 = string.Format("{0}{1}</color>", str1, object_0.cn0wjG78s());
			return str2;
		}

		private static void LAsLqgDOw(object object_0, object object_1, object object_2, object object_3)
		{
			object_2.IconBackground.set_enabled(true);
			object_2.Icon.set_enabled(true);
			object_2.IconContainer.SetActive(true);
			object_2.Icon.set_texture(object_0);
		}

		public static bool lPBUPh6ZM(this object object_0)
		{
			return object_0.Method_Public_get_VRCPlayerApi_0().get_isMaster();
		}

		internal static Transform nq4PaVUNT(object object_0, int int_0)
		{
			Transform transform = UnityEngine.Object.Instantiate<Transform>(object_0, object_0.get_parent(), false);
			transform.set_name(string.Format("EvolveTags:{0}", int_0));
			transform.set_localPosition(new Vector3(0f, 33f, 0f));
			transform.get_gameObject().set_active(true);
			Transform transform1 = null;
			for (int i = transform.get_childCount(); i > 0; i--)
			{
				Transform child = transform.GetChild(i - 1);
				if (child.get_name() == "Trust Text")
				{
					transform1 = child;
				}
				else
				{
					UnityEngine.Object.Destroy(child.get_gameObject());
				}
			}
			return transform1;
		}

		public static string qL203EWee(this object object_0)
		{
			return object_0.Method_Internal_get_APIUser_0().get_id();
		}

		public static void tAF9LuFi3()
		{
			ClassInjector.RegisterTypeInIl2Cpp<Nameplate>();
			MelonCoroutines.Start(w1ZTpJvRDIlLwNIjNM.gme8IvpZE());
		}

		internal static w1ZTpJvRDIlLwNIjNM uKtO35fOSxBxGt8q4dm()
		{
			return w1ZTpJvRDIlLwNIjNM.YrlXTBfnnLW9THtlbN4;
		}

		private static void UVUZlBqkd(object object_0, Color? nullable_0 = null, Color? nullable_1 = null, Color? nullable_2 = null, Color? nullable_3 = null, bool bool_0 = false, bool bool_1 = false)
		{
			Color color = new Color();
			if (object_0 != null)
			{
				if (bool_0)
				{
					object_0.NameBackground.set_material(null);
					object_0.QuickStatsBackground.set_material(null);
					object_0.IconBackground.set_material(null);
				}
				else
				{
					object_0.NameBackground.set_material(w1ZTpJvRDIlLwNIjNM.hZCfVUWyP);
					object_0.QuickStatsBackground.set_material(w1ZTpJvRDIlLwNIjNM.hZCfVUWyP);
					object_0.IconBackground.set_material(w1ZTpJvRDIlLwNIjNM.hZCfVUWyP);
				}
				Color _color = object_0.NameBackground.get_color();
				Color _color1 = object_0.IconBackground.get_color();
				Color color1 = object_0.QuickStatsBackground.get_color();
				Color _faceColor = object_0.Name.get_faceColor();
				if (nullable_0.HasValue)
				{
					Color value = nullable_0.Value;
					Color value1 = nullable_0.Value;
					value.a = _color.a;
					value1.a = color1.a;
					object_0.NameBackground.set_color(value / 2f);
					object_0.QuickStatsBackground.set_color(value1);
				}
				if (nullable_1.HasValue)
				{
					Color value2 = nullable_0.Value;
					value2.a = _color1.a;
					object_0.IconBackground.set_color(value2);
				}
				if ((!nullable_2.HasValue ? false : !nullable_3.HasValue))
				{
					Color color2 = nullable_2.Value;
					color2.a = _faceColor.a;
					object_0.SNC(color2);
					object_0.ORbld();
				}
				if ((!nullable_2.HasValue ? false : nullable_3.HasValue))
				{
					Color value3 = nullable_2.Value;
					Color color3 = nullable_3.Value;
					value3.a = _faceColor.a;
					color3.a = _faceColor.a;
				}
				if (bool_1)
				{
					object_0.IsEvolved = true;
					ColorUtility.TryParseHtmlString("#ff0062", ref color);
					object_0.IconPulse.set_color(color);
					object_0.IconGlow.set_color(Color.get_black() * 2f);
					object_0.NamePulse.set_color(color);
					object_0.NameGlow.set_color(Color.get_black() * 2f);
				}
			}
		}

		public static Il2CppSystem.Collections.Generic.List<Player> vaOxdDR8b(this object object_0)
		{
			return object_0.get_field_Private_List_1_Player_0();
		}

		internal static bool VTG7e7fQ93TvtDMtgnX()
		{
			return w1ZTpJvRDIlLwNIjNM.YrlXTBfnnLW9THtlbN4 == null;
		}

		internal static void xeRuB1HIW(ref int int_0, object object_0, object object_1, Color color_0, object object_2)
		{
			Transform transform;
			Transform transform1 = object_1.Find(string.Format("EvolveTags:{0}", int_0));
			if (transform1 != null)
			{
				transform1.get_gameObject().SetActive(true);
				transform = transform1.Find("Trust Text");
			}
			else
			{
				transform = w1ZTpJvRDIlLwNIjNM.nq4PaVUNT(object_0, int_0);
			}
			TextMeshProUGUI component = transform.GetComponent<TextMeshProUGUI>();
			component.set_color(color_0);
			component.set_text(object_2);
			int_0++;
		}

		internal static void Y1OV6MN2Q()
		{
			using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Evolve.Assets"))
			{
				using (MemoryStream memoryStream = new MemoryStream((int)manifestResourceStream.Length))
				{
					manifestResourceStream.CopyTo(memoryStream);
					w1ZTpJvRDIlLwNIjNM.tFxk4jMHV = AssetBundle.LoadFromMemory_Internal(memoryStream.ToArray(), 0);
					AssetBundle assetBundle = w1ZTpJvRDIlLwNIjNM.tFxk4jMHV;
					assetBundle.set_hideFlags(assetBundle.get_hideFlags() | 32);
				}
			}
			if (w1ZTpJvRDIlLwNIjNM.tFxk4jMHV != null)
			{
				w1ZTpJvRDIlLwNIjNM.hZCfVUWyP = w1ZTpJvRDIlLwNIjNM.tFxk4jMHV.LoadAsset_Internal("NameplateMat", Il2CppType.Of<Material>()).Cast<Material>();
				Material material = w1ZTpJvRDIlLwNIjNM.hZCfVUWyP;
				material.set_hideFlags(material.get_hideFlags() | 32);
				w1ZTpJvRDIlLwNIjNM.JgLmLox27 = w1ZTpJvRDIlLwNIjNM.tFxk4jMHV.LoadAsset_Internal("NameplateOutline", Il2CppType.Of<Sprite>()).Cast<Sprite>();
				Sprite jgLmLox27 = w1ZTpJvRDIlLwNIjNM.JgLmLox27;
				jgLmLox27.set_hideFlags(jgLmLox27.get_hideFlags() | 32);
			}
		}
	}
}