using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Core;

internal delegate void hPXCSKVR843R4lkbLsY(object object_0, APIUser apiuser_0);