using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Color32 RR2yuGEQpglFmPIfZtm(object object_0);