using b3eD5DgJPcASx0xfHYB;
using System;
using System.Runtime.CompilerServices;

internal delegate void WSIOfyAD4geXb0H0I4J(ref AsyncTaskMethodBuilder );