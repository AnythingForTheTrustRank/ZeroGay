using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate bool SB4H6qVJ9Hq6NZsyo0R(object );