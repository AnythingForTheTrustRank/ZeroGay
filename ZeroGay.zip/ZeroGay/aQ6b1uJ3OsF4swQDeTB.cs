using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string aQ6b1uJ3OsF4swQDeTB(object , int );