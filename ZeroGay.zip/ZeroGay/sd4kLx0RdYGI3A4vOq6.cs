using b3eD5DgJPcASx0xfHYB;
using System;
using VRC;

internal delegate SimpleAvatarPedestal sd4kLx0RdYGI3A4vOq6(object );