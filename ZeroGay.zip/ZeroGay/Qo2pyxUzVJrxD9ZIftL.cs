using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate bool Qo2pyxUzVJrxD9ZIftL(ref Cache cache_0);