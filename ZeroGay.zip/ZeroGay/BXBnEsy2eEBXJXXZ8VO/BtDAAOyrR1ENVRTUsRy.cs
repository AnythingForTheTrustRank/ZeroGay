using System;

namespace BXBnEsy2eEBXJXXZ8VO
{
	internal interface BtDAAOyrR1ENVRTUsRy
	{
		void nNg0iMbTSP();
	}
}