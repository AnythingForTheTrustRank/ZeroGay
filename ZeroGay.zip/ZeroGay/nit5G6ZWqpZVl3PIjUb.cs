using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate PlayerNameplate nit5G6ZWqpZVl3PIjUb(object object_0);