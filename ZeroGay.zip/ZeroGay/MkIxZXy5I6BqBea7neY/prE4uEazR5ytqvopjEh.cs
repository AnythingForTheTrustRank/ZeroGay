using AksgHVKH9UOXlBDvRpO;
using BXBnEsy2eEBXJXXZ8VO;
using Events;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.UI;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;

namespace MkIxZXy5I6BqBea7neY
{
	internal class prE4uEazR5ytqvopjEh : OnUpdateEvent, BtDAAOyrR1ENVRTUsRy
	{
		public ZeroDayMain DF2yQKZIqh;

		private static GameObject XJGyO3jMMR;

		public static UiAvatarList zPbyIEH1e5;

		public static Il2CppSystem.Collections.Generic.List<ApiAvatar> uo3yoEotlV;

		private bool drxy6jIwF0;

		public System.Collections.Generic.List<OnUpdateEvent> Vp2yYSeFjK;

		public System.Collections.Generic.List<BtDAAOyrR1ENVRTUsRy> DeCyBAucFO;

		internal static prE4uEazR5ytqvopjEh mehuTxmjV9iWQLX0uDT;

		static prE4uEazR5ytqvopjEh()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			prE4uEazR5ytqvopjEh.uo3yoEotlV = new Il2CppSystem.Collections.Generic.List<ApiAvatar>();
		}

		public prE4uEazR5ytqvopjEh()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.Vp2yYSeFjK = new System.Collections.Generic.List<OnUpdateEvent>();
			this.DeCyBAucFO = new System.Collections.Generic.List<BtDAAOyrR1ENVRTUsRy>();
			base();
			this.DeCyBAucFO.Add(this);
			this.Vp2yYSeFjK.Add(this);
		}

		void BXBnEsy2eEBXJXXZ8VO.BtDAAOyrR1ENVRTUsRy.nNg0iMbTSP()
		{
			prE4uEazR5ytqvopjEh.eUyycdqQHi();
		}

		internal static prE4uEazR5ytqvopjEh eKI78QmbDklBT9jxO6X()
		{
			return prE4uEazR5ytqvopjEh.mehuTxmjV9iWQLX0uDT;
		}

		public static void eUyycdqQHi()
		{
			if (!File.Exists("ZeroDay_Favorites_config.json"))
			{
				File.Create("ZeroDay_Favorites_config.json");
			}
			prE4uEazR5ytqvopjEh.XJGyO3jMMR = GameObject.Find("UserInterface/MenuContent/Screens/Avatar");
			prE4uEazR5ytqvopjEh.zPbyIEH1e5 = VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_GameObject_0().get_transform().Find("Screens/Avatar/Vertical Scroll View/Viewport/Content/Legacy Avatar List").get_gameObject().GetComponent<UiAvatarList>();
			prE4uEazR5ytqvopjEh.zPbyIEH1e5.get_transform().SetAsFirstSibling();
			prE4uEazR5ytqvopjEh.zPbyIEH1e5.set_clearUnseenListOnCollapse(false);
			prE4uEazR5ytqvopjEh.zPbyIEH1e5.set_field_Public_Category_0(4);
			prE4uEazR5ytqvopjEh.zPbyIEH1e5.GetComponentInChildren<Text>().set_text("ZeroDay Favorites.");
			GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_GameObject_0().get_transform().Find("Screens/Avatar/Favorite Button").get_gameObject(), VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_GameObject_0().get_transform().Find("Screens/Avatar/"));
			gameObject.GetComponentInChildren<RectTransform>().set_localPosition(new Vector3(238.9283f, 372.6159f, -2f));
			GameObject gameObject1 = UnityEngine.Object.Instantiate<GameObject>(VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_GameObject_0().get_transform().Find("Screens/Avatar/Favorite Button").get_gameObject(), VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_GameObject_0().get_transform().Find("Screens/Avatar/"));
			gameObject1.GetComponentInChildren<RectTransform>().set_localPosition(new Vector3(-224.6199f, 373.36f, -2f));
			PageAvatar componentInChildren = VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_field_Public_GameObject_0().get_transform().Find("Screens/Avatar/").GetComponentInChildren<PageAvatar>();
			Button component = gameObject.GetComponent<Button>();
			Button button = gameObject1.GetComponent<Button>();
			button.get_transform().Find("Horizontal/FavoritesCountSpacingText").get_gameObject().SetActive(false);
			button.get_transform().Find("Horizontal/FavoritesCurrentCountText").get_gameObject().SetActive(false);
			button.get_transform().Find("Horizontal/FavoritesCountDividerText").get_gameObject().SetActive(false);
			button.get_transform().Find("Horizontal/FavoritesMaxAvailableText").get_gameObject().SetActive(false);
			button.GetComponentInChildren<Text>().set_text("Refresh Avatars");
			button.get_gameObject().SetActive(true);
			button.get_onClick().RemoveAllListeners();
			button.get_onClick().AddListener(new Action(() => {
				MelonCoroutines.Start(prE4uEazR5ytqvopjEh.YoUynyvff0(1f));
				prE4uEazR5ytqvopjEh.zPbyIEH1e5.StartRenderElementsCoroutine(prE4uEazR5ytqvopjEh.uo3yoEotlV, 0, true, null);
			}));
			component.get_transform().Find("Horizontal/FavoritesCountSpacingText").get_gameObject().SetActive(false);
			component.get_transform().Find("Horizontal/FavoritesCurrentCountText").get_gameObject().SetActive(false);
			component.get_transform().Find("Horizontal/FavoritesCountDividerText").get_gameObject().SetActive(false);
			component.get_transform().Find("Horizontal/FavoritesMaxAvailableText").get_gameObject().SetActive(false);
			component.GetComponentInChildren<Text>().set_text("Favorite/UnFavorite");
			component.get_gameObject().SetActive(true);
			component.get_onClick().RemoveAllListeners();
			component.get_onClick().AddListener(new Action(() => {
				ApiAvatar fieldInternalApiAvatar0 = componentInChildren.get_field_Public_SimpleAvatarPedestal_0().get_field_Internal_ApiAvatar_0();
				if (!prE4uEazR5ytqvopjEh.uo3yoEotlV.Contains(fieldInternalApiAvatar0))
				{
					prE4uEazR5ytqvopjEh.uo3yoEotlV.Add(fieldInternalApiAvatar0);
					MelonCoroutines.Start(prE4uEazR5ytqvopjEh.YoUynyvff0(1f));
					File.AppendAllText("ZeroDay_Favorites_config.json", string.Concat(new string[] { fieldInternalApiAvatar0.get_id(), "|", fieldInternalApiAvatar0.get_name(), "|", fieldInternalApiAvatar0.get_thumbnailImageUrl(), "\n" }));
					prE4uEazR5ytqvopjEh.zPbyIEH1e5.StartRenderElementsCoroutine(prE4uEazR5ytqvopjEh.uo3yoEotlV, 0, true, null);
				}
				else
				{
					prE4uEazR5ytqvopjEh.uo3yoEotlV.Remove(fieldInternalApiAvatar0);
					string[] strArrays = File.ReadAllLines("ZeroDay_Favorites_config.json");
					string str = "";
					for (int i = 0; i < (int)strArrays.Length; i++)
					{
						if (!strArrays[i].Contains(fieldInternalApiAvatar0.get_id()))
						{
							str = string.Concat(str, strArrays[i]);
						}
						File.WriteAllText("ZeroDay_Favorites_config.json", str);
						prE4uEazR5ytqvopjEh.zPbyIEH1e5.StartRenderElementsCoroutine(prE4uEazR5ytqvopjEh.uo3yoEotlV, 0, true, null);
					}
				}
			}));
			string[] strArrays1 = File.ReadAllLines("ZeroDay_Favorites_config.json");
			for (int j = 0; j < (int)strArrays1.Length; j++)
			{
				string[] strArrays2 = strArrays1[j].Split(new char[] { '|' });
				Il2CppSystem.Collections.Generic.List<ApiAvatar> list = prE4uEazR5ytqvopjEh.uo3yoEotlV;
				ApiAvatar apiAvatar = new ApiAvatar();
				apiAvatar.set_id(strArrays2[0]);
				apiAvatar.set_name(strArrays2[1]);
				apiAvatar.set_thumbnailImageUrl(strArrays2[2]);
				list.Add(apiAvatar);
			}
			MelonCoroutines.Start(prE4uEazR5ytqvopjEh.YoUynyvff0(1f));
		}

		internal static bool FUbWafmSu7Ls8nptepX()
		{
			return prE4uEazR5ytqvopjEh.mehuTxmjV9iWQLX0uDT == null;
		}

		public void OnUpdate()
		{
			if (RoomManager.get_field_Internal_Static_ApiWorldInstance_0() != null)
			{
				if ((!prE4uEazR5ytqvopjEh.XJGyO3jMMR.get_activeSelf() ? false : !this.drxy6jIwF0))
				{
					this.drxy6jIwF0 = true;
					MelonCoroutines.Start(prE4uEazR5ytqvopjEh.YoUynyvff0(1f));
				}
				else if ((prE4uEazR5ytqvopjEh.XJGyO3jMMR.get_activeSelf() ? false : this.drxy6jIwF0))
				{
					this.drxy6jIwF0 = false;
				}
			}
		}

		public static IEnumerator YoUynyvff0(float float_0)
		{
			return new prE4uEazR5ytqvopjEh.<RefreshMenu>d__10(0)
			{
				v = float_0
			};
		}
	}
}