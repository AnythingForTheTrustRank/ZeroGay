using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object DCSsj7Ll7MhMpd0avxC(object , int );