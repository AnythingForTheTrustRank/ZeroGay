using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;

internal delegate bool JGkScAJwwZseXY5sl4B(MethodInfo , MethodInfo );