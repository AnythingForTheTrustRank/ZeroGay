using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object ReteRf32Fa6nIt6CHV8(Type type_0, sbyte sbyte_0);