using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate void f2awne16qPJa5JIdcpu(ref AsyncVoidMethodBuilder asyncVoidMethodBuilder_0);