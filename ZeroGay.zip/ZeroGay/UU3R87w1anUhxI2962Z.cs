using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool UU3R87w1anUhxI2962Z(object object_0);