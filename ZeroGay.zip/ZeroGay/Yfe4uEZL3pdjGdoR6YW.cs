using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool Yfe4uEZL3pdjGdoR6YW(object object_0, string string_0, StringComparison stringComparison_0);