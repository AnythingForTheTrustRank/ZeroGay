using AksgHVKH9UOXlBDvRpO;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections.Generic;
using tj5E7kTcTdevpjQ41CC;
using UnityEngine;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace pw9US87YAVX4ooVmsJY
{
	internal class Ohp8cy76CFn28WDiium
	{
		protected GameObject Re97eWmwCA;

		protected Text Gck7CAY3rI;

		internal static Ohp8cy76CFn28WDiium PJlLHq4QgIVwmevoJvh;

		public Ohp8cy76CFn28WDiium(x5iKdsT53msph4ugL7v.MifxmhtwP8rVW59du8e mifxmhtwP8rVW59du8e_0, float float_0, float float_1, float float_2, float float_3, string string_0, Color? nullable_0 = null)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.kSa7BpvmJD(x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find(mifxmhtwP8rVW59du8e_0.ToString()), float_0, float_1, float_2, float_3, string_0, nullable_0);
		}

		public Ohp8cy76CFn28WDiium(Transform transform_0, float float_0, float float_1, float float_2, float float_3, string string_0, Color? nullable_0 = null)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.kSa7BpvmJD(transform_0, float_0, float_1, float_2, float_3, string_0, nullable_0);
		}

		public void BGE7ylD2e6(TextAnchor textAnchor_0)
		{
			this.Gck7CAY3rI.set_alignment(textAnchor_0);
		}

		public void dNe7rgstjB(Vector2 vector2_0)
		{
			this.Re97eWmwCA.GetComponent<RectTransform>().set_anchoredPosition(vector2_0);
		}

		public void fUx7MlDqtv(Color color_0)
		{
			this.Gck7CAY3rI.set_color(color_0);
		}

		public void GSW7aVa4fB(string string_0)
		{
			this.Gck7CAY3rI.set_supportRichText(true);
			this.Gck7CAY3rI.set_text(string_0);
		}

		public GameObject h6e77pvCiH()
		{
			return this.Re97eWmwCA;
		}

		private void kSa7BpvmJD(Transform transform_0, float float_0, float float_1, float float_2, float float_3, string string_0, Color? nullable_0 = null)
		{
			this.Re97eWmwCA = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find("Settings/AudioDevicePanel/MicDeviceText").get_gameObject(), transform_0, false);
			this.Gck7CAY3rI = this.Re97eWmwCA.GetComponent<Text>();
			this.Re97eWmwCA.set_name(string.Format("{0}-SMText-{1}", "WTFBlaze", x5iKdsT53msph4ugL7v.accTMUKvyj()));
			this.dNe7rgstjB(new Vector2(float_0, float_1));
			this.rik72enFcQ(new Vector2(float_2, float_3));
			this.GSW7aVa4fB(string_0);
			if (nullable_0.HasValue)
			{
				this.fUx7MlDqtv(nullable_0.Value);
			}
			UUyEqSykY4SKTrGkSI9.KipyzaHItX.Add(this);
		}

		internal static bool l1jiw84OnPXDlT9o71I()
		{
			return Ohp8cy76CFn28WDiium.PJlLHq4QgIVwmevoJvh == null;
		}

		public void LXP7TgLCQm(int int_0)
		{
			this.Gck7CAY3rI.set_fontSize(int_0);
		}

		internal static Ohp8cy76CFn28WDiium m1Y0ks4Io5c7jrPqAV9()
		{
			return Ohp8cy76CFn28WDiium.PJlLHq4QgIVwmevoJvh;
		}

		public void rik72enFcQ(Vector2 vector2_0)
		{
			this.Re97eWmwCA.GetComponent<RectTransform>().set_sizeDelta(vector2_0);
		}
	}
}