using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.SDKBase;

internal delegate void SgA58iKyhS5ZhbEuPYK(object , VRC_Pickup );