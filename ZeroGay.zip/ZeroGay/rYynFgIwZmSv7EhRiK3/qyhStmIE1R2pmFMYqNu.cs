using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using MelonLoader;
using System;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace rYynFgIwZmSv7EhRiK3
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class qyhStmIE1R2pmFMYqNu
	{
		public static bool ky1IpcAYdn;

		internal static qyhStmIE1R2pmFMYqNu QIgQnGfm4FGCNGrnNZI;

		public qyhStmIE1R2pmFMYqNu()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static qyhStmIE1R2pmFMYqNu KAZj7KfgLArHZdKgBue()
		{
			return qyhStmIE1R2pmFMYqNu.QIgQnGfm4FGCNGrnNZI;
		}

		public static void UdonLogShit(ref string __0, object __1)
		{
			string str;
			if (!qyhStmIE1R2pmFMYqNu.ky1IpcAYdn)
			{
				MelonLogger.Log("Started Udon Logger");
				qyhStmIE1R2pmFMYqNu.ky1IpcAYdn = true;
			}
			if (__0.Contains(""))
			{
				string _0 = __0;
				object _1 = __1;
				if (_1 == null)
				{
					str = null;
				}
				else
				{
					str = _1.ToString();
				}
				MelonLogger.Log(string.Concat(_0, "From : ", str));
			}
		}

		internal static bool vDJUpYfDJRZx5bcFvJe()
		{
			return qyhStmIE1R2pmFMYqNu.QIgQnGfm4FGCNGrnNZI == null;
		}
	}
}