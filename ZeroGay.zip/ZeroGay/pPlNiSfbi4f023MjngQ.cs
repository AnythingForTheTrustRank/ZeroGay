using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine.UI;

internal delegate void pPlNiSfbi4f023MjngQ(ref ColorBlock , float );