using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate VRCVrCamera NkkSpdRlMZhu74w6PBJ();