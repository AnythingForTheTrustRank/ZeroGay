using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string OmnfkiknVQJ5aESmfSK(object object_0, int int_0);