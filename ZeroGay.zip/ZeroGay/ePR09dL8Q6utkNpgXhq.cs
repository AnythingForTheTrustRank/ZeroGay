using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object ePR09dL8Q6utkNpgXhq(Type , byte );