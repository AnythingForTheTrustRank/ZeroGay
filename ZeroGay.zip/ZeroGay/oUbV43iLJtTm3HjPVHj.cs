using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate byte[] oUbV43iLJtTm3HjPVHj(string );