using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector3 tyuNo0UqBd1ALnKuJ8u(ref Quaternion quaternion_0);