using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.Core;

internal delegate void Cm49bw0nDtli0AjEVxV(object , ApiAvatar );