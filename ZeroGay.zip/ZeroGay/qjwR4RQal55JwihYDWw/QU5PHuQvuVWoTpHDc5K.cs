using System;

namespace qjwR4RQal55JwihYDWw
{
	internal interface QU5PHuQvuVWoTpHDc5K
	{
		void wNFlGr1Diu();
	}
}