using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using System;

internal delegate bool YsTWnUpU5ITfETUawlH(Il2CppSystem.Type type_0, Il2CppSystem.Type type_1);