using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void qOVk94p2i7V93T4LUPS(object , Quaternion );