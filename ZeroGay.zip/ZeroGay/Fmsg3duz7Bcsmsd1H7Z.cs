using AksgHVKH9UOXlBDvRpO;
using System;
using System.Diagnostics;

internal delegate Process Fmsg3duz7Bcsmsd1H7Z();