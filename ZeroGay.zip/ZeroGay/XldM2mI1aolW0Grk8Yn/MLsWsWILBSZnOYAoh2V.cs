using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using HellTaker.mainshiet.patches.murder4;
using System;
using System.Collections.Generic;
using Tr14UwanpaMXFeWIqTO;
using UnityEngine;
using VRC.Networking;
using VRC.SDK3.Components;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;

namespace XldM2mI1aolW0Grk8Yn
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class MLsWsWILBSZnOYAoh2V
	{
		internal static MLsWsWILBSZnOYAoh2V RlPAiNmoiOjtHJBCIIf;

		public MLsWsWILBSZnOYAoh2V()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static bool cdLI3LVi9H(ref string string_0)
		{
			if (Murder4.PatreonEnforcer)
			{
				List<VRCPickup> vRCPickups = new List<VRCPickup>()
				{
					GameObject.Find("Game Logic/Weapons/Revolver").GetComponent<VRCPickup>()
				};
				GameObject.Find("Game Logic/Weapons/Revolver");
				GameObject gameObject = GameObject.Find("Game Logic/Weapons/Revolver/Patron skin sound");
				foreach (VRCPickup vRCPickup in vRCPickups)
				{
					if ((string_0 == "SyncFire" ? !Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup.get_gameObject()) : true))
					{
						continue;
					}
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Play", null, false);
				}
			}
			return true;
		}

		internal static MLsWsWILBSZnOYAoh2V yXAv4emYifbno59ixGr()
		{
			return MLsWsWILBSZnOYAoh2V.RlPAiNmoiOjtHJBCIIf;
		}

		internal static bool zu1fkYm6gvwH8gLqUQa()
		{
			return MLsWsWILBSZnOYAoh2V.RlPAiNmoiOjtHJBCIIf == null;
		}
	}
}