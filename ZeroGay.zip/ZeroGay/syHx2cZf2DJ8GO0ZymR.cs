using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;

internal delegate List<string> syHx2cZf2DJ8GO0ZymR(object );