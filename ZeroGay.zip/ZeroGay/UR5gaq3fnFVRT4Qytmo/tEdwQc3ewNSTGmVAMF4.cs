using Area51.Events;
using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using ZeroDayAPI;

namespace UR5gaq3fnFVRT4Qytmo
{
	internal abstract class tEdwQc3ewNSTGmVAMF4
	{
		public string jJP3xaq89T;

		public bool VEw31Y9XrH;

		public bool MMa3K5V9IJ;

		public int K8G3AcjCFs;

		public int Vq43VyndYX;

		private string p0H3LlBde9;

		private QMNestedButton ItK3JQB5v4;

		private bool JbB35131AS;

		private Sprite x9p3dGye2v;

		internal static tEdwQc3ewNSTGmVAMF4 FWLXny5n9RP4AWP6E2i;

		public tEdwQc3ewNSTGmVAMF4(string u0020, string u0020, QMNestedButton u0020, int u0020, int u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.jJP3xaq89T = u0020;
			this.p0H3LlBde9 = u0020;
			this.ItK3JQB5v4 = u0020;
			this.K8G3AcjCFs = u0020;
			this.Vq43VyndYX = u0020;
			this.JbB35131AS = this.JbB35131AS;
			this.MMa3K5V9IJ = this.MMa3K5V9IJ;
			this.x9p3dGye2v = this.x9p3dGye2v;
		}

		internal static bool gO6mLo5eFPKaTgs0BLj()
		{
			return tEdwQc3ewNSTGmVAMF4.FWLXny5n9RP4AWP6E2i == null;
		}

		public virtual void HQVlqcwVIY()
		{
		}

		public virtual void k1mlkwNOEe()
		{
		}

		public virtual void MtbPzolxTl()
		{
		}

		internal static tEdwQc3ewNSTGmVAMF4 v11Bwa5fjHAXKyS8YUq()
		{
			return tEdwQc3ewNSTGmVAMF4.FWLXny5n9RP4AWP6E2i;
		}

		public virtual void xoil8RhstR()
		{
			QMToggleButton qMToggleButton = new QMToggleButton(this.ItK3JQB5v4, (float)this.K8G3AcjCFs, (float)this.Vq43VyndYX, this.jJP3xaq89T, () => ZeroDayMain.Instance.OnAssetBundleLoadEventArray = ZeroDayMain.Instance.OnAssetBundleLoadEvents.ToArray(), () => {
			}, this.p0H3LlBde9, false);
		}
	}
}