using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.Core;

internal delegate void MiG83BKC0tSHq3vfoiN(object , APIUser );