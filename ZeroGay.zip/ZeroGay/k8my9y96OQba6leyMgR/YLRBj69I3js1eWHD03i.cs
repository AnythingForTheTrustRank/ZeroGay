using b3eD5DgJPcASx0xfHYB;
using C2NmTt6c7EcPo9p0lXu;
using HarmonyLib;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC.Networking;

namespace k8my9y96OQba6leyMgR
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class YLRBj69I3js1eWHD03i
	{
		private static YLRBj69I3js1eWHD03i gXtvxU5JUEIxeCebTfW;

		public YLRBj69I3js1eWHD03i()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static YLRBj69I3js1eWHD03i e9kboj5d2Ki5jGXan7t()
		{
			return YLRBj69I3js1eWHD03i.gXtvxU5JUEIxeCebTfW;
		}

		internal static bool iR7bem55UEt4bGG912V()
		{
			return YLRBj69I3js1eWHD03i.gXtvxU5JUEIxeCebTfW == null;
		}

		public static bool nKx9tNJLZi(ref string u0020, object u0020)
		{
			bool flag;
			if (ESjP9x6DeMXH5ll0XwX.ceOt6sddEl)
			{
				flag = (u0020 != "SyncVotedOut" ? true : false);
			}
			else
			{
				flag = true;
			}
			return flag;
		}
	}
}