using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void VLTae3E9FuFEkkZ54Qt(object object_0, Texture texture_0);