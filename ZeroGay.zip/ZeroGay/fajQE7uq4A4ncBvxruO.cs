using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void fajQE7uq4A4ncBvxruO(object object_0, HorizontalWrapMode horizontalWrapMode_0);