using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate QuickMenuContextualDisplay sd6dONpSLhilS7T3ksV(object object_0);