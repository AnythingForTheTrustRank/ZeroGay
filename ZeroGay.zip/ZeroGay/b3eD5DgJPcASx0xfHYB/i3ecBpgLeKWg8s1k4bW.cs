using G9uwVeSIQfveRC25TAV;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Security.Cryptography;
using System.Text;

namespace b3eD5DgJPcASx0xfHYB
{
	internal class i3ecBpgLeKWg8s1k4bW
	{
		private static bool xYsWrh9rlk;

		internal static Assembly BKOWn6D37w;

		private static bool IT5WfpWfEn;

		private static List<string> zhMWJtp8pO;

		private static byte[] mYAWoHxvoh;

		private static SortedList a8ouqWvhfK;

		private static int NrNukNgRJA;

		private static long CEgu3EAXeo;

		private static bool HbFuMBeEZN;

		private static IntPtr xmAu4Jm5Xv;

		private static i3ecBpgLeKWg8s1k4bW.YambrdupFMvmauP3K7v SaWuN124Fd;

		private static i3ecBpgLeKWg8s1k4bW.LOlqbqunnCM4dyivWSF hruu28U6yn;

		private static IntPtr o9GubdjRed;

		private static string q9CuhDINps;

		private static int lwDWELtQOD;

		private static int[] NTxWylE3tl;

		private static i3ecBpgLeKWg8s1k4bW.dC7hBOur1rNOnay1jRV GDuuCJlbgK;

		private static object X6HWLIeur4;

		private static int bxIu97Lut0;

		private static i3ecBpgLeKWg8s1k4bW.u9dCVAuiQ1HsrVGWDnt VsRutOyCSx;

		private static Dictionary<int, int> twaWKS1vkk;

		[cP3gEOuTFZKXFwueWBV(typeof(i3ecBpgLeKWg8s1k4bW.cP3gEOuTFZKXFwueWBV.UWZdvfuvW4bsIO4y0aq<Object>[]))]
		private static bool PV1uIJN9O3;

		internal static RSACryptoServiceProvider TIbW1Dpsl4;

		private static int eHBu7jE9rg;

		internal static Hashtable IlMu6O0vL1;

		private static i3ecBpgLeKWg8s1k4bW.kAj8IKuRAJ3AX2ZSG1e Jeduw43wIa;

		private static byte[] zC0WdeCKxb;

		private static bool cdAuseJbAa;

		private static long xkcu8F4evH;

		private static int nh2WVAwMca;

		private static uint[] Y3mWev03Uf;

		internal static i3ecBpgLeKWg8s1k4bW.FnS2y3uuKEQgVoDQ55U kLquHk3XmY;

		private static bool znIWxoQxcM;

		private static i3ecBpgLeKWg8s1k4bW.FuIE6pu0PT2sfs0Y8hG nPFuQHhrem;

		private static List<int> ntdW5Zpc4h;

		internal static i3ecBpgLeKWg8s1k4bW.FnS2y3uuKEQgVoDQ55U CiWuGFes15;

		private static IntPtr O3jWmZFCDc;

		private static IntPtr YphWDcgVsi;

		private static object r4BWAsc3Fp;

		private static object vsNWcvweDs;

		private static bool cglWzmWd5j;

		static i3ecBpgLeKWg8s1k4bW()
		{
		}

		internal i3ecBpgLeKWg8s1k4bW()
		{
		}

		private static void A1PgDy99sx(ref uint u0020, uint u0020, uint u0020, uint u0020, uint u0020, ushort u0020, uint u0020, object u0020)
		{
			// 
			// Current member / type: System.Void b3eD5DgJPcASx0xfHYB.i3ecBpgLeKWg8s1k4bW::A1PgDy99sx(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void A1PgDy99sx(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static object afyWCcMLss(object u0020)
		{
			object location;
			try
			{
				if (File.Exists(((Assembly)u0020).Location))
				{
					location = ((Assembly)u0020).Location;
					return location;
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(((Assembly)u0020).GetName().CodeBase.ToString().Replace("file:///", "")))
				{
					location = ((Assembly)u0020).GetName().CodeBase.ToString().Replace("file:///", "");
					return location;
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(u0020.GetType().GetProperty("Location").GetValue(u0020, new object[0]).ToString()))
				{
					location = u0020.GetType().GetProperty("Location").GetValue(u0020, new object[0]).ToString();
					return location;
				}
			}
			catch
			{
			}
			return "";
		}

		private static int al4WQR4u5q()
		{
			return 5;
		}

		private static uint ApUWMC1Iqi(uint u0020)
		{
			return (uint)"{11111-22222-10009-11112}".Length;
		}

		private byte[] bcFWjCrx76()
		{
			int length = "{11111-22222-20001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		private byte[] bL9WFooTAh()
		{
			int length = "{11111-22222-30001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		internal static bool BLXnmCjefhXvXrAipNZ()
		{
			return null == null;
		}

		private static byte[] C4CWWkb46t(object u0020)
		{
			byte[] numArray;
			using (FileStream fileStream = new FileStream(u0020, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				int num = 0;
				int length = (int)fileStream.Length;
				numArray = new byte[length];
				while (length > 0)
				{
					int num1 = fileStream.Read(numArray, num, length);
					num += num1;
					length -= num1;
				}
			}
			return numArray;
		}

		[DllImport("kernel32", CharSet=CharSet.Ansi, EntryPoint="GetProcAddress", ExactSpelling=false)]
		public static extern IntPtr DfUWbBfcCP(IntPtr u0020, string u0020);

		private static int dVcWgl6IIj(IntPtr u0020)
		{
			if (i3ecBpgLeKWg8s1k4bW.hruu28U6yn == null)
			{
				i3ecBpgLeKWg8s1k4bW.hruu28U6yn = (i3ecBpgLeKWg8s1k4bW.LOlqbqunnCM4dyivWSF)Marshal.GetDelegateForFunctionPointer(i3ecBpgLeKWg8s1k4bW.DfUWbBfcCP(i3ecBpgLeKWg8s1k4bW.tmL0uXbJ0(), string.Concat("Close ".Trim(), "Handle")), typeof(i3ecBpgLeKWg8s1k4bW.LOlqbqunnCM4dyivWSF));
			}
			return i3ecBpgLeKWg8s1k4bW.hruu28U6yn(u0020);
		}

		internal byte[] eKeW0RAJEq()
		{
			int length = "{11111-22222-40001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		internal static void FUTW84pD03(object u0020, object u0020, uint u0020, object u0020)
		{
			// 
			// Current member / type: System.Void b3eD5DgJPcASx0xfHYB.i3ecBpgLeKWg8s1k4bW::FUTW84pD03(System.Object,System.Object,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void FUTW84pD03(System.Object,System.Object,System.UInt32,System.Object)
			// 
			// Index was out of range. Must be non-negative and less than the size of the collection.
			// Parameter name: index
			//    at System.ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument argument, ExceptionResource resource)
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 184
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 118
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 56
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		private static IntPtr g5eWawlkAH(uint u0020, int u0020, uint u0020)
		{
			if (i3ecBpgLeKWg8s1k4bW.GDuuCJlbgK == null)
			{
				i3ecBpgLeKWg8s1k4bW.GDuuCJlbgK = (i3ecBpgLeKWg8s1k4bW.dC7hBOur1rNOnay1jRV)Marshal.GetDelegateForFunctionPointer(i3ecBpgLeKWg8s1k4bW.DfUWbBfcCP(i3ecBpgLeKWg8s1k4bW.tmL0uXbJ0(), string.Concat("Open ".Trim(), "Process")), typeof(i3ecBpgLeKWg8s1k4bW.dC7hBOur1rNOnay1jRV));
			}
			return i3ecBpgLeKWg8s1k4bW.GDuuCJlbgK(u0020, u0020, u0020);
		}

		private byte[] GiHWlEJflL()
		{
			int length = "{11111-22222-20001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		private static IntPtr GuAWh9ZBKX(IntPtr u0020, object u0020, uint u0020)
		{
			if (i3ecBpgLeKWg8s1k4bW.VsRutOyCSx == null)
			{
				i3ecBpgLeKWg8s1k4bW.VsRutOyCSx = (i3ecBpgLeKWg8s1k4bW.u9dCVAuiQ1HsrVGWDnt)Marshal.GetDelegateForFunctionPointer(i3ecBpgLeKWg8s1k4bW.DfUWbBfcCP(i3ecBpgLeKWg8s1k4bW.tmL0uXbJ0(), string.Concat("Find ".Trim(), "ResourceA")), typeof(i3ecBpgLeKWg8s1k4bW.u9dCVAuiQ1HsrVGWDnt));
			}
			return i3ecBpgLeKWg8s1k4bW.VsRutOyCSx(u0020, u0020, u0020);
		}

		[DllImport("kernel32", CharSet=CharSet.None, EntryPoint="LoadLibrary", ExactSpelling=false)]
		public static extern IntPtr HGkW2TKTPI(string u0020);

		private static void IfUgmbHBLF(ref uint u0020, uint u0020, uint u0020, uint u0020, uint u0020, ushort u0020, uint u0020, object u0020)
		{
			// 
			// Current member / type: System.Void b3eD5DgJPcASx0xfHYB.i3ecBpgLeKWg8s1k4bW::IfUgmbHBLF(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void IfUgmbHBLF(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static bool ixBWOPKVhv(object u0020, object u0020)
		{
			if (u0020 == u0020)
			{
				return true;
			}
			if (u0020 == null || u0020 == null)
			{
				return false;
			}
			bool flag = false;
			bool flag1 = false;
			int chars = 0;
			int num = 0;
			if (u0020.StartsWith(i3ecBpgLeKWg8s1k4bW.q9CuhDINps))
			{
				flag = true;
				chars = u0020[4] | (char)(u0020[5] << '\b') | u0020[6] << '\u0010' | u0020[7] << '\u0018';
			}
			if (u0020.StartsWith(i3ecBpgLeKWg8s1k4bW.q9CuhDINps))
			{
				flag1 = true;
				num = u0020[4] | (char)(u0020[5] << '\b') | u0020[6] << '\u0010' | u0020[7] << '\u0018';
			}
			if (!flag && !flag1)
			{
				return false;
			}
			if (!flag)
			{
				chars = i3ecBpgLeKWg8s1k4bW.Y6dWX2Umfm(u0020);
			}
			if (!flag1)
			{
				num = i3ecBpgLeKWg8s1k4bW.Y6dWX2Umfm(u0020);
			}
			return chars == num;
		}

		internal static byte[] JhWg5xCXkM(object u0020)
		{
			// 
			// Current member / type: System.Byte[] b3eD5DgJPcASx0xfHYB.i3ecBpgLeKWg8s1k4bW::JhWg5xCXkM(System.Object)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Byte[] JhWg5xCXkM(System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		private static uint jiggcFun8S(uint u0020, ushort u0020)
		{
			return u0020 >> (32 - u0020 & 31) | u0020 << (u0020 & 31);
		}

		internal static string JkpWtIYFMD(object u0020)
		{
			"{11111-22222-50001-00000}".Trim();
			byte[] numArray = Convert.FromBase64String(u0020);
			return Encoding.Unicode.GetString(numArray, 0, (int)numArray.Length);
		}

		private static int LeBWvg76Hi(IntPtr u0020, int u0020, int u0020, ref int u0020)
		{
			if (i3ecBpgLeKWg8s1k4bW.SaWuN124Fd == null)
			{
				i3ecBpgLeKWg8s1k4bW.SaWuN124Fd = (i3ecBpgLeKWg8s1k4bW.YambrdupFMvmauP3K7v)Marshal.GetDelegateForFunctionPointer(i3ecBpgLeKWg8s1k4bW.DfUWbBfcCP(i3ecBpgLeKWg8s1k4bW.tmL0uXbJ0(), string.Concat("Virtual ".Trim(), "Protect")), typeof(i3ecBpgLeKWg8s1k4bW.YambrdupFMvmauP3K7v));
			}
			return i3ecBpgLeKWg8s1k4bW.SaWuN124Fd(u0020, u0020, u0020, ref u0020);
		}

		internal byte[] lTNWRJwYjM()
		{
			int length = "{11111-22222-50001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		private static int MtwWT3VCN0(IntPtr u0020, IntPtr u0020, [In][Out] byte[] u0020, uint u0020, out IntPtr u0020)
		{
			if (i3ecBpgLeKWg8s1k4bW.Jeduw43wIa == null)
			{
				i3ecBpgLeKWg8s1k4bW.Jeduw43wIa = (i3ecBpgLeKWg8s1k4bW.kAj8IKuRAJ3AX2ZSG1e)Marshal.GetDelegateForFunctionPointer(i3ecBpgLeKWg8s1k4bW.DfUWbBfcCP(i3ecBpgLeKWg8s1k4bW.tmL0uXbJ0(), string.Concat("Write ".Trim(), "Process ".Trim(), "Memory")), typeof(i3ecBpgLeKWg8s1k4bW.kAj8IKuRAJ3AX2ZSG1e));
			}
			return i3ecBpgLeKWg8s1k4bW.Jeduw43wIa(u0020, u0020, u0020, u0020, out u0020);
		}

		private static void oJLWwVRZ1t()
		{
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		internal static string PS1W6uVnQ4(int u0020)
		{
			return null;
		}

		private byte[] qCOWZlu8Yy()
		{
			int length = "{11111-22222-30001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		internal static byte[] rG4Wkdhl8Z(object u0020)
		{
			if (CryptoConfig.AllowOnlyFipsAlgorithms)
			{
				return i3ecBpgLeKWg8s1k4bW.JhWg5xCXkM(u0020);
			}
			return (new MD5CryptoServiceProvider()).ComputeHash(u0020);
		}

		internal static uint rv8WGSMVMI(uint u0020, int u0020, long u0020, object u0020)
		{
			for (int i = 0; i < u0020; i++)
			{
				u0020.BaseStream.Position = u0020 + (long)(i * 40 + 8);
				uint num = u0020.ReadUInt32();
				uint num1 = u0020.ReadUInt32();
				u0020.ReadUInt32();
				uint num2 = u0020.ReadUInt32();
				if (num1 <= u0020 && u0020 < num1 + num)
				{
					return num2 + u0020 - num1;
				}
			}
			return (uint)0;
		}

		internal static SymmetricAlgorithm SdHgzfyLUg()
		{
			SymmetricAlgorithm rijndaelManaged = null;
			if (!CryptoConfig.AllowOnlyFipsAlgorithms)
			{
				try
				{
					rijndaelManaged = new RijndaelManaged();
				}
				catch
				{
					rijndaelManaged = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
				}
			}
			else
			{
				rijndaelManaged = new AesCryptoServiceProvider();
			}
			return rijndaelManaged;
		}

		internal static void slEW3yweK8()
		{
		}

		private void sVVgEl8Y8r(byte[] u0020, byte[] u0020, byte[] u0020)
		{
			int length = (int)u0020.Length % 4;
			int num = (int)u0020.Length / 4;
			byte[] numArray = new byte[(int)u0020.Length];
			int length1 = (int)u0020.Length / 4;
			uint num1 = 0;
			uint num2 = 0;
			uint num3 = 0;
			if (length > 0)
			{
				num++;
			}
			uint num4 = 0;
			for (int i = 0; i < num; i++)
			{
				int num5 = i % length1;
				int num6 = i * 4;
				num4 = (uint)(num5 * 4);
				num2 = (uint)(u0020[num4 + 3] << 24 | u0020[num4 + 2] << 16 | u0020[num4 + 1] << 8 | u0020[num4]);
				uint num7 = 255;
				int num8 = 0;
				if (i != num - 1 || length <= 0)
				{
					num1 += num2;
					num4 = (uint)num6;
					num3 = (uint)(u0020[num4 + 3] << 24 | u0020[num4 + 2] << 16 | u0020[num4 + 1] << 8 | u0020[num4]);
				}
				else
				{
					num3 = 0;
					num1 += num2;
					for (int j = 0; j < length; j++)
					{
						if (j > 0)
						{
							num3 <<= 8;
						}
						num3 |= u0020[(int)u0020.Length - (1 + j)];
					}
				}
				uint num9 = num1;
				num1 = 0;
				uint num10 = num9;
				num10 = num10 ^ num10 << 10;
				num10 += 2105314805;
				num10 = num10 ^ num10 >> 9;
				num10 += 1041097865;
				num10 = num10 ^ num10 << 21;
				num10 += 318111531;
				num10 = 429728319 - num10;
				num1 = num9 + (uint)((double)((float)num10));
				if (i != num - 1 || length <= 0)
				{
					uint num11 = num1 ^ num3;
					numArray[num6] = (byte)(num11 & 255);
					numArray[num6 + 1] = (byte)((num11 & 65280) >> 8);
					numArray[num6 + 2] = (byte)((num11 & 16711680) >> 16);
					numArray[num6 + 3] = (byte)((num11 & -16777216) >> 24);
				}
				else
				{
					uint num12 = num1 ^ num3;
					for (int k = 0; k < length; k++)
					{
						if (k > 0)
						{
							num7 <<= 8;
							num8 += 8;
						}
						numArray[num6 + k] = (byte)((num12 & num7) >> (num8 & 31));
					}
				}
			}
			i3ecBpgLeKWg8s1k4bW.zC0WdeCKxb = numArray;
		}

		internal static void ta2W4MZeBP()
		{
		}

		internal static object ThRpObjfv7gOYq8GdBU()
		{
			return null;
		}

		private static byte[] Tj2WYs9mjj(object u0020)
		{
			Stream memoryStream = new MemoryStream();
			SymmetricAlgorithm symmetricAlgorithm = i3ecBpgLeKWg8s1k4bW.SdHgzfyLUg();
			symmetricAlgorithm.Key = new byte[] { 200, 243, 102, 214, 57, 84, 192, 183, 81, 102, 88, 34, 231, 35, 187, 137, 162, 191, 218, 158, 211, 254, 56, 243, 244, 235, 109, 42, 111, 95, 248, 144 };
			symmetricAlgorithm.IV = new byte[] { 63, 47, 57, 159, 234, 144, 242, 75, 68, 18, 1, 76, 119, 212, 220, 16 };
			CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
			cryptoStream.Write(u0020, 0, (int)u0020.Length);
			cryptoStream.Close();
			return memoryStream.ToArray();
		}

		private static IntPtr tmL0uXbJ0()
		{
			if (i3ecBpgLeKWg8s1k4bW.o9GubdjRed == IntPtr.Zero)
			{
				i3ecBpgLeKWg8s1k4bW.o9GubdjRed = i3ecBpgLeKWg8s1k4bW.HGkW2TKTPI(string.Concat("kernel ".Trim(), "32.dll"));
			}
			return i3ecBpgLeKWg8s1k4bW.o9GubdjRed;
		}

		private byte[] UDdWPJtJJA()
		{
			return null;
		}

		internal byte[] VsxWi58Og1()
		{
			int length = "{11111-22222-40001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		private static void XKigdYp7YM(ref uint u0020, uint u0020, uint u0020, uint u0020, uint u0020, ushort u0020, uint u0020, object u0020)
		{
			// 
			// Current member / type: System.Void b3eD5DgJPcASx0xfHYB.i3ecBpgLeKWg8s1k4bW::XKigdYp7YM(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void XKigdYp7YM(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		private static Delegate xS1WNDmKYC(IntPtr u0020, Type u0020)
		{
			return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[] { typeof(IntPtr), typeof(Type) }).Invoke(null, new object[] { u0020, u0020 });
		}

		private static void xTeWIbHaII(object u0020, int u0020)
		{
			object[] objArray = new object[] { u0020, u0020 };
			BRsI3YS41tRIm0CdPSm.RU5Sw2rZf6(0, objArray, null);
		}

		private static unsafe int Y6dWX2Umfm(object u0020)
		{
			fixed (string str = u0020)
			{
				char* offsetToStringData = (char*)(&str);
				if (offsetToStringData != null)
				{
					offsetToStringData += RuntimeHelpers.OffsetToStringData;
				}
				int num = 5381;
				int num1 = 5381;
				char* chrPointer = offsetToStringData;
				while (true)
				{
					ushort num2 = (ushort)(*chrPointer);
					int num3 = (int)num2;
					if (num2 == 0)
					{
						break;
					}
					num = (num << 5) + num ^ num3;
					num3 = (ushort)(*(chrPointer + 2));
					if (num3 == 0)
					{
						break;
					}
					num1 = (num1 << 5) + num1 ^ num3;
					chrPointer = chrPointer + 2 * 2;
				}
				return num + num1 * 1566083941;
			}
		}

		private static IntPtr yECWUx6OiU(IntPtr u0020, uint u0020, uint u0020, uint u0020)
		{
			if (i3ecBpgLeKWg8s1k4bW.nPFuQHhrem == null)
			{
				i3ecBpgLeKWg8s1k4bW.nPFuQHhrem = (i3ecBpgLeKWg8s1k4bW.FuIE6pu0PT2sfs0Y8hG)Marshal.GetDelegateForFunctionPointer(i3ecBpgLeKWg8s1k4bW.DfUWbBfcCP(i3ecBpgLeKWg8s1k4bW.tmL0uXbJ0(), string.Concat("Virtual ".Trim(), "Alloc")), typeof(i3ecBpgLeKWg8s1k4bW.FuIE6pu0PT2sfs0Y8hG));
			}
			return i3ecBpgLeKWg8s1k4bW.nPFuQHhrem(u0020, u0020, u0020, u0020);
		}

		private void YQ3kGq4rbM2()
		{
		}

		private byte[] YYyWBLWL51()
		{
			return null;
		}

		internal byte[] zMgWpXtaux()
		{
			int length = "{11111-22222-50001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		private static void ztOgonHM3d(ref uint u0020, uint u0020, uint u0020, uint u0020, uint u0020, ushort u0020, uint u0020, object u0020)
		{
			// 
			// Current member / type: System.Void b3eD5DgJPcASx0xfHYB.i3ecBpgLeKWg8s1k4bW::ztOgonHM3d(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void ztOgonHM3d(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public static void zVJW96eS1B(RuntimeTypeHandle u0020)
		{
			try
			{
				Type typeFromHandle = Type.GetTypeFromHandle(u0020);
				if (i3ecBpgLeKWg8s1k4bW.twaWKS1vkk == null)
				{
					lock (i3ecBpgLeKWg8s1k4bW.r4BWAsc3Fp)
					{
						Dictionary<int, int> nums = new Dictionary<int, int>();
						BinaryReader binaryReader = new BinaryReader(typeof(i3ecBpgLeKWg8s1k4bW).Assembly.GetManifestResourceStream("etWhU2IZlkfj3F5vTp.GJOWZx6swlWcHqfKWS"));
						binaryReader.BaseStream.Position = 0L;
						byte[] numArray = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
						binaryReader.Close();
						if (numArray.Length != 0)
						{
							int length = (int)numArray.Length % 4;
							int num = (int)numArray.Length / 4;
							byte[] numArray1 = new byte[(int)numArray.Length];
							uint num1 = 0;
							uint num2 = 0;
							if (length > 0)
							{
								num++;
							}
							uint num3 = 0;
							for (int i = 0; i < num; i++)
							{
								int num4 = i * 4;
								uint num5 = 255;
								int num6 = 0;
								if (i != num - 1 || length <= 0)
								{
									num3 = (uint)num4;
									num2 = (uint)(numArray[num3 + 3] << 24 | numArray[num3 + 2] << 16 | numArray[num3 + 1] << 8 | numArray[num3]);
								}
								else
								{
									num2 = 0;
									for (int j = 0; j < length; j++)
									{
										if (j > 0)
										{
											num2 <<= 8;
										}
										num2 |= numArray[(int)numArray.Length - (1 + j)];
									}
								}
								num1 = num1;
								uint num7 = num1;
								num7 = num7 ^ num7 << 10;
								num7 += 2105314805;
								num7 = num7 ^ num7 >> 9;
								num7 += 1041097865;
								num7 = num7 ^ num7 << 21;
								num7 += 318111531;
								num7 = 429728319 - num7;
								num1 += (uint)((double)((float)num7));
								if (i != num - 1 || length <= 0)
								{
									uint num8 = num1 ^ num2;
									numArray1[num4] = (byte)(num8 & 255);
									numArray1[num4 + 1] = (byte)((num8 & 65280) >> 8);
									numArray1[num4 + 2] = (byte)((num8 & 16711680) >> 16);
									numArray1[num4 + 3] = (byte)((num8 & -16777216) >> 24);
								}
								else
								{
									uint num9 = num1 ^ num2;
									for (int k = 0; k < length; k++)
									{
										if (k > 0)
										{
											num5 <<= 8;
											num6 += 8;
										}
										numArray1[num4 + k] = (byte)((num9 & num5) >> (num6 & 31));
									}
								}
							}
							numArray = numArray1;
							numArray1 = null;
							int length1 = (int)numArray.Length / 8;
							i3ecBpgLeKWg8s1k4bW.oaAYsNuBqKMOnyVqbo8 _oaAYsNuBqKMOnyVqbo8 = new i3ecBpgLeKWg8s1k4bW.oaAYsNuBqKMOnyVqbo8(new MemoryStream(numArray));
							for (int l = 0; l < length1; l++)
							{
								nums.Add(_oaAYsNuBqKMOnyVqbo8.RsPuj8fbIa(), _oaAYsNuBqKMOnyVqbo8.RsPuj8fbIa());
							}
							_oaAYsNuBqKMOnyVqbo8.noBuZM3NFY();
						}
						i3ecBpgLeKWg8s1k4bW.twaWKS1vkk = nums;
					}
				}
				FieldInfo[] fields = typeFromHandle.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetField);
				for (int m = 0; m < (int)fields.Length; m++)
				{
					try
					{
						FieldInfo fieldInfo = fields[m];
						int metadataToken = fieldInfo.MetadataToken;
						int item = i3ecBpgLeKWg8s1k4bW.twaWKS1vkk[metadataToken];
						bool flag = (item & 1073741824) > 0;
						item &= 1073741823;
						MethodInfo methodInfo = (MethodInfo)typeof(i3ecBpgLeKWg8s1k4bW).Module.ResolveMethod(item, typeFromHandle.GetGenericArguments(), new Type[0]);
						if (!methodInfo.IsStatic)
						{
							ParameterInfo[] parameters = methodInfo.GetParameters();
							int length2 = (int)parameters.Length + 1;
							Type[] parameterType = new Type[length2];
							if (!methodInfo.DeclaringType.IsValueType)
							{
								parameterType[0] = typeof(object);
							}
							else
							{
								parameterType[0] = methodInfo.DeclaringType.MakeByRefType();
							}
							for (int n = 0; n < (int)parameters.Length; n++)
							{
								parameterType[n + 1] = parameters[n].ParameterType;
							}
							DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, methodInfo.ReturnType, parameterType, typeFromHandle, true);
							ILGenerator lGenerator = dynamicMethod.GetILGenerator();
							for (int o = 0; o < length2; o++)
							{
								switch (o)
								{
									case 0:
									{
										lGenerator.Emit(OpCodes.Ldarg_0);
										break;
									}
									case 1:
									{
										lGenerator.Emit(OpCodes.Ldarg_1);
										break;
									}
									case 2:
									{
										lGenerator.Emit(OpCodes.Ldarg_2);
										break;
									}
									case 3:
									{
										lGenerator.Emit(OpCodes.Ldarg_3);
										break;
									}
									default:
									{
										lGenerator.Emit(OpCodes.Ldarg_S, o);
										break;
									}
								}
							}
							lGenerator.Emit(OpCodes.Tailcall);
							lGenerator.Emit((flag ? OpCodes.Callvirt : OpCodes.Call), methodInfo);
							lGenerator.Emit(OpCodes.Ret);
							fieldInfo.SetValue(null, dynamicMethod.CreateDelegate(typeFromHandle));
						}
						else
						{
							fieldInfo.SetValue(null, Delegate.CreateDelegate(fieldInfo.FieldType, methodInfo));
						}
					}
					catch
					{
					}
				}
			}
			catch (Exception exception)
			{
			}
		}

		internal struct AjwXVCuYlkHL854QOoY
		{
			internal bool C8KuXI1pju;

			internal byte[] y79uOYKQmr;
		}

		internal class cP3gEOuTFZKXFwueWBV : Attribute
		{
			public cP3gEOuTFZKXFwueWBV(object u0020)
			{
			}

			internal class UWZdvfuvW4bsIO4y0aq<bdAPgHuatoatG07R0Ds>
			{
				internal static object JjnBSMkkYERouQ5l8dHd;

				public UWZdvfuvW4bsIO4y0aq()
				{
					i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
					Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
					base();
				}

				internal static object jkedMQkkOrL639WJe11j()
				{
					return i3ecBpgLeKWg8s1k4bW.cP3gEOuTFZKXFwueWBV.UWZdvfuvW4bsIO4y0aq<bdAPgHuatoatG07R0Ds>.JjnBSMkkYERouQ5l8dHd;
				}

				internal static bool rxMP8TkkXuPB2ygLkpxY()
				{
					return i3ecBpgLeKWg8s1k4bW.cP3gEOuTFZKXFwueWBV.UWZdvfuvW4bsIO4y0aq<bdAPgHuatoatG07R0Ds>.JjnBSMkkYERouQ5l8dHd == null;
				}
			}
		}

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr dC7hBOur1rNOnay1jRV(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		internal delegate uint FnS2y3uuKEQgVoDQ55U(IntPtr classthis, IntPtr comp, IntPtr info, uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr FuIE6pu0PT2sfs0Y8hG(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		[Flags]
		private enum HUiBD0ueLIY4lA9oxNu
		{

		}

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int kAj8IKuRAJ3AX2ZSG1e(IntPtr hProcess, IntPtr lpBaseAddress, [In][Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr KlYhhquSdDCHWFTfnZ5();

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int LOlqbqunnCM4dyivWSF(IntPtr ptr);

		internal class oaAYsNuBqKMOnyVqbo8
		{
			private BinaryReader MinuF3GIUn;

			public oaAYsNuBqKMOnyVqbo8(Stream u0020)
			{
				this.MinuF3GIUn = new BinaryReader(u0020);
			}

			internal Stream bJfBUv9Xn2()
			{
				return this.MinuF3GIUn.BaseStream;
			}

			internal byte[] E2IuPJsqSl(int u0020)
			{
				return this.MinuF3GIUn.ReadBytes(u0020);
			}

			internal void noBuZM3NFY()
			{
				this.MinuF3GIUn.Close();
			}

			internal int RsPuj8fbIa()
			{
				return this.MinuF3GIUn.ReadInt32();
			}

			internal int zioulSJZeZ(byte[] u0020, int u0020, int u0020)
			{
				return this.MinuF3GIUn.Read(u0020, u0020, u0020);
			}
		}

		private delegate void OiK0veuUawylyWbL6Gg(object o);

		internal class QD4osyugNgYx4cByUVr
		{
			public QD4osyugNgYx4cByUVr()
			{
			}

			internal static string gl1uW2OSTt(object u0020, object u0020)
			{
				byte[] bytes = Encoding.Unicode.GetBytes(u0020);
				byte[] numArray = new byte[] { 82, 102, 104, 110, 32, 77, 24, 34, 118, 181, 51, 17, 18, 51, 12, 109, 10, 32, 77, 24, 34, 158, 161, 41, 97, 28, 118, 181, 5, 25, 1, 88 };
				byte[] numArray1 = i3ecBpgLeKWg8s1k4bW.rG4Wkdhl8Z(Encoding.Unicode.GetBytes(u0020));
				MemoryStream memoryStream = new MemoryStream();
				SymmetricAlgorithm symmetricAlgorithm = i3ecBpgLeKWg8s1k4bW.SdHgzfyLUg();
				symmetricAlgorithm.Key = numArray;
				symmetricAlgorithm.IV = numArray1;
				CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
				cryptoStream.Write(bytes, 0, (int)bytes.Length);
				cryptoStream.Close();
				return Convert.ToBase64String(memoryStream.ToArray());
			}
		}

		[UnmanagedFunctionPointer(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
		private delegate IntPtr u9dCVAuiQ1HsrVGWDnt(IntPtr hModule, string lpName, uint lpType);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int YambrdupFMvmauP3K7v(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);
	}
}