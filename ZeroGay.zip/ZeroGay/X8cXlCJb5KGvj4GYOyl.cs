using AksgHVKH9UOXlBDvRpO;
using System;
using System.IO;

internal delegate Stream X8cXlCJb5KGvj4GYOyl(object object_0);