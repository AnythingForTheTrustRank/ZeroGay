using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.Core;

internal delegate ApiWorld XLEXloiYFtDlMds7TQp();