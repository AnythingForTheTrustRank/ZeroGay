using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using UnityEngine.XR;

internal delegate Vector3 VXHFgvRu68MMCjt0X8h(XRNode );