using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool pbuPjIEmOYEPiK6jl5c();