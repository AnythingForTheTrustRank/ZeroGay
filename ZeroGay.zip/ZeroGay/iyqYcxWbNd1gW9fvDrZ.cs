using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using System;
using System.Reflection;

internal delegate MethodInfo iyqYcxWbNd1gW9fvDrZ(object object_0, MethodBase methodBase_0, HarmonyMethod harmonyMethod_0, HarmonyMethod harmonyMethod_1, HarmonyMethod harmonyMethod_2, HarmonyMethod harmonyMethod_3, HarmonyMethod harmonyMethod_4);