using b3eD5DgJPcASx0xfHYB;
using cupyhe32CdSmRLkgtUq;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using t5eG7owXnu4dEOdK95P;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UyW1FlOl3XL1EHOVRF;
using VRC;
using VRC.Core;
using VRC.SDKBase;

namespace Blaze.Modules
{
	public class ZDUserInfo : MonoBehaviour
	{
		internal Player JfCwPVBZBZ;

		internal VRCPlayer MuEwlSfvZF;

		internal PlayerNet xKEwjhZIRt;

		internal VRCPlayerApi rRFwZ55lKs;

		internal APIUser yWfwFZVXX5;

		internal Transform SwTwiT9CwT;

		internal GameObject ORLw0uXroZ;

		internal TextMeshProUGUI yOCwRgAcXD;

		private byte W85wpPbcb5;

		private byte uMMwrM2Uv7;

		private int Fcmwn7ZSB2;

		private string iRHweDmTKp;

		internal static ZDUserInfo NrAnsymodOtkULlcx2s;

		public ZDUserInfo(IntPtr id)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.Fcmwn7ZSB2 = 0;
			this.iRHweDmTKp = "";
			base(id);
		}

		internal static ZDUserInfo bTQUhpmD8ija5P68deX()
		{
			return ZDUserInfo.NrAnsymodOtkULlcx2s;
		}

		public void DestroyLowerNameplate()
		{
			if (this.ORLw0uXroZ != null)
			{
				UnityEngine.Object.Destroy(this.ORLw0uXroZ);
				this.ORLw0uXroZ = null;
			}
		}

		internal static bool EpH4ITmmMMtgfyQqKmn()
		{
			return ZDUserInfo.NrAnsymodOtkULlcx2s == null;
		}

		private void mF6wB4rMuq()
		{
			this.SwTwiT9CwT = base.get_gameObject().get_transform().Find("Player Nameplate/Canvas/Nameplate/Contents");
			this.JfCwPVBZBZ = base.get_gameObject().GetComponent<Player>();
			this.MuEwlSfvZF = base.get_gameObject().GetComponent<VRCPlayer>();
			this.xKEwjhZIRt = base.get_gameObject().GetComponent<PlayerNet>();
			this.rRFwZ55lKs = this.JfCwPVBZBZ.Method_Public_get_VRCPlayerApi_0();
			this.yWfwFZVXX5 = this.JfCwPVBZBZ.Method_Internal_get_APIUser_0();
			this.SwTwiT9CwT.Find("Main/Background").GetComponent<ImageThreeSlice>().set_color(this.JfCwPVBZBZ.PAj3uqg4Aq());
			this.SwTwiT9CwT.Find("Main/Pulse").GetComponent<ImageThreeSlice>().set_color(this.JfCwPVBZBZ.PAj3uqg4Aq());
			this.SwTwiT9CwT.Find("Main/Glow").GetComponent<ImageThreeSlice>().set_color(this.JfCwPVBZBZ.PAj3uqg4Aq());
			this.SwTwiT9CwT.Find("Icon/Background").GetComponent<Image>().set_color(this.JfCwPVBZBZ.PAj3uqg4Aq());
			this.SwTwiT9CwT.Find("Icon/Pulse").GetComponent<Image>().set_color(this.JfCwPVBZBZ.PAj3uqg4Aq());
			this.SwTwiT9CwT.Find("Icon/Glow").GetComponent<Image>().set_color(this.JfCwPVBZBZ.PAj3uqg4Aq());
			this.SwTwiT9CwT.Find("Quick Stats").GetComponent<ImageThreeSlice>().set_color(this.JfCwPVBZBZ.PAj3uqg4Aq());
		}

		public void OnDestroy()
		{
			UIgbLCwYwfEUV2GA7DN.UVrwOoZAqi.Remove(this);
		}

		public void ResetNameplateColors()
		{
			if (this.ORLw0uXroZ != null)
			{
				this.ORLw0uXroZ.GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			}
			this.SwTwiT9CwT.Find("Main/Background").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Main/Pulse").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Main/Glow").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Icon/Background").GetComponent<Image>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Icon/Pulse").GetComponent<Image>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Icon/Glow").GetComponent<Image>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Quick Stats").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
		}

		public void ResetNameplates()
		{
			if (this.ORLw0uXroZ != null)
			{
				UnityEngine.Object.Destroy(this.ORLw0uXroZ);
			}
			this.SwTwiT9CwT.Find("Main/Background").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Main/Pulse").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Main/Glow").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Icon/Background").GetComponent<Image>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Icon/Pulse").GetComponent<Image>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Icon/Glow").GetComponent<Image>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Quick Stats").GetComponent<ImageThreeSlice>().set_color(Color.get_white());
			this.SwTwiT9CwT.Find("Quick Stats").set_localPosition(new Vector3(0f, 30f, 0f));
		}

		public void SetupLowerNameplate()
		{
			try
			{
				this.ORLw0uXroZ = UnityEngine.Object.Instantiate<GameObject>(this.SwTwiT9CwT.Find("Quick Stats").get_gameObject(), this.SwTwiT9CwT, false);
			}
			catch (Exception exception)
			{
				MelonLogger.Log("Failed To Find Nameplate!");
				throw;
			}
			this.ORLw0uXroZ.set_name("Blaze Nameplate");
			for (int i = this.ORLw0uXroZ.get_transform().get_childCount(); i > 0; i--)
			{
				Transform child = this.ORLw0uXroZ.get_transform().GetChild(i - 1);
				if (child.get_name() != "Trust Text")
				{
					UnityEngine.Object.Destroy(child.get_gameObject());
				}
				else
				{
					this.yOCwRgAcXD = child.GetComponent<TextMeshProUGUI>();
					this.yOCwRgAcXD.set_color(Color.get_white());
				}
			}
			this.ORLw0uXroZ.get_gameObject().SetActive(true);
			this.ORLw0uXroZ.GetComponent<RectTransform>().set_localPosition(new Vector3(0f, -60f, 0f));
			this.JfCwPVBZBZ.get_transform().Find("Player Nameplate/Canvas/Avatar Progress").GetComponent<RectTransform>().set_localPosition(new Vector3(0f, -45f, 0f));
		}

		public void Start()
		{
			this.mF6wB4rMuq();
			this.SetupLowerNameplate();
		}

		public void Update()
		{
			string str;
			WaitForSeconds waitForSecond = new WaitForSeconds(1f);
			if (this.W85wpPbcb5 != this.JfCwPVBZBZ.get__playerNet().get_field_Private_Byte_0() || this.uMMwrM2Uv7 != this.JfCwPVBZBZ.get__playerNet().get_field_Private_Byte_1())
			{
				this.Fcmwn7ZSB2 = 0;
			}
			else
			{
				this.Fcmwn7ZSB2++;
			}
			this.W85wpPbcb5 = this.JfCwPVBZBZ.get__playerNet().get_field_Private_Byte_0();
			this.uMMwrM2Uv7 = this.JfCwPVBZBZ.get__playerNet().get_field_Private_Byte_1();
			string str1 = "<color=green>Stable</color>";
			if (this.Fcmwn7ZSB2 > 35)
			{
				str1 = "<color=yellow>Lagging</color>";
			}
			if (this.Fcmwn7ZSB2 > 375)
			{
				str1 = "<color=red>Crashed</color>";
			}
			if (this.JfCwPVBZBZ.Method_Internal_get_APIUser_0().get_id() == "usr_508a881f-0bd5-40a9-ad5c-6642e37efdef")
			{
				str = "<color=blue>ZeroDay Owner</color>";
			}
			else if (this.JfCwPVBZBZ.Method_Internal_get_APIUser_0().get_id() == "usr_9be64934-6c08-45d5-89d3-b8fa1d5edcdf")
			{
				str = "<color=red>Psychopath</color>";
			}
			else if (this.JfCwPVBZBZ.Method_Internal_get_APIUser_0().get_id() == "usr_d8e9c2a7-891b-4fba-9c88-d007b789dc21")
			{
				str = "<color=yellow>British Cunt That Likes To Crash</color>";
			}
			else if (this.JfCwPVBZBZ.Method_Internal_get_APIUser_0().get_id() != "usr_d2ff31fe-ad0a-478c-9583-0932958caa15")
			{
				str = (this.JfCwPVBZBZ.Method_Internal_get_APIUser_0().get_id() == "usr_1c4ffc38-240e-4b52-837d-3a9fa9e4b8bc" ? "<color=green>Silent As A Mouse</color>" : this.JfCwPVBZBZ.Method_Internal_get_APIUser_0().uENjdoXKw().ToLower());
			}
			else
			{
				str = "<color=green>Iris Lmao</color>";
			}
			if (this.JfCwPVBZBZ == null || this.MuEwlSfvZF == null || this.xKEwjhZIRt == null || this.rRFwZ55lKs == null || this.yWfwFZVXX5 == null)
			{
				this.mF6wB4rMuq();
			}
			if (this.ORLw0uXroZ != null)
			{
				this.yOCwRgAcXD.set_text(string.Concat(new string[] { "[<color=green>", this.JfCwPVBZBZ.rmf3Ut66iB(), "</color>] |[", str1, "] |<color=white>Ping:</color> ", this.JfCwPVBZBZ.wDj3BkNF8Q(), " |<color=white>FPS</color>: ", this.JfCwPVBZBZ.pH23XFYQSL(), " | [", str, "]" }));
			}
		}
	}
}