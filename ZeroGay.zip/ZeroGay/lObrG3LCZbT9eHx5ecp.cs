using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void* lObrG3LCZbT9eHx5ecp(IntPtr );