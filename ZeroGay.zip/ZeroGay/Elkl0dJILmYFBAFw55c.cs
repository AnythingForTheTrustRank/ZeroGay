using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection.Emit;

internal delegate void Elkl0dJILmYFBAFw55c(object , OpCode , Type );