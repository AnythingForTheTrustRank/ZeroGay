using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.Core;

internal delegate Dictionary<int, List<ApiModel>> nLiybgfDMyGqy4AG9S9(object );