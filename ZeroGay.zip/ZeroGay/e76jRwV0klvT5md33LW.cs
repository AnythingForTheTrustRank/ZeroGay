using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate double e76jRwV0klvT5md33LW(object );