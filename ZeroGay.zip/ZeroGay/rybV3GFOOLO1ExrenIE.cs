using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string rybV3GFOOLO1ExrenIE(ref DateTime dateTime_0, string string_0);