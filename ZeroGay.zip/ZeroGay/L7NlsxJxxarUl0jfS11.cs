using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Transform L7NlsxJxxarUl0jfS11(object object_0);