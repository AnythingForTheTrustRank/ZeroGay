using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate ActionMenu KRpmXFWoANJwMVVGuqY(object object_0);