using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate Il2CppStructArray<Plane> N8I8VywKgQfiTBajV41(Camera camera_0);