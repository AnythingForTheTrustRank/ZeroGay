using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.DataModel;
using VRC.SDKBase;
using VRC.UI;
using VRC.UI.Elements.Menus;

namespace cupyhe32CdSmRLkgtUq
{
	internal static class aKEqp43C0rRsZh8xfF3
	{
		private static GameObject GlK3RTiEdw;

		private static int Ki53pPiRGy;

		public static string GZD3rGGcgi;

		public static System.Collections.Generic.Dictionary<int, Player> iro3nMZLcr;

		internal static aKEqp43C0rRsZh8xfF3 l11Wbs5lhEriRqUOvqK;

		static aKEqp43C0rRsZh8xfF3()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			aKEqp43C0rRsZh8xfF3.Ki53pPiRGy = 0;
			aKEqp43C0rRsZh8xfF3.GZD3rGGcgi = "";
			aKEqp43C0rRsZh8xfF3.iro3nMZLcr = new System.Collections.Generic.Dictionary<int, Player>();
		}

		public static bool AkB3a8ugaa(this object u0020)
		{
			return (u0020.get__playerNet() > 0 || u0020.get__playerNet() > 0f ? false : u0020.get__playerNet() <= -1f);
		}

		public static void cg33PZT18t(this object u0020, bool u0020)
		{
			u0020.get__player();
			return u0020.get_transform();
		}

		public static string fuk3OuZuHj(this object u0020)
		{
			string str;
			float __playerNet = u0020.get__playerNet();
			short num = u0020.get__playerNet();
			if (num > 665)
			{
				str = " <color=red>ClientUser</color>";
			}
			else if (num < -2)
			{
				str = " <color=red>ClientUser</color>";
			}
			else if (__playerNet <= 140f)
			{
				str = (__playerNet >= -2f ? "" : " <color=red>ClientUser</color>");
			}
			else
			{
				str = " <color=red>ClientUser</color>";
			}
			return str;
		}

		public static bool i4d3g59S71(this object u0020)
		{
			return (u0020.get__playerNet() > 0 || u0020.get__playerNet() > 0f ? u0020.get_transform().get_position() == Vector3.get_zero() : true);
		}

		public static int k7K3YG962c(this object u0020)
		{
			byte fieldPrivateByte0 = u0020.get__playerNet().get_field_Private_Byte_0();
			byte fieldPrivateByte1 = u0020.get__playerNet().get_field_Private_Byte_1();
			if (fieldPrivateByte0 != u0020.get__playerNet().get_field_Private_Byte_0() || fieldPrivateByte1 != u0020.get__playerNet().get_field_Private_Byte_1())
			{
				aKEqp43C0rRsZh8xfF3.Ki53pPiRGy = 0;
			}
			else
			{
				aKEqp43C0rRsZh8xfF3.Ki53pPiRGy++;
			}
			return aKEqp43C0rRsZh8xfF3.Ki53pPiRGy;
		}

		public static void KVI3jWtSFr(object u0020)
		{
			PageAvatar component = GameObject.Find("Screens").get_transform().Find("Avatar").GetComponent<PageAvatar>();
			SimpleAvatarPedestal fieldPublicSimpleAvatarPedestal0 = component.get_field_Public_SimpleAvatarPedestal_0();
			ApiAvatar apiAvatar = new ApiAvatar();
			apiAvatar.set_id(u0020);
			fieldPublicSimpleAvatarPedestal0.set_field_Internal_ApiAvatar_0(apiAvatar);
			component.ChangeToSelectedAvatar();
		}

		internal static aKEqp43C0rRsZh8xfF3 luLStZ5Z0EcE29NqtAJ()
		{
			return aKEqp43C0rRsZh8xfF3.l11Wbs5lhEriRqUOvqK;
		}

		public static void NRZ3S3AnPG()
		{
			AssetBundleDownloadManager.get_field_Private_Static_AssetBundleDownloadManager_0().get_field_Private_Cache_0().ClearCache();
			AssetBundleDownloadManager.get_field_Private_Static_AssetBundleDownloadManager_0().get_field_Private_Queue_1_AssetBundleDownload_0().Clear();
			AssetBundleDownloadManager.get_field_Private_Static_AssetBundleDownloadManager_0().get_field_Private_Queue_1_AssetBundleDownload_1().Clear();
		}

		public static Color PAj3uqg4Aq(this object u0020)
		{
			return VRCPlayer.Method_Public_Static_Color_APIUser_0(u0020.Method_Internal_get_APIUser_0());
		}

		public static string pH23XFYQSL(this object u0020)
		{
			string str;
			float __playerNet = u0020.get__playerNet();
			if (__playerNet > 80f)
			{
				str = string.Concat("<color=green>", __playerNet.ToString(), "</color>");
			}
			else
			{
				str = (__playerNet > 30f ? string.Concat("<color=yellow>", __playerNet.ToString(), "</color>") : string.Concat("<color=red>", __playerNet.ToString(), "</color>"));
			}
			return str;
		}

		public static string rmf3Ut66iB(this object u0020)
		{
			string str;
			if (!u0020.Method_Internal_get_APIUser_0().get_IsOnMobile())
			{
				str = (!u0020.Method_Public_get_VRCPlayerApi_0().IsUserInVR() ? "<color=grey>PC</color>" : "<color=#CE00D5>VR</color>");
			}
			else
			{
				str = "<color=green>Q</color>";
			}
			return str;
		}

		internal static bool SjDkVu5jU2j6qNAVU6k()
		{
			return aKEqp43C0rRsZh8xfF3.l11Wbs5lhEriRqUOvqK == null;
		}

		public static bool T4B3v0PTIE(this object u0020)
		{
			return ((u0020.get__playerNet() > 0 || u0020.get__playerNet() > 0f) && u0020.get__playerNet() > -1f ? u0020.get_transform().get_position() == Vector3.get_zero() : true);
		}

		public static string tKL3Z3kxjM()
		{
			int _playerId = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().Method_Public_get_VRCPlayerApi_0().get_playerId();
			return _playerId.ToString();
		}

		public static IUser uLY3WQrds6(this object u0020)
		{
			return u0020.get_field_Private_IUser_0();
		}

		public static string wDj3BkNF8Q(this object u0020)
		{
			string str;
			short __playerNet = u0020.get__playerNet();
			if (__playerNet <= 150)
			{
				str = (__playerNet <= 75 ? string.Concat("<color=green>", __playerNet.ToString(), "</color>") : string.Concat("<color=yellow>", __playerNet.ToString(), "</color>"));
			}
			else
			{
				str = string.Concat("<color=red>", __playerNet.ToString(), "</color>");
			}
			return str;
		}

		private static VRCPlayer wHU3bY3TK6()
		{
			return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
		}
	}
}