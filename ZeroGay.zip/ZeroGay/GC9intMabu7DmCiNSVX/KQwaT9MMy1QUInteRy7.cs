using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using UnityEngine;
using VRC.Udon;
using X7IetPATbOXxq4U7Vmy;

namespace GC9intMabu7DmCiNSVX
{
	internal class KQwaT9MMy1QUInteRy7
	{
		private static KQwaT9MMy1QUInteRy7 DKb0SMm8WbqqY9wmkpq;

		public KQwaT9MMy1QUInteRy7()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static void L6UMywL3Il()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (1)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (2)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (3)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (4)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (5)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (6)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (7)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (8)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (9)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (10)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (11)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (12)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (13)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (14)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (15)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (!gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (16)"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
			}
		}

		internal static void sH2MT2ds86()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (1)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (2)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (3)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (4)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (5)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (6)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (7)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (8)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (9)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (10)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (11)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (12)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (13)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (14)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (15)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (!gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (16)"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
			}
		}

		internal static bool vjIpsYmEjBVopuWArAi()
		{
			return KQwaT9MMy1QUInteRy7.DKb0SMm8WbqqY9wmkpq == null;
		}

		internal static KQwaT9MMy1QUInteRy7 vRKO4UmwYGDrMj7xnLC()
		{
			return KQwaT9MMy1QUInteRy7.DKb0SMm8WbqqY9wmkpq;
		}
	}
}