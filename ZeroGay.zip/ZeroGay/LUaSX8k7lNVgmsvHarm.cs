using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection.Emit;

internal delegate ILGenerator LUaSX8k7lNVgmsvHarm(object object_0);