using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate Il2CppStructArray<ContactPoint> lvYAQqfHJIR5NFkkQvv(object );