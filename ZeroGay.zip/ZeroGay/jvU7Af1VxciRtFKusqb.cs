using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate double jvU7Af1VxciRtFKusqb(object object_0);