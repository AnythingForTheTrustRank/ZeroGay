using b3eD5DgJPcASx0xfHYB;
using DW6c39Q48fhvTF5jMI;
using q4loiAuxF6MNtBcZrh7;
using System;
using UnityEngine;
using VRC.SDKBase;
using VRCSDK2;

internal class PortableMirror
{
	public static GameObject OjwGKcQR5i;

	public static float jNrGARblis;

	public static float hWtGVGK0Cr;

	public static bool PN1GLeHrKi;

	public static bool NbnGJwuMle;

	private static PortableMirror YWRmAx5bCRXAA711r74;

	static PortableMirror()
	{
		i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
		Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
		PortableMirror.jNrGARblis = 3f;
		PortableMirror.hWtGVGK0Cr = 2.5f;
		PortableMirror.PN1GLeHrKi = false;
		PortableMirror.NbnGJwuMle = true;
	}

	public PortableMirror()
	{
		i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
		Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
		base();
	}

	internal static PortableMirror neNn4a5UVZW8382G9dv()
	{
		return PortableMirror.YWRmAx5bCRXAA711r74;
	}

	internal static bool QM5XlS5hyIBWKYPYxtU()
	{
		return PortableMirror.YWRmAx5bCRXAA711r74 == null;
	}

	public static void tI0G1ri0db(bool u0020)
	{
		if (!u0020 && PortableMirror.OjwGKcQR5i != null)
		{
			UnityEngine.Object.Destroy(PortableMirror.OjwGKcQR5i);
			PortableMirror.OjwGKcQR5i = null;
		}
		else if (u0020)
		{
			VRCPlayer fieldInternalStaticVRCPlayer0 = VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
			Vector3 _position = fieldInternalStaticVRCPlayer0.get_transform().get_position() + fieldInternalStaticVRCPlayer0.get_transform().get_forward();
			ref float singlePointer = ref _position.y;
			singlePointer = singlePointer + PortableMirror.hWtGVGK0Cr / 1.7f;
			GameObject gameObject = GameObject.CreatePrimitive(5);
			gameObject.get_transform().set_position(_position);
			gameObject.get_transform().set_rotation(fieldInternalStaticVRCPlayer0.get_transform().get_rotation());
			gameObject.get_transform().set_localScale(new Vector3(PortableMirror.jNrGARblis, PortableMirror.hWtGVGK0Cr, 1f));
			gameObject.set_name("PortableMirror");
			UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
			gameObject.hlCglFD42<BoxCollider>().set_size(new Vector3(1f, 1f, 0.05f));
			gameObject.hlCglFD42<BoxCollider>().set_isTrigger(true);
			gameObject.hlCglFD42<MeshRenderer>().get_material().set_shader(Shader.Find("FX/MirrorReflection"));
			VRCSDK2.VRC_MirrorReflection vRCMirrorReflection = gameObject.hlCglFD42<VRCSDK2.VRC_MirrorReflection>();
			LayerMask layerMask = new LayerMask();
			layerMask.set_value((!PortableMirror.PN1GLeHrKi ? -1025 : 263680));
			vRCMirrorReflection.set_m_ReflectLayers(layerMask);
			PortableMirror.OjwGKcQR5i = gameObject;
		}
	}
}