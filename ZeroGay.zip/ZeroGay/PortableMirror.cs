using AksgHVKH9UOXlBDvRpO;
using DI1Ec8yA4vBbNqCqHF;
using System;
using UnityEngine;
using VRC.SDKBase;
using VRCSDK2;
using X7IetPATbOXxq4U7Vmy;

internal class PortableMirror
{
	public static GameObject fhFOL83uWt;

	public static float SiwO1EUui9;

	public static float jnEO3uK9Uv;

	public static bool BRmOk8x5sv;

	public static bool o9UOfAt61A;

	internal static PortableMirror KsWJOEflQ94K50Op4n9;

	static PortableMirror()
	{
		CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
		ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
		PortableMirror.SiwO1EUui9 = 3f;
		PortableMirror.jnEO3uK9Uv = 2.5f;
		PortableMirror.BRmOk8x5sv = false;
		PortableMirror.o9UOfAt61A = true;
	}

	public PortableMirror()
	{
		CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
		ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
		base();
	}

	internal static PortableMirror fnKsr0fGjuHt6eFNxi4()
	{
		return PortableMirror.KsWJOEflQ94K50Op4n9;
	}

	internal static bool pGcVSrfAIi4Jb9JHfIn()
	{
		return PortableMirror.KsWJOEflQ94K50Op4n9 == null;
	}

	public static VRCPlayer QHlOZjd7ZQ()
	{
		return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
	}

	public static void vrGOVWV7RC(bool bool_0)
	{
		if ((bool_0 ? false : PortableMirror.fhFOL83uWt != null))
		{
			UnityEngine.Object.Destroy(PortableMirror.fhFOL83uWt);
			PortableMirror.fhFOL83uWt = null;
		}
		else if (bool_0)
		{
			VRCPlayer vRCPlayer = PortableMirror.QHlOZjd7ZQ();
			Vector3 _position = vRCPlayer.get_transform().get_position() + vRCPlayer.get_transform().get_forward();
			ref float singlePointer = ref _position.y;
			singlePointer = singlePointer + PortableMirror.jnEO3uK9Uv / 1.7f;
			GameObject gameObject = GameObject.CreatePrimitive(5);
			gameObject.get_transform().set_position(_position);
			gameObject.get_transform().set_rotation(vRCPlayer.get_transform().get_rotation());
			gameObject.get_transform().set_localScale(new Vector3(PortableMirror.SiwO1EUui9, PortableMirror.jnEO3uK9Uv, 1f));
			gameObject.set_name("PortableMirror");
			UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
			gameObject.cZRK1kpdT<BoxCollider>().set_size(new Vector3(1f, 1f, 0.05f));
			gameObject.cZRK1kpdT<BoxCollider>().set_isTrigger(true);
			gameObject.cZRK1kpdT<MeshRenderer>().get_material().set_shader(Shader.Find("FX/MirrorReflection"));
			VRCSDK2.VRC_MirrorReflection vRCMirrorReflection = gameObject.cZRK1kpdT<VRCSDK2.VRC_MirrorReflection>();
			LayerMask layerMask = new LayerMask();
			layerMask.set_value((PortableMirror.BRmOk8x5sv ? 263680 : -1025));
			vRCMirrorReflection.set_m_ReflectLayers(layerMask);
			PortableMirror.fhFOL83uWt = gameObject;
		}
	}
}