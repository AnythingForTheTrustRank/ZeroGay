using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;
using System.Reflection.Emit;

internal delegate void lVUL6XkijUsdX5MJANv(object object_0, OpCode opCode_0, ConstructorInfo constructorInfo_0);