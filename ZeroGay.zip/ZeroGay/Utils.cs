using Il2CppSystem;
using Photon.Realtime;
using System;
using UnhollowerBaseLib;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.XR;
using VRC;
using VRC.Management;
using VRC.SDKBase;
using VRC.UserCamera;

public static class Utils
{
	internal static Utils CM1BZbfekBOi0yHwqvp;

	public static ActionMenu ActionMenu
	{
		get
		{
			return Utils.ActionMenu.get_field_Private_ActionMenuOpener_0().get_field_Public_ActionMenu_0();
		}
	}

	public static UnityEngine.Camera Camera
	{
		get
		{
			return VRCVrCamera.get_field_Private_Static_VRCVrCamera_0().get_field_Public_Camera_0();
		}
	}

	public static VRCPlayer CurrentUser
	{
		get
		{
			return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
		}
		set
		{
			Utils.CurrentUser = Utils.CurrentUser;
		}
	}

	public static LoadBalancingClient LoadBalancingPeer
	{
		get
		{
			return MonoBehaviour1PrivateObInPrInBoInInInInUnique.get_field_Internal_Static_MonoBehaviour1PrivateObInPrInBoInInInInUnique_0().Method_Public_get_LoadBalancingClient_0();
		}
	}

	public static VRCPlayerApi LocalPlayer
	{
		get
		{
			return Networking.get_LocalPlayer();
		}
	}

	public static VRC.Management.ModerationManager ModerationManager
	{
		get
		{
			return VRC.Management.ModerationManager.Method_Public_Static_get_ModerationManager_PDM_0();
		}
	}

	public static NetworkManager NetworkManager
	{
		get
		{
			return NetworkManager.get_field_Internal_Static_NetworkManager_0();
		}
	}

	public static NotificationManager NotificationManager
	{
		get
		{
			return NotificationManager.get_field_Private_Static_NotificationManager_0();
		}
	}

	public static MonoBehaviour1PrivateObInPrInBoInInInInUnique PhotonHandler
	{
		get
		{
			return MonoBehaviour1PrivateObInPrInBoInInInInUnique.get_field_Internal_Static_MonoBehaviour1PrivateObInPrInBoInInInInUnique_0();
		}
	}

	public static VRC.PlayerManager PlayerManager
	{
		get
		{
			return VRC.PlayerManager.get_field_Private_Static_PlayerManager_0();
		}
	}

	public static QuickMenu QuickMenu
	{
		get
		{
			return QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0();
		}
	}

	public static QuickMenuContextualDisplay QuickMenuContextualDisplay
	{
		get
		{
			return Utils.QuickMenu.get_field_Private_QuickMenuContextualDisplay_0();
		}
	}

	public static VRC.UserCamera.UserCameraController UserCameraController
	{
		get
		{
			return VRC.UserCamera.UserCameraController.get_field_Internal_Static_UserCameraController_0();
		}
	}

	public static UserInteractMenu UserInteractMenu
	{
		get
		{
			return Resources.FindObjectsOfTypeAll<UserInteractMenu>().get_Item(0);
		}
	}

	public static VRCTrackingManager VRCTrackingManager
	{
		get
		{
			return VRCTrackingManager.get_field_Private_Static_VRCTrackingManager_0();
		}
	}

	public static VRCUiCursorManager VRCUiCursorManager
	{
		get
		{
			return VRCUiCursorManager.get_field_Private_Static_VRCUiCursorManager_0();
		}
	}

	public static VRCUiManager VRCUiManager
	{
		get
		{
			return VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0();
		}
	}

	public static VRCUiPopupManager VRCUiPopupManager
	{
		get
		{
			return VRCUiPopupManager.get_field_Private_Static_VRCUiPopupManager_0();
		}
	}

	public static VRCVrCamera VRCVrCamera
	{
		get
		{
			return VRCVrCamera.get_field_Private_Static_VRCVrCamera_0();
		}
	}

	public static VRCWebSocketsManager VRCWebSocketsManager
	{
		get
		{
			return VRCWebSocketsManager.get_field_Private_Static_VRCWebSocketsManager_0();
		}
	}

	internal static Utils FyMJBVfqJX2aGbOR87T()
	{
		return Utils.CM1BZbfekBOi0yHwqvp;
	}

	public static Vector3 GetLocalCameraPosition()
	{
		Vector3 _localPosition;
		VRCVrCamera vRCVrCamera = Utils.VRCVrCamera;
		Il2CppSystem.Type il2CppType = vRCVrCamera.GetIl2CppType();
		if (il2CppType == Il2CppType.Of<VRCVrCamera>())
		{
			_localPosition = vRCVrCamera.get_transform().get_localPosition();
		}
		else if (il2CppType == Il2CppType.Of<VRCVrCameraSteam>())
		{
			VRCVrCameraSteam vRCVrCameraSteam = vRCVrCamera.Cast<VRCVrCameraSteam>();
			Transform fieldPrivateTransform0 = vRCVrCameraSteam.get_field_Private_Transform_0();
			Transform fieldPrivateTransform1 = vRCVrCameraSteam.get_field_Private_Transform_1();
			if (fieldPrivateTransform0.get_name() == "Camera (eye)")
			{
				_localPosition = vRCVrCamera.get_transform().get_parent().InverseTransformPoint(fieldPrivateTransform0.get_position());
			}
			else
			{
				_localPosition = (fieldPrivateTransform1.get_name() == "Camera (eye)" ? vRCVrCamera.get_transform().get_parent().InverseTransformPoint(fieldPrivateTransform1.get_position()) : Vector3.get_zero());
			}
		}
		else if (il2CppType != Il2CppType.Of<VRCVrCameraUnity>())
		{
			if (il2CppType != Il2CppType.Of<VRCVrCameraWave>())
			{
				_localPosition = Vector3.get_zero();
			}
			else
			{
				VRCVrCameraWave vRCVrCameraWave = vRCVrCamera.Cast<VRCVrCameraWave>();
				_localPosition = vRCVrCameraWave.get_field_Public_Transform_0().InverseTransformPoint(vRCVrCamera.get_transform().get_position());
			}
		}
		else if (MiskExtension.IsInVR())
		{
			_localPosition = vRCVrCamera.get_transform().get_localPosition() + InputTracking.GetLocalPosition(2);
		}
		else
		{
			VRCVrCameraUnity vRCVrCameraUnity = vRCVrCamera.Cast<VRCVrCameraUnity>();
			_localPosition = vRCVrCamera.get_transform().get_parent().InverseTransformPoint(vRCVrCameraUnity.get_field_Public_Camera_0().get_transform().get_position());
		}
		return _localPosition;
	}

	public static Vector3 GetWorldCameraPosition()
	{
		VRCVrCameraUnity vRCVrCameraUnity;
		Vector3 _position;
		VRCVrCamera vRCVrCamera = Utils.VRCVrCamera;
		Il2CppSystem.Type il2CppType = vRCVrCamera.GetIl2CppType();
		if (il2CppType == Il2CppType.Of<VRCVrCameraSteam>())
		{
			VRCVrCameraSteam vRCVrCameraSteam = vRCVrCamera.Cast<VRCVrCameraSteam>();
			Transform fieldPrivateTransform0 = vRCVrCameraSteam.get_field_Private_Transform_0();
			Transform fieldPrivateTransform1 = vRCVrCameraSteam.get_field_Private_Transform_1();
			if (fieldPrivateTransform0.get_name() != "Camera (eye)")
			{
				if (fieldPrivateTransform1.get_name() != "Camera (eye)")
				{
					if (il2CppType != Il2CppType.Of<VRCVrCameraUnity>())
					{
						_position = (il2CppType != Il2CppType.Of<VRCVrCameraWave>() ? vRCVrCamera.get_transform().get_parent().TransformPoint(Utils.GetLocalCameraPosition()) : vRCVrCamera.Cast<VRCVrCameraWave>().get_transform().get_position());
					}
					else
					{
						vRCVrCameraUnity = vRCVrCamera.Cast<VRCVrCameraUnity>();
						_position = vRCVrCameraUnity.get_field_Public_Camera_0().get_transform().get_position();
					}
					return _position;
				}
				_position = fieldPrivateTransform1.get_position();
				return _position;
			}
			else
			{
				_position = fieldPrivateTransform0.get_position();
				return _position;
			}
		}
		if (il2CppType != Il2CppType.Of<VRCVrCameraUnity>())
		{
			_position = (il2CppType != Il2CppType.Of<VRCVrCameraWave>() ? vRCVrCamera.get_transform().get_parent().TransformPoint(Utils.GetLocalCameraPosition()) : vRCVrCamera.Cast<VRCVrCameraWave>().get_transform().get_position());
		}
		else
		{
			vRCVrCameraUnity = vRCVrCamera.Cast<VRCVrCameraUnity>();
			_position = vRCVrCameraUnity.get_field_Public_Camera_0().get_transform().get_position();
		}
		return _position;
	}

	internal static bool IxgwyAfC4N3wZgnYiIx()
	{
		return Utils.CM1BZbfekBOi0yHwqvp == null;
	}
}