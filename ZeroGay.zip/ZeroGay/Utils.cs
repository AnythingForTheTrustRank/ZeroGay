using Il2CppSystem;
using Photon.Realtime;
using System;
using UnhollowerBaseLib;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.XR;
using VRC;
using VRC.Management;
using VRC.SDKBase;
using VRC.UserCamera;

public static class Utils
{
	private static Utils mNS1Am54QN8Ziniy4yk;

	// 
	// Current member / type: ActionMenu Utils::ActionMenu()
	// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
	// 
	// Product version: 2019.1.118.0
	// Exception in: ActionMenu ActionMenu()
	// 
	// Object reference not set to an instance of an object.
	//    at Telerik.JustDecompiler.Languages.CSharp.CSharpWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\CSharp\CSharpWriter.cs:line 1680
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 615
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 858
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.Write(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 1276
	//    at ..WriteInternal(IMemberDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseLanguageWriter.cs:line 453
	// 
	// mailto: JustDecompilePublicFeedback@telerik.com


	public static UnityEngine.Camera Camera
	{
		get
		{
			return VRCVrCamera.get_field_Private_Static_VRCVrCamera_0().get_field_Public_Camera_0();
		}
	}

	// 
	// Current member / type: VRCPlayer Utils::CurrentUser()
	// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
	// 
	// Product version: 2019.1.118.0
	// Exception in: VRCPlayer CurrentUser()
	// 
	// Object reference not set to an instance of an object.
	//    at Telerik.JustDecompiler.Languages.CSharp.CSharpWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\CSharp\CSharpWriter.cs:line 1680
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 615
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 858
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.Write(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 1276
	//    at ..WriteInternal(IMemberDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseLanguageWriter.cs:line 453
	// 
	// mailto: JustDecompilePublicFeedback@telerik.com


	public static LoadBalancingClient LoadBalancingPeer
	{
		get
		{
			return MonoBehaviour1PrivateObInPrInBoInInInInUnique.get_field_Internal_Static_MonoBehaviour1PrivateObInPrInBoInInInInUnique_0().Method_Public_get_LoadBalancingClient_0();
		}
	}

	public static VRCPlayerApi LocalPlayer
	{
		get
		{
			return Networking.get_LocalPlayer();
		}
	}

	public static VRC.Management.ModerationManager ModerationManager
	{
		get
		{
			return VRC.Management.ModerationManager.Method_Public_Static_get_ModerationManager_PDM_0();
		}
	}

	public static NetworkManager NetworkManager
	{
		get
		{
			return NetworkManager.get_field_Internal_Static_NetworkManager_0();
		}
	}

	public static NotificationManager NotificationManager
	{
		get
		{
			return NotificationManager.get_field_Private_Static_NotificationManager_0();
		}
	}

	public static MonoBehaviour1PrivateObInPrInBoInInInInUnique PhotonHandler
	{
		get
		{
			return MonoBehaviour1PrivateObInPrInBoInInInInUnique.get_field_Internal_Static_MonoBehaviour1PrivateObInPrInBoInInInInUnique_0();
		}
	}

	// 
	// Current member / type: VRC.PlayerManager Utils::PlayerManager()
	// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
	// 
	// Product version: 2019.1.118.0
	// Exception in: VRC.PlayerManager PlayerManager()
	// 
	// Object reference not set to an instance of an object.
	//    at Telerik.JustDecompiler.Languages.CSharp.CSharpWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\CSharp\CSharpWriter.cs:line 1680
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 615
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 858
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.Write(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 1276
	//    at ..WriteInternal(IMemberDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseLanguageWriter.cs:line 453
	// 
	// mailto: JustDecompilePublicFeedback@telerik.com


	// 
	// Current member / type: QuickMenu Utils::QuickMenu()
	// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
	// 
	// Product version: 2019.1.118.0
	// Exception in: QuickMenu QuickMenu()
	// 
	// Object reference not set to an instance of an object.
	//    at Telerik.JustDecompiler.Languages.CSharp.CSharpWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\CSharp\CSharpWriter.cs:line 1680
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 615
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 858
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.Write(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 1276
	//    at ..WriteInternal(IMemberDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseLanguageWriter.cs:line 453
	// 
	// mailto: JustDecompilePublicFeedback@telerik.com


	public static QuickMenuContextualDisplay QuickMenuContextualDisplay
	{
		get
		{
			return QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0().get_field_Private_QuickMenuContextualDisplay_0();
		}
	}

	public static VRC.UserCamera.UserCameraController UserCameraController
	{
		get
		{
			return VRC.UserCamera.UserCameraController.get_field_Internal_Static_UserCameraController_0();
		}
	}

	public static UserInteractMenu UserInteractMenu
	{
		get
		{
			return Resources.FindObjectsOfTypeAll<UserInteractMenu>().get_Item(0);
		}
	}

	// 
	// Current member / type: VRCTrackingManager Utils::VRCTrackingManager()
	// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
	// 
	// Product version: 2019.1.118.0
	// Exception in: VRCTrackingManager VRCTrackingManager()
	// 
	// Object reference not set to an instance of an object.
	//    at Telerik.JustDecompiler.Languages.CSharp.CSharpWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\CSharp\CSharpWriter.cs:line 1680
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 615
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 858
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.Write(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 1276
	//    at ..WriteInternal(IMemberDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseLanguageWriter.cs:line 453
	// 
	// mailto: JustDecompilePublicFeedback@telerik.com


	public static VRCUiCursorManager VRCUiCursorManager
	{
		get
		{
			return VRCUiCursorManager.get_field_Private_Static_VRCUiCursorManager_0();
		}
	}

	public static VRCUiManager VRCUiManager
	{
		get
		{
			return VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0();
		}
	}

	public static VRCUiPopupManager VRCUiPopupManager
	{
		get
		{
			return VRCUiPopupManager.get_field_Private_Static_VRCUiPopupManager_0();
		}
	}

	// 
	// Current member / type: VRCVrCamera Utils::VRCVrCamera()
	// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
	// 
	// Product version: 2019.1.118.0
	// Exception in: VRCVrCamera VRCVrCamera()
	// 
	// Object reference not set to an instance of an object.
	//    at Telerik.JustDecompiler.Languages.CSharp.CSharpWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\CSharp\CSharpWriter.cs:line 1680
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(MethodDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 615
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 858
	//    at Telerik.JustDecompiler.Languages.BaseImperativeLanguageWriter.Write(PropertyDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseImperativeLanguageWriter.cs:line 1276
	//    at ..WriteInternal(IMemberDefinition ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Languages\BaseLanguageWriter.cs:line 453
	// 
	// mailto: JustDecompilePublicFeedback@telerik.com


	public static VRCWebSocketsManager VRCWebSocketsManager
	{
		get
		{
			return VRCWebSocketsManager.get_field_Private_Static_VRCWebSocketsManager_0();
		}
	}

	internal static bool aQ9Gk15IarWJuc3J1o9()
	{
		return Utils.mNS1Am54QN8Ziniy4yk == null;
	}

	public static Vector3 GetLocalCameraPosition()
	{
		Vector3 _localPosition;
		VRCVrCamera fieldPrivateStaticVRCVrCamera0 = VRCVrCamera.get_field_Private_Static_VRCVrCamera_0();
		Il2CppSystem.Type il2CppType = fieldPrivateStaticVRCVrCamera0.GetIl2CppType();
		if (il2CppType == Il2CppType.Of<VRCVrCamera>())
		{
			_localPosition = fieldPrivateStaticVRCVrCamera0.get_transform().get_localPosition();
		}
		else if (il2CppType == Il2CppType.Of<VRCVrCameraSteam>())
		{
			VRCVrCameraSteam vRCVrCameraSteam = fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraSteam>();
			Transform fieldPrivateTransform0 = vRCVrCameraSteam.get_field_Private_Transform_0();
			Transform fieldPrivateTransform1 = vRCVrCameraSteam.get_field_Private_Transform_1();
			if (fieldPrivateTransform0.get_name() != "Camera (eye)")
			{
				_localPosition = (fieldPrivateTransform1.get_name() != "Camera (eye)" ? Vector3.get_zero() : fieldPrivateStaticVRCVrCamera0.get_transform().get_parent().InverseTransformPoint(fieldPrivateTransform1.get_position()));
			}
			else
			{
				_localPosition = fieldPrivateStaticVRCVrCamera0.get_transform().get_parent().InverseTransformPoint(fieldPrivateTransform0.get_position());
			}
		}
		else if (il2CppType != Il2CppType.Of<VRCVrCameraUnity>())
		{
			if (il2CppType != Il2CppType.Of<VRCVrCameraWave>())
			{
				_localPosition = Vector3.get_zero();
			}
			else
			{
				VRCVrCameraWave vRCVrCameraWave = fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraWave>();
				_localPosition = vRCVrCameraWave.get_field_Public_Transform_0().InverseTransformPoint(fieldPrivateStaticVRCVrCamera0.get_transform().get_position());
			}
		}
		else if (!XRDevice.get_isPresent())
		{
			VRCVrCameraUnity vRCVrCameraUnity = fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraUnity>();
			_localPosition = fieldPrivateStaticVRCVrCamera0.get_transform().get_parent().InverseTransformPoint(vRCVrCameraUnity.get_field_Public_Camera_0().get_transform().get_position());
		}
		else
		{
			_localPosition = fieldPrivateStaticVRCVrCamera0.get_transform().get_localPosition() + InputTracking.GetLocalPosition(2);
		}
		return _localPosition;
	}

	public static Vector3 GetWorldCameraPosition()
	{
		Vector3 _position;
		VRCVrCameraUnity vRCVrCameraUnity;
		VRCVrCamera fieldPrivateStaticVRCVrCamera0 = VRCVrCamera.get_field_Private_Static_VRCVrCamera_0();
		Il2CppSystem.Type il2CppType = fieldPrivateStaticVRCVrCamera0.GetIl2CppType();
		if (il2CppType == Il2CppType.Of<VRCVrCameraSteam>())
		{
			VRCVrCameraSteam vRCVrCameraSteam = fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraSteam>();
			Transform fieldPrivateTransform0 = vRCVrCameraSteam.get_field_Private_Transform_0();
			Transform fieldPrivateTransform1 = vRCVrCameraSteam.get_field_Private_Transform_1();
			if (fieldPrivateTransform0.get_name() != "Camera (eye)")
			{
				if (fieldPrivateTransform1.get_name() != "Camera (eye)")
				{
					if (il2CppType != Il2CppType.Of<VRCVrCameraUnity>())
					{
						_position = (il2CppType == Il2CppType.Of<VRCVrCameraWave>() ? fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraWave>().get_transform().get_position() : fieldPrivateStaticVRCVrCamera0.get_transform().get_parent().TransformPoint(Utils.GetLocalCameraPosition()));
					}
					else
					{
						vRCVrCameraUnity = fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraUnity>();
						_position = vRCVrCameraUnity.get_field_Public_Camera_0().get_transform().get_position();
					}
					return _position;
				}
				_position = fieldPrivateTransform1.get_position();
				return _position;
			}
			else
			{
				_position = fieldPrivateTransform0.get_position();
				return _position;
			}
		}
		if (il2CppType != Il2CppType.Of<VRCVrCameraUnity>())
		{
			_position = (il2CppType == Il2CppType.Of<VRCVrCameraWave>() ? fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraWave>().get_transform().get_position() : fieldPrivateStaticVRCVrCamera0.get_transform().get_parent().TransformPoint(Utils.GetLocalCameraPosition()));
		}
		else
		{
			vRCVrCameraUnity = fieldPrivateStaticVRCVrCamera0.Cast<VRCVrCameraUnity>();
			_position = vRCVrCameraUnity.get_field_Public_Camera_0().get_transform().get_position();
		}
		return _position;
	}

	internal static Utils r8kk9m56myPsk7fNQn7()
	{
		return Utils.mNS1Am54QN8Ziniy4yk;
	}
}