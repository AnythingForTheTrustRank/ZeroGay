using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;

internal delegate bool OkWcBQL04nThhycgNsW(FieldInfo , FieldInfo );