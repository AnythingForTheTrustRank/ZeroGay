using HdsmvfAPYqEVFmIuQdn;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Security.Cryptography;
using System.Text;
using X7IetPATbOXxq4U7Vmy;

namespace AksgHVKH9UOXlBDvRpO
{
	internal class CjlfmMKhfV8QPfhHT9P
	{
		private static bool mB8l2ZXFsE;

		internal static Assembly Eb5lMUO6q9;

		private static uint[] WL4lavl9Ca;

		private static object a8IlCqllJ2;

		private static List<int> ObhlsibTAq;

		private static IntPtr tvJlKcJAbB;

		private static IntPtr KNRllJtoDY;

		private static int fHKldRlgf7;

		private static int lotl9iSya0;

		internal static CjlfmMKhfV8QPfhHT9P.kJWgKKlSXQLtJAVyusn xH4lxPF4HI;

		private static long XmGl8y7YaB;

		private static int B6SlEkQHqB;

		private static CjlfmMKhfV8QPfhHT9P.z30PFMArHrlH0YVAQCI GMslVihr2F;

		private static CjlfmMKhfV8QPfhHT9P.kQKds7A2ZyqXVZybpH6 TDIlLpkKMQ;

		private static CjlfmMKhfV8QPfhHT9P.sGFOoXAMnDOAFmMh6sH Ep8l1DkQ8k;

		private static bool cd1lTpnnXl;

		private static List<string> VNBlH9YxPU;

		private static CjlfmMKhfV8QPfhHT9P.dkK5JvAYMDy85GPpRmV omflX7ZMGY;

		private static bool qWplpx4ay0;

		private static int nYZlqufjyA;

		private static CjlfmMKhfV8QPfhHT9P.Uq0RLsABxv4SMGPHpMU o5hlZsbD6r;

		private static byte[] Sf0ltW6WYl;

		private static bool jHPlylWfPy;

		private static IntPtr E1nlUQf3xL;

		private static byte[] dNZlRWJQpt;

		internal static RSACryptoServiceProvider MjIl7I9Wy3;

		private static int tXBlW7S2t4;

		private static object yJElACaMcG;

		private static bool K1SlvH9VIB;

		private static string o1rlkSV0qP;

		private static bool xsjlwEk4RL;

		private static IntPtr YIYl3uCXSJ;

		internal static Hashtable C9oludyukx;

		internal static CjlfmMKhfV8QPfhHT9P.kJWgKKlSXQLtJAVyusn OCClJ82kFK;

		private static CjlfmMKhfV8QPfhHT9P.rVPPBfA61nUWeptpw0l rumlFZY5vW;

		[TWrZi8lmjMs1KBJQIS0(typeof(CjlfmMKhfV8QPfhHT9P.TWrZi8lmjMs1KBJQIS0.l2xYEylDMw0lLCtMQku<object>[]))]
		private static bool oF3lPQDxld;

		private static Dictionary<int, int> jR6leFrYAB;

		private static long kFol0Q3X60;

		private static int[] fRVlGtvVYb;

		private static object oU8lhMtdwU;

		private static SortedList aY8li3VF86;

		static CjlfmMKhfV8QPfhHT9P()
		{
		}

		internal CjlfmMKhfV8QPfhHT9P()
		{
		}

		internal static bool AYSkk0JYXO3KssqjDPZ()
		{
			return null == null;
		}

		private static byte[] bwdKjjE9oM(object object_0)
		{
			byte[] numArray;
			using (FileStream fileStream = new FileStream(object_0, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				int num = 0;
				int length = (int)fileStream.Length;
				numArray = new byte[length];
				while (length > 0)
				{
					int num1 = fileStream.Read(numArray, num, length);
					num += num1;
					length -= num1;
				}
			}
			return numArray;
		}

		internal static bool CBFl5bsmbD(object object_0, object object_1)
		{
			if (object_0 == object_1)
			{
				return true;
			}
			if (object_0 == null || object_1 == null)
			{
				return false;
			}
			bool flag = false;
			bool flag1 = false;
			int chars = 0;
			int num = 0;
			if (object_0.StartsWith(CjlfmMKhfV8QPfhHT9P.o1rlkSV0qP))
			{
				flag = true;
				chars = object_0[4] | (char)(object_0[5] << '\b') | object_0[6] << '\u0010' | object_0[7] << '\u0018';
			}
			if (object_1.StartsWith(CjlfmMKhfV8QPfhHT9P.o1rlkSV0qP))
			{
				flag1 = true;
				num = object_1[4] | (char)(object_1[5] << '\b') | object_1[6] << '\u0010' | object_1[7] << '\u0018';
			}
			if (!flag && !flag1)
			{
				return false;
			}
			if (!flag)
			{
				chars = CjlfmMKhfV8QPfhHT9P.ueXKzs9IDm(object_0);
			}
			if (!flag1)
			{
				num = CjlfmMKhfV8QPfhHT9P.ueXKzs9IDm(object_1);
			}
			return chars == num;
		}

		private byte[] DIHlnXlCh2()
		{
			return null;
		}

		private byte[] e3SlOrm8xw()
		{
			int length = "{11111-22222-20001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		private static uint Ev9KpI0ZdI(uint uint_0)
		{
			return (uint)"{11111-22222-10009-11112}".Length;
		}

		private void FbOKds9gIb(byte[] byte_0, byte[] byte_1, byte[] byte_2)
		{
			int length = (int)byte_2.Length % 4;
			int num = (int)byte_2.Length / 4;
			byte[] numArray = new byte[(int)byte_2.Length];
			int length1 = (int)byte_0.Length / 4;
			uint num1 = 0;
			uint byte0 = 0;
			uint byte2 = 0;
			if (length > 0)
			{
				num++;
			}
			uint num2 = 0;
			for (int i = 0; i < num; i++)
			{
				int num3 = i % length1;
				int num4 = i * 4;
				num2 = (uint)(num3 * 4);
				byte0 = (uint)(byte_0[num2 + 3] << 24 | byte_0[num2 + 2] << 16 | byte_0[num2 + 1] << 8 | byte_0[num2]);
				uint num5 = 255;
				int num6 = 0;
				if (i != num - 1 || length <= 0)
				{
					num1 += byte0;
					num2 = (uint)num4;
					byte2 = (uint)(byte_2[num2 + 3] << 24 | byte_2[num2 + 2] << 16 | byte_2[num2 + 1] << 8 | byte_2[num2]);
				}
				else
				{
					byte2 = 0;
					num1 += byte0;
					for (int j = 0; j < length; j++)
					{
						if (j > 0)
						{
							byte2 <<= 8;
						}
						byte2 |= byte_2[(int)byte_2.Length - (1 + j)];
					}
				}
				uint num7 = num1;
				num1 = 0;
				uint num8 = num7;
				num8 = num8 ^ num8 << 10;
				num8 += 2105314805;
				num8 = num8 ^ num8 >> 9;
				num8 += -574245095;
				num8 = num8 ^ num8 << 21;
				num8 += 810515191;
				num8 = 1845683818 - num8;
				num1 = num7 + (uint)((double)((float)num8));
				if (i != num - 1 || length <= 0)
				{
					uint num9 = num1 ^ byte2;
					numArray[num4] = (byte)(num9 & 255);
					numArray[num4 + 1] = (byte)((num9 & 65280) >> 8);
					numArray[num4 + 2] = (byte)((num9 & 16711680) >> 16);
					numArray[num4 + 3] = (byte)((num9 & -16777216) >> 24);
				}
				else
				{
					uint num10 = num1 ^ byte2;
					for (int k = 0; k < length; k++)
					{
						if (k > 0)
						{
							num5 <<= 8;
							num6 += 8;
						}
						numArray[num4 + k] = (byte)((num10 & num5) >> (num6 & 31));
					}
				}
			}
			CjlfmMKhfV8QPfhHT9P.dNZlRWJQpt = numArray;
		}

		internal static SymmetricAlgorithm fIMKvk45TS()
		{
			SymmetricAlgorithm rijndaelManaged = null;
			if (!CjlfmMKhfV8QPfhHT9P.mBIKGoAbVk())
			{
				try
				{
					rijndaelManaged = new RijndaelManaged();
				}
				catch
				{
					rijndaelManaged = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
				}
			}
			else
			{
				rijndaelManaged = new AesCryptoServiceProvider();
			}
			return rijndaelManaged;
		}

		internal static byte[] fjCKbRUrVF(object object_0)
		{
			return ((MemoryStream)object_0).ToArray();
		}

		[DllImport("kernel32", CharSet=CharSet.Ansi, ExactSpelling=false)]
		public static extern IntPtr GetProcAddress(IntPtr intptr_0, string string_0);

		private static Delegate gGmKVO5u9p(IntPtr intptr_0, Type type_0)
		{
			return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[] { typeof(IntPtr), typeof(Type) }).Invoke(null, new object[] { intptr_0, type_0 });
		}

		private static IntPtr gKOKgAHWG7(uint uint_0, int int_0, uint uint_1)
		{
			if (CjlfmMKhfV8QPfhHT9P.TDIlLpkKMQ == null)
			{
				CjlfmMKhfV8QPfhHT9P.TDIlLpkKMQ = (CjlfmMKhfV8QPfhHT9P.kQKds7A2ZyqXVZybpH6)Marshal.GetDelegateForFunctionPointer(CjlfmMKhfV8QPfhHT9P.GetProcAddress(CjlfmMKhfV8QPfhHT9P.tmL0uXbJ0(), string.Concat("Open ".Trim(), "Process")), typeof(CjlfmMKhfV8QPfhHT9P.kQKds7A2ZyqXVZybpH6));
			}
			return CjlfmMKhfV8QPfhHT9P.TDIlLpkKMQ(uint_0, int_0, uint_1);
		}

		internal static string Gn2Ku4HnbT(int int_0)
		{
			return null;
		}

		private static void GU9KP2fXaN(object object_0, int int_0)
		{
			object[] object0 = new object[] { object_0, int_0 };
			jyRxpEAUNlcH3bE07bK.mnqAZ13Fvp(0, object0, null);
		}

		private static byte[] gVMKNtdr9G(object object_0)
		{
			Stream memoryStream = new MemoryStream();
			SymmetricAlgorithm symmetricAlgorithm = CjlfmMKhfV8QPfhHT9P.fIMKvk45TS();
			symmetricAlgorithm.Key = new byte[] { 140, 100, 79, 82, 91, 81, 217, 109, 25, 72, 64, 173, 40, 122, 192, 142, 25, 14, 226, 27, 112, 241, 196, 93, 238, 177, 229, 64, 64, 189, 13, 219 };
			symmetricAlgorithm.IV = new byte[] { 162, 69, 38, 147, 62, 127, 70, 212, 36, 62, 68, 10, 107, 7, 7, 194 };
			CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
			cryptoStream.Write(object_0, 0, (int)object_0.Length);
			cryptoStream.Close();
			return CjlfmMKhfV8QPfhHT9P.fjCKbRUrVF(memoryStream);
		}

		private static int HZoK4kxswZ(IntPtr intptr_0)
		{
			if (CjlfmMKhfV8QPfhHT9P.Ep8l1DkQ8k == null)
			{
				CjlfmMKhfV8QPfhHT9P.Ep8l1DkQ8k = (CjlfmMKhfV8QPfhHT9P.sGFOoXAMnDOAFmMh6sH)Marshal.GetDelegateForFunctionPointer(CjlfmMKhfV8QPfhHT9P.GetProcAddress(CjlfmMKhfV8QPfhHT9P.tmL0uXbJ0(), string.Concat("Close ".Trim(), "Handle")), typeof(CjlfmMKhfV8QPfhHT9P.sGFOoXAMnDOAFmMh6sH));
			}
			return CjlfmMKhfV8QPfhHT9P.Ep8l1DkQ8k(intptr_0);
		}

		internal static void iNEK8wAYZR()
		{
		}

		internal static void iw7KicUtg4()
		{
			try
			{
				CjlfmMKhfV8QPfhHT9P.cd1lTpnnXl = CryptoConfig.AllowOnlyFipsAlgorithms;
			}
			catch
			{
			}
		}

		private static IntPtr IyfKfeVEoT(IntPtr intptr_0, uint uint_0, uint uint_1, uint uint_2)
		{
			if (CjlfmMKhfV8QPfhHT9P.omflX7ZMGY == null)
			{
				CjlfmMKhfV8QPfhHT9P.omflX7ZMGY = (CjlfmMKhfV8QPfhHT9P.dkK5JvAYMDy85GPpRmV)Marshal.GetDelegateForFunctionPointer(CjlfmMKhfV8QPfhHT9P.GetProcAddress(CjlfmMKhfV8QPfhHT9P.tmL0uXbJ0(), string.Concat("Virtual ".Trim(), "Alloc")), typeof(CjlfmMKhfV8QPfhHT9P.dkK5JvAYMDy85GPpRmV));
			}
			return CjlfmMKhfV8QPfhHT9P.omflX7ZMGY(intptr_0, uint_0, uint_1, uint_2);
		}

		internal static void jcfK0jnJ1D(object object_0, object object_1, uint uint_0, object object_2)
		{
			while (uint_0 > 0)
			{
				int num = (uint_0 > (int)object_2.Length ? (int)object_2.Length : (int)uint_0);
				object_1.Read(object_2, 0, num);
				CjlfmMKhfV8QPfhHT9P.r52Kx6aVmv(object_0, object_2, 0, num);
				uint_0 -= num;
			}
		}

		private static int jmSKmNgxVc(IntPtr intptr_0, IntPtr intptr_1, [In][Out] byte[] byte_0, uint uint_0, out IntPtr intptr_2)
		{
			if (CjlfmMKhfV8QPfhHT9P.o5hlZsbD6r == null)
			{
				CjlfmMKhfV8QPfhHT9P.o5hlZsbD6r = (CjlfmMKhfV8QPfhHT9P.Uq0RLsABxv4SMGPHpMU)Marshal.GetDelegateForFunctionPointer(CjlfmMKhfV8QPfhHT9P.GetProcAddress(CjlfmMKhfV8QPfhHT9P.tmL0uXbJ0(), string.Concat("Write ".Trim(), "Process ".Trim(), "Memory")), typeof(CjlfmMKhfV8QPfhHT9P.Uq0RLsABxv4SMGPHpMU));
			}
			return CjlfmMKhfV8QPfhHT9P.o5hlZsbD6r(intptr_0, intptr_1, byte_0, uint_0, out intptr_2);
		}

		private static void kS5KRyqCvo(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, object object_0)
		{
			// 
			// Current member / type: System.Void AksgHVKH9UOXlBDvRpO.CjlfmMKhfV8QPfhHT9P::kS5KRyqCvo(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void kS5KRyqCvo(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		[DllImport("kernel32", CharSet=CharSet.None, ExactSpelling=false)]
		public static extern IntPtr LoadLibrary(string string_0);

		internal static byte[] lq2KsLqgYB(object object_0)
		{
			// 
			// Current member / type: System.Byte[] AksgHVKH9UOXlBDvRpO.CjlfmMKhfV8QPfhHT9P::lq2KsLqgYB(System.Object)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Byte[] lq2KsLqgYB(System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static bool mBIKGoAbVk()
		{
			if (!CjlfmMKhfV8QPfhHT9P.jHPlylWfPy)
			{
				CjlfmMKhfV8QPfhHT9P.iw7KicUtg4();
				CjlfmMKhfV8QPfhHT9P.jHPlylWfPy = true;
			}
			return CjlfmMKhfV8QPfhHT9P.cd1lTpnnXl;
		}

		private static void mKVKKHyijR(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, object object_0)
		{
			// 
			// Current member / type: System.Void AksgHVKH9UOXlBDvRpO.CjlfmMKhfV8QPfhHT9P::mKVKKHyijR(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void mKVKKHyijR(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal byte[] NBXlYIAXPK()
		{
			int length = "{11111-22222-40001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		private byte[] Nh3lc9xrYH()
		{
			return null;
		}

		private static void nRBKttsvNE(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, object object_0)
		{
			// 
			// Current member / type: System.Void AksgHVKH9UOXlBDvRpO.CjlfmMKhfV8QPfhHT9P::nRBKttsvNE(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void nRBKttsvNE(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal byte[] o1rl6dvyt9()
		{
			int length = "{11111-22222-40001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		private static void oaqKlK1QYG(ref uint uint_0, uint uint_1, uint uint_2, uint uint_3, uint uint_4, ushort ushort_0, uint uint_5, object object_0)
		{
			// 
			// Current member / type: System.Void AksgHVKH9UOXlBDvRpO.CjlfmMKhfV8QPfhHT9P::oaqKlK1QYG(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void oaqKlK1QYG(System.UInt32&,System.UInt32,System.UInt32,System.UInt32,System.UInt32,System.UInt16,System.UInt32,System.Object)
			// 
			// Specified argument was out of the range of valid values.
			// Parameter name: Target of array indexer expression is not an array.
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Ast\Expressions\ArrayIndexerExpression.cs:line 129
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 143
			//    at Telerik.JustDecompiler.Decompiler.ExpressionDecompilerStep.(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\ExpressionDecompilerStep.cs:line 73
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal byte[] OVQlrmrwJK()
		{
			int length = "{11111-22222-50001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		internal static void r52Kx6aVmv(object object_0, object object_1, int int_0, int int_1)
		{
			object_0.TransformBlock(object_1, int_0, int_1, object_1, int_0);
		}

		private static int rgJKD5uEyY(IntPtr intptr_0, int int_0, int int_1, ref int int_2)
		{
			if (CjlfmMKhfV8QPfhHT9P.GMslVihr2F == null)
			{
				CjlfmMKhfV8QPfhHT9P.GMslVihr2F = (CjlfmMKhfV8QPfhHT9P.z30PFMArHrlH0YVAQCI)Marshal.GetDelegateForFunctionPointer(CjlfmMKhfV8QPfhHT9P.GetProcAddress(CjlfmMKhfV8QPfhHT9P.tmL0uXbJ0(), string.Concat("Virtual ".Trim(), "Protect")), typeof(CjlfmMKhfV8QPfhHT9P.z30PFMArHrlH0YVAQCI));
			}
			return CjlfmMKhfV8QPfhHT9P.GMslVihr2F(intptr_0, int_0, int_1, ref int_2);
		}

		private byte[] soWlocoT3y()
		{
			int length = "{11111-22222-30001-00002}".Length;
			return new byte[] { 1, 2 };
		}

		private byte[] suRlIpP1mx()
		{
			int length = "{11111-22222-30001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		internal static string sYvKFaPEBJ(object object_0)
		{
			"{11111-22222-50001-00000}".Trim();
			byte[] numArray = Convert.FromBase64String(object_0);
			return Encoding.Unicode.GetString(numArray, 0, (int)numArray.Length);
		}

		private void SZucn0TvUkH()
		{
		}

		private byte[] TBKlQKo4Zk()
		{
			int length = "{11111-22222-20001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		private static IntPtr tmL0uXbJ0()
		{
			if (CjlfmMKhfV8QPfhHT9P.YIYl3uCXSJ == IntPtr.Zero)
			{
				CjlfmMKhfV8QPfhHT9P.YIYl3uCXSJ = CjlfmMKhfV8QPfhHT9P.LoadLibrary(string.Concat("kernel ".Trim(), "32.dll"));
			}
			return CjlfmMKhfV8QPfhHT9P.YIYl3uCXSJ;
		}

		private static unsafe int ueXKzs9IDm(object object_0)
		{
			fixed (string object0 = object_0)
			{
				char* offsetToStringData = (char*)(&object0);
				if (offsetToStringData != null)
				{
					offsetToStringData += RuntimeHelpers.OffsetToStringData;
				}
				int num = 5381;
				int num1 = 5381;
				char* chrPointer = offsetToStringData;
				while (true)
				{
					ushort num2 = (ushort)(*chrPointer);
					int num3 = (int)num2;
					if (num2 == 0)
					{
						break;
					}
					num = (num << 5) + num ^ num3;
					num3 = (ushort)(*(chrPointer + 2));
					if (num3 == 0)
					{
						break;
					}
					num1 = (num1 << 5) + num1 ^ num3;
					chrPointer = chrPointer + 2 * 2;
				}
				return num + num1 * 1566083941;
			}
		}

		public static void UM6KEiW1XD(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			try
			{
				Type typeFromHandle = Type.GetTypeFromHandle(runtimeTypeHandle_0);
				if (CjlfmMKhfV8QPfhHT9P.jR6leFrYAB == null)
				{
					lock (CjlfmMKhfV8QPfhHT9P.a8IlCqllJ2)
					{
						Dictionary<int, int> nums = new Dictionary<int, int>();
						BinaryReader binaryReader = new BinaryReader(typeof(CjlfmMKhfV8QPfhHT9P).Assembly.GetManifestResourceStream("e2OaaZ2LGnKV6i2ibH.aTIxPBMFPXMVx1PwZA"));
						binaryReader.BaseStream.Position = 0L;
						byte[] numArray = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
						binaryReader.Close();
						if (numArray.Length != 0)
						{
							int length = (int)numArray.Length % 4;
							int num = (int)numArray.Length / 4;
							byte[] numArray1 = new byte[(int)numArray.Length];
							uint num1 = 0;
							uint num2 = 0;
							if (length > 0)
							{
								num++;
							}
							uint num3 = 0;
							for (int i = 0; i < num; i++)
							{
								int num4 = i * 4;
								uint num5 = 255;
								int num6 = 0;
								if (i != num - 1 || length <= 0)
								{
									num3 = (uint)num4;
									num2 = (uint)(numArray[num3 + 3] << 24 | numArray[num3 + 2] << 16 | numArray[num3 + 1] << 8 | numArray[num3]);
								}
								else
								{
									num2 = 0;
									for (int j = 0; j < length; j++)
									{
										if (j > 0)
										{
											num2 <<= 8;
										}
										num2 |= numArray[(int)numArray.Length - (1 + j)];
									}
								}
								num1 = num1;
								uint num7 = num1;
								num7 = num7 ^ num7 << 10;
								num7 += 2105314805;
								num7 = num7 ^ num7 >> 9;
								num7 += -574245095;
								num7 = num7 ^ num7 << 21;
								num7 += 810515191;
								num7 = 1845683818 - num7;
								num1 += (uint)((double)((float)num7));
								if (i != num - 1 || length <= 0)
								{
									uint num8 = num1 ^ num2;
									numArray1[num4] = (byte)(num8 & 255);
									numArray1[num4 + 1] = (byte)((num8 & 65280) >> 8);
									numArray1[num4 + 2] = (byte)((num8 & 16711680) >> 16);
									numArray1[num4 + 3] = (byte)((num8 & -16777216) >> 24);
								}
								else
								{
									uint num9 = num1 ^ num2;
									for (int k = 0; k < length; k++)
									{
										if (k > 0)
										{
											num5 <<= 8;
											num6 += 8;
										}
										numArray1[num4 + k] = (byte)((num9 & num5) >> (num6 & 31));
									}
								}
							}
							numArray = numArray1;
							numArray1 = null;
							int length1 = (int)numArray.Length / 8;
							CjlfmMKhfV8QPfhHT9P.R9O6eZAcj1JgwB1Jjrm r9O6eZAcj1JgwB1Jjrm = new CjlfmMKhfV8QPfhHT9P.R9O6eZAcj1JgwB1Jjrm(new MemoryStream(numArray));
							for (int l = 0; l < length1; l++)
							{
								nums.Add(r9O6eZAcj1JgwB1Jjrm.ogTAO4aNRR(), r9O6eZAcj1JgwB1Jjrm.ogTAO4aNRR());
							}
							r9O6eZAcj1JgwB1Jjrm.TmZAI2h7e6();
						}
						CjlfmMKhfV8QPfhHT9P.jR6leFrYAB = nums;
					}
				}
				FieldInfo[] fields = typeFromHandle.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetField);
				for (int m = 0; m < (int)fields.Length; m++)
				{
					try
					{
						FieldInfo fieldInfo = fields[m];
						int metadataToken = fieldInfo.MetadataToken;
						int item = CjlfmMKhfV8QPfhHT9P.jR6leFrYAB[metadataToken];
						bool flag = (item & 1073741824) > 0;
						item &= 1073741823;
						MethodInfo methodInfo = (MethodInfo)typeof(CjlfmMKhfV8QPfhHT9P).Module.ResolveMethod(item, typeFromHandle.GetGenericArguments(), new Type[0]);
						if (!methodInfo.IsStatic)
						{
							ParameterInfo[] parameters = methodInfo.GetParameters();
							int length2 = (int)parameters.Length + 1;
							Type[] parameterType = new Type[length2];
							if (!methodInfo.DeclaringType.IsValueType)
							{
								parameterType[0] = typeof(object);
							}
							else
							{
								parameterType[0] = methodInfo.DeclaringType.MakeByRefType();
							}
							for (int n = 0; n < (int)parameters.Length; n++)
							{
								parameterType[n + 1] = parameters[n].ParameterType;
							}
							DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, methodInfo.ReturnType, parameterType, typeFromHandle, true);
							ILGenerator lGenerator = dynamicMethod.GetILGenerator();
							for (int o = 0; o < length2; o++)
							{
								switch (o)
								{
									case 0:
									{
										lGenerator.Emit(OpCodes.Ldarg_0);
										break;
									}
									case 1:
									{
										lGenerator.Emit(OpCodes.Ldarg_1);
										break;
									}
									case 2:
									{
										lGenerator.Emit(OpCodes.Ldarg_2);
										break;
									}
									case 3:
									{
										lGenerator.Emit(OpCodes.Ldarg_3);
										break;
									}
									default:
									{
										lGenerator.Emit(OpCodes.Ldarg_S, o);
										break;
									}
								}
							}
							lGenerator.Emit(OpCodes.Tailcall);
							lGenerator.Emit((flag ? OpCodes.Callvirt : OpCodes.Call), methodInfo);
							lGenerator.Emit(OpCodes.Ret);
							fieldInfo.SetValue(null, dynamicMethod.CreateDelegate(typeFromHandle));
						}
						else
						{
							fieldInfo.SetValue(null, Delegate.CreateDelegate(fieldInfo.FieldType, methodInfo));
						}
					}
					catch
					{
					}
				}
			}
			catch (Exception exception)
			{
			}
		}

		private static int VwLKXRDKZS()
		{
			return 5;
		}

		private static uint w4CKAY1rJp(uint uint_0, ushort ushort_0)
		{
			return uint_0 >> (32 - ushort_0 & 31) | uint_0 << (ushort_0 & 31);
		}

		internal static void WQRKUO5a9D()
		{
		}

		internal static object xAWKLTqxSR(object object_0)
		{
			object location;
			try
			{
				if (File.Exists(((Assembly)object_0).Location))
				{
					location = ((Assembly)object_0).Location;
					return location;
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(((Assembly)object_0).GetName().CodeBase.ToString().Replace("file:///", "")))
				{
					location = ((Assembly)object_0).GetName().CodeBase.ToString().Replace("file:///", "");
					return location;
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(object_0.GetType().GetProperty("Location").GetValue(object_0, new object[0]).ToString()))
				{
					location = object_0.GetType().GetProperty("Location").GetValue(object_0, new object[0]).ToString();
					return location;
				}
			}
			catch
			{
			}
			return "";
		}

		internal static uint xFaKJw02WC(uint uint_0, int int_0, long long_0, object object_0)
		{
			for (int i = 0; i < int_0; i++)
			{
				object_0.BaseStream.Position = long_0 + (long)(i * 40 + 8);
				uint num = object_0.ReadUInt32();
				uint num1 = object_0.ReadUInt32();
				object_0.ReadUInt32();
				uint num2 = object_0.ReadUInt32();
				if (num1 <= uint_0 && uint_0 < num1 + num)
				{
					return num2 + uint_0 - num1;
				}
			}
			return (uint)0;
		}

		private static void XI5KZRvRwX()
		{
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		internal static object XsVpWnJBUeCvuSygZ5r()
		{
			return null;
		}

		internal byte[] YFhlBABOGL()
		{
			int length = "{11111-22222-50001-00001}".Length;
			return new byte[] { 1, 2 };
		}

		internal static byte[] z1wK9cHu6s(object object_0)
		{
			if (CjlfmMKhfV8QPfhHT9P.mBIKGoAbVk())
			{
				return CjlfmMKhfV8QPfhHT9P.lq2KsLqgYB(object_0);
			}
			return (new MD5CryptoServiceProvider()).ComputeHash(object_0);
		}

		private static IntPtr zeWKkJZIRa(IntPtr intptr_0, object object_0, uint uint_0)
		{
			if (CjlfmMKhfV8QPfhHT9P.rumlFZY5vW == null)
			{
				CjlfmMKhfV8QPfhHT9P.rumlFZY5vW = (CjlfmMKhfV8QPfhHT9P.rVPPBfA61nUWeptpw0l)Marshal.GetDelegateForFunctionPointer(CjlfmMKhfV8QPfhHT9P.GetProcAddress(CjlfmMKhfV8QPfhHT9P.tmL0uXbJ0(), string.Concat("Find ".Trim(), "ResourceA")), typeof(CjlfmMKhfV8QPfhHT9P.rVPPBfA61nUWeptpw0l));
			}
			return CjlfmMKhfV8QPfhHT9P.rumlFZY5vW(intptr_0, object_0, uint_0);
		}

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr CCkfIPlbRUIdZTtcmUG();

		[Flags]
		private enum cEd5LwAaDhv53pZ2cBn
		{

		}

		private delegate void cfNpcGlfJo5dtP4TZJR(object o);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr dkK5JvAYMDy85GPpRmV(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		internal delegate uint kJWgKKlSXQLtJAVyusn(IntPtr classthis, IntPtr comp, IntPtr info, uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr kQKds7A2ZyqXVZybpH6(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

		internal class R9O6eZAcj1JgwB1Jjrm
		{
			private BinaryReader GAOAo2HO3I;

			public R9O6eZAcj1JgwB1Jjrm(Stream stream_0)
			{
				this.GAOAo2HO3I = new BinaryReader(stream_0);
			}

			internal Stream bJfBUv9Xn2()
			{
				return this.GAOAo2HO3I.BaseStream;
			}

			internal int h2vAQgDCag(byte[] byte_0, int int_0, int int_1)
			{
				return this.GAOAo2HO3I.Read(byte_0, int_0, int_1);
			}

			internal byte[] K8nAnGe1gS(int int_0)
			{
				return this.GAOAo2HO3I.ReadBytes(int_0);
			}

			internal int ogTAO4aNRR()
			{
				return this.GAOAo2HO3I.ReadInt32();
			}

			internal void TmZAI2h7e6()
			{
				this.GAOAo2HO3I.Close();
			}
		}

		[UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet=CharSet.Ansi)]
		private delegate IntPtr rVPPBfA61nUWeptpw0l(IntPtr hModule, string lpName, uint lpType);

		internal class SdpkgEl4E4dgN2Gwpyl
		{
			public SdpkgEl4E4dgN2Gwpyl()
			{
			}

			internal static string XVwlj5fog9(object object_0, object object_1)
			{
				byte[] bytes = Encoding.Unicode.GetBytes(object_0);
				byte[] numArray = new byte[] { 82, 102, 104, 110, 32, 77, 24, 34, 118, 181, 51, 17, 18, 51, 12, 109, 10, 32, 77, 24, 34, 158, 161, 41, 97, 28, 118, 181, 5, 25, 1, 88 };
				byte[] numArray1 = CjlfmMKhfV8QPfhHT9P.z1wK9cHu6s(Encoding.Unicode.GetBytes(object_1));
				MemoryStream memoryStream = new MemoryStream();
				SymmetricAlgorithm symmetricAlgorithm = CjlfmMKhfV8QPfhHT9P.fIMKvk45TS();
				symmetricAlgorithm.Key = numArray;
				symmetricAlgorithm.IV = numArray1;
				CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
				cryptoStream.Write(bytes, 0, (int)bytes.Length);
				cryptoStream.Close();
				return Convert.ToBase64String(memoryStream.ToArray());
			}
		}

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int sGFOoXAMnDOAFmMh6sH(IntPtr ptr);

		internal class TWrZi8lmjMs1KBJQIS0 : Attribute
		{
			public TWrZi8lmjMs1KBJQIS0(object object_0)
			{
			}

			internal class l2xYEylDMw0lLCtMQku<OA6hp0lgPaJDPncmtZW>
			{
				internal static object R71mySc55DiiWjGgwdnT;

				public l2xYEylDMw0lLCtMQku()
				{
					CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
					ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
					base();
				}

				internal static object BKGySUc5n587XslpGE3d()
				{
					return CjlfmMKhfV8QPfhHT9P.TWrZi8lmjMs1KBJQIS0.l2xYEylDMw0lLCtMQku<OA6hp0lgPaJDPncmtZW>.R71mySc55DiiWjGgwdnT;
				}

				internal static bool NWOWNEc5cWhs6WQdi3p2()
				{
					return CjlfmMKhfV8QPfhHT9P.TWrZi8lmjMs1KBJQIS0.l2xYEylDMw0lLCtMQku<OA6hp0lgPaJDPncmtZW>.R71mySc55DiiWjGgwdnT == null;
				}
			}
		}

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int Uq0RLsABxv4SMGPHpMU(IntPtr hProcess, IntPtr lpBaseAddress, [In][Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

		internal struct Ye65PZlNeRhm3pD7gMc
		{
			internal bool GQjlzVgoDZ;

			internal byte[] nDdA5jq3W4;
		}

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int z30PFMArHrlH0YVAQCI(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);
	}
}