using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void waalgYV8qp6kgGRGY8K(object , string , bool );