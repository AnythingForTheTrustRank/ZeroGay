using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate MethodInfo GEM8QUUatrmb44tyXRD(object object_0, string string_0);