using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using System;
using UnhollowerRuntimeLib.XrefScans;

internal delegate Il2CppSystem.Object EMYF4r1pK8b8iKOB8BT(ref XrefInstance );