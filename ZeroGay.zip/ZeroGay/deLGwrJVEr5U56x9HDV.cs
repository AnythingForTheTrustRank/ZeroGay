using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool deLGwrJVEr5U56x9HDV(object object_0, string string_0);