using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;

internal delegate Dictionary<string, List<uint>> vkaSAhwfSly8GINsY9o(object object_0);