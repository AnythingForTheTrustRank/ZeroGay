using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCTrackingManager YdkqUyWnZVfZDoUrnNU();