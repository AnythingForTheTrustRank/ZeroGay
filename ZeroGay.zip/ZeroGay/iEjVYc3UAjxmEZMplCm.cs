using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object iEjVYc3UAjxmEZMplCm(object object_0, int int_0);