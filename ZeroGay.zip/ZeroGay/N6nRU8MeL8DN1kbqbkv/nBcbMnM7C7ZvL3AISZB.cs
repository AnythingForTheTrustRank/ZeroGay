using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnhollowerBaseLib;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;
using X7IetPATbOXxq4U7Vmy;

namespace N6nRU8MeL8DN1kbqbkv
{
	internal class nBcbMnM7C7ZvL3AISZB
	{
		public static bool swpMAHKQC3;

		public static bool hL9MGQegs4;

		public static bool ACfMd66ZV2;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup> gaiMvEOJYD;

		public static Il2CppSystem.Collections.Generic.List<VRCObjectSync> LshMiUYdtK;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger> xTRM9jZEpi;

		public static Il2CppSystem.Collections.Generic.List<VRC_ObjectSync> Dp2M0JKnh7;

		public static string C9cMxthOuG;

		public static bool VuoMJpSwDQ;

		public static bool MlFM893cOC;

		public static bool O7hME59iH3;

		public static bool TwGMw9fK9B;

		public static bool a4cMpigrMI;

		public static bool ImVMWTCSru;

		private static nBcbMnM7C7ZvL3AISZB EDAsYnmp7EtAdaI3iAW;

		static nBcbMnM7C7ZvL3AISZB()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			nBcbMnM7C7ZvL3AISZB.swpMAHKQC3 = false;
			nBcbMnM7C7ZvL3AISZB.hL9MGQegs4 = false;
			nBcbMnM7C7ZvL3AISZB.ACfMd66ZV2 = false;
			nBcbMnM7C7ZvL3AISZB.gaiMvEOJYD = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup>();
			nBcbMnM7C7ZvL3AISZB.LshMiUYdtK = new Il2CppSystem.Collections.Generic.List<VRCObjectSync>();
			nBcbMnM7C7ZvL3AISZB.xTRM9jZEpi = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger>();
			nBcbMnM7C7ZvL3AISZB.Dp2M0JKnh7 = new Il2CppSystem.Collections.Generic.List<VRC_ObjectSync>();
			nBcbMnM7C7ZvL3AISZB.C9cMxthOuG = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
			nBcbMnM7C7ZvL3AISZB.VuoMJpSwDQ = false;
			nBcbMnM7C7ZvL3AISZB.MlFM893cOC = false;
			nBcbMnM7C7ZvL3AISZB.O7hME59iH3 = false;
			nBcbMnM7C7ZvL3AISZB.TwGMw9fK9B = false;
			nBcbMnM7C7ZvL3AISZB.a4cMpigrMI = false;
			nBcbMnM7C7ZvL3AISZB.ImVMWTCSru = false;
		}

		public nBcbMnM7C7ZvL3AISZB()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static void Abort()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAbort");
			}
		}

		public static IEnumerator bhfMRdYJJO(bool bool_0)
		{
			return new nBcbMnM7C7ZvL3AISZB.<KillAuraAlarm>d__19(0)
			{
				state = bool_0
			};
		}

		public static void D4oMl6UaYy()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryB");
			}
		}

		public static IEnumerable<WaitForSeconds> He4MhXyEGY(bool bool_0)
		{
			return new nBcbMnM7C7ZvL3AISZB.<LoopTeleport>d__14(-2)
			{
				<>3__state = bool_0
			};
		}

		internal static nBcbMnM7C7ZvL3AISZB ieJlFYmUXHApiTsrydr()
		{
			return nBcbMnM7C7ZvL3AISZB.EDAsYnmp7EtAdaI3iAW;
		}

		internal static void j7VMqnENnf()
		{
			foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
			{
				vRCPickup.set_pickupable(true);
				vRCPickup.set_DisallowTheft(false);
				vRCPickup.set_proximity(99999f);
			}
		}

		internal static bool MQciQOmWSuuxo3xeHgo()
		{
			return nBcbMnM7C7ZvL3AISZB.EDAsYnmp7EtAdaI3iAW == null;
		}

		public static void PJ0MtptJAS()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OnLocalPlayerBlinded");
			}
		}

		public static void sJaMHiaIYY()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "KillLocalPlayer");
			}
		}

		public static void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_Start");
			}
		}

		internal static IEnumerator taqMsflFkQ()
		{
			bool flag;
			VRCPickup component = GameObject.Find("Game Logic").get_transform().Find("Weapons/Revolver").GetComponent<VRCPickup>();
			UdonBehaviour udonBehaviour = component.get_gameObject().GetComponent<UdonBehaviour>();
			while (nBcbMnM7C7ZvL3AISZB.a4cMpigrMI)
			{
				yield return new WaitForSeconds(0.3f);
				flag = (component.get_IsHeld() ? Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), component.get_gameObject()) : false);
				if (!flag)
				{
					continue;
				}
				udonBehaviour.SendCustomEvent("Fire");
			}
		}

		public static bool tqJMC7Q5WQ()
		{
			bool flag;
			flag = (RoomManager.Method_Internal_Static_get_String_0().Contains(nBcbMnM7C7ZvL3AISZB.C9cMxthOuG) ? true : false);
			return flag;
		}

		public static void X8pMKyNR1Y()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryM");
			}
		}
	}
}