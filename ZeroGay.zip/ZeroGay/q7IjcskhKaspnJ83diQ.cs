using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection.Emit;

internal delegate void q7IjcskhKaspnJ83diQ(object object_0, OpCode opCode_0);