using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Vector3 vRnsIwek1NMDOrYwrv4(Vector3 , float );