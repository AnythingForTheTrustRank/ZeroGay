using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate Type Ofd7BG0Jlaj0BcHEs5q(RuntimeTypeHandle );