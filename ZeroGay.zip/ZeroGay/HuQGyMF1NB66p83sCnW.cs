using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

internal delegate Task HuQGyMF1NB66p83sCnW(ref AsyncTaskMethodBuilder asyncTaskMethodBuilder_0);