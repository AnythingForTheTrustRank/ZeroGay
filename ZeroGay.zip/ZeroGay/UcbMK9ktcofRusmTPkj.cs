using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection.Emit;

internal delegate LocalBuilder UcbMK9ktcofRusmTPkj(object object_0, Type type_0);