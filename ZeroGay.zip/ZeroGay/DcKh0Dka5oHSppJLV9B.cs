using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool DcKh0Dka5oHSppJLV9B(double double_0);