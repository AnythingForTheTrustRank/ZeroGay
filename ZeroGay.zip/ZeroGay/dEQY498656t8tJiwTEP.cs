using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using VRC;

internal delegate List<Player> dEQY498656t8tJiwTEP(object object_0);