using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Quaternion hQ62GCUKsDSEeHRo08y(Quaternion quaternion_0, Quaternion quaternion_1, float float_0);