using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using System;

internal delegate bool Tyd3TNRwi1YKlFK5UQc(Il2CppSystem.Type , Il2CppSystem.Type );