using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;

internal delegate ParameterInfo[] usMToDpox3qWBWYYTAf(object );