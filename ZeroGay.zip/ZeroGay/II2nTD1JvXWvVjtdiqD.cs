using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void II2nTD1JvXWvVjtdiqD(object object_0, ref bool bool_0);