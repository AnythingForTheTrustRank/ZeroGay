using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int pZ2BarwO3REpIqNrOwm(object object_0, string string_0, StringComparison stringComparison_0);