using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection.Emit;

internal delegate void l2HGhOJtn4wbKlj1PaG(object , OpCode );