using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.UI;

internal delegate void rlWoy4FHNJZqyDnnMG7(ref ColorBlock colorBlock_0, float float_0);