using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate DateTime kHyFIRFnkKAspVxp1T1();