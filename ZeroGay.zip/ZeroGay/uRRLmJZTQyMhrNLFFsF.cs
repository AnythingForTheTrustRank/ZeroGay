using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void uRRLmJZTQyMhrNLFFsF(object object_0, ParticleSystemTrailTextureMode particleSystemTrailTextureMode_0);