using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.SDKBase;

internal delegate void Hb0gKGK5eL6gNfII5Gs(object , List<VRC_Interactable> );