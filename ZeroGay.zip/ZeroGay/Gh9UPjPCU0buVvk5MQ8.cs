using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Sprite Gh9UPjPCU0buVvk5MQ8(object object_0);