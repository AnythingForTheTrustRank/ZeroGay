using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.Wings
{
	public class WingToggle
	{
		private bool hMVT8RFbkn;

		private readonly Action<bool> X3vTENHjRy;

		public BaseWing wing;

		public WingButton button;

		public Color on;

		public Color off;

		private static WingToggle h2kFtcg4h7AKKsnLwoG;

		public bool State
		{
			get
			{
				return this.hMVT8RFbkn;
			}
			set
			{
				if (this.hMVT8RFbkn != value)
				{
					this.button.text.set_color((!value ? this.off : this.on));
					bool flag = value;
					bool flag1 = flag;
					this.hMVT8RFbkn = flag;
					this.X3vTENHjRy(flag1);
				}
			}
		}

		public WingToggle(BaseWing wing, string name, Transform parent, int pos, Color on, Color off, bool initial, Action<bool> onClick)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.wing = wing;
			this.on = on;
			this.off = off;
			this.X3vTENHjRy = onClick;
			this.button = new WingButton(wing, name, parent, pos, () => this.State = !this.State);
			this.button.text.set_color((initial ? on : off));
		}

		public WingToggle(WingPage page, string name, int index, Color on, Color off, bool initial, Action<bool> onClick)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.wing = page.wing;
			this.on = on;
			this.off = off;
			this.X3vTENHjRy = onClick;
			WingButton wingButton = new WingButton(page, name, index, () => this.State = !this.State);
			wingButton.text.set_color((initial ? on : off));
			this.button = wingButton;
		}

		internal static WingToggle mPfdlygS0rjEyqiTw0u()
		{
			return WingToggle.h2kFtcg4h7AKKsnLwoG;
		}

		internal static bool uP8IROgjpSBOtJP6OyP()
		{
			return WingToggle.h2kFtcg4h7AKKsnLwoG == null;
		}
	}
}