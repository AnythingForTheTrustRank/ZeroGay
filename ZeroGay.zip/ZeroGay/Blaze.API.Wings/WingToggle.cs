using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;

namespace Blaze.API.Wings
{
	public class WingToggle
	{
		private bool Ab0NXM6deY;

		private readonly Action<bool> jxhNOaOG0H;

		public BaseWing wing;

		public WingButton button;

		public Color on;

		public Color off;

		internal static WingToggle LAK14TDI0JMJjXHM65l;

		public bool State
		{
			get
			{
				return this.Ab0NXM6deY;
			}
			set
			{
				if (this.Ab0NXM6deY != value)
				{
					this.button.text.set_color((value ? this.on : this.off));
					bool flag = value;
					bool flag1 = flag;
					this.Ab0NXM6deY = flag;
					this.jxhNOaOG0H(flag1);
				}
			}
		}

		public WingToggle(BaseWing wing, string name, Transform parent, int pos, Color on, Color off, bool initial, Action<bool> onClick)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.wing = wing;
			this.on = on;
			this.off = off;
			this.jxhNOaOG0H = onClick;
			this.button = new WingButton(wing, name, parent, pos, () => this.State = !this.State);
			this.button.text.set_color((initial ? on : off));
		}

		public WingToggle(WingPage page, string name, int index, Color on, Color off, bool initial, Action<bool> onClick)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.wing = page.wing;
			this.on = on;
			this.off = off;
			this.jxhNOaOG0H = onClick;
			WingButton wingButton = new WingButton(page, name, index, () => this.State = !this.State);
			wingButton.text.set_color((initial ? on : off));
			this.button = wingButton;
		}

		internal static bool lyerl3D68MEXwSMFlqc()
		{
			return WingToggle.LAK14TDI0JMJjXHM65l == null;
		}

		internal static WingToggle QSabliDtFFHuYegfe71()
		{
			return WingToggle.LAK14TDI0JMJjXHM65l;
		}
	}
}