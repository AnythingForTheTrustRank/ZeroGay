using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.Wings
{
	public class BaseWing
	{
		public readonly List<WingPage> openedPages;

		public Transform Wing;

		public Transform WingOpen;

		public Transform WingPages;

		public Transform WingMenu;

		public Transform WingButtons;

		public Transform ProfilePage;

		public Transform ProfileButton;

		private static BaseWing AsDm6egVKMRsRYD3eDa;

		public BaseWing()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.openedPages = new List<WingPage>();
			base();
		}

		internal static BaseWing aPT5l2g1xOasE4h8F9E()
		{
			return BaseWing.AsDm6egVKMRsRYD3eDa;
		}

		internal static bool GSfYWWgLnUNesDdR9m4()
		{
			return BaseWing.AsDm6egVKMRsRYD3eDa == null;
		}

		internal void M00TiOj8tj(Transform transform_0)
		{
			this.Wing = transform_0;
			this.WingOpen = transform_0.Find("Button");
			this.WingPages = transform_0.Find("Container/InnerContainer");
			this.WingMenu = this.WingPages.Find("WingMenu");
			this.WingButtons = this.WingPages.Find("WingMenu/ScrollRect/Viewport/VerticalLayoutGroup");
			this.ProfilePage = this.WingPages.Find("Profile");
			this.ProfileButton = this.WingButtons.Find("Button_Profile");
		}
	}
}