using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Blaze.API.Wings
{
	public class BaseWing
	{
		public readonly List<WingPage> openedPages;

		public Transform Wing;

		public Transform WingOpen;

		public Transform WingPages;

		public Transform WingMenu;

		public Transform WingButtons;

		public Transform ProfilePage;

		public Transform ProfileButton;

		internal static BaseWing J091djD8SMlfhpDjGW0;

		public BaseWing()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.openedPages = new List<WingPage>();
			base();
		}

		internal static BaseWing NA3FDSDG8df1plqlVLD()
		{
			return BaseWing.J091djD8SMlfhpDjGW0;
		}

		internal void RggNgYlJqq(Transform u0020)
		{
			this.Wing = u0020;
			this.WingOpen = u0020.Find("Button");
			this.WingPages = u0020.Find("Container/InnerContainer");
			this.WingMenu = this.WingPages.Find("WingMenu");
			this.WingButtons = this.WingPages.Find("WingMenu/ScrollRect/Viewport/VerticalLayoutGroup");
			this.ProfilePage = this.WingPages.Find("Profile");
			this.ProfileButton = this.WingButtons.Find("Button_Profile");
		}

		internal static bool rjhjFADHCAjS4UKgf4S()
		{
			return BaseWing.J091djD8SMlfhpDjGW0 == null;
		}
	}
}