using AksgHVKH9UOXlBDvRpO;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.Wings
{
	public class WingButton
	{
		public BaseWing wing;

		public TextMeshProUGUI text;

		public Transform transform;

		internal static WingButton hq8vvKg36uW2vOLau2P;

		public WingButton(BaseWing wing, string name, Transform parent, int pos, Action onClick)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.wing = wing;
			this.transform = UnityEngine.Object.Instantiate<Transform>(wing.ProfileButton, parent);
			this.transform.GetComponent<RectTransform>().set_sizeDelta(new Vector2(420f, 144f));
			this.transform.get_transform().set_localPosition(new Vector3(0f, (float)pos, this.transform.get_transform().get_localPosition().z));
			TextMeshProUGUI componentInChildren = this.transform.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			Button component = this.transform.GetComponent<Button>();
			component.set_onClick(new Button.ButtonClickedEvent());
			component.get_onClick().AddListener(onClick);
		}

		public WingButton(WingPage page, string name, int index, Action onClick)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.wing = page.wing;
			Transform transform = UnityEngine.Object.Instantiate<Transform>(this.wing.ProfileButton, page.transform);
			transform.GetComponent<RectTransform>().set_sizeDelta(new Vector2(420f, 144f));
			transform.get_transform().set_localPosition(new Vector3(0f, (float)(320 - index * 120), transform.get_transform().get_localPosition().z));
			TextMeshProUGUI componentInChildren = transform.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			Button component = transform.GetComponent<Button>();
			component.set_onClick(new Button.ButtonClickedEvent());
			component.get_onClick().AddListener(onClick);
		}

		internal static bool g4ie2SgkUG552MAwlaV()
		{
			return WingButton.hq8vvKg36uW2vOLau2P == null;
		}

		internal static WingButton QgamRdgfUEqCPWpeJqT()
		{
			return WingButton.hq8vvKg36uW2vOLau2P;
		}
	}
}