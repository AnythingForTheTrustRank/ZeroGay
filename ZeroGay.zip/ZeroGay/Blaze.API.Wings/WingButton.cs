using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Blaze.API.Wings
{
	public class WingButton
	{
		public BaseWing wing;

		public TextMeshProUGUI text;

		public Transform transform;

		internal static WingButton A17Q2YD3SDHdLgpactj;

		public WingButton(BaseWing wing, string name, Transform parent, int pos, Action onClick)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.wing = wing;
			this.transform = UnityEngine.Object.Instantiate<Transform>(wing.ProfileButton, parent);
			this.transform.GetComponent<RectTransform>().set_sizeDelta(new Vector2(420f, 144f));
			this.transform.get_transform().set_localPosition(new Vector3(0f, (float)pos, this.transform.get_transform().get_localPosition().z));
			TextMeshProUGUI componentInChildren = this.transform.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			Button component = this.transform.GetComponent<Button>();
			component.set_onClick(new Button.ButtonClickedEvent());
			component.get_onClick().AddListener(onClick);
		}

		public WingButton(WingPage page, string name, int index, Action onClick)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.wing = page.wing;
			Transform transform = UnityEngine.Object.Instantiate<Transform>(this.wing.ProfileButton, page.transform);
			transform.GetComponent<RectTransform>().set_sizeDelta(new Vector2(420f, 144f));
			transform.get_transform().set_localPosition(new Vector3(0f, (float)(320 - index * 120), transform.get_transform().get_localPosition().z));
			TextMeshProUGUI componentInChildren = transform.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			Button component = transform.GetComponent<Button>();
			component.set_onClick(new Button.ButtonClickedEvent());
			component.get_onClick().AddListener(onClick);
		}

		internal static WingButton BD22rwDsmjc6dXEOmjV()
		{
			return WingButton.A17Q2YD3SDHdLgpactj;
		}

		internal static bool xhlEVPD9LXA1FSN1NTg()
		{
			return WingButton.A17Q2YD3SDHdLgpactj == null;
		}
	}
}