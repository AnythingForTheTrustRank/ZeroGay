using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Blaze.API.Wings
{
	public class WingPage
	{
		public BaseWing wing;

		public Transform transform;

		public TextMeshProUGUI text;

		public Button closeButton;

		public Button openButton;

		internal static WingPage IfspTlDMLihh2CH2lVl;

		public WingPage(BaseWing wing, string name)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			WingPage wingPage = this;
			this.wing = wing;
			this.transform = UnityEngine.Object.Instantiate<Transform>(wing.ProfilePage, wing.WingPages);
			Transform transform = this.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup");
			this.transform.get_gameObject().SetActive(false);
			for (int i = 0; i < transform.GetChildCount(); i++)
			{
				UnityEngine.Object.Destroy(transform.GetChild(i).get_gameObject());
			}
			this.transform.GetComponentInChildren<TextMeshProUGUI>().set_text(name);
			this.closeButton = this.transform.GetComponentInChildren<Button>();
			this.closeButton.set_onClick(new Button.ButtonClickedEvent());
			this.closeButton.get_onClick().AddListener(new Action(() => {
				wingPage.transform.get_gameObject().SetActive(false);
				wing.openedPages.RemoveAt(wing.openedPages.Count - 1);
				if (wing.openedPages.Count > 0)
				{
					wing.openedPages[wing.openedPages.Count - 1].transform.get_gameObject().SetActive(true);
				}
				else
				{
					wing.WingMenu.get_gameObject().SetActive(true);
				}
			}));
			Transform transform1 = UnityEngine.Object.Instantiate<Transform>(wing.ProfileButton, wing.WingButtons);
			TextMeshProUGUI componentInChildren = transform1.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			this.openButton = transform1.GetComponent<Button>();
			this.openButton.set_onClick(new Button.ButtonClickedEvent());
			this.openButton.get_onClick().AddListener(new Action(() => {
				wingPage.transform.get_gameObject().SetActive(true);
				wing.openedPages.Add(wingPage);
				if (wing.openedPages.Count > 1)
				{
					wing.openedPages[wing.openedPages.Count - 2].transform.get_gameObject().SetActive(false);
				}
				else
				{
					wing.WingMenu.get_gameObject().SetActive(false);
				}
			}));
		}

		public WingPage(WingPage page, string name, int index)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.wing = page.wing;
			this.transform = UnityEngine.Object.Instantiate<Transform>(this.wing.ProfilePage, this.wing.WingPages);
			Transform transform = this.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup");
			this.transform.get_gameObject().SetActive(false);
			for (int i = 0; i < transform.GetChildCount(); i++)
			{
				UnityEngine.Object.Destroy(transform.GetChild(i).get_gameObject());
			}
			this.transform.GetComponentInChildren<TextMeshProUGUI>().set_text(name);
			this.closeButton = this.transform.GetComponentInChildren<Button>();
			this.closeButton.set_onClick(new Button.ButtonClickedEvent());
			this.closeButton.get_onClick().AddListener(new Action(() => {
				this.transform.get_gameObject().SetActive(false);
				this.wing.openedPages.RemoveAt(this.wing.openedPages.Count - 1);
				if (this.wing.openedPages.Count > 0)
				{
					this.wing.openedPages[this.wing.openedPages.Count - 1].transform.get_gameObject().SetActive(true);
				}
				else
				{
					this.wing.WingMenu.get_gameObject().SetActive(true);
				}
			}));
			Transform transform1 = UnityEngine.Object.Instantiate<Transform>(this.wing.ProfileButton, page.transform);
			TextMeshProUGUI componentInChildren = transform1.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			this.openButton = transform1.GetComponent<Button>();
			this.openButton.GetComponent<RectTransform>().set_sizeDelta(new Vector2(420f, 144f));
			this.openButton.get_transform().set_localPosition(new Vector3(0f, (float)(320 - index * 120), this.transform.get_transform().get_localPosition().z));
			this.openButton.set_onClick(new Button.ButtonClickedEvent());
			this.openButton.get_onClick().AddListener(new Action(() => {
				this.transform.get_gameObject().SetActive(true);
				this.wing.openedPages.Add(this);
				if (this.wing.openedPages.Count > 1)
				{
					this.wing.openedPages[this.wing.openedPages.Count - 2].transform.get_gameObject().SetActive(false);
				}
				else
				{
					this.wing.WingMenu.get_gameObject().SetActive(false);
				}
			}));
		}

		internal static WingPage ogS55lD49lFeaFE1pTE()
		{
			return WingPage.IfspTlDMLihh2CH2lVl;
		}

		internal static bool wXbv0dD7qwKHKxYqQi2()
		{
			return WingPage.IfspTlDMLihh2CH2lVl == null;
		}
	}
}