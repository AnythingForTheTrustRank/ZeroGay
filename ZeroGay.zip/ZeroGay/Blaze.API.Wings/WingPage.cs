using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace Blaze.API.Wings
{
	public class WingPage
	{
		public BaseWing wing;

		public Transform transform;

		public TextMeshProUGUI text;

		public Button closeButton;

		public Button openButton;

		private static WingPage RgDF5hgm557ukU6TrmX;

		public WingPage(BaseWing wing, string name)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			WingPage wingPage = this;
			this.wing = wing;
			this.transform = UnityEngine.Object.Instantiate<Transform>(wing.ProfilePage, wing.WingPages);
			Transform transform = this.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup");
			this.transform.get_gameObject().SetActive(false);
			for (int i = 0; i < transform.GetChildCount(); i++)
			{
				UnityEngine.Object.Destroy(transform.GetChild(i).get_gameObject());
			}
			this.transform.GetComponentInChildren<TextMeshProUGUI>().set_text(name);
			this.closeButton = this.transform.GetComponentInChildren<Button>();
			this.closeButton.set_onClick(new Button.ButtonClickedEvent());
			this.closeButton.get_onClick().AddListener(new Action(() => {
				wingPage.transform.get_gameObject().SetActive(false);
				wing.openedPages.RemoveAt(wing.openedPages.Count - 1);
				if (wing.openedPages.Count <= 0)
				{
					wing.WingMenu.get_gameObject().SetActive(true);
				}
				else
				{
					wing.openedPages[wing.openedPages.Count - 1].transform.get_gameObject().SetActive(true);
				}
			}));
			Transform transform1 = UnityEngine.Object.Instantiate<Transform>(wing.ProfileButton, wing.WingButtons);
			TextMeshProUGUI componentInChildren = transform1.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			this.openButton = transform1.GetComponent<Button>();
			this.openButton.set_onClick(new Button.ButtonClickedEvent());
			this.openButton.get_onClick().AddListener(new Action(() => {
				wingPage.transform.get_gameObject().SetActive(true);
				wing.openedPages.Add(wingPage);
				if (wing.openedPages.Count > 1)
				{
					wing.openedPages[wing.openedPages.Count - 2].transform.get_gameObject().SetActive(false);
				}
				else
				{
					wing.WingMenu.get_gameObject().SetActive(false);
				}
			}));
		}

		public WingPage(WingPage page, string name, int index)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.wing = page.wing;
			this.transform = UnityEngine.Object.Instantiate<Transform>(this.wing.ProfilePage, this.wing.WingPages);
			Transform transform = this.transform.Find("ScrollRect/Viewport/VerticalLayoutGroup");
			this.transform.get_gameObject().SetActive(false);
			for (int i = 0; i < transform.GetChildCount(); i++)
			{
				UnityEngine.Object.Destroy(transform.GetChild(i).get_gameObject());
			}
			this.transform.GetComponentInChildren<TextMeshProUGUI>().set_text(name);
			this.closeButton = this.transform.GetComponentInChildren<Button>();
			this.closeButton.set_onClick(new Button.ButtonClickedEvent());
			this.closeButton.get_onClick().AddListener(new Action(() => {
				this.transform.get_gameObject().SetActive(false);
				this.wing.openedPages.RemoveAt(this.wing.openedPages.Count - 1);
				if (this.wing.openedPages.Count > 0)
				{
					this.wing.openedPages[this.wing.openedPages.Count - 1].transform.get_gameObject().SetActive(true);
				}
				else
				{
					this.wing.WingMenu.get_gameObject().SetActive(true);
				}
			}));
			Transform transform1 = UnityEngine.Object.Instantiate<Transform>(this.wing.ProfileButton, page.transform);
			TextMeshProUGUI componentInChildren = transform1.GetComponentInChildren<TextMeshProUGUI>();
			TextMeshProUGUI textMeshProUGUI = componentInChildren;
			this.text = componentInChildren;
			textMeshProUGUI.set_text(name);
			this.openButton = transform1.GetComponent<Button>();
			this.openButton.GetComponent<RectTransform>().set_sizeDelta(new Vector2(420f, 144f));
			this.openButton.get_transform().set_localPosition(new Vector3(0f, (float)(320 - index * 120), this.transform.get_transform().get_localPosition().z));
			this.openButton.set_onClick(new Button.ButtonClickedEvent());
			this.openButton.get_onClick().AddListener(new Action(() => {
				this.transform.get_gameObject().SetActive(true);
				this.wing.openedPages.Add(this);
				if (this.wing.openedPages.Count > 1)
				{
					this.wing.openedPages[this.wing.openedPages.Count - 2].transform.get_gameObject().SetActive(false);
				}
				else
				{
					this.wing.WingMenu.get_gameObject().SetActive(false);
				}
			}));
		}

		internal static bool cZHF8NgDMF4slDVaQey()
		{
			return WingPage.RgDF5hgm557ukU6TrmX == null;
		}

		internal static WingPage IhgseyggP9pcMKx35Xv()
		{
			return WingPage.RgDF5hgm557ukU6TrmX;
		}
	}
}