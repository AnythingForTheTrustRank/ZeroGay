using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem;
using System;

internal delegate Il2CppSystem.Object hJNB0p0SUHtju6yn386(string );