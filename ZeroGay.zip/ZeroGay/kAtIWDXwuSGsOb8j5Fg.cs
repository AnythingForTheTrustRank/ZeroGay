using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string kAtIWDXwuSGsOb8j5Fg(string string_0, string string_1, string string_2, string string_3);