using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.Core;

internal delegate APIUser rEKG15ZR2bSnfk0MO82(object );