using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using VRC.Udon;

namespace znK53UQmmAuKkotHsBI
{
	internal class KYjPthQoq2k24rGvLhO
	{
		internal static KYjPthQoq2k24rGvLhO E43cT2oaEYHhDcX9qPf;

		public KYjPthQoq2k24rGvLhO()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool bSdsjKogQqR41dgIcwe()
		{
			return KYjPthQoq2k24rGvLhO.E43cT2oaEYHhDcX9qPf == null;
		}

		public static void F65QcboWl2(object u0020)
		{
			if (RoomManager.Method_Internal_Static_String_PDM_0() != null)
			{
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("Game Logic"))
					{
						continue;
					}
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, u0020);
				}
			}
		}

		internal static KYjPthQoq2k24rGvLhO WFgjTUoWPpAFrsFbtr6()
		{
			return KYjPthQoq2k24rGvLhO.E43cT2oaEYHhDcX9qPf;
		}
	}
}