using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object raJu5gL9HVw9HFSyQIG(Type , long );