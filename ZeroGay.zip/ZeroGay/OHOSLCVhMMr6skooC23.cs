using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int OHOSLCVhMMr6skooC23();