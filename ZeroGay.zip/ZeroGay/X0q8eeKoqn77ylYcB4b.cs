using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.SDKBase;

internal delegate void X0q8eeKoqn77ylYcB4b(object , VRCPlayerApi );