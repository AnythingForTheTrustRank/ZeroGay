using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.SDKBase;

internal delegate VRCPlayerApi sWapKpZGCLiD8q2ymEp();