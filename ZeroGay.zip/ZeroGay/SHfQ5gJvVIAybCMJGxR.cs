using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.SDKBase;

internal delegate VRCPlayerApi SHfQ5gJvVIAybCMJGxR();