using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.Events;

internal delegate void Adf81XPXgJrGdZJJw4b(object object_0, UnityAction unityAction_0);