using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Shader RqOqiwWkVpRdeZD1wgf(string string_0);