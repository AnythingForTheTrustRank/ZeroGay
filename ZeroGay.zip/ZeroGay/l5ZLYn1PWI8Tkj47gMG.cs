using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using UnityEngine.Networking;

internal delegate Texture2D l5ZLYn1PWI8Tkj47gMG(UnityWebRequest );