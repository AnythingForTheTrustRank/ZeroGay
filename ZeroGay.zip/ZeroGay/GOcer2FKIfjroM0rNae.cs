using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using UnityEngine.UI;

internal delegate void GOcer2FKIfjroM0rNae(ref ColorBlock colorBlock_0, Color color_0);