using AksgHVKH9UOXlBDvRpO;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using tj5E7kTcTdevpjQ41CC;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;
using UnityEngine.UI;
using X7IetPATbOXxq4U7Vmy;

namespace VqcUVtTpNQvxPM1kfeq
{
	internal class wce0YjTwoh5s2q9qAUw
	{
		public GameObject PNvTgwwZXf;

		public Text y7BT44A51D;

		internal static wce0YjTwoh5s2q9qAUw VEMO3dgbdZmM3VnUX6p;

		public wce0YjTwoh5s2q9qAUw(wce0YjTwoh5s2q9qAUw.QBPEH3tkJwajIewiFIf qbpeh3tkJwajIewiFIf_0, string string_0, float float_0, float float_1, string string_1, Action action_0, float float_2 = 1f, float float_3 = 1f)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.OSYTWwW2tu(qbpeh3tkJwajIewiFIf_0, x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find(string_0), float_0, float_1, string_1, action_0, float_2, float_3);
		}

		public wce0YjTwoh5s2q9qAUw(wce0YjTwoh5s2q9qAUw.QBPEH3tkJwajIewiFIf qbpeh3tkJwajIewiFIf_0, Transform transform_0, float float_0, float float_1, string string_0, Action action_0, float float_2 = 1f, float float_3 = 1f)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.OSYTWwW2tu(qbpeh3tkJwajIewiFIf_0, transform_0, float_0, float_1, string_0, action_0, float_2, float_3);
		}

		public GameObject CA6TVHqpwh()
		{
			return this.PNvTgwwZXf;
		}

		public void kSWTLllytp(Sprite sprite_0)
		{
			this.PNvTgwwZXf.GetComponentInChildren<Image>().set_sprite(sprite_0);
		}

		public void L8sTuiZhoV(Vector2 vector2_0)
		{
			this.PNvTgwwZXf.GetComponent<RectTransform>().set_anchoredPosition(vector2_0);
		}

		public void MhiT1eEGqq(Color color_0)
		{
			ColorBlock _colors = this.PNvTgwwZXf.GetComponent<Button>().get_colors();
			ColorBlock colorBlock = new ColorBlock();
			colorBlock.set_colorMultiplier(_colors.get_colorMultiplier());
			colorBlock.set_disabledColor(_colors.get_disabledColor());
			colorBlock.set_fadeDuration(_colors.get_fadeDuration());
			colorBlock.set_highlightedColor(color_0);
			colorBlock.set_normalColor(color_0);
			colorBlock.set_pressedColor(_colors.get_pressedColor());
			this.PNvTgwwZXf.GetComponent<Button>().set_colors(colorBlock);
		}

		public async void nrYT3xPVJK(string string_0)
		{
			await this.vVcTkCjyxk(this.PNvTgwwZXf.GetComponentInChildren<Image>(), string_0);
		}

		internal static wce0YjTwoh5s2q9qAUw Oq2Iyjgz7muB9mveOPj()
		{
			return wce0YjTwoh5s2q9qAUw.VEMO3dgbdZmM3VnUX6p;
		}

		private void OSYTWwW2tu(wce0YjTwoh5s2q9qAUw.QBPEH3tkJwajIewiFIf qbpeh3tkJwajIewiFIf_0, Transform transform_0, float float_0, float float_1, string string_0, Action action_0, float float_2, float float_3)
		{
			switch (qbpeh3tkJwajIewiFIf_0)
			{
				case 0:
				{
					this.PNvTgwwZXf = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find("Social/UserProfileAndStatusSection/Status/EditStatusButton").get_gameObject(), transform_0);
					this.y7BT44A51D = this.PNvTgwwZXf.get_transform().Find("Text").GetComponent<Text>();
					this.y7BT44A51D.get_transform().SetAsLastSibling();
					break;
				}
				case 1:
				{
					this.PNvTgwwZXf = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find("Avatar/Change Button").get_gameObject(), transform_0);
					this.y7BT44A51D = this.PNvTgwwZXf.get_transform().Find("Label").GetComponent<Text>();
					break;
				}
				case 2:
				{
					this.PNvTgwwZXf = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find("Settings/Footer/Exit").get_gameObject(), transform_0);
					this.y7BT44A51D = this.PNvTgwwZXf.get_transform().Find("Text").GetComponent<Text>();
					break;
				}
				case 3:
				{
					this.PNvTgwwZXf = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find("WorldInfo/WorldButtons/PortalButton").get_gameObject(), transform_0);
					this.y7BT44A51D = this.PNvTgwwZXf.get_transform().Find("Text").GetComponent<Text>();
					break;
				}
				default:
				{
					this.PNvTgwwZXf = UnityEngine.Object.Instantiate<GameObject>(x5iKdsT53msph4ugL7v.C0kTQASGMO().get_transform().Find("Social/UserProfileAndStatusSection/Status/EditStatusButton").get_gameObject(), transform_0);
					this.y7BT44A51D = this.PNvTgwwZXf.get_transform().Find("Text").GetComponent<Text>();
					break;
				}
			}
			this.PNvTgwwZXf.set_name(string.Format("{0}-SMButton-{1}", "WTFBlaze", x5iKdsT53msph4ugL7v.accTMUKvyj()));
			ColorBlock _colors = this.PNvTgwwZXf.GetComponent<Button>().get_colors();
			Button component = this.PNvTgwwZXf.GetComponent<Button>();
			ColorBlock colorBlock = new ColorBlock();
			colorBlock.set_colorMultiplier(_colors.get_colorMultiplier());
			colorBlock.set_disabledColor(_colors.get_disabledColor());
			colorBlock.set_fadeDuration(_colors.get_fadeDuration());
			colorBlock.set_highlightedColor(_colors.get_highlightedColor());
			colorBlock.set_normalColor(_colors.get_normalColor());
			colorBlock.set_selectedColor(_colors.get_normalColor());
			colorBlock.set_pressedColor(_colors.get_pressedColor());
			component.set_colors(colorBlock);
			this.PNvTgwwZXf.GetComponent<Button>().set_onClick(new Button.ButtonClickedEvent());
			this.PNvTgwwZXf.GetComponent<Button>().get_onClick().AddListener(action_0);
			this.PNvTgwwZXf.get_transform().set_localScale(new Vector3(1f, 1f, 1f));
			RectTransform rectTransform = this.PNvTgwwZXf.GetComponent<RectTransform>();
			rectTransform.set_sizeDelta(rectTransform.get_sizeDelta() / new Vector2(float_2, float_3));
			this.wyZTPn9i0t(string_0);
			this.L8sTuiZhoV(new Vector2(float_0, float_1));
			this.y7BT44A51D.set_color(Color.get_white());
			UUyEqSykY4SKTrGkSI9.PYyyb6rsCJ.Add(this);
		}

		internal static bool qweBVXgN2sLLmivf4yV()
		{
			return wce0YjTwoh5s2q9qAUw.VEMO3dgbdZmM3VnUX6p == null;
		}

		public void tf0TF70Yu5(Color color_0)
		{
			this.PNvTgwwZXf.GetComponentInChildren<Image>().set_color(color_0);
		}

		public void TFCTXuESbH(bool bool_0)
		{
			this.PNvTgwwZXf.SetActive(bool_0);
		}

		public Text tUtTZKtyR0()
		{
			return this.y7BT44A51D;
		}

		public Texture2D UI1TmB9mEq()
		{
			Texture2D texture2D = new Texture2D(this.PNvTgwwZXf.get_gameObject().GetComponent<Image>().get_mainTexture().get_width(), this.PNvTgwwZXf.get_gameObject().GetComponent<Image>().get_mainTexture().get_height(), 4, false);
			return texture2D;
		}

		private async Task vVcTkCjyxk(Image image_0, string string_0)
		{
			wce0YjTwoh5s2q9qAUw.<GetRemoteTexture>d__15 variable = null;
			AsyncTaskMethodBuilder asyncTaskMethodBuilder = AsyncTaskMethodBuilder.Create();
			asyncTaskMethodBuilder.Start<wce0YjTwoh5s2q9qAUw.<GetRemoteTexture>d__15>(ref variable);
			return asyncTaskMethodBuilder.Task;
		}

		public void VwpTDGiHVx(bool bool_0)
		{
			this.PNvTgwwZXf.GetComponentInChildren<Image>().set_enabled(bool_0);
		}

		public void wqSTfjLHdB(string string_0)
		{
			Material material = new Material(this.PNvTgwwZXf.GetComponentInChildren<Image>().get_material());
			material.set_shader(Shader.Find(string_0));
			this.PNvTgwwZXf.get_gameObject().GetComponentInChildren<Image>().set_material(material);
		}

		public void wyZTPn9i0t(string string_0)
		{
			this.y7BT44A51D.set_supportRichText(true);
			this.y7BT44A51D.set_text(string_0);
		}

		public void z37TUPcyXW(bool bool_0)
		{
			this.PNvTgwwZXf.GetComponent<Button>().set_interactable(bool_0);
		}

		public enum QBPEH3tkJwajIewiFIf
		{

		}
	}
}