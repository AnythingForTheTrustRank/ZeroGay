using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.UI;

internal delegate Text jpb5L5EZSfo938PjiO4(object object_0);