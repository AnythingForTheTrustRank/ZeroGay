using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector3 vJUiysuM5l0JULHBH8u(Vector3 vector3_0, float float_0);