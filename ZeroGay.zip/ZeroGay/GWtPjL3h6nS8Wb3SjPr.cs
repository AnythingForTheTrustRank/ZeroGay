using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string GWtPjL3h6nS8Wb3SjPr(ref long long_0);