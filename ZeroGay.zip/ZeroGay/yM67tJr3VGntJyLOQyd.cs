using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Vector3 yM67tJr3VGntJyLOQyd(float , Vector3 );