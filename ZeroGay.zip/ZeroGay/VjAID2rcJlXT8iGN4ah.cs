using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using VRC.SDKBase;

internal delegate void VjAID2rcJlXT8iGN4ah(VRCPlayerApi , GameObject );