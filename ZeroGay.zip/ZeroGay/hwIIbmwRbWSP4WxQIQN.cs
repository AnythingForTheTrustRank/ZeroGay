using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Camera hwIIbmwRbWSP4WxQIQN(object object_0);