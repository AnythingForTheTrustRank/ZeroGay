using System;
using VRC;

namespace Area51.Events
{
	public interface OnPlayerJoinEvent
	{
		void OnPlayerEnteredRoom(Player player);

		void OnPlayerJoin(Player player);
	}
}