using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Transform nY2wr28PswHBSJgD7Od(object object_0, int int_0);