using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector4 faLQKcVVZ3S57jPq2gD();