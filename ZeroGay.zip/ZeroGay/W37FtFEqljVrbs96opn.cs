using AksgHVKH9UOXlBDvRpO;
using System;
using System.IO;

internal delegate void W37FtFEqljVrbs96opn(object object_0, Stream stream_0);