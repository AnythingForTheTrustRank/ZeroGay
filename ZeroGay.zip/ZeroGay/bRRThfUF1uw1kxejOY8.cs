using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using VRC.SDKBase;

internal delegate bool bRRThfUF1uw1kxejOY8(VRCPlayerApi vrcplayerApi_0, GameObject gameObject_0);