using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;

internal delegate List<string> VBZaoj8BvrGSOVjHcG7(object object_0);