using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void bh8J6OJsdfHpVJeVAtc(object object_0, Vector2 vector2_0);