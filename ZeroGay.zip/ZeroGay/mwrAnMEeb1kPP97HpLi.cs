using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate long mwrAnMEeb1kPP97HpLi(object object_0);