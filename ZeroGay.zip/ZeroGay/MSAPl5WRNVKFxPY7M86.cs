using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using Il2CppSystem.IO;
using System;

internal delegate Il2CppSystem.Object MSAPl5WRNVKFxPY7M86(object object_0, Stream stream_0);