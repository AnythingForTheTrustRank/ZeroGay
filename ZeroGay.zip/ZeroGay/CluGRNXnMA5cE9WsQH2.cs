using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector2 CluGRNXnMA5cE9WsQH2();