using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Exception xKuCU33kvHkMUi016lT(object object_0);