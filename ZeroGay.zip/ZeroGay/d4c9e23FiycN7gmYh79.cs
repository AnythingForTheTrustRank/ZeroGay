using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object d4c9e23FiycN7gmYh79(object object_0, object object_1);