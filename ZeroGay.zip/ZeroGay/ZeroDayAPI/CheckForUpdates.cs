using AksgHVKH9UOXlBDvRpO;
using MelonLoader;
using System;
using System.IO;
using System.Net;
using X7IetPATbOXxq4U7Vmy;

namespace ZeroDayAPI
{
	public class CheckForUpdates
	{
		internal static CheckForUpdates zaomItDOI9wCui56mw3;

		public CheckForUpdates()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static void CheckAndUpdateLol()
		{
			MelonLogger.Log("Downloading ZeroDay DLL", new object[] { false, ConsoleColor.White });
			File.WriteAllBytes("Mods/FreeLoaded/ZeroDayAPI.dll", (new WebClient()).DownloadData("https://github.com/CoolGuyBrandon/CoolGuyBrandonChildShop/blob/main/ZeroDayAPI.dll?raw=true"));
		}

		internal static bool ikpZgVDIgWAUTb9vEXY()
		{
			return CheckForUpdates.zaomItDOI9wCui56mw3 == null;
		}

		internal static CheckForUpdates JP5nYLDo0fTTRiR37Cl()
		{
			return CheckForUpdates.zaomItDOI9wCui56mw3;
		}
	}
}