using b3eD5DgJPcASx0xfHYB;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;

namespace ZeroDayAPI
{
	public class CheckForUpdates
	{
		private static CheckForUpdates wnkDquo9vhlBPik739a;

		public CheckForUpdates()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static void CheckAndUpdateLol()
		{
			MelonLogger.Log("Checking If ZeroDay Is Online..", new object[] { false, ConsoleColor.White });
			if ((new WebClient()).DownloadString("https://raw.githubusercontent.com/CoolGuyBrandon/updater-/main/killswitch.txt").Contains("ShutDown"))
			{
				MelonLogger.Log("ZeroDay Has Been ShutDown For An Unknown Reason, Closing VRChat..", new object[] { false, ConsoleColor.White });
				Thread.Sleep(5000);
				Process.GetCurrentProcess().Kill();
			}
			else
			{
				MelonLogger.Log("ZeroDay Is Online!");
				MelonLogger.Log("Downloading ZeroDay DLL", new object[] { false, 15 });
				File.WriteAllBytes("Mods/FreeLoaded/ZeroDayAPI.dll", (new WebClient()).DownloadData("https://github.com/CoolGuyBrandon/updater-/raw/main/ZeroDayAPI.dll"));
			}
		}

		internal static bool FxXut4os3Nluw6QKSCK()
		{
			return CheckForUpdates.wnkDquo9vhlBPik739a == null;
		}

		internal static CheckForUpdates YPcv2koMStHIlHc2Vvw()
		{
			return CheckForUpdates.wnkDquo9vhlBPik739a;
		}
	}
}