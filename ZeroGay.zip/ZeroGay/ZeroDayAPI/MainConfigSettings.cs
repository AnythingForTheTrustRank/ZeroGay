using b3eD5DgJPcASx0xfHYB;
using Newtonsoft.Json;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.IO;

namespace ZeroDayAPI
{
	public class MainConfigSettings
	{
		public string[] meshList;

		public string[] shaderList;

		public int MaxAudioSources;

		public int MaxLightSources;

		public int MaxMaterials;

		public int MaxCloth;

		public int MaxPolys;

		public int MaxDynBoneCollider;

		public int MaxColliders;

		public bool PickUpAutoHoldBool;

		public bool RGBESP;

		public bool PlayerESP;

		public bool NoBlindKillScreen;

		public bool GB_Friends;

		public bool GB_Enabled;

		public bool GB_FeetColliders;

		public bool GB_HandColliders;

		public bool GB_HipBones;

		public bool GB_ChestBones;

		public bool GB_HeadBones;

		public bool avatarlogger;

		public bool joinleavelogger;

		public bool UdonLogger;

		public bool blockphoton;

		public bool InfiniteJump;

		public bool PickupsESP;

		public bool Event8blockNonfriends;

		public bool Event8blockfriend;

		public bool Event9blockNonfriends;

		public bool Event9blockfriend;

		public bool Event6blockNonfriends;

		public bool Event6blockfriend;

		public bool Event4blockNonfriends;

		public bool Event4blockfriend;

		public bool Event33blockNonfriends;

		public bool Event33blockfriend;

		public bool Event210blockNonfriends;

		public bool Event210blockfriend;

		public bool Event209blockNonfriends;

		public bool Event209blockfriend;

		public static MainConfigSettings Instance;

		internal static MainConfigSettings Ve01I8own1Ehqn6w0kW;

		public MainConfigSettings()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.meshList = new string[] { "125k", "medusa", "inside", "outside", "mill" };
			this.shaderList = new string[] { "dbtc", "crash", "nigger", "nigga", "n1gga", "n1gg@", "nigg@", "go home", "byebye", "distance based", "tess", "tessellation", "cr4sh", "die", "get fucked", "spryth", "hidden/", ".hidden/", "nigg", "distancebased", "fuck:screen:fuckery:fuckyou:vilar", "bluescreen", "butterfly:vrchat:particle", "bluescream", "custom/hyu", "ebola", "yeet", "kill:xiexe", "lag ", "/die", " die ", "tessel:fur:poiyomi:standard:noise", "thot", "eatingmy", "undetected", "retard", "retrd", "standard on", "kyuzu", "oof ", ".Star/Bacon", ".Woofaa/Medusa", "Custom/Custom", "DistanceBased", "Knuckles_Gang/Free Crash", "Kyran/E  G  G", "Medusa Crash/Standard", "onion", "Pretty", "Sprythu/Why is my screen black", "custom/oof", "kys", "kos", "??", "yeeet", "got em", "medusa", "nigs", "sfere", " rip ", "/rip:/ripple", "sanity", "school", "shooter", "bacon", ".star:metal", "umbrella", "_bpu", "clap", "cooch:mochie", "sprythu", "bpu", "atençao", "izzyfrag", "izzy", "fragm", "shinigami:vhs:eye:vision", "clap shader", "clapped", "clapper", " clap ", "/clap", "world clap", "killer", ".blaze", "gang:troll:doppel", "makochill", "dead:sins", "death", "coffin", "onion", "suspicious", "darkwing", "keylime", "efrag", "yfrag", "brr", "temmie", "basically standard", "rampag", "reap", "uber shader 1.2", "C4", "2edgy", "lag:plague", "thotkyuzu", "loops", "overwatch:shader", "slay", "90hz:glasses", "autism", "penis", "randomname", "careful", "hurts", "truepink", "aнти", "Уфф", "рендер", "Это", "Ñoño", "nuke:almgp", "login", "go home", "ban:band", "buddy", "üõõüõ", "卍", "no sharing", "luka/megaae10", ".NEK0/Screen/Radial Blurr Zoom", "DocMe/BeautifulShaderv0.21", "Huyami/Ultrashader", "Leviant's Shaders/ScreenSpace Ubershader v2.7", "Leviant's Shaders/ScreenSpace Ubershader v2.7.3", "Leviant's Shaders/UberShader v2.9", "Magic3000/ScreenSpace", "Magic3000/ScreenSpacePub", "Magic3000/RGB-Glitch", "NEK0/Screen/Fade Screen v1", "VoidyShaders/Cave" };
			this.MaxAudioSources = 10;
			this.MaxLightSources = 0;
			this.MaxMaterials = 20;
			this.MaxCloth = 1;
			this.MaxPolys = 200000;
			this.MaxColliders = 0;
			this.Event8blockNonfriends = false;
			this.Event8blockfriend = false;
			this.Event9blockNonfriends = false;
			this.Event9blockfriend = false;
			this.Event6blockNonfriends = false;
			this.Event6blockfriend = false;
			this.Event4blockNonfriends = false;
			this.Event4blockfriend = false;
			this.Event33blockNonfriends = false;
			this.Event33blockfriend = false;
			this.Event210blockNonfriends = false;
			this.Event210blockfriend = false;
			this.Event209blockNonfriends = false;
			this.Event209blockfriend = false;
			base();
		}

		internal static bool AoHF2foNDVvLLvnVVkF()
		{
			return MainConfigSettings.Ve01I8own1Ehqn6w0kW == null;
		}

		internal static MainConfigSettings o6pQZ9kmGK()
		{
			MainConfigSettings mainConfigSetting;
			if (!File.Exists("ZeroDay_config.json"))
			{
				mainConfigSetting = new MainConfigSettings();
			}
			else
			{
				MainConfigSettings.Instance = JsonConvert.DeserializeObject<MainConfigSettings>(File.ReadAllText("ZeroDay_config.json"));
				mainConfigSetting = MainConfigSettings.Instance;
			}
			return mainConfigSetting;
		}

		internal static MainConfigSettings p1hrSsoCMpMWF4mq6Mh()
		{
			return MainConfigSettings.Ve01I8own1Ehqn6w0kW;
		}

		internal void SfuQjPNsy4()
		{
			File.WriteAllText("ZeroDay_config.json", JsonConvert.SerializeObject(this, 1));
		}
	}
}