using AksgHVKH9UOXlBDvRpO;
using Newtonsoft.Json;
using System;
using System.IO;
using X7IetPATbOXxq4U7Vmy;

namespace ZeroDayAPI
{
	public class MainConfigSettings
	{
		public int MaxAudioSources;

		public int MaxLightSources;

		public int MaxMaterials;

		public int MaxCloth;

		public int MaxPolys;

		public int MaxDynBoneCollider;

		public int MaxColliders;

		public bool PickUpAutoHoldBool;

		public bool RGBESP;

		public bool PlayerESP;

		public bool NoBlindKillScreen;

		public bool GB_Friends;

		public bool GB_Enabled;

		public bool GB_FeetColliders;

		public bool GB_HandColliders;

		public bool GB_HipBones;

		public bool GB_ChestBones;

		public bool GB_HeadBones;

		public bool joinleavelogger;

		public bool UdonLogger;

		public bool blockphoton;

		public bool InfiniteJump;

		public bool PickupsESP;

		public bool Event8blockNonfriends;

		public bool Event8blockfriend;

		public bool Event9blockNonfriends;

		public bool Event9blockfriend;

		public bool Event6blockNonfriends;

		public bool Event6blockfriend;

		public bool Event4blockNonfriends;

		public bool Event4blockfriend;

		public bool Event33blockNonfriends;

		public bool Event33blockfriend;

		public bool Event210blockNonfriends;

		public bool Event210blockfriend;

		public bool Event209blockNonfriends;

		public bool Event209blockfriend;

		public static MainConfigSettings Instance;

		private static MainConfigSettings xuc85SDaoBRYKjAhIrP;

		public MainConfigSettings()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.MaxAudioSources = 10;
			this.MaxLightSources = 0;
			this.MaxMaterials = 20;
			this.MaxCloth = 1;
			this.MaxPolys = 200000;
			this.MaxColliders = 0;
			this.Event8blockNonfriends = false;
			this.Event8blockfriend = false;
			this.Event9blockNonfriends = false;
			this.Event9blockfriend = false;
			this.Event6blockNonfriends = false;
			this.Event6blockfriend = false;
			this.Event4blockNonfriends = false;
			this.Event4blockfriend = false;
			this.Event33blockNonfriends = false;
			this.Event33blockfriend = false;
			this.Event210blockNonfriends = false;
			this.Event210blockfriend = false;
			this.Event209blockNonfriends = false;
			this.Event209blockfriend = false;
			base();
		}

		internal void BpCys1iF5G()
		{
			File.WriteAllText("ZeroDay_config.json", JsonConvert.SerializeObject(this, 1));
		}

		internal static MainConfigSettings BQyyR6rvEc()
		{
			MainConfigSettings instance;
			if (File.Exists("ZeroDay_config.json"))
			{
				MainConfigSettings.Instance = JsonConvert.DeserializeObject<MainConfigSettings>(File.ReadAllText("ZeroDay_config.json"));
				instance = MainConfigSettings.Instance;
			}
			else
			{
				instance = new MainConfigSettings();
			}
			return instance;
		}

		internal static MainConfigSettings FEoDRTDT4J5iiD0Vvs5()
		{
			return MainConfigSettings.xuc85SDaoBRYKjAhIrP;
		}

		internal static bool gEOalrDyXiELifxOXJg()
		{
			return MainConfigSettings.xuc85SDaoBRYKjAhIrP == null;
		}
	}
}