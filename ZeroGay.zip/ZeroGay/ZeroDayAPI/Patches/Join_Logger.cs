using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using MelonLoader;
using System;
using VRC;
using VRC.Core;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_1")]
	public class Join_Logger
	{
		internal static Join_Logger eUhpvUDKT4koOtpRWaL;

		public Join_Logger()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool LeLxUiDlb0qq7wxDSpH()
		{
			return Join_Logger.eUhpvUDKT4koOtpRWaL == null;
		}

		public static void Prefix(ref Player __0)
		{
			if (MainConfigSettings.Instance.joinleavelogger)
			{
				MelonLogger.Log(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has left."));
				try
				{
					MainMenuLol.logleave(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has Left."));
				}
				catch (Exception exception)
				{
					MelonLogger.Log("Error In OnUiDebugger");
					throw;
				}
			}
		}

		internal static Join_Logger Te3VcqDA5iaUM5m6eTR()
		{
			return Join_Logger.eUhpvUDKT4koOtpRWaL;
		}
	}
}