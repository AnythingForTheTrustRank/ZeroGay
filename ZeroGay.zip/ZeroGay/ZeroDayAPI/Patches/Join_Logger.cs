using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC;
using VRC.Core;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_1")]
	public class Join_Logger
	{
		internal static Join_Logger EwVlmGoP6Kq8s09uO3y;

		public Join_Logger()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool ppu56Col6Q5EiPngESe()
		{
			return Join_Logger.EwVlmGoP6Kq8s09uO3y == null;
		}

		public static void Prefix(ref Player __0)
		{
			if (MainConfigSettings.Instance.joinleavelogger)
			{
				MelonLogger.Log(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has left."));
				try
				{
					MainMenuLol.logleave(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has Left."));
				}
				catch (Exception exception)
				{
					MelonLogger.Log("Error In OnUiDebugger");
					throw;
				}
			}
		}

		internal static Join_Logger VyAA6pojMPwfig3nRsV()
		{
			return Join_Logger.EwVlmGoP6Kq8s09uO3y;
		}
	}
}