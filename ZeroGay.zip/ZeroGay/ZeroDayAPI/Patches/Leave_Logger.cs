using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using kWhG3wo7dROsCRbltNp;
using MelonLoader;
using System;
using UnityEngine;
using VRC;
using VRC.Core;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_0")]
	public class Leave_Logger
	{
		public static Player player;

		internal static Leave_Logger fDwPpsDGp85MAtWxANk;

		static Leave_Logger()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			Leave_Logger.player = new Player();
		}

		public Leave_Logger()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static Leave_Logger byBAP5DvgF1XKvl9jM6()
		{
			return Leave_Logger.fDwPpsDGp85MAtWxANk;
		}

		public static void Prefix(ref Player __0)
		{
			if (MainConfigSettings.Instance.PlayerESP)
			{
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}
			if (MainConfigSettings.Instance.joinleavelogger)
			{
				try
				{
					MainMenuLol.logjoin(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has Joined."));
				}
				catch (Exception exception)
				{
					MelonLogger.Log("Error In OnUiDebugger");
					throw;
				}
				MelonLogger.Log(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has Joined."));
			}
			INoLOnoTjlV0JbUwbrx noLOnoTjlV0JbUwbrx = Leave_Logger.player.get_transform().Find("Player Nameplate/Canvas/Nameplate").get_gameObject().AddComponent<INoLOnoTjlV0JbUwbrx>();
			noLOnoTjlV0JbUwbrx.v1aoqiL01C = Leave_Logger.player;
		}

		internal static bool ttswmLDddbSZnrgmrOf()
		{
			return Leave_Logger.fDwPpsDGp85MAtWxANk == null;
		}
	}
}