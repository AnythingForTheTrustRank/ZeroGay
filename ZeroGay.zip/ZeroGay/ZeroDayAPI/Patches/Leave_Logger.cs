using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC;
using VRC.Core;
using ZeroDayAPI;
using ZeroDayAPI.Buttons;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_0")]
	public class Leave_Logger
	{
		public static Player player;

		private static Leave_Logger B5DMcboZkByqgsqb1pB;

		static Leave_Logger()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			Leave_Logger.player = new Player();
		}

		public Leave_Logger()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool gZ0uN1oF4Shy09quKER()
		{
			return Leave_Logger.B5DMcboZkByqgsqb1pB == null;
		}

		public static void Prefix(ref Player __0)
		{
			if (MainConfigSettings.Instance.PlayerESP)
			{
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}
			if (MainConfigSettings.Instance.joinleavelogger)
			{
				try
				{
					MainMenuLol.logjoin(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has Joined."));
				}
				catch (Exception exception)
				{
					MelonLogger.Log("Error In OnUiDebugger");
					throw;
				}
				MelonLogger.Log(string.Concat("[  ", __0.Method_Internal_get_APIUser_0().get_displayName(), "  ]: Has Joined."));
			}
		}

		internal static Leave_Logger uFbyo6oipjjYW256g1A()
		{
			return Leave_Logger.B5DMcboZkByqgsqb1pB;
		}
	}
}