using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using System;
using VRC;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_0")]
	public class espupdater
	{
		internal static espupdater HJ6dO0DsUZxYCgVH0mP;

		public espupdater()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool bfctsYDRNdaZT7vpijX()
		{
			return espupdater.HJ6dO0DsUZxYCgVH0mP == null;
		}

		public static void Prefix(ref Player __0)
		{
			if (MainConfigSettings.Instance.PlayerESP)
			{
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}
		}

		internal static espupdater QU0ZG2DtkvB1BT9ch2u()
		{
			return espupdater.HJ6dO0DsUZxYCgVH0mP;
		}
	}
}