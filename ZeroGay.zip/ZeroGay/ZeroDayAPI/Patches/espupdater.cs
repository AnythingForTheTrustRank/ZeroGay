using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC;
using ZeroDayAPI;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_0")]
	public class espupdater
	{
		private static espupdater UHMsImoXSQi2VfPADs4;

		public espupdater()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool OJMjSJoO3DYcONgI9Ys()
		{
			return espupdater.UHMsImoXSQi2VfPADs4 == null;
		}

		public static void Prefix(ref Player __0)
		{
			if (MainConfigSettings.Instance.PlayerESP)
			{
				Esp.ToggleESP(false);
				Esp.ToggleESP(true);
			}
		}

		internal static espupdater xHZrMboBZEkWVphmTql()
		{
			return espupdater.UHMsImoXSQi2VfPADs4;
		}
	}
}