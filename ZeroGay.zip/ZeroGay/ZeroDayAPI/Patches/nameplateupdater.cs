using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_0")]
	public class nameplateupdater
	{
		public static Player player;

		private static nameplateupdater fMckguo01Bn8YnpWfg8;

		static nameplateupdater()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			nameplateupdater.player = new Player();
		}

		public nameplateupdater()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static nameplateupdater ggUS8XopkKKs5VMETkP()
		{
			return nameplateupdater.fMckguo01Bn8YnpWfg8;
		}

		internal static bool O6JhvhoRPpqH1BuMp6l()
		{
			return nameplateupdater.fMckguo01Bn8YnpWfg8 == null;
		}

		public static void Prefix(ref Player __0)
		{
		}
	}
}