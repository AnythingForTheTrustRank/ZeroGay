using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using System;
using VRC;
using X7IetPATbOXxq4U7Vmy;

namespace ZeroDayAPI.Patches
{
	[HarmonyPatch(typeof(NetworkManager), "Method_Public_Void_Player_0")]
	public class nameplateupdater
	{
		public static Player player;

		private static nameplateupdater ymtGHDDiG6agOUNrvJe;

		static nameplateupdater()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			nameplateupdater.player = new Player();
		}

		public nameplateupdater()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static nameplateupdater nNHL5vD0Xos82itpTFP()
		{
			return nameplateupdater.ymtGHDDiG6agOUNrvJe;
		}

		internal static bool p9IAmXD9uelXwSk0Sb1()
		{
			return nameplateupdater.ymtGHDDiG6agOUNrvJe == null;
		}

		public static void Prefix(ref Player __0)
		{
		}
	}
}