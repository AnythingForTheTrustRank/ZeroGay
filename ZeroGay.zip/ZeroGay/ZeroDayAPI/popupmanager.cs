using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using TMPro;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.SDKBase;

namespace ZeroDayAPI
{
	public static class popupmanager
	{
		public static Text HudMessage1;

		public static System.Collections.Generic.List<string> MessagesList;

		private static popupmanager eHPsoZo2v8qYWMR8iNZ;

		static popupmanager()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			popupmanager.MessagesList = new System.Collections.Generic.List<string>();
		}

		internal static popupmanager BGfE3BohaF0leO7b0Fy()
		{
			return popupmanager.eHPsoZo2v8qYWMR8iNZ;
		}

		public static void ClearHudMessages(this VRCUiManager instance)
		{
			instance.get_field_Private_List_1_String_0().Clear();
			instance.get_field_Public_Text_0().set_text("");
			popupmanager.HudMessage1.set_text("");
			popupmanager.MessagesList.Clear();
		}

		public static Image CreateImage(string name, float offset)
		{
			GameObject gameObject = GameObject.Find("UserInterface/UnscaledUI/HudContent/Hud");
			Transform transform = gameObject.get_transform().Find("NotificationDotParent");
			GameObject gameObject1 = UnityEngine.Object.Instantiate<GameObject>(gameObject.get_transform().Find("NotificationDotParent/NotificationDot").get_gameObject(), transform, false).Cast<GameObject>();
			gameObject1.set_name(string.Concat("NotifyDot-", name));
			gameObject1.SetActive(true);
			Transform _transform = gameObject1.get_transform();
			_transform.set_localPosition(_transform.get_localPosition() + (Vector3.get_right() * offset));
			Image component = gameObject1.GetComponent<Image>();
			component.set_enabled(false);
			return component;
		}

		public static Text CreateTextNear(Image image, float offset, TextAnchor alignment)
		{
			GameObject gameObject = new GameObject(string.Concat(image.get_gameObject().get_name(), "-text"));
			gameObject.AddComponent<Text>();
			gameObject.get_transform().SetParent(image.get_transform(), false);
			gameObject.get_transform().set_localScale(Vector3.get_one());
			gameObject.get_transform().set_localPosition((Vector3.get_up() * offset) + (Vector3.get_right() * 300f));
			Text component = gameObject.GetComponent<Text>();
			component.set_color(Color.get_white());
			component.set_fontStyle(3);
			component.set_horizontalOverflow(1);
			component.set_verticalOverflow(1);
			component.set_alignment(6);
			component.set_fontSize(20);
			component.set_font(Resources.GetBuiltinResource<Font>("Arial.ttf"));
			component.set_supportRichText(true);
			gameObject.SetActive(true);
			return component;
		}

		internal static Player FXbQFLWWb4()
		{
			Player player;
			Player player1;
			if (!GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local").get_active())
			{
				player = null;
			}
			else
			{
				string _text = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_SelectedUser_Local/ScrollRect/Viewport/VerticalLayoutGroup/UserProfile_Compact/PanelBG/Info/Text_Username_NonFriend").GetComponent<TextMeshProUGUI>().get_text();
				Il2CppSystem.Collections.Generic.List<Player>.Enumerator enumerator = PlayerManager.get_field_Private_Static_PlayerManager_0().get_field_Private_List_1_Player_0().GetEnumerator();
				while (enumerator.MoveNext())
				{
					Player current = enumerator.get_Current();
					if (current.GetVRCPlayerApi().get_displayName() != _text)
					{
						continue;
					}
					player1 = current;
					return player1;
				}
				player = null;
			}
			player1 = player;
			return player1;
		}

		public static VRCPlayerApi GetVRCPlayerApi(this Player Instance)
		{
			VRCPlayerApi vRCPlayerApi;
			if (Instance == null)
			{
				vRCPlayerApi = null;
			}
			else
			{
				vRCPlayerApi = Instance.Method_Public_VRCPlayerApi_0();
			}
			return vRCPlayerApi;
		}

		public static void QueHudMessage(this VRCUiManager instance, string Message)
		{
			if (popupmanager.HudMessage1 == null)
			{
				popupmanager.HudMessage1 = popupmanager.CreateTextNear(popupmanager.CreateImage("yes", 0f), 110f, 6);
			}
			MelonCoroutines.Start(popupmanager.ShowMessage(popupmanager.HudMessage1, popupmanager.MessagesList, Message));
		}

		public static IEnumerator ShowMessage(Text text, System.Collections.Generic.List<string> MessagesList, string message)
		{
			if (MessagesList.Count < 250)
			{
				MessagesList.Add(message);
				text.set_text(string.Join("\n", MessagesList));
				yield return new WaitForSeconds(7f);
				MessagesList.Remove(message);
				text.set_text(string.Join("\n", MessagesList));
			}
		}

		internal static bool vd2shKobvULPaWKcv34()
		{
			return popupmanager.eHPsoZo2v8qYWMR8iNZ == null;
		}
	}
}