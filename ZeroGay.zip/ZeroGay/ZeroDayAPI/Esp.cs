using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;
using X7IetPATbOXxq4U7Vmy;

namespace ZeroDayAPI
{
	public static class Esp
	{
		public static Il2CppSystem.Collections.Generic.List<VRCSDK2.VRC_Pickup> AllPickups;

		public static Il2CppSystem.Collections.Generic.List<VRCPickup> AllUdonPickups;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger> AllTriggers;

		public static Il2CppSystem.Collections.Generic.List<VRC_ObjectSync> AllSyncPickups;

		public static bool Esptest2;

		public static bool outlineesp;

		public static HighlightsFXStandalone _friendsHighlights;

		public static HighlightsFXStandalone _othersHighlights;

		public static HighlightsFXStandalone pickuphighlight;

		public static Il2CppSystem.Collections.Generic.List<Renderer> TriggersRenderers;

		public static Il2CppSystem.Collections.Generic.List<Renderer> PickupsRenderers;

		public static HighlightsFXStandalone keys;

		public static HighlightsFXStandalone folders;

		internal static Esp cNqjlQD6nQ3OlEuDYpa;

		static Esp()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			Esp.AllPickups = new Il2CppSystem.Collections.Generic.List<VRCSDK2.VRC_Pickup>();
			Esp.AllUdonPickups = new Il2CppSystem.Collections.Generic.List<VRCPickup>();
			Esp.AllTriggers = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger>();
			Esp.AllSyncPickups = new Il2CppSystem.Collections.Generic.List<VRC_ObjectSync>();
			Esp.Esptest2 = false;
			Esp.outlineesp = false;
			Esp.TriggersRenderers = new Il2CppSystem.Collections.Generic.List<Renderer>();
			Esp.PickupsRenderers = new Il2CppSystem.Collections.Generic.List<Renderer>();
		}

		private static bool FoKyC1hIem(ref Player player_0)
		{
			return true;
		}

		internal static IEnumerator GBuyaXfckC(bool bool_0)
		{
			while (true)
			{
				MeshRenderer component = GameObject.Find("Game Logic/Player Nodes/Player Node (0)/Corpse/Chalk outline (1)").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer = GameObject.Find("Game Logic/Player Nodes/Player Node (1)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component1 = GameObject.Find("Game Logic/Player Nodes/Player Node (2)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer1 = GameObject.Find("Game Logic/Player Nodes/Player Node (3)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component2 = GameObject.Find("Game Logic/Player Nodes/Player Node (4)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer2 = GameObject.Find("Game Logic/Player Nodes/Player Node (5)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component3 = GameObject.Find("Game Logic/Player Nodes/Player Node (6)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer3 = GameObject.Find("Game Logic/Player Nodes/Player Node (7)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component4 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer4 = GameObject.Find("Game Logic/Player Nodes/Player Node (8)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component5 = GameObject.Find("Game Logic/Player Nodes/Player Node (10)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer5 = GameObject.Find("Game Logic/Player Nodes/Player Node (11)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component6 = GameObject.Find("Game Logic/Player Nodes/Player Node (12)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer6 = GameObject.Find("Game Logic/Player Nodes/Player Node (13)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component7 = GameObject.Find("Game Logic/Player Nodes/Player Node (14)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer7 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component8 = GameObject.Find("Game Logic/Player Nodes/Player Node (15)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer8 = GameObject.Find("Game Logic/Player Nodes/Player Node (16)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component9 = GameObject.Find("Game Logic/Player Nodes/Player Node (17)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer9 = GameObject.Find("Game Logic/Player Nodes/Player Node (18)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				MeshRenderer component10 = GameObject.Find("Game Logic/Player Nodes/Player Node (19)/Corpse/Chalk outline").GetComponent<MeshRenderer>();
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Virtual_Boolean_0();
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().get_field_Protected_Material_0().SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component1.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer1.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component2.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer2.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component3.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer3.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component4.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer4.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component5.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer5.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component6.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer6.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component7.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer7.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component8.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer8.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component9.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer9.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component10.GetComponent<MeshRenderer>(), bool_0);
				yield return new WaitForSeconds(0.1f);
				component = null;
				meshRenderer = null;
				component1 = null;
				meshRenderer1 = null;
				component2 = null;
				meshRenderer2 = null;
				component3 = null;
				meshRenderer3 = null;
				component4 = null;
				meshRenderer4 = null;
				component5 = null;
				meshRenderer5 = null;
				component6 = null;
				meshRenderer6 = null;
				component7 = null;
				meshRenderer7 = null;
				component8 = null;
				meshRenderer8 = null;
				component9 = null;
				meshRenderer9 = null;
				component10 = null;
			}
		}

		public static Player[] GetPlayers(this PlayerManager playerManager)
		{
			return playerManager.Method_Public_get_ArrayOf_Player_0();
		}

		public static void HighlightPlayer(Player player, bool highlighted)
		{
			Transform transform = player.get_transform().Find("SelectRegion");
			if (transform != null)
			{
				Esp.ipcyT8PGwO(player.get_field_Private_APIUser_0()).Method_Public_Void_Renderer_Boolean_0(transform.GetComponent<Renderer>(), highlighted);
			}
		}

		private static HighlightsFXStandalone ipcyT8PGwO(object object_0)
		{
			HighlightsFXStandalone highlightsFXStandalone;
			try
			{
				highlightsFXStandalone = (APIUser.IsFriendsWith(object_0.get_id()) ? Esp._friendsHighlights : Esp._othersHighlights);
			}
			catch (Exception exception)
			{
				MelonLogger.LogError("Error in ESP!");
				throw;
			}
			return highlightsFXStandalone;
		}

		internal static void IRwyeFQmQE(bool bool_0)
		{
			GameObject[] gameObjectArray = GameObject.FindGameObjectsWithTag("Player");
			for (int i = 0; i < (int)gameObjectArray.Length; i++)
			{
				if ((gameObjectArray[i] != null ? gameObjectArray[i].get_transform().Find("SelectRegion") : false))
				{
					Renderer component = gameObjectArray[i].get_transform().Find("SelectRegion").GetComponent<Renderer>();
					HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().get_field_Protected_Material_0().SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
					HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component, bool_0);
				}
			}
		}

		internal static IEnumerator LOryyQIpFW(bool bool_0)
		{
			while (true)
			{
				SkinnedMeshRenderer component = GameObject.Find("Game Logic/Snakes/Snake/Geo/Snake Stuff/Snake Geo/snake/snake").GetComponent<SkinnedMeshRenderer>();
				MeshRenderer meshRenderer = GameObject.Find("Game Logic/Weapons/Knife (0)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer component1 = GameObject.Find("Game Logic/Weapons/Knife (1)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer1 = GameObject.Find("Game Logic/Weapons/Knife (2)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer component2 = GameObject.Find("Game Logic/Weapons/Knife (3)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer2 = GameObject.Find("Game Logic/Weapons/Knife (4)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer component3 = GameObject.Find("Game Logic/Weapons/Knife (5)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer3 = GameObject.Find("Game Logic/Weapons/Revolver/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer component4 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer4 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer component5 = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer5 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap jaw (0)").GetComponent<MeshRenderer>();
				MeshRenderer component6 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap jaw (0)").GetComponent<MeshRenderer>();
				GameObject gameObject = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap jaw (0)");
				MeshRenderer meshRenderer6 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer component7 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer7 = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer component8 = GameObject.Find("Game Logic/Weapons/Unlockables/Luger (0)/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer8 = GameObject.Find("Game Logic/Weapons/Unlockables/Shotgun (0)/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer component9 = GameObject.Find("Game Logic/Weapons/Unlockables/Frag (0)/Intact/frag geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer9 = GameObject.Find("Game Logic/Weapons/Unlockables/Smoke (0)/Intact/smoke geo").GetComponent<MeshRenderer>();
				MeshRenderer component10 = GameObject.Find("Game Logic/Snakes/SnakeDispenser/snake crate geo").GetComponent<MeshRenderer>();
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Virtual_Boolean_0();
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().get_field_Protected_Material_0().SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component.GetComponent<SkinnedMeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component1.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer1.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component2.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer2.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component3.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer3.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component4.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer4.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component5.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer5.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component6.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(gameObject.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer6.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component7.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer7.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component8.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer8.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component9.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer9.GetComponent<MeshRenderer>(), bool_0);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component10.GetComponent<MeshRenderer>(), bool_0);
				yield return new WaitForSeconds(0.1f);
				component = null;
				meshRenderer = null;
				component1 = null;
				meshRenderer1 = null;
				component2 = null;
				meshRenderer2 = null;
				component3 = null;
				meshRenderer3 = null;
				component4 = null;
				meshRenderer4 = null;
				component5 = null;
				meshRenderer5 = null;
				component6 = null;
				gameObject = null;
				meshRenderer6 = null;
				component7 = null;
				meshRenderer7 = null;
				component8 = null;
				meshRenderer8 = null;
				component9 = null;
				meshRenderer9 = null;
				component10 = null;
			}
		}

		internal static void NUjyMfvV0Y(bool bool_0)
		{
			foreach (VRCPickup vRCPickup in Resources.FindObjectsOfTypeAll<VRCPickup>())
			{
				if ((vRCPickup == null || vRCPickup.get_gameObject() == null || !vRCPickup.get_gameObject().get_active() || !vRCPickup.get_enabled() ? true : !vRCPickup.get_pickupable()))
				{
					continue;
				}
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Virtual_Boolean_0();
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().get_field_Protected_Material_0().SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(vRCPickup.GetComponent<MeshRenderer>(), bool_0);
			}
		}

		public static void PlayerMeshEsp(Player Target, bool State)
		{
			try
			{
				foreach (Renderer componentsInChild in Target.get__vrcplayer().get_field_Internal_GameObject_0().GetComponentsInChildren<Renderer>())
				{
					HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(componentsInChild, State);
				}
			}
			catch
			{
			}
		}

		internal static void rrByqVUpJx(object object_0, bool bool_0)
		{
			if (HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() != null)
			{
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(object_0, bool_0);
			}
		}

		internal static IEnumerator tgJy7uPMi6(bool bool_0)
		{
			return new Esp.<GhostV1ESP>d__22(0)
			{
				state = bool_0
			};
		}

		public static void ToggleESP(bool enabled)
		{
			try
			{
				PlayerManager fieldPrivateStaticPlayerManager0 = PlayerManager.get_field_Private_Static_PlayerManager_0();
				if (fieldPrivateStaticPlayerManager0 != null)
				{
					Player[] players = fieldPrivateStaticPlayerManager0.GetPlayers();
					for (int i = 0; i < (int)players.Length; i++)
					{
						Esp.HighlightPlayer(players[i], enabled);
					}
				}
			}
			catch (Exception exception)
			{
				MelonLogger.LogError("Error in ESP!");
				throw;
			}
		}

		public static IEnumerator togglepickupsesp()
		{
			while (true)
			{
				if (MainConfigSettings.Instance.PickupsESP)
				{
					Esp.NUjyMfvV0Y(true);
				}
				else
				{
					Esp.NUjyMfvV0Y(false);
				}
				yield return new WaitForSeconds(1f);
			}
		}

		internal static Esp WgDpCgDBtFsyTeOSHb7()
		{
			return Esp.cNqjlQD6nQ3OlEuDYpa;
		}

		internal static bool Xbg732DYWRBC3y8awa8()
		{
			return Esp.cNqjlQD6nQ3OlEuDYpa == null;
		}
	}
}