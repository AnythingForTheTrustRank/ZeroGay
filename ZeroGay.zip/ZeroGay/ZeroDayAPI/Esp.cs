using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRCSDK2;

namespace ZeroDayAPI
{
	public static class Esp
	{
		public static Il2CppSystem.Collections.Generic.List<VRCSDK2.VRC_Pickup> AllPickups;

		public static Il2CppSystem.Collections.Generic.List<VRCPickup> AllUdonPickups;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger> AllTriggers;

		public static Il2CppSystem.Collections.Generic.List<VRC_ObjectSync> AllSyncPickups;

		public static bool Esptest2;

		public static bool outlineesp;

		public static HighlightsFXStandalone _friendsHighlights;

		public static HighlightsFXStandalone _othersHighlights;

		public static HighlightsFXStandalone pickuphighlight;

		public static Il2CppSystem.Collections.Generic.List<Renderer> TriggersRenderers;

		public static Il2CppSystem.Collections.Generic.List<Renderer> PickupsRenderers;

		public static HighlightsFXStandalone keys;

		public static HighlightsFXStandalone folders;

		private static Esp ph4LC7o7AAj2Bt1bt0s;

		static Esp()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			Esp.AllPickups = new Il2CppSystem.Collections.Generic.List<VRCSDK2.VRC_Pickup>();
			Esp.AllUdonPickups = new Il2CppSystem.Collections.Generic.List<VRCPickup>();
			Esp.AllTriggers = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger>();
			Esp.AllSyncPickups = new Il2CppSystem.Collections.Generic.List<VRC_ObjectSync>();
			Esp.Esptest2 = false;
			Esp.outlineesp = false;
			Esp.TriggersRenderers = new Il2CppSystem.Collections.Generic.List<Renderer>();
			Esp.PickupsRenderers = new Il2CppSystem.Collections.Generic.List<Renderer>();
		}

		internal static void ApaQXt0XQ3(bool u0020)
		{
			GameObject[] gameObjectArray = GameObject.FindGameObjectsWithTag("Player");
			for (int i = 0; i < (int)gameObjectArray.Length; i++)
			{
				if (!(gameObjectArray[i] == null) && gameObjectArray[i].get_transform().Find("SelectRegion"))
				{
					Renderer component = gameObjectArray[i].get_transform().Find("SelectRegion").GetComponent<Renderer>();
					HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().get_field_Protected_Material_0().SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
					HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component, u0020);
				}
			}
		}

		internal static IEnumerator cvUQYtBEss(bool u0020)
		{
			while (true)
			{
				GameObject gameObject = GameObject.Find("NameClueSystem/NameClues/CluePickup/Folder_file");
				GameObject gameObject1 = GameObject.Find("NameClueSystem/NameClues/CluePickup (1)/Folder_file");
				GameObject gameObject2 = GameObject.Find("NameClueSystem/NameClues/CluePickup (2)/Folder_file");
				GameObject gameObject3 = GameObject.Find("NameClueSystem/NameClues/CluePickup (3)/Folder_file");
				GameObject gameObject4 = GameObject.Find("NameClueSystem/NameClues/CluePickup (4)/Folder_file");
				GameObject gameObject5 = GameObject.Find("NameClueSystem/NameClues/CluePickup (5)/Folder_file");
				GameObject gameObject6 = GameObject.Find("NameClueSystem/NameClues/CluePickup (6)/Folder_file");
				GameObject gameObject7 = GameObject.Find("NameClueSystem/NameClues/CluePickup (7)/Folder_file");
				GameObject gameObject8 = GameObject.Find("NameClueSystem/NameClues/CluePickup (8)/Folder_file");
				GameObject gameObject9 = GameObject.Find("PoliceStation/Props/NameClueSystem/NameClues/CluePickup (9)/Folder_file");
				GameObject gameObject10 = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key/KeyModel/prf_v_key_02/sm_key_01");
				GameObject gameObject11 = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key (1)/KeyModel/prf_v_key_02/sm_key_01");
				Esp.keys.Method_Public_Void_Renderer_Boolean_0(gameObject10.GetComponent<MeshRenderer>(), u0020);
				Esp.keys.Method_Public_Void_Renderer_Boolean_0(gameObject11.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject1.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject2.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject3.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject4.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject5.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject6.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject7.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject8.GetComponent<MeshRenderer>(), u0020);
				Esp.folders.Method_Public_Void_Renderer_Boolean_0(gameObject9.GetComponent<MeshRenderer>(), u0020);
				yield return new WaitForSeconds(1f);
				gameObject = null;
				gameObject1 = null;
				gameObject2 = null;
				gameObject3 = null;
				gameObject4 = null;
				gameObject5 = null;
				gameObject6 = null;
				gameObject7 = null;
				gameObject8 = null;
				gameObject9 = null;
				gameObject10 = null;
				gameObject11 = null;
			}
		}

		internal static void DiFQgBbyJc(bool u0020)
		{
			foreach (VRCPickup vRCPickup in Resources.FindObjectsOfTypeAll<VRCPickup>())
			{
				if (vRCPickup == null || vRCPickup.get_gameObject() == null || !vRCPickup.get_gameObject().get_active() || !vRCPickup.get_enabled() || !vRCPickup.get_pickupable())
				{
					continue;
				}
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Virtual_Boolean_0();
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().get_field_Protected_Material_0().SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(vRCPickup.GetComponent<MeshRenderer>(), u0020);
			}
		}

		internal static IEnumerator DiHQWCI6SB(bool u0020)
		{
			return new Esp.<amungusESP1>d__14(0)
			{
				state = u0020
			};
		}

		public static void HighlightPlayer(Player player, bool highlighted)
		{
			Transform transform = player.get_transform().Find("SelectRegion");
			if (transform != null)
			{
				Esp.xAWQSGllE7(player.get_field_Private_APIUser_0()).Method_Public_Void_Renderer_Boolean_0(transform.GetComponent<Renderer>(), highlighted);
			}
		}

		internal static bool NIqhYko41yTin4GLr4q()
		{
			return Esp.ph4LC7o7AAj2Bt1bt0s == null;
		}

		public static void PlayerMeshEsp(Player Target, bool State)
		{
			try
			{
				foreach (Renderer componentsInChild in Target.get__vrcplayer().get_field_Internal_GameObject_0().GetComponentsInChildren<Renderer>())
				{
					HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().Method_Public_Void_Renderer_Boolean_0(componentsInChild, State);
				}
			}
			catch
			{
			}
		}

		public static void ToggleESP(bool enabled)
		{
			try
			{
				PlayerManager fieldPrivateStaticPlayerManager0 = PlayerManager.get_field_Private_Static_PlayerManager_0();
				if (fieldPrivateStaticPlayerManager0 != null)
				{
					Player[] playerArray = fieldPrivateStaticPlayerManager0.Method_Public_get_ArrayOf_Player_0();
					for (int i = 0; i < (int)playerArray.Length; i++)
					{
						Esp.HighlightPlayer(playerArray[i], enabled);
					}
				}
			}
			catch (Exception exception)
			{
				MelonLogger.LogError("Error in ESP!");
				throw;
			}
		}

		public static IEnumerator togglepickupsesp()
		{
			return new Esp.<togglepickupsesp>d__11(0);
		}

		private static bool VPqQOCyoYr(ref Player u0020)
		{
			return true;
		}

		private static HighlightsFXStandalone xAWQSGllE7(object u0020)
		{
			HighlightsFXStandalone highlightsFXStandalone;
			try
			{
				highlightsFXStandalone = (APIUser.IsFriendsWith(u0020.get_id()) ? Esp._friendsHighlights : Esp._othersHighlights);
			}
			catch (Exception exception)
			{
				MelonLogger.LogError("Error in ESP!");
				throw;
			}
			return highlightsFXStandalone;
		}

		internal static void XPhQBLVB1l(object u0020, bool u0020)
		{
			if (HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0() != null)
			{
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(u0020, u0020);
			}
		}

		internal static IEnumerator yS6Qu4tenP(bool u0020)
		{
			while (true)
			{
				SkinnedMeshRenderer component = GameObject.Find("Game Logic/Snakes/Snake/Geo/Snake Stuff/Snake Geo/snake/snake").GetComponent<SkinnedMeshRenderer>();
				MeshRenderer meshRenderer = GameObject.Find("Game Logic/Weapons/Knife (0)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer component1 = GameObject.Find("Game Logic/Weapons/Knife (1)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer1 = GameObject.Find("Game Logic/Weapons/Knife (2)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer component2 = GameObject.Find("Game Logic/Weapons/Knife (3)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer2 = GameObject.Find("Game Logic/Weapons/Knife (4)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer component3 = GameObject.Find("Game Logic/Weapons/Knife (5)/Slash Anim/Slash/knife geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer3 = GameObject.Find("Game Logic/Weapons/Revolver/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer component4 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer4 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer component5 = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer5 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap jaw (0)").GetComponent<MeshRenderer>();
				MeshRenderer component6 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap jaw (0)").GetComponent<MeshRenderer>();
				GameObject gameObject = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap jaw (0)");
				MeshRenderer meshRenderer6 = GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer component7 = GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer7 = GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Bear Trap Anim/bear trap jaw (1)").GetComponent<MeshRenderer>();
				MeshRenderer component8 = GameObject.Find("Game Logic/Weapons/Unlockables/Luger (0)/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer8 = GameObject.Find("Game Logic/Weapons/Unlockables/Shotgun (0)/Recoil Anim/Recoil/geo").GetComponent<MeshRenderer>();
				MeshRenderer component9 = GameObject.Find("Game Logic/Weapons/Unlockables/Frag (0)/Intact/frag geo").GetComponent<MeshRenderer>();
				MeshRenderer meshRenderer9 = GameObject.Find("Game Logic/Weapons/Unlockables/Smoke (0)/Intact/smoke geo").GetComponent<MeshRenderer>();
				MeshRenderer component10 = GameObject.Find("Game Logic/Snakes/SnakeDispenser/snake crate geo").GetComponent<MeshRenderer>();
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Virtual_Boolean_0();
				HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0().get_field_Protected_Material_0().SetColor("_HighlightColor", new Color(0.3f, 0f, 5f));
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component.GetComponent<SkinnedMeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component1.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer1.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component2.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer2.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component3.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer3.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component4.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer4.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component5.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer5.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component6.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(gameObject.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer6.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component7.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer7.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component8.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer8.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component9.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(meshRenderer9.GetComponent<MeshRenderer>(), u0020);
				HighlightsFX.get_field_Private_Static_HighlightsFX_0().Method_Public_Void_Renderer_Boolean_0(component10.GetComponent<MeshRenderer>(), u0020);
				yield return new WaitForSeconds(0.1f);
				component = null;
				meshRenderer = null;
				component1 = null;
				meshRenderer1 = null;
				component2 = null;
				meshRenderer2 = null;
				component3 = null;
				meshRenderer3 = null;
				component4 = null;
				meshRenderer4 = null;
				component5 = null;
				meshRenderer5 = null;
				component6 = null;
				gameObject = null;
				meshRenderer6 = null;
				component7 = null;
				meshRenderer7 = null;
				component8 = null;
				meshRenderer8 = null;
				component9 = null;
				meshRenderer9 = null;
				component10 = null;
			}
		}

		internal static Esp zrX2uqoIYEdld3cjYLZ()
		{
			return Esp.ph4LC7o7AAj2Bt1bt0s;
		}
	}
}