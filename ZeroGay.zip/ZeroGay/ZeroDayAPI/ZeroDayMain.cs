using AksgHVKH9UOXlBDvRpO;
using DdrQhYOSxxUr8ga8aOm;
using DI1Ec8yA4vBbNqCqHF;
using etGHFk2gZHdbnPrtgfG;
using GJtRdIah28mCMA5LgYD;
using HellTaker.mainshiet.patches.murder4;
using HQ1hUrGO9ZpjeNrt8c;
using Late_Night_V3;
using m4amehrzBZcmRlV97Pi;
using MelonLoader;
using MkIxZXy5I6BqBea7neY;
using Photon.Realtime;
using QQvuud280hKNN3PPqgR;
using RjT7emc7tqaURbFlcDX;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using TJCsWGiGgNfnUAT30r;
using Tr14UwanpaMXFeWIqTO;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.Networking;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayAPI.Buttons;
using ZeroDayByRetards.mainshiet.patches.ghostV1;

namespace ZeroDayAPI
{
	public class ZeroDayMain : MelonMod
	{
		public static float RunSpeed;

		public static float WalkSpeed;

		public static bool SpeedMods;

		public static bool orbitPlayer;

		public static bool SitonLeftHand;

		public static bool SitonRightHand;

		public static bool SitonHead;

		public static bool SitonRightshoulder;

		public static bool SitonLeftshoulder;

		public static bool SitonRightfeet;

		public static bool SitonLeftfeet;

		public float OrbitSpeed;

		public float OrbitDist;

		public static bool Flyenabled;

		public static Player player;

		public static GameObject Boom;

		internal static Color ysey9iAgKw;

		internal static Color Wwky0VNh1d;

		public static GameObject ENDER;

		private static ZeroDayMain YO7LcSDqFUZPe6i10TM;

		static ZeroDayMain()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			ZeroDayMain.RunSpeed = 4f;
			ZeroDayMain.WalkSpeed = 3f;
			ZeroDayMain.SpeedMods = false;
			ZeroDayMain.player = new Player();
			ZeroDayMain.ysey9iAgKw = new Color(0f, 2f, 0f, 0.4f);
			ZeroDayMain.Wwky0VNh1d = new Color(2f, 0f, 0f, 0.4f);
		}

		public ZeroDayMain()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.OrbitSpeed = 130f;
			this.OrbitDist = 2f;
			base();
		}

		public static string ColorHudText(string Msg, ConsoleColor A = 15)
		{
			string str;
			switch (A)
			{
				case ConsoleColor.Black:
				{
					str = string.Concat("<color=#000000>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkBlue:
				{
					str = string.Concat("<color=#0b0785>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkGreen:
				{
					str = string.Concat("<color=#00800b>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkCyan:
				{
					str = string.Concat("<color=#00a39b>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkRed:
				{
					str = string.Concat("<color=#8a0000>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkMagenta:
				{
					str = string.Concat("<color=#8a007c>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkYellow:
				{
					str = string.Concat("<color=#8a8a00>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Gray:
				{
					str = string.Concat("<color=##b5b5b5>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkGray:
				{
					str = string.Concat("<color=#787878>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Blue:
				{
					str = string.Concat("<color=#0400ff>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Green:
				{
					str = string.Concat("<color=#11ff00>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Cyan:
				{
					str = string.Concat("<color=#00ffea>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Red:
				{
					str = string.Concat("<color=#ff0800>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Magenta:
				{
					str = string.Concat("<color=#ff00b3>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Yellow:
				{
					str = string.Concat("<color=#fbff00>", Msg, "</color>");
					break;
				}
				default:
				{
					str = string.Concat("<color=#ffffff>", Msg, "</color>");
					break;
				}
			}
			return str;
		}

		private static void DFlyvI4PUk()
		{
			w1ZTpJvRDIlLwNIjNM.tAF9LuFi3();
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Starting UI", ConsoleColor.White));
			MelonLogger.Log("Initializing UI..");
			MelonCoroutines.Start(MainMenuLol.StartMainMenu());
			MelonCoroutines.Start(Ig3vqXaqsh9qRJd1pGc.yhxatuVTIb(true));
			MelonCoroutines.Start(Ig3vqXaqsh9qRJd1pGc.et7asF3KAT(true));
			MelonCoroutines.Start(Murder4.PatreonSync(true));
			MelonCoroutines.Start(teleports.wallbang(true));
			MelonCoroutines.Start(MaFwvJ2DbFoFIA3BUAO.CH12STXMp1(true));
			MelonCoroutines.Start(MaFwvJ2DbFoFIA3BUAO.Ggt2brRtAd(true));
			MelonCoroutines.Start(MaFwvJ2DbFoFIA3BUAO.WAV2NANpU3(true));
			MelonCoroutines.Start(MaFwvJ2DbFoFIA3BUAO.RaM2zb9Wsa(true));
			MelonCoroutines.Start(teleports.tpcal50(true));
			MelonCoroutines.Start(teleports.tpRS(true));
			MelonCoroutines.Start(teleports.tpshotty(true));
			MelonCoroutines.Start(teleports.tpvect(true));
			MelonCoroutines.Start(teleports.tpMP7(true));
			MelonCoroutines.Start(A6yTqvrNqfGTNPs86pr.fIe2Qd6Vg3(true));
			MelonCoroutines.Start(A6yTqvrNqfGTNPs86pr.y6x2n8aTdA(true));
			MelonCoroutines.Start(A6yTqvrNqfGTNPs86pr.Ybt2OuU9bX(true));
			MelonCoroutines.Start(bUqSA52JHZYZDdqgmrb.IDi2EJsn9f(true));
			MelonCoroutines.Start(MaFwvJ2DbFoFIA3BUAO.aq024tpbDQ(true));
			MelonCoroutines.Start(ZeroDayMain.speed(true));
			MelonCoroutines.Start(MaFwvJ2DbFoFIA3BUAO.EPcM5F8M00(true));
			prE4uEazR5ytqvopjEh.eUyycdqQHi();
			MelonCoroutines.Start(prE4uEazR5ytqvopjEh.YoUynyvff0(1f));
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("Finished UI", ConsoleColor.White));
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText(string.Concat("Welcome To ZeroDay, ", APIUser.get_CurrentUser().get_displayName()), ConsoleColor.White));
			VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().QueHudMessage(ZeroDayMain.ColorHudText("ZeroDayClient Made By Afton, Iris And Blaze", ConsoleColor.Magenta));
		}

		internal static ZeroDayMain JAf3QeDHaHlKtKU5lAL()
		{
			return ZeroDayMain.YO7LcSDqFUZPe6i10TM;
		}

		private static IEnumerator ksvyAZhQ4t()
		{
			return new ZeroDayMain.<CheckUI>d__4(0);
		}

		internal static void lhOydSbSxQ()
		{
			if (ZeroDayMain.Boom == null)
			{
				Vector3 bonePosition = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18);
				GameObject gameObject = GameObject.CreatePrimitive(0);
				gameObject.get_transform().set_position(bonePosition);
				gameObject.get_transform().set_localScale(new Vector3(0.1f, 0.1f, 0.1f));
				gameObject.set_name("BOOM");
				UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
				gameObject.cZRK1kpdT<BoxCollider>().set_size(new Vector3(1f, 1f, 1f));
				gameObject.cZRK1kpdT<BoxCollider>().set_isTrigger(true);
				gameObject.cZRK1kpdT<MeshRenderer>().get_material().set_color(ZeroDayMain.Wwky0VNh1d);
				gameObject.cZRK1kpdT<Rigidbody>().set_useGravity(false);
				gameObject.cZRK1kpdT<Rigidbody>().set_drag(0f);
				gameObject.cZRK1kpdT<Rigidbody>().set_angularDrag(0.01f);
				gameObject.cZRK1kpdT<VRC_Pickup>().set_pickupable(true);
				gameObject.cZRK1kpdT<VRC_Pickup>().set_ThrowVelocityBoostScale(7.5f);
				gameObject.AddComponent<ewoOruyP5ycGmhU6XIS>();
				ZeroDayMain.Boom = gameObject;
			}
			else
			{
				UnityEngine.Object.Destroy(ZeroDayMain.Boom);
				ZeroDayMain.Boom = null;
			}
		}

		public override void OnApplicationQuit()
		{
			Process.GetCurrentProcess().Kill();
		}

		public override void OnApplicationStart()
		{
			MainConfigSettings.Instance = MainConfigSettings.BQyyR6rvEc();
			ClassInjector.RegisterTypeInIl2Cpp<INoLOnoTjlV0JbUwbrx>();
			ClassInjector.RegisterTypeInIl2Cpp<Nameplate>();
			ClassInjector.RegisterTypeInIl2Cpp<cmFAXby8sKuqHARyc1s>();
			ClassInjector.RegisterTypeInIl2Cpp<ewoOruyP5ycGmhU6XIS>();
			Console.Title = "ZeroDay";
			Console.Clear();
			MelonLogger.Log("=====================================================================================");
			MelonLogger.Log("=====================================================================================");
			MelonCoroutines.Start(ZeroDayMain.ksvyAZhQ4t());
			MelonCoroutines.Start(ZeroDayMain.ViCyKtJJiq());
			(new wU7oNsOjabh7rJBPZf4("ONPlayerJoin_", typeof(NetworkManager).GetMethod("Method_Public_Void_Player_0"), Late_Night_V3.Patches.GetLocalPatch("onJoin"), null)).RyLObZBD3K();
			(new wU7oNsOjabh7rJBPZf4("ONPlayerLeft_", typeof(NetworkManager).GetMethod("Method_Public_Void_Player_1"), Late_Night_V3.Patches.GetLocalPatch("onLeft"), null)).RyLObZBD3K();
			(new wU7oNsOjabh7rJBPZf4("PhotonFaggots", typeof(LoadBalancingClient).GetMethod("OnEvent"), Late_Night_V3.Patches.GetLocalPatch("photonevents"), null)).RyLObZBD3K();
			(new wU7oNsOjabh7rJBPZf4("LogUdon", typeof(UdonSync).GetMethod("UdonSyncRunProgramAsRPC"), Late_Night_V3.Patches.GetLocalPatch("UdonLogShit"), null)).RyLObZBD3K();
			(new wU7oNsOjabh7rJBPZf4("UIconf", typeof(VRCUiManager).GetMethod(Late_Night_V3.Patches.PlaceUI().Name), Late_Night_V3.Patches.GetLocalPatch("comfyMenu"), null)).RyLObZBD3K();
			CheckForUpdates.CheckAndUpdateLol();
		}

		public override void OnSceneWasLoaded(int buildIndex, string sceneName)
		{
			Console.Title = "ZeroDay V2 by Afton, Iris & Blaze";
			Console.Clear();
			MelonLogger.Log("=====================================================================================");
			MelonLogger.Log("=====================================================================================");
		}

		public override void OnUpdate()
		{
			if ((ZeroDayMain.SitonLeftHand || ZeroDayMain.SitonRightHand || ZeroDayMain.SitonHead || ZeroDayMain.SitonLeftshoulder || ZeroDayMain.SitonRightshoulder || ZeroDayMain.SitonRightfeet || ZeroDayMain.SitonLeftfeet || ZeroDayMain.orbitPlayer ? VRCInputManager.Method_Public_Static_VRCInput_String_0("Jump").Method_Public_get_Boolean_3() : false))
			{
				ZeroDayMain.SitonLeftHand = false;
				ZeroDayMain.SitonRightHand = false;
				ZeroDayMain.SitonHead = false;
				ZeroDayMain.SitonLeftshoulder = false;
				ZeroDayMain.SitonRightshoulder = false;
				ZeroDayMain.SitonRightfeet = false;
				ZeroDayMain.SitonLeftfeet = false;
				ZeroDayMain.orbitPlayer = false;
				Physics.set_gravity(new Vector3(0f, -9.81f, 0f));
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(true);
			}
			if (ZeroDayMain.orbitPlayer)
			{
				if (Vector3.Distance(mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().get_position(), j25MPyacibgF0kcPwHe.rjYaCVqqPo.Method_Internal_get_VRCPlayer_0().get_field_Internal_GameObject_0().get_transform().get_position()) > this.OrbitDist * Time.get_deltaTime())
				{
					mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(Vector3.MoveTowards(mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().get_position(), j25MPyacibgF0kcPwHe.rjYaCVqqPo.Method_Internal_get_VRCPlayer_0().get_field_Internal_GameObject_0().get_transform().get_position(), this.OrbitSpeed));
				}
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().RotateAround(j25MPyacibgF0kcPwHe.rjYaCVqqPo.Method_Internal_get_VRCPlayer_0().get_field_Internal_GameObject_0().get_transform().get_position(), Vector3.get_up(), this.OrbitSpeed * Time.get_deltaTime());
			}
			if (ZeroDayMain.SitonLeftHand)
			{
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_field_Private_VRCPlayerApi_0().GetBonePosition(17));
			}
			if (ZeroDayMain.SitonRightHand)
			{
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_field_Private_VRCPlayerApi_0().GetBonePosition(18));
			}
			if (ZeroDayMain.SitonHead)
			{
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_field_Private_VRCPlayerApi_0().GetBonePosition(10) + new Vector3(0f, 0.15f, 0f));
			}
			if (ZeroDayMain.SitonRightshoulder)
			{
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_field_Private_VRCPlayerApi_0().GetBonePosition(12));
			}
			if (ZeroDayMain.SitonLeftshoulder)
			{
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_field_Private_VRCPlayerApi_0().GetBonePosition(11));
			}
			if (ZeroDayMain.SitonRightfeet)
			{
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_field_Private_VRCPlayerApi_0().GetBonePosition(6));
			}
			if (ZeroDayMain.SitonLeftfeet)
			{
				mDXrgOcTInjaUDi52SW.rNpcdWYZKL().get_gameObject().get_transform().set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_field_Private_VRCPlayerApi_0().GetBonePosition(5));
			}
		}

		private static void p0hylolhcn()
		{
			HighlightsFX fieldPrivateStaticHighlightsFX0 = HighlightsFX.get_field_Private_Static_HighlightsFX_0();
			Esp.keys = fieldPrivateStaticHighlightsFX0.get_gameObject().AddComponent<HighlightsFXStandalone>();
			Esp.keys.set_highlightColor(Color.get_cyan());
			Esp.folders = fieldPrivateStaticHighlightsFX0.get_gameObject().AddComponent<HighlightsFXStandalone>();
			Esp.folders.set_highlightColor(Color.get_yellow());
			Esp.pickuphighlight = fieldPrivateStaticHighlightsFX0.get_gameObject().AddComponent<HighlightsFXStandalone>();
			Esp.pickuphighlight.set_highlightColor(Color.get_yellow());
			Esp._friendsHighlights = fieldPrivateStaticHighlightsFX0.get_gameObject().AddComponent<HighlightsFXStandalone>();
			Esp._friendsHighlights.set_highlightColor(new Color(0.4157f, 0f, 1f, 1f));
			Esp._othersHighlights = fieldPrivateStaticHighlightsFX0.get_gameObject().AddComponent<HighlightsFXStandalone>();
			Esp._othersHighlights.set_highlightColor(Color.get_red());
			MelonCoroutines.Start(Fi4AeSAEDIdGC4tGAq.twwdLZsT6());
			MelonCoroutines.Start(loadingsong.StartSong());
			Color color = new Color(0.4157f, 0f, 1f, 1f);
			GameObject gameObject = GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/SkyCube_Baked");
			MelonCoroutines.Start(ZeroDayMain.XF6yiLumwH());
			GameObject gameObject1 = UnityEngine.Object.Instantiate<GameObject>(GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles/FX_snow"), GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles").get_transform());
			gameObject1.GetComponent<ParticleSystem>().get_trails().set_mode(1);
			gameObject1.GetComponent<ParticleSystem>().set_emissionRate(2f);
			gameObject.set_active(false);
		}

		internal static bool pm8nuTDhylfISYe9mY5()
		{
			return ZeroDayMain.YO7LcSDqFUZPe6i10TM == null;
		}

		public static IEnumerator speed(bool state)
		{
			while (true)
			{
				if (!ZeroDayMain.SpeedMods)
				{
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					Networking.get_LocalPlayer().SetWalkSpeed(ZeroDayMain.WalkSpeed);
					Networking.get_LocalPlayer().SetRunSpeed(ZeroDayMain.RunSpeed);
					Networking.get_LocalPlayer().SetStrafeSpeed(ZeroDayMain.WalkSpeed);
					yield return new WaitForSeconds(0.1f);
				}
			}
		}

		internal static void T7GyGLO04Q()
		{
			if (ZeroDayMain.ENDER == null)
			{
				Vector3 bonePosition = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18);
				GameObject gameObject = GameObject.CreatePrimitive(0);
				gameObject.get_transform().set_position(bonePosition);
				gameObject.get_transform().set_localScale(new Vector3(0.1f, 0.1f, 0.1f));
				gameObject.set_name("Ender");
				UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
				gameObject.cZRK1kpdT<BoxCollider>().set_size(new Vector3(1f, 1f, 1f));
				gameObject.cZRK1kpdT<BoxCollider>().set_isTrigger(true);
				gameObject.cZRK1kpdT<MeshRenderer>().get_material().set_color(ZeroDayMain.ysey9iAgKw);
				gameObject.cZRK1kpdT<Rigidbody>().set_useGravity(false);
				gameObject.cZRK1kpdT<Rigidbody>().set_drag(0f);
				gameObject.cZRK1kpdT<Rigidbody>().set_angularDrag(0.01f);
				gameObject.cZRK1kpdT<VRC_Pickup>().set_pickupable(true);
				gameObject.cZRK1kpdT<VRC_Pickup>().set_ThrowVelocityBoostScale(9.5f);
				gameObject.cZRK1kpdT<cmFAXby8sKuqHARyc1s>();
				ZeroDayMain.ENDER = gameObject;
			}
			else
			{
				UnityEngine.Object.Destroy(ZeroDayMain.ENDER);
				ZeroDayMain.ENDER = null;
			}
		}

		private static IEnumerator ViCyKtJJiq()
		{
			while (UnityEngine.Object.FindObjectOfType<QuickMenu>() == null)
			{
				yield return null;
			}
			ZeroDayMain.DFlyvI4PUk();
		}
	}
}