using Apollo_Base.Modules;
using Area51.Events;
using b3eD5DgJPcASx0xfHYB;
using BBagbqkNIJ3q0STpvuq;
using DW6c39Q48fhvTF5jMI;
using gpd3oZtw5qhYneWRlWY;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using VRC;
using VRC.SDKBase;

namespace ZeroDayAPI
{
	public class ZeroDayMain : MelonMod
	{
		public static float RunSpeed;

		public static float WalkSpeed;

		public static bool SpeedMods;

		public static bool orbitPlayer;

		public static bool SitonLeftHand;

		public static bool SitonRightHand;

		public static bool SitonHead;

		public static bool SitonRightshoulder;

		public static bool SitonLeftshoulder;

		public static bool SitonRightfeet;

		public static bool SitonLeftfeet;

		public float OrbitSpeed;

		public float OrbitDist;

		public static bool Flyenabled;

		public static Player player;

		public static GameObject Boom;

		public static GameObject BoomConst;

		internal static Color vEXQAVEy7j;

		internal static Color QlSQVF1ekk;

		public static GameObject ENDER;

		internal static ZeroDayMain KSSgESoU9GEu19RWkaO;

		public static ZeroDayMain Instance
		{
			get;
			set;
		}

		public OnAssetBundleLoadEvent[] OnAssetBundleLoadEventArray
		{
			get;
			set;
		}

		public List<OnAssetBundleLoadEvent> OnAssetBundleLoadEvents
		{
			get;
			set;
		}

		static ZeroDayMain()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			ZeroDayMain.RunSpeed = 4f;
			ZeroDayMain.WalkSpeed = 3f;
			ZeroDayMain.SpeedMods = false;
			ZeroDayMain.player = new Player();
			ZeroDayMain.vEXQAVEy7j = new Color(0f, 2f, 0f, 0.4f);
			ZeroDayMain.QlSQVF1ekk = new Color(2f, 0f, 0f, 0.4f);
		}

		public ZeroDayMain()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.OrbitSpeed = 130f;
			this.OrbitDist = 2f;
			this.cZWQLmWi09 = new List<ModuleBase>();
			this.OnAssetBundleLoadEventArray = new OnAssetBundleLoadEvent[0];
			this.OnAssetBundleLoadEvents = new List<OnAssetBundleLoadEvent>();
			base();
		}

		public static string ColorHudText(string Msg, ConsoleColor A = 15)
		{
			string str;
			switch (A)
			{
				case ConsoleColor.Black:
				{
					str = string.Concat("<color=#000000>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkBlue:
				{
					str = string.Concat("<color=#0b0785>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkGreen:
				{
					str = string.Concat("<color=#00800b>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkCyan:
				{
					str = string.Concat("<color=#00a39b>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkRed:
				{
					str = string.Concat("<color=#8a0000>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkMagenta:
				{
					str = string.Concat("<color=#8a007c>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkYellow:
				{
					str = string.Concat("<color=#8a8a00>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Gray:
				{
					str = string.Concat("<color=##b5b5b5>", Msg, "</color>");
					break;
				}
				case ConsoleColor.DarkGray:
				{
					str = string.Concat("<color=#787878>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Blue:
				{
					str = string.Concat("<color=#0400ff>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Green:
				{
					str = string.Concat("<color=#11ff00>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Cyan:
				{
					str = string.Concat("<color=#00ffea>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Red:
				{
					str = string.Concat("<color=#ff0800>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Magenta:
				{
					str = string.Concat("<color=#ff00b3>", Msg, "</color>");
					break;
				}
				case ConsoleColor.Yellow:
				{
					str = string.Concat("<color=#fbff00>", Msg, "</color>");
					break;
				}
				default:
				{
					str = string.Concat("<color=#ffffff>", Msg, "</color>");
					break;
				}
			}
			return str;
		}

		internal static ZeroDayMain D3ZQw3ovmTZoAnQf2e2()
		{
			return ZeroDayMain.KSSgESoU9GEu19RWkaO;
		}

		private static void EgfQeGD9Xs()
		{
			// 
			// Current member / type: System.Void ZeroDayAPI.ZeroDayMain::EgfQeGD9Xs()
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void EgfQeGD9Xs()
			// 
			// Object reference not set to an instance of an object.
			//    at ..(UInt32 , Instruction ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 313
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 162
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 118
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 128
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 56
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		internal static bool F64TueoTi0g97tjTsHv()
		{
			return ZeroDayMain.KSSgESoU9GEu19RWkaO == null;
		}

		public override void OnApplicationQuit()
		{
			Process.GetCurrentProcess().Kill();
		}

		public override void OnApplicationStart()
		{
			// 
			// Current member / type: System.Void ZeroDayAPI.ZeroDayMain::OnApplicationStart()
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void OnApplicationStart()
			// 
			// Index was out of range. Must be non-negative and less than the size of the collection.
			// Parameter name: index
			//    at System.ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument argument, ExceptionResource resource)
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 184
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 118
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 56
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public override void OnSceneWasLoaded(int buildIndex, string sceneName)
		{
			Console.Title = "ZeroDay V2 by Afton, Iris & Blaze";
			Console.Clear();
			MelonLogger.Log("=====================================================================================");
			MelonLogger.Log("=====================================================================================");
		}

		public override void OnUpdate()
		{
			if ((ZeroDayMain.SitonLeftHand || ZeroDayMain.SitonRightHand || ZeroDayMain.SitonHead || ZeroDayMain.SitonLeftshoulder || ZeroDayMain.SitonRightshoulder || ZeroDayMain.SitonRightfeet || ZeroDayMain.SitonLeftfeet || ZeroDayMain.orbitPlayer) && VRCInputManager.Method_Public_Static_VRCInput_String_0("Jump").Method_Public_get_Boolean_3())
			{
				ZeroDayMain.SitonLeftHand = false;
				ZeroDayMain.SitonRightHand = false;
				ZeroDayMain.SitonHead = false;
				ZeroDayMain.SitonLeftshoulder = false;
				ZeroDayMain.SitonRightshoulder = false;
				ZeroDayMain.SitonRightfeet = false;
				ZeroDayMain.SitonLeftfeet = false;
				ZeroDayMain.orbitPlayer = false;
				Physics.set_gravity(new Vector3(0f, -9.81f, 0f));
				VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_gameObject().GetComponent<CharacterController>().set_enabled(true);
			}
			if (ZeroDayMain.orbitPlayer)
			{
				if (Vector3.Distance(j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().get_position(), QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.Method_Internal_get_VRCPlayer_0().get_field_Internal_GameObject_0().get_transform().get_position()) > this.OrbitDist * Time.get_deltaTime())
				{
					j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(Vector3.MoveTowards(j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().get_position(), QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.Method_Internal_get_VRCPlayer_0().get_field_Internal_GameObject_0().get_transform().get_position(), this.OrbitSpeed));
				}
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().RotateAround(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.Method_Internal_get_VRCPlayer_0().get_field_Internal_GameObject_0().get_transform().get_position(), Vector3.get_up(), this.OrbitSpeed * Time.get_deltaTime());
			}
			if (ZeroDayMain.SitonLeftHand)
			{
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_field_Private_VRCPlayerApi_0().GetBonePosition(17));
			}
			if (ZeroDayMain.SitonRightHand)
			{
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_field_Private_VRCPlayerApi_0().GetBonePosition(18));
			}
			if (ZeroDayMain.SitonHead)
			{
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_field_Private_VRCPlayerApi_0().GetBonePosition(10) + new Vector3(0f, 0.15f, 0f));
			}
			if (ZeroDayMain.SitonRightshoulder)
			{
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_field_Private_VRCPlayerApi_0().GetBonePosition(12));
			}
			if (ZeroDayMain.SitonLeftshoulder)
			{
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_field_Private_VRCPlayerApi_0().GetBonePosition(11));
			}
			if (ZeroDayMain.SitonRightfeet)
			{
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_field_Private_VRCPlayerApi_0().GetBonePosition(6));
			}
			if (ZeroDayMain.SitonLeftfeet)
			{
				j7Ipg1kwBirUGgO7rnG.s5QkYRroxn().get_gameObject().get_transform().set_position(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_field_Private_VRCPlayerApi_0().GetBonePosition(5));
			}
		}

		private static void OwkQ0XwpaD()
		{
			// 
			// Current member / type: System.Void ZeroDayAPI.ZeroDayMain::OwkQ0XwpaD()
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Void OwkQ0XwpaD()
			// 
			// Index was out of range. Must be non-negative and less than the size of the collection.
			// Parameter name: index
			//    at System.ThrowHelper.ThrowArgumentOutOfRangeException(ExceptionArgument argument, ExceptionResource resource)
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 184
			//    at ..( , Int32[] ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 118
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 74
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DefineUseAnalysis\StackUsageAnalysis.cs:line 56
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public static IEnumerator pickupconst()
		{
			ZeroDayMain.x6lQn0YHwu();
			yield return new WaitForSeconds(2f);
			GameObject gameObject = GameObject.Find("CONSTBOOM");
			while (true)
			{
				yield return new WaitForSeconds(0.05f);
				gameObject.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18));
				gameObject.get_transform().set_localScale(new Vector3(0.3f, 0.3f, 0.3f));
			}
		}

		internal static void ruKQrE1lDf()
		{
			if (ZeroDayMain.Boom == null)
			{
				Vector3 bonePosition = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18);
				GameObject gameObject = GameObject.CreatePrimitive(0);
				gameObject.get_transform().set_position(bonePosition);
				gameObject.get_transform().set_localScale(new Vector3(0.1f, 0.1f, 0.1f));
				gameObject.set_name("BOOM");
				UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
				gameObject.hlCglFD42<BoxCollider>().set_size(new Vector3(1f, 1f, 1f));
				gameObject.hlCglFD42<BoxCollider>().set_isTrigger(true);
				gameObject.hlCglFD42<MeshRenderer>().get_material().set_color(ZeroDayMain.QlSQVF1ekk);
				gameObject.hlCglFD42<Rigidbody>().set_useGravity(false);
				gameObject.hlCglFD42<Rigidbody>().set_drag(0f);
				gameObject.hlCglFD42<Rigidbody>().set_angularDrag(0.01f);
				gameObject.hlCglFD42<VRC_Pickup>().set_pickupable(true);
				gameObject.hlCglFD42<VRC_Pickup>().set_ThrowVelocityBoostScale(7.5f);
				gameObject.AddComponent<fxTgUnwhYhYpJGMgKT3>();
				ZeroDayMain.Boom = gameObject;
			}
			else
			{
				UnityEngine.Object.Destroy(ZeroDayMain.Boom);
				ZeroDayMain.Boom = null;
			}
		}

		internal static void RVvQpLs62c()
		{
			if (ZeroDayMain.ENDER != null)
			{
				UnityEngine.Object.Destroy(ZeroDayMain.ENDER);
				ZeroDayMain.ENDER = null;
			}
			else
			{
				Vector3 bonePosition = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18);
				GameObject gameObject = GameObject.CreatePrimitive(0);
				gameObject.get_transform().set_position(bonePosition);
				gameObject.get_transform().set_localScale(new Vector3(0.1f, 0.1f, 0.1f));
				gameObject.set_name("Ender");
				UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
				gameObject.hlCglFD42<BoxCollider>().set_size(new Vector3(1f, 1f, 1f));
				gameObject.hlCglFD42<BoxCollider>().set_isTrigger(true);
				gameObject.hlCglFD42<MeshRenderer>().get_material().set_color(ZeroDayMain.vEXQAVEy7j);
				gameObject.hlCglFD42<Rigidbody>().set_useGravity(false);
				gameObject.hlCglFD42<Rigidbody>().set_drag(0f);
				gameObject.hlCglFD42<Rigidbody>().set_angularDrag(0.01f);
				gameObject.hlCglFD42<VRC_Pickup>().set_pickupable(true);
				gameObject.hlCglFD42<VRC_Pickup>().set_ThrowVelocityBoostScale(9.5f);
				gameObject.hlCglFD42<b3d8XTwQ9fVOFfxeNFl>();
				ZeroDayMain.ENDER = gameObject;
			}
		}

		internal static void x6lQn0YHwu()
		{
			Vector3 bonePosition = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0().GetBonePosition(18);
			GameObject gameObject = GameObject.CreatePrimitive(0);
			gameObject.get_transform().set_position(bonePosition);
			gameObject.get_transform().set_localScale(new Vector3(0.1f, 0.1f, 0.1f));
			gameObject.set_name("CONSTBOOM");
			UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
			gameObject.hlCglFD42<BoxCollider>().set_size(new Vector3(1f, 1f, 1f));
			gameObject.hlCglFD42<BoxCollider>().set_isTrigger(true);
			gameObject.hlCglFD42<MeshRenderer>().get_material().set_color(ZeroDayMain.QlSQVF1ekk);
			gameObject.hlCglFD42<Rigidbody>().set_useGravity(false);
			gameObject.hlCglFD42<Rigidbody>().set_drag(0f);
			gameObject.hlCglFD42<Rigidbody>().set_angularDrag(0.01f);
			gameObject.hlCglFD42<VRC_Pickup>().set_pickupable(true);
			gameObject.hlCglFD42<VRC_Pickup>().set_ThrowVelocityBoostScale(7.5f);
			gameObject.AddComponent<rhXTB0w7WmOU6Pc4JBk>();
			ZeroDayMain.BoomConst = gameObject;
		}
	}
}