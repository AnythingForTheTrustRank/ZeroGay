using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace ZeroDayAPI
{
	public class loadingsong
	{
		private static AudioSource dtQyhKlYFD;

		private static AudioSource vpoyHGcaLv;

		internal static loadingsong SJQQtqDrNa2lbkTdWFb;

		public loadingsong()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool FXo4GSD2NFNKewguaPJ()
		{
			return loadingsong.SJQQtqDrNa2lbkTdWFb == null;
		}

		internal static loadingsong NgPwDXDMPvweRWxn6TV()
		{
			return loadingsong.SJQQtqDrNa2lbkTdWFb;
		}

		public static IEnumerator StartSong()
		{
			object component;
			object component1;
			object obj1;
			object obj2;
			string[] strArrays = new string[] { "//music.wixstatic.com/preview/085ec5_64efc30ee74a4b68b6d1feaf4c9662d4-128.mp3" };
			UnityEngine.Random random = new UnityEngine.Random();
			while (true)
			{
				GameObject gameObject = GameObject.Find("/UserInterface");
				if (gameObject != null)
				{
					Transform transform = gameObject.get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound");
					if (transform == null)
					{
						component = null;
					}
					else
					{
						component = transform.GetComponent<AudioSource>();
					}
					obj1 = component;
					transform = null;
				}
				else
				{
					obj1 = null;
				}
				if ((UnityEngine.Object)obj1 != null)
				{
					break;
				}
				while (true)
				{
					GameObject gameObject1 = GameObject.Find("/UserInterface");
					if (gameObject1 != null)
					{
						Transform transform1 = gameObject1.get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound");
						if (transform1 != null)
						{
							component1 = transform1.GetComponent<AudioSource>();
						}
						else
						{
							component1 = null;
						}
						obj2 = component1;
						transform1 = null;
					}
					else
					{
						obj2 = null;
					}
					if ((UnityEngine.Object)obj2 != null)
					{
						break;
					}
					yield return null;
					gameObject1 = null;
					obj2 = null;
				}
				gameObject = null;
				obj1 = null;
			}
			loadingsong.dtQyhKlYFD = GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>();
			loadingsong.vpoyHGcaLv = GameObject.Find("UserInterface/LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>();
			UnityWebRequest unityWebRequest = UnityWebRequest.Get("//music.wixstatic.com/preview/085ec5_64efc30ee74a4b68b6d1feaf4c9662d4-128.mp3");
			unityWebRequest.SendWebRequest();
			while (!unityWebRequest.get_isDone())
			{
				yield return null;
			}
			if (!unityWebRequest.get_isHttpError())
			{
				AudioClip audioClip = WebRequestWWW.InternalCreateAudioClipUsingDH(unityWebRequest.get_downloadHandler(), unityWebRequest.get_url(), false, false, 0);
				loadingsong.dtQyhKlYFD.set_clip(audioClip);
				loadingsong.vpoyHGcaLv.set_clip(audioClip);
				audioClip.set_name("ZeroDay Sound");
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().set_clip(audioClip);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().set_clip(audioClip);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().set_maxVolume(float.MaxValue);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().set_maxVolume(float.MaxValue);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().set_volume(3f);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().set_volume(3f);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().Play();
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().Play();
				audioClip = null;
			}
		}
	}
}