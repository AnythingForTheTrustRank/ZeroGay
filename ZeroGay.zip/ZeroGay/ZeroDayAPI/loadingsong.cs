using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Networking;

namespace ZeroDayAPI
{
	public class loadingsong
	{
		private static AudioSource UHCQPvli6Q;

		private static AudioSource Nb9QlecFox;

		internal static loadingsong onc2VFo6WLSYiGI1X7N;

		public loadingsong()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool BnYaKcot2IMcbCjqes5()
		{
			return loadingsong.onc2VFo6WLSYiGI1X7N == null;
		}

		internal static loadingsong pd0sjDoQVloG5jlgYG1()
		{
			return loadingsong.onc2VFo6WLSYiGI1X7N;
		}

		public static IEnumerator StartSong()
		{
			object component;
			object component1;
			object obj1;
			object obj2;
			string[] strArrays = new string[] { "//music.wixstatic.com/preview/085ec5_64efc30ee74a4b68b6d1feaf4c9662d4-128.mp3" };
			UnityEngine.Random random = new UnityEngine.Random();
			while (true)
			{
				GameObject gameObject = GameObject.Find("/UserInterface");
				if (gameObject == null)
				{
					obj1 = null;
				}
				else
				{
					Transform transform = gameObject.get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound");
					if (transform != null)
					{
						component1 = transform.GetComponent<AudioSource>();
					}
					else
					{
						component1 = null;
					}
					obj1 = component1;
					transform = null;
				}
				if ((UnityEngine.Object)obj1 != null)
				{
					break;
				}
				while (true)
				{
					GameObject gameObject1 = GameObject.Find("/UserInterface");
					if (gameObject1 == null)
					{
						obj2 = null;
					}
					else
					{
						Transform transform1 = gameObject1.get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound");
						if (transform1 == null)
						{
							component = null;
						}
						else
						{
							component = transform1.GetComponent<AudioSource>();
						}
						obj2 = component;
						transform1 = null;
					}
					if ((UnityEngine.Object)obj2 != null)
					{
						break;
					}
					yield return null;
					gameObject1 = null;
					obj2 = null;
				}
				gameObject = null;
				obj1 = null;
			}
			loadingsong.UHCQPvli6Q = GameObject.Find("UserInterface/MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>();
			loadingsong.Nb9QlecFox = GameObject.Find("UserInterface/LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>();
			UnityWebRequest unityWebRequest = UnityWebRequest.Get("//music.wixstatic.com/preview/085ec5_64efc30ee74a4b68b6d1feaf4c9662d4-128.mp3");
			unityWebRequest.SendWebRequest();
			while (!unityWebRequest.get_isDone())
			{
				yield return null;
			}
			if (!unityWebRequest.get_isHttpError())
			{
				AudioClip audioClip = WebRequestWWW.InternalCreateAudioClipUsingDH(unityWebRequest.get_downloadHandler(), unityWebRequest.get_url(), false, false, 0);
				loadingsong.UHCQPvli6Q.set_clip(audioClip);
				loadingsong.Nb9QlecFox.set_clip(audioClip);
				audioClip.set_name("ZeroDay Sound");
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().set_clip(audioClip);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().set_clip(audioClip);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().set_maxVolume(float.MaxValue);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().set_maxVolume(float.MaxValue);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().set_volume(3f);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().set_volume(3f);
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("LoadingBackground_TealGradient_Music/LoadingSound").GetComponent<AudioSource>().Play();
				VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().get_transform().Find("MenuContent/Popups/LoadingPopup/LoadingSound").GetComponent<AudioSource>().Play();
				audioClip = null;
			}
		}
	}
}