using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using znK53UQmmAuKkotHsBI;

namespace ZeroDayAPI.Buttons
{
	public class ZombieTag
	{
		private static ZombieTag FX473oofmEUxnJWjZEo;

		public ZombieTag()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool sjKA7ioxe4TNybMNuNv()
		{
			return ZombieTag.FX473oofmEUxnJWjZEo == null;
		}

		public static void StartZTag()
		{
			QMNestedButton zombieTagLmao = MainMenuLol.ZombieTagLmao;
			QMNestedButton qMNestedButton = zombieTagLmao;
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton = new QMSingleButton(qMNestedButton, 1f, 0f, "Make Human", () => KYjPthQoq2k24rGvLhO.F65QcboWl2("MakeHuman"), "", nullable1, nullable, false);
			QMNestedButton qMNestedButton1 = zombieTagLmao;
			nullable = null;
			Color? nullable2 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton1 = new QMSingleButton(qMNestedButton1, 1f, 1f, "Make Zombie", () => KYjPthQoq2k24rGvLhO.F65QcboWl2("MakeZombie"), "", nullable2, nullable, false);
			QMNestedButton qMNestedButton2 = zombieTagLmao;
			nullable = null;
			Color? nullable3 = nullable;
			nullable = null;
			QMSingleButton qMSingleButton2 = new QMSingleButton(qMNestedButton2, 1f, 2f, "QuitGame", () => KYjPthQoq2k24rGvLhO.F65QcboWl2("QuitGame"), "", nullable3, nullable, false);
		}

		internal static ZombieTag Tgt3aso1ofPsIL4OHxJ()
		{
			return ZombieTag.FX473oofmEUxnJWjZEo;
		}
	}
}