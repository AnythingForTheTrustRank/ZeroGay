using b3eD5DgJPcASx0xfHYB;
using Blaze.API.QM;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using UnityEngine.XR;
using VRC.Core;
using ZeroDayClientByRetards.MainClient.UI.Buttons;

namespace ZeroDayAPI.Buttons
{
	public class MainMenuLol
	{
		internal static QMNestedButton AT3wMingXk;

		public static QMNestedButton gamesetting;

		public static QMNestedButton photonexploits;

		public static QMNestedButton WorldGameHacks;

		public static QMNestedButton Loggers;

		public static QMNestedButton mirrors;

		public static QMNestedButton BaseExploits;

		public static QMNestedButton PenExploits;

		public static QMNestedButton murder;

		public static QMNestedButton amongus;

		public static QMNestedButton GhostV17;

		public static QMNestedButton AntiCrash;

		public static QMNestedButton Photon;

		public static QMNestedButton movement;

		public static QMNestedButton Flight;

		public static QMNestedButton Jump;

		public static QMNestedButton Speed;

		public static QMNestedButton MicOptions;

		public static QMNestedButton Esp;

		public static QMNestedButton playerinfos;

		public static QMNestedButton murderinteract;

		public static QMNestedButton amonginteract;

		public static QMNestedButton ghostinteract;

		public static QMNestedButton interactattatch;

		public static QMNestedButton towerdefender;

		public static QMNestedButton selfmenu;

		public static QMNestedButton worldsmenu;

		public static QMSingleButton consolebutton;

		public static QMNestedButton utilitiesselecteduser;

		public static QMNestedButton ZombieTagLmao;

		public static QMToggleButton anticrash;

		public static QMInfo playerlist;

		public static float linecheck;

		public static Sprite justicelol;

		internal static MainMenuLol d9bh2LorvFHFBrrkv3Z;

		public MainMenuLol()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool aop4dfonDZpAiuGlUof()
		{
			return MainMenuLol.d9bh2LorvFHFBrrkv3Z == null;
		}

		public static void LogAPIDEBUGGER(string text)
		{
			MainMenuLol.linecheck += 1f;
			QMSingleButton qMSingleButton = MainMenuLol.consolebutton;
			string str = DateTime.Now.ToString("HH:mm:ss");
			if (MainMenuLol.linecheck > 19f)
			{
				MainMenuLol.linecheck = 0f;
				qMSingleButton.SetButtonText("");
			}
			TextMeshProUGUI component = qMSingleButton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_text(string.Concat(new string[] { component.get_text(), "<color=white>- [", str, "]</color><color=#5100ff> [ZeroDay]</color>   <color=#ff007a>[API]:  ", text, "</color>\n" }));
		}

		public static void logjoin(string text)
		{
			MainMenuLol.linecheck += 1f;
			QMSingleButton qMSingleButton = MainMenuLol.consolebutton;
			string str = DateTime.Now.ToString("HH:mm:ss");
			if (MainMenuLol.linecheck > 19f)
			{
				MainMenuLol.linecheck = 0f;
				qMSingleButton.SetButtonText("");
			}
			TextMeshProUGUI component = qMSingleButton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_text(string.Concat(new string[] { component.get_text(), "<color=white>- [", str, "]</color><color=#5100ff> [ZeroDay]</color>  <color=#ff00cc>[+]:  ", text, "</color>\n" }));
		}

		public static void logleave(string text)
		{
			MainMenuLol.linecheck += 1f;
			QMSingleButton qMSingleButton = MainMenuLol.consolebutton;
			string str = DateTime.Now.ToString("HH:mm:ss");
			if (MainMenuLol.linecheck > 19f)
			{
				MainMenuLol.linecheck = 0f;
				qMSingleButton.SetButtonText("");
			}
			TextMeshProUGUI component = qMSingleButton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_text(string.Concat(new string[] { component.get_text(), "<color=white>- [", str, "]</color><color=#5100ff> [ZeroDay]</color>   <color=#6b6b6b>[-]:  ", text, "</color>\n" }));
		}

		public static void LogUDONDEBUGGER(string text)
		{
			MainMenuLol.linecheck += 1f;
			QMSingleButton qMSingleButton = MainMenuLol.consolebutton;
			string str = DateTime.Now.ToString("HH:mm:ss");
			if (MainMenuLol.linecheck > 19f)
			{
				MainMenuLol.linecheck = 0f;
				qMSingleButton.SetButtonText("");
			}
			TextMeshProUGUI component = qMSingleButton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_text(string.Concat(new string[] { component.get_text(), "<color=white>- [", str, "]</color><color=#5100ff> [ZeroDay]</color>   <color=yellow>[UDON]:  ", text, "</color>\n" }));
		}

		public static IEnumerator StartMainMenu()
		{
			MainMenuLol.AT3wMingXk = new QMNestedButton("Menu_Dashboard", "ZeroDay", 2f, 3.5f, "ZeroDay Lol", "ZeroDay");
			MainMenuLol.gamesetting = new QMNestedButton("Menu_Dashboard", "Game \n Settings", 3f, 3.5f, "", "Game Settings");
			MainMenuLol.photonexploits = new QMNestedButton(MainMenuLol.AT3wMingXk, "Photon Exploits", 1f, 0f, "", "Photon Exploits");
			MainMenuLol.playerlist = new QMInfo(GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/Wing_Right/Button").get_transform(), 1f, 0f, 2f, 2f, "ZeroDay Info");
			MainMenuLol.WorldGameHacks = new QMNestedButton(MainMenuLol.AT3wMingXk, "World \n Game \n Hacks", 1f, 1f, "", "WorldGameHacks");
			MainMenuLol.Loggers = new QMNestedButton(MainMenuLol.AT3wMingXk, "Logging", 1f, 2f, "", "Logging");
			MainMenuLol.mirrors = new QMNestedButton(MainMenuLol.AT3wMingXk, "Mirrors", 1f, 3f, "", "Mirror");
			MainMenuLol.BaseExploits = new QMNestedButton(MainMenuLol.AT3wMingXk, "Base Exploits", 2f, 0f, "", "Base Exploits");
			MainMenuLol.murder = new QMNestedButton(MainMenuLol.WorldGameHacks, "Murder", 2f, 1f, "", "Murder 4");
			MainMenuLol.amongus = new QMNestedButton(MainMenuLol.WorldGameHacks, "Among Us", 2f, 2f, "", "Among Us");
			MainMenuLol.GhostV17 = new QMNestedButton(MainMenuLol.WorldGameHacks, "Ghost V21", 2f, 3f, "", "Ghost V21");
			MainMenuLol.movement = new QMNestedButton(MainMenuLol.AT3wMingXk, "Movement", 2f, 1f, "", "Movement");
			MainMenuLol.Flight = new QMNestedButton(MainMenuLol.movement, "Flight", 1f, 0f, "", "Flight");
			MainMenuLol.Jump = new QMNestedButton(MainMenuLol.movement, "Jump", 2f, 0f, "", "Jump");
			MainMenuLol.Speed = new QMNestedButton(MainMenuLol.movement, "Speed", 3f, 0f, "", "Speed");
			MainMenuLol.MicOptions = new QMNestedButton(MainMenuLol.AT3wMingXk, "Mic Options", 2f, 2f, "", "Mic Options");
			MainMenuLol.Esp = new QMNestedButton(MainMenuLol.AT3wMingXk, "ESP", 2f, 3f, "", "");
			MainMenuLol.selfmenu = new QMNestedButton(MainMenuLol.AT3wMingXk, "Self \n Menu", 3f, 0f, "", "Self Menu");
			MainMenuLol.worldsmenu = new QMNestedButton(MainMenuLol.AT3wMingXk, "World Options", 3f, 1f, "", "World Options");
			MainMenuLol.Photon = new QMNestedButton(MainMenuLol.AT3wMingXk, "Anti Events", 3f, 2f, "", "Anti Events");
			MainMenuLol.utilitiesselecteduser = new QMNestedButton("Menu_SelectedUser_Local", "Utilities", 1.3f, -0.9f, "", "Utilities");
			MainMenuLol.murderinteract = new QMNestedButton("Menu_SelectedUser_Local", "Murder", 2f, -0.9f, "", "Murder Interactions");
			MainMenuLol.amonginteract = new QMNestedButton("Menu_SelectedUser_Local", "Among Us", 2.7f, -0.9f, "", "Among Interactions");
			MainMenuLol.ghostinteract = new QMNestedButton("Menu_SelectedUser_Local", "Ghost", 3.4f, -0.9f, "", "Ghost Interactions");
			Sprite sprite = new Sprite();
			UnityWebRequest texture = UnityWebRequestTexture.GetTexture("https://i.imgur.com/yia0emM.png");
			yield return texture.SendWebRequest();
			if (texture.get_isNetworkError() || texture.get_isHttpError())
			{
				MelonLogger.LogError(texture.get_error());
			}
			else
			{
				Texture2D content = DownloadHandlerTexture.GetContent(texture);
				Sprite sprite1 = Sprite.CreateSprite(content, new Rect(0f, 0f, (float)content.get_width(), (float)content.get_height()), new Vector2((float)(content.get_width() / 2), (float)(content.get_height() / 2)), 100000f, 1000, 0, Vector4.get_zero(), false);
				UnityEngine.Object.Destroy((UnityEngine.Object)MainMenuLol.AT3wMingXk.GetMainButton().GetGameObject().GetComponent<StyleElement>());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer01").GetComponent<Image>().set_color(Color.get_black());
				content = null;
				sprite1 = null;
			}
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			MainMenuLol.consolebutton = new QMSingleButton("Menu_Dashboard", 2.05f, 2.3f, "", () => {
			}, "", nullable1, nullable, false);
			TextMeshProUGUI component = MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_fontSize(2.5f);
			component.set_m_isUsingBold(true);
			component.set_alignment(257);
			component.set_enableWordWrapping(false);
			component.set_maxVisibleLines(19);
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(139.01f, -152.2081f, 0f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localScale(new Vector3(6f, 6f, 5.5f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().set_localPosition(new Vector3(-0.0317f, -68.7f, 0.0005f));
			Sprite sprite2 = new Sprite();
			UnityWebRequest unityWebRequest = UnityWebRequestTexture.GetTexture("https://i.imgur.com/Q4juzES.png");
			yield return unityWebRequest.SendWebRequest();
			if (unityWebRequest.get_isNetworkError() || unityWebRequest.get_isHttpError())
			{
				MelonLogger.LogError(unityWebRequest.get_error());
			}
			else
			{
				Texture2D texture2D = DownloadHandlerTexture.GetContent(unityWebRequest);
				Sprite sprite3 = Sprite.CreateSprite(texture2D, new Rect(0f, 0f, (float)texture2D.get_width(), (float)texture2D.get_height()), new Vector2((float)(texture2D.get_width() / 2), (float)(texture2D.get_height() / 2)), 100000f, 1000, 0, Vector4.get_zero(), false);
				MainMenuLol.consolebutton.SetButtonText("");
				RectTransform rectTransform = MainMenuLol.consolebutton.GetGameObject().GetComponent<RectTransform>();
				rectTransform.set_sizeDelta(rectTransform.get_sizeDelta() * new Vector2(6f, 2.5f));
				MainMenuLol.consolebutton.SetBackgroundImage(sprite3);
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").set_active(true);
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").GetComponent<Image>().set_color(Color.get_black());
				MelonLogger.Log("Loading Sprite Textures..");
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").get_transform().set_localScale(new Vector3(1.05f, 1.05f, 1f));
				texture2D = null;
				sprite3 = null;
			}
			ZeroDayClientByRetards.MainClient.UI.Buttons.photonexploits.StartPhotonExploits();
			baseexploits.StartBaseExploits();
			GameSettings.StartGameSettings();
			ZeroDayClientByRetards.MainClient.UI.Buttons.murder.StartMurder();
			ZeroDayClientByRetards.MainClient.UI.Buttons.amongus.StartAmigos();
			ZeroDayClientByRetards.MainClient.UI.Buttons.Flight.StartFlight();
			speed.StartSpeed();
			ESP.StartESP();
			ZeroDayClientByRetards.MainClient.UI.Buttons.Loggers.StartLoggers();
			Mic_Options.StartMicOptions();
			self_menu.StartSelfMenu();
			ZeroDayClientByRetards.MainClient.UI.Buttons.mirrors.StartMirror();
			ghost.StartGhost();
			utilsinteract.StartUtilsInteract();
			murdinteract.StartMurdInteract();
			ZeroDayClientByRetards.MainClient.UI.Buttons.amonginteract.StartAmongInteract();
			ZeroDayClientByRetards.MainClient.UI.Buttons.ghostinteract.StartGhost();
			ZeroDayClientByRetards.MainClient.UI.Buttons.Jump.StartJump();
			WorldOptions.StartWorldOptions();
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Carousel_Banners").set_active(false);
			GameObject gameObject = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks");
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_GoHome").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_Respawn").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_SelectUser").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_Emojis").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/SitStandCalibrateButton").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickActions").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickLinks/LeftItemContainer/Text_Title").GetComponent<TextMeshProUGUI>().set_text("<color=blue>VRC Stuff</color>");
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Worlds/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Avatars/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Safety/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_GoHome/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Respawn/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_SelectUser/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Emojis/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Social/Icon").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Worlds/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Avatars/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Safety/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_GoHome/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Respawn/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_SelectUser/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Emojis/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Social/Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			Transform _transform = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Worlds/Text_H4").get_transform();
			_transform.set_localPosition(_transform.get_localPosition() + new Vector3(0f, 50f, 0f));
			Transform transform = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Avatars/Text_H4").get_transform();
			transform.set_localPosition(transform.get_localPosition() + new Vector3(0f, 50f, 0f));
			Transform _transform1 = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Safety/Text_H4").get_transform();
			_transform1.set_localPosition(_transform1.get_localPosition() + new Vector3(0f, 50f, 0f));
			Transform transform1 = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_GoHome/Text_H4").get_transform();
			transform1.set_localPosition(transform1.get_localPosition() + new Vector3(0f, 50f, 0f));
			Transform _transform2 = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Respawn/Text_H4").get_transform();
			_transform2.set_localPosition(_transform2.get_localPosition() + new Vector3(0f, 50f, 0f));
			Transform transform2 = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_SelectUser/Text_H4").get_transform();
			transform2.set_localPosition(transform2.get_localPosition() + new Vector3(0f, 50f, 0f));
			Transform _transform3 = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Emojis/Text_H4").get_transform();
			_transform3.set_localPosition(_transform3.get_localPosition() + new Vector3(0f, 50f, 0f));
			Transform transform3 = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Social/Text_H4").get_transform();
			transform3.set_localPosition(transform3.get_localPosition() + new Vector3(0f, 50f, 0f));
			MainMenuLol.LogAPIDEBUGGER(string.Concat("Welcome To ZeroDay, ", APIUser.get_CurrentUser().get_displayName()));
			MainMenuLol.LogAPIDEBUGGER("ZeroDayClient Made By Afton, Iris And Blaze");
			GameObject gameObject1 = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard");
			MainMenuLol.AT3wMingXk.GetMainButton().GetGameObject().get_transform().Find("Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			MainMenuLol.gamesetting.GetMainButton().GetGameObject().get_transform().Find("Background").get_transform().set_localScale(new Vector3(1f, 0.5f, 1f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(139.01f, -152.2081f, 0f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(139.01f, -152.2081f, 0f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(139.01f, -152.2081f, 0f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(139.01f, -152.2081f, 0f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(139.01f, -152.2081f, 0f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(139.01f, -152.2081f, 0f));
			if (!XRDevice.get_isPresent())
			{
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/SitStandCalibrateButton").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_GoHome").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Respawn").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_SelectUser").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Emojis").get_transform().set_parent(gameObject1.get_transform());
			}
			else
			{
				MelonLogger.Log("Detected VR! Changing Layout");
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_GoHome").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Respawn").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Emojis").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/SitStandCalibrateButton").get_transform().set_parent(gameObject1.get_transform());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/Button_Emojis").get_transform().set_localPosition(new Vector3(113.7403f, -344.0009f, -0.001f));
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/SitStandCalibrateButton").get_transform().set_localPosition(new Vector3(369.8061f, -397.5393f, -1.0288f));
			}
		}

		internal static MainMenuLol ygO9Y0oe3mZNhANHhcf()
		{
			return MainMenuLol.d9bh2LorvFHFBrrkv3Z;
		}
	}
}