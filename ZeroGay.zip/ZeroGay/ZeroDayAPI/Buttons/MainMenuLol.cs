using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using MelonLoader;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using VRC.Core;
using X7IetPATbOXxq4U7Vmy;
using ZeroDayClientByRetards.MainClient.UI.Buttons;

namespace ZeroDayAPI.Buttons
{
	public class MainMenuLol
	{
		internal static QMNestedButton kadyx8Vc0W;

		public static QMNestedButton gamesetting;

		public static QMNestedButton photonexploits;

		public static QMNestedButton WorldGameHacks;

		public static QMNestedButton Loggers;

		public static QMNestedButton mirrors;

		public static QMNestedButton BaseExploits;

		public static QMNestedButton PenExploits;

		public static QMNestedButton murder;

		public static QMNestedButton amongus;

		public static QMNestedButton GhostV17;

		public static QMNestedButton AntiCrash;

		public static QMNestedButton Photon;

		public static QMNestedButton movement;

		public static QMNestedButton Flight;

		public static QMNestedButton Jump;

		public static QMNestedButton Speed;

		public static QMNestedButton MicOptions;

		public static QMNestedButton Esp;

		public static QMNestedButton playerinfos;

		public static QMNestedButton murderinteract;

		public static QMNestedButton amonginteract;

		public static QMNestedButton ghostinteract;

		public static QMNestedButton interactattatch;

		public static QMNestedButton towerdefender;

		public static QMNestedButton selfmenu;

		public static QMNestedButton worldsmenu;

		public static QMSingleButton consolebutton;

		public static QMNestedButton utilitiesselecteduser;

		public static QMToggleButton anticrash;

		public static QMInfo playerlist;

		public static float linecheck;

		private static MainMenuLol QOEkifDxeM6ic12ihkS;

		public MainMenuLol()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool Bvy33RDJ7fFJEh7E9qt()
		{
			return MainMenuLol.QOEkifDxeM6ic12ihkS == null;
		}

		public static void LogAPIDEBUGGER(string text)
		{
			MainMenuLol.linecheck += 1f;
			QMSingleButton qMSingleButton = MainMenuLol.consolebutton;
			string str = DateTime.Now.ToString("HH:mm:ss");
			if (MainMenuLol.linecheck > 19f)
			{
				MainMenuLol.linecheck = 0f;
				qMSingleButton.SetButtonText("");
			}
			TextMeshProUGUI component = qMSingleButton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_text(string.Concat(new string[] { component.get_text(), "<color=white>- [", str, "]</color><color=#5100ff> [ZeroDay]</color>   <color=#ff007a>[API]:  ", text, "</color>\n" }));
		}

		public static void logjoin(string text)
		{
			MainMenuLol.linecheck += 1f;
			QMSingleButton qMSingleButton = MainMenuLol.consolebutton;
			string str = DateTime.Now.ToString("HH:mm:ss");
			if (MainMenuLol.linecheck > 19f)
			{
				MainMenuLol.linecheck = 0f;
				qMSingleButton.SetButtonText("");
			}
			TextMeshProUGUI component = qMSingleButton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_text(string.Concat(new string[] { component.get_text(), "<color=white>- [", str, "]</color><color=#5100ff> [ZeroDay]</color>  <color=#ff00cc>[+]:  ", text, "</color>\n" }));
		}

		public static void logleave(string text)
		{
			MainMenuLol.linecheck += 1f;
			QMSingleButton qMSingleButton = MainMenuLol.consolebutton;
			string str = DateTime.Now.ToString("HH:mm:ss");
			if (MainMenuLol.linecheck > 19f)
			{
				MainMenuLol.linecheck = 0f;
				qMSingleButton.SetButtonText("");
			}
			TextMeshProUGUI component = qMSingleButton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_text(string.Concat(new string[] { component.get_text(), "<color=white>- [", str, "]</color><color=#5100ff> [ZeroDay]</color>   <color=#6b6b6b>[-]:  ", text, "</color>\n" }));
		}

		internal static MainMenuLol pYWYLND8Aa4YoF4fhZJ()
		{
			return MainMenuLol.QOEkifDxeM6ic12ihkS;
		}

		public static IEnumerator StartMainMenu()
		{
			bool flag;
			bool flag1;
			MainMenuLol.kadyx8Vc0W = new QMNestedButton("Menu_Dashboard", "ZeroDay V2", 0.85f, 2.3f, "ZeroDay Lol", "ZeroDay");
			MainMenuLol.gamesetting = new QMNestedButton("Menu_Dashboard", "Game \n Settings", 0.85f, 3.3f, "", "Game Settings");
			MainMenuLol.photonexploits = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Photon Exploits", 1f, 0f, "", "Photon Exploits");
			MainMenuLol.playerlist = new QMInfo(GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/Wing_Right/Button").get_transform(), 1f, 0f, 2f, 2f, "ZeroDay Info");
			MainMenuLol.WorldGameHacks = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "World \n Game \n Hacks", 1f, 1f, "", "WorldGameHacks");
			MainMenuLol.Loggers = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Logging", 1f, 2f, "", "Logging");
			MainMenuLol.mirrors = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Mirrors", 1f, 3f, "", "Mirror");
			MainMenuLol.BaseExploits = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Base Exploits", 2f, 0f, "", "Base Exploits");
			MainMenuLol.murder = new QMNestedButton(MainMenuLol.WorldGameHacks, "Murder", 2f, 1f, "", "Murder 4");
			MainMenuLol.amongus = new QMNestedButton(MainMenuLol.WorldGameHacks, "Among Us", 2f, 2f, "", "Among Us");
			MainMenuLol.GhostV17 = new QMNestedButton(MainMenuLol.WorldGameHacks, "Ghost V21", 2f, 3f, "", "Ghost V21");
			MainMenuLol.movement = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Movement", 2f, 1f, "", "Movement");
			MainMenuLol.Flight = new QMNestedButton(MainMenuLol.movement, "Flight", 1f, 0f, "", "Flight");
			MainMenuLol.Jump = new QMNestedButton(MainMenuLol.movement, "Jump", 2f, 0f, "", "Jump");
			MainMenuLol.Speed = new QMNestedButton(MainMenuLol.movement, "Speed", 3f, 0f, "", "Speed");
			MainMenuLol.MicOptions = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Mic Options", 2f, 2f, "", "Mic Options");
			MainMenuLol.Esp = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "ESP", 2f, 3f, "", "");
			MainMenuLol.selfmenu = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Self \n Menu", 3f, 0f, "", "Self Menu");
			MainMenuLol.worldsmenu = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "World Options", 3f, 1f, "", "World Options");
			MainMenuLol.Photon = new QMNestedButton(MainMenuLol.kadyx8Vc0W, "Anti Events", 3f, 2f, "", "Anti Events");
			MainMenuLol.utilitiesselecteduser = new QMNestedButton("Menu_SelectedUser_Local", "Utilities", 1.3f, -0.9f, "", "Utilities");
			MainMenuLol.murderinteract = new QMNestedButton("Menu_SelectedUser_Local", "Murder", 2f, -0.9f, "", "Murder Interactions");
			MainMenuLol.amonginteract = new QMNestedButton("Menu_SelectedUser_Local", "Among Us", 2.7f, -0.9f, "", "Among Interactions");
			MainMenuLol.ghostinteract = new QMNestedButton("Menu_SelectedUser_Local", "Ghost", 3.4f, -0.9f, "", "Ghost Interactions");
			Sprite sprite = new Sprite();
			UnityWebRequest texture = UnityWebRequestTexture.GetTexture("https://i.imgur.com/yia0emM.png");
			yield return texture.SendWebRequest();
			flag = (!texture.get_isNetworkError() ? texture.get_isHttpError() : true);
			if (!flag)
			{
				Texture2D content = DownloadHandlerTexture.GetContent(texture);
				Sprite sprite1 = Sprite.CreateSprite(content, new Rect(0f, 0f, (float)content.get_width(), (float)content.get_height()), new Vector2((float)(content.get_width() / 2), (float)(content.get_height() / 2)), 100000f, 1000, 0, Vector4.get_zero(), false);
				UnityEngine.Object.Destroy((UnityEngine.Object)MainMenuLol.kadyx8Vc0W.GetMainButton().GetGameObject().GetComponent<StyleElement>());
				GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/BackgroundLayer01").GetComponent<Image>().set_sprite(sprite1);
				content = null;
				sprite1 = null;
			}
			else
			{
				MelonLogger.LogError(texture.get_error());
			}
			Color? nullable = null;
			Color? nullable1 = nullable;
			nullable = null;
			MainMenuLol.consolebutton = new QMSingleButton("Menu_Dashboard", 3f, 2.8f, "", () => {
			}, "", nullable1, nullable, false);
			TextMeshProUGUI component = MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").GetComponent<TextMeshProUGUI>();
			component.set_fontSize(2.5f);
			component.set_m_isUsingBold(true);
			component.set_alignment(257);
			component.set_enableWordWrapping(false);
			component.set_maxVisibleLines(19);
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localPosition(new Vector3(270.0931f, -70f, 0f));
			MainMenuLol.consolebutton.GetGameObject().get_transform().Find("Text_H4").get_transform().set_localScale(new Vector3(7f, 7f, 7f));
			Sprite sprite2 = new Sprite();
			UnityWebRequest unityWebRequest = UnityWebRequestTexture.GetTexture("https://i.imgur.com/pGse0iC.png");
			yield return unityWebRequest.SendWebRequest();
			flag1 = (unityWebRequest.get_isNetworkError() ? true : unityWebRequest.get_isHttpError());
			if (!flag1)
			{
				Texture2D texture2D = DownloadHandlerTexture.GetContent(unityWebRequest);
				Sprite sprite3 = Sprite.CreateSprite(texture2D, new Rect(0f, 0f, (float)texture2D.get_width(), (float)texture2D.get_height()), new Vector2((float)(texture2D.get_width() / 2), (float)(texture2D.get_height() / 2)), 100000f, 1000, 0, Vector4.get_zero(), false);
				MainMenuLol.consolebutton.SetButtonText("");
				RectTransform rectTransform = MainMenuLol.consolebutton.GetGameObject().GetComponent<RectTransform>();
				rectTransform.set_sizeDelta(rectTransform.get_sizeDelta() * new Vector2(3.8f, 2.2f));
				MainMenuLol.consolebutton.SetBackgroundImage(sprite3);
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").set_active(true);
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").GetComponent<Image>().set_sprite(sprite3);
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").get_transform().set_localScale(new Vector3(1.05f, 1.05f, 1f));
				GameObject.Find("UserInterface/MenuContent/Backdrop/Backdrop/Background").GetComponent<Image>().set_color(Color.get_white());
				texture2D = null;
				sprite3 = null;
			}
			else
			{
				MelonLogger.LogError(unityWebRequest.get_error());
			}
			ZeroDayClientByRetards.MainClient.UI.Buttons.photonexploits.StartPhotonExploits();
			baseexploits.StartBaseExploits();
			GameSettings.StartGameSettings();
			ZeroDayClientByRetards.MainClient.UI.Buttons.murder.StartMurder();
			ZeroDayClientByRetards.MainClient.UI.Buttons.amongus.StartAmigos();
			ZeroDayClientByRetards.MainClient.UI.Buttons.Flight.StartFlight();
			speed.StartSpeed();
			ESP.StartESP();
			ZeroDayClientByRetards.MainClient.UI.Buttons.Loggers.StartLoggers();
			Mic_Options.StartMicOptions();
			self_menu.StartSelfMenu();
			ZeroDayClientByRetards.MainClient.UI.Buttons.mirrors.StartMirror();
			ghost.StartGhost();
			utilsinteract.StartUtilsInteract();
			murdinteract.StartMurdInteract();
			ZeroDayClientByRetards.MainClient.UI.Buttons.amonginteract.StartAmongInteract();
			ZeroDayClientByRetards.MainClient.UI.Buttons.ghostinteract.StartGhost();
			ZeroDayClientByRetards.MainClient.UI.Buttons.Jump.StartJump();
			WorldOptions.StartWorldOptions();
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Carousel_Banners").set_active(false);
			GameObject gameObject = GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks");
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_GoHome").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_Respawn").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_SelectUser").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_Emojis").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/SitStandCalibrateButton").get_transform().set_parent(gameObject.get_transform());
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickActions").set_active(false);
			GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickLinks/LeftItemContainer/Text_Title").GetComponent<TextMeshProUGUI>().set_text("<color=blue>VRC Stuff</color>");
			MainMenuLol.LogAPIDEBUGGER(string.Concat("Welcome To ZeroDay, ", APIUser.get_CurrentUser().get_displayName()));
			MainMenuLol.LogAPIDEBUGGER("ZeroDayClient Made By Afton, Iris And Blaze");
		}
	}
}