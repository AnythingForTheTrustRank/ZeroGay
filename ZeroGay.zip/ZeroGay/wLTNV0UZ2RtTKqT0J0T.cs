using AksgHVKH9UOXlBDvRpO;
using ExitGames.Client.Photon;
using Il2CppSystem;
using Photon.Realtime;
using System;

internal delegate bool wLTNV0UZ2RtTKqT0J0T(byte byte_0, Il2CppSystem.Object object_0, RaiseEventOptions raiseEventOptions_0, SendOptions sendOptions_0);