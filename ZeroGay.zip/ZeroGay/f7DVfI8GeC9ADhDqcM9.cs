using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate byte f7DVfI8GeC9ADhDqcM9(object object_0);