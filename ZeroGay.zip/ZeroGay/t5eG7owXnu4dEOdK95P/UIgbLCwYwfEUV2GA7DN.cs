using Apollo_Base.Modules;
using b3eD5DgJPcASx0xfHYB;
using Blaze.Modules;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using VRC;

namespace t5eG7owXnu4dEOdK95P
{
	internal class UIgbLCwYwfEUV2GA7DN : ModuleBase
	{
		internal static List<ZDUserInfo> UVrwOoZAqi;

		internal static UIgbLCwYwfEUV2GA7DN c7qCenmJQ1EuCawWI1e;

		static UIgbLCwYwfEUV2GA7DN()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			UIgbLCwYwfEUV2GA7DN.UVrwOoZAqi = new List<ZDUserInfo>();
		}

		public UIgbLCwYwfEUV2GA7DN()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool Lt3732m5PLSTMVvguoy()
		{
			return UIgbLCwYwfEUV2GA7DN.c7qCenmJQ1EuCawWI1e == null;
		}

		public override void PlayerJoined(Player u0020)
		{
			UIgbLCwYwfEUV2GA7DN.UVrwOoZAqi.Add(u0020.get_gameObject().AddComponent<ZDUserInfo>());
		}

		internal static UIgbLCwYwfEUV2GA7DN qXL1BgmdPxieuioieIA()
		{
			return UIgbLCwYwfEUV2GA7DN.c7qCenmJQ1EuCawWI1e;
		}

		public override void Start()
		{
		}
	}
}