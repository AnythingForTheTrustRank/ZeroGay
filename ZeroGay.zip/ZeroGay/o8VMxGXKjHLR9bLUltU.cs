using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.UI.Elements;

internal delegate List<UIPage> o8VMxGXKjHLR9bLUltU(object object_0);