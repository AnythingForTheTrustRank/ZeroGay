using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using UnityEngine.Networking;

internal delegate AudioClip hyZuJmKBC4YKGBLhJ4F(DownloadHandler , string , bool , bool , AudioType );