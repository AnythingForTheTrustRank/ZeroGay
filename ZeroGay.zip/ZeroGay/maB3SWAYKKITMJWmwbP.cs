using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Transform maB3SWAYKKITMJWmwbP(object , HumanBodyBones );