using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate byte[] pUZC78wTWt3RMyWSbcS(string string_0);