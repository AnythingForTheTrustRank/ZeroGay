using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object Yh4L803TEKpHd7d2n8A(Type type_0, ulong ulong_0);