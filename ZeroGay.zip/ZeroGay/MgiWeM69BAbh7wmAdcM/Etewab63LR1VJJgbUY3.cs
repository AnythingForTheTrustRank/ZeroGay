using b3eD5DgJPcASx0xfHYB;
using gpd3oZtw5qhYneWRlWY;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.XR;
using VRC.SDK3.Components;
using VRC.SDKBase;

namespace MgiWeM69BAbh7wmAdcM
{
	internal static class Etewab63LR1VJJgbUY3
	{
		public static bool PWS6QNbl5o;

		public static bool pht6wHjyVw;

		public static bool yp46N2K5GM;

		public static bool PWH6CP8rjC;

		public static bool JA7622A5Tg;

		public static bool CV76b5TKwZ;

		private static InputDevice EG76h77TYT;

		public static bool cac6UfwmqP;

		public static bool mnn6TSyj0Q;

		public static bool oM96vnbqIt;

		public static string n9f6aEhDJa;

		private static Etewab63LR1VJJgbUY3 V36ELmdjX6v7XSliQj2;

		static Etewab63LR1VJJgbUY3()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			Etewab63LR1VJJgbUY3.PWS6QNbl5o = false;
			Etewab63LR1VJJgbUY3.pht6wHjyVw = false;
			Etewab63LR1VJJgbUY3.yp46N2K5GM = false;
			Etewab63LR1VJJgbUY3.PWH6CP8rjC = false;
			Etewab63LR1VJJgbUY3.JA7622A5Tg = false;
			Etewab63LR1VJJgbUY3.CV76b5TKwZ = false;
			Etewab63LR1VJJgbUY3.cac6UfwmqP = false;
			Etewab63LR1VJJgbUY3.mnn6TSyj0Q = false;
			Etewab63LR1VJJgbUY3.oM96vnbqIt = false;
			Etewab63LR1VJJgbUY3.n9f6aEhDJa = "wrld_0ec97c4f-1e84-4a3a-9e3a-fa3075b6c56d";
		}

		public static IEnumerator CUa67Cco8Q(bool u0020)
		{
			VRCPickup component;
			VRCPickup vRCPickup;
			while (true)
			{
				if (Etewab63LR1VJJgbUY3.cac6UfwmqP && Etewab63LR1VJJgbUY3.DdI6MULR8A())
				{
					List<VRCPickup> vRCPickups = new List<VRCPickup>();
					GameObject gameObject = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A -01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					if (gameObject == null)
					{
						component = null;
					}
					else
					{
						component = gameObject.GetComponent<VRCPickup>();
					}
					vRCPickups.Add(component);
					List<VRCPickup> vRCPickups1 = vRCPickups;
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A -01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					foreach (VRCPickup vRCPickup1 in vRCPickups1)
					{
						if (Input.GetKey(324) && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_FireOneShot", null, false);
						}
						if (vRCPickup1.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_FireOneShot", null, false);
						}
						if (vRCPickup1.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_FireOneShot", null, false);
						}
					}
					List<VRCPickup> vRCPickups2 = new List<VRCPickup>();
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					if (gameObject2 == null)
					{
						vRCPickup = null;
					}
					else
					{
						vRCPickup = gameObject2.GetComponent<VRCPickup>();
					}
					vRCPickups2.Add(vRCPickup);
					List<VRCPickup> vRCPickups3 = vRCPickups2;
					GameObject gameObject3 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					foreach (VRCPickup vRCPickup2 in vRCPickups3)
					{
						if (Input.GetKey(324) && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "Local_FireOneShot", null, false);
						}
						if (vRCPickup2.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "Local_FireOneShot", null, false);
						}
						if (vRCPickup2.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "Local_FireOneShot", null, false);
						}
					}
					vRCPickups1 = null;
					gameObject1 = null;
					vRCPickups3 = null;
					gameObject3 = null;
				}
				yield return new WaitForSeconds(0.3f);
			}
		}

		public static bool DdI6MULR8A()
		{
			bool flag;
			flag = (RoomManager.Method_Internal_Static_get_String_0().Contains(Etewab63LR1VJJgbUY3.n9f6aEhDJa) ? true : false);
			return flag;
		}

		internal static Etewab63LR1VJJgbUY3 eQW5P4dFm0ViTHIJVgY()
		{
			return Etewab63LR1VJJgbUY3.V36ELmdjX6v7XSliQj2;
		}

		internal static bool Hhxo0UdZ0YEdBsBf4Zh()
		{
			return Etewab63LR1VJJgbUY3.V36ELmdjX6v7XSliQj2 == null;
		}

		public static IEnumerator jtr6IRrbPD(bool u0020)
		{
			VRCPickup component;
			VRCPickup vRCPickup;
			while (true)
			{
				if (Etewab63LR1VJJgbUY3.oM96vnbqIt && Etewab63LR1VJJgbUY3.DdI6MULR8A())
				{
					List<VRCPickup> vRCPickups = new List<VRCPickup>();
					GameObject gameObject = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					if (gameObject != null)
					{
						component = gameObject.GetComponent<VRCPickup>();
					}
					else
					{
						component = null;
					}
					vRCPickups.Add(component);
					List<VRCPickup> vRCPickups1 = vRCPickups;
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					foreach (VRCPickup vRCPickup1 in vRCPickups1)
					{
						if (Input.GetKey(324) && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_FireOneShot", null, false);
						}
						if (vRCPickup1.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_FireOneShot", null, false);
						}
						if (vRCPickup1.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_FireOneShot", null, false);
						}
					}
					List<VRCPickup> vRCPickups2 = new List<VRCPickup>();
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					if (gameObject2 == null)
					{
						vRCPickup = null;
					}
					else
					{
						vRCPickup = gameObject2.GetComponent<VRCPickup>();
					}
					vRCPickups2.Add(vRCPickup);
					List<VRCPickup> vRCPickups3 = vRCPickups2;
					GameObject gameObject3 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					foreach (VRCPickup vRCPickup2 in vRCPickups3)
					{
						if (Input.GetKey(324) && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "Local_FireOneShot", null, false);
						}
						if (vRCPickup2.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "Local_FireOneShot", null, false);
						}
						if (vRCPickup2.get_IsHeld() && Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") > 0f && Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()))
						{
							QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "Local_FireOneShot", null, false);
						}
					}
					vRCPickups1 = null;
					gameObject1 = null;
					vRCPickups3 = null;
					gameObject3 = null;
				}
				yield return new WaitForSeconds(0.01f);
			}
		}

		public static IEnumerator R5C6sONa3K(bool u0020)
		{
			// 
			// Current member / type: System.Collections.IEnumerator MgiWeM69BAbh7wmAdcM.Etewab63LR1VJJgbUY3::R5C6sONa3K(System.Boolean)
			// File path: C:\Users\Charlie\Desktop\ZeroGay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Collections.IEnumerator R5C6sONa3K(System.Boolean)
			// 
			// Invalid state value
			//    at ..( , Queue`1 , ILogicalConstruct ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 203
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 187
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 129
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 76
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\LogicalFlowBuilderStep.cs:line 126
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\LogicalFlowBuilderStep.cs:line 51
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext ,  , Func`2 , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 104
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext , & ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 139
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 134
			//    at ..Match( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 49
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 20
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public static IEnumerator uEx6t6qTXH(bool u0020)
		{
			return new Etewab63LR1VJJgbUY3.<currencyspamtarget>d__17(0)
			{
				state = u0020
			};
		}

		public static IEnumerator WSc64xBWmB(bool u0020)
		{
			return new Etewab63LR1VJJgbUY3.<gunshit2>d__14(0)
			{
				state = u0020
			};
		}

		public static IEnumerator yCY66VlxeG(bool u0020)
		{
			while (true)
			{
				if (Etewab63LR1VJJgbUY3.PWH6CP8rjC)
				{
					GameObject gameObject = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor");
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor (1)");
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Local_AddOneMoreKey", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_AddOneMoreKey", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "UnLockSound", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "UnLockSound", null, false);
					yield return new WaitForSeconds(0.5f);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Local_AddOneMoreKey", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Local_AddOneMoreKey", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Local_AddOneMoreKey", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject, "Local_AddOneMoreKey", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					Etewab63LR1VJJgbUY3.PWH6CP8rjC = false;
					gameObject = null;
					gameObject1 = null;
				}
				else if (Etewab63LR1VJJgbUY3.JA7622A5Tg)
				{
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor/Door_Metal_Gray_mesh (1)");
					GameObject gameObject3 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor (1)/Door_Metal_Gray_mesh (1)");
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject2, "Local_OpenClockwise", null, false);
					QdA6prtQJZNe9CGe8IK.iXUt274MFU(gameObject3, "Local_OpenClockwise", null, false);
					Etewab63LR1VJJgbUY3.JA7622A5Tg = false;
					gameObject2 = null;
					gameObject3 = null;
				}
				else if (Etewab63LR1VJJgbUY3.CV76b5TKwZ)
				{
					GameObject gameObject4 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor/Door_Metal_Gray_mesh (1)");
					GameObject gameObject5 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor (1)/Door_Metal_Gray_mesh (1)");
					gameObject4.set_active(false);
					gameObject5.set_active(false);
					Etewab63LR1VJJgbUY3.CV76b5TKwZ = false;
					gameObject4 = null;
					gameObject5 = null;
				}
				yield return new WaitForSeconds(1f);
			}
		}
	}
}