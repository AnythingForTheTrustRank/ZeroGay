using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using VRC.Core;

internal delegate Color VcC3hIrgfZ26ux4jMp4(APIUser );