using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Skq89h9RZgXKFTIx1Mo
{
	internal class H0Z2a890qe6bfIwSnp8
	{
		internal static H0Z2a890qe6bfIwSnp8 q8OZn1dvfJS1gpw8HJe;

		static H0Z2a890qe6bfIwSnp8()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			H0Z2a890qe6bfIwSnp8.ww84HPLU9E = 1f;
			H0Z2a890qe6bfIwSnp8.ahT4G64jn2 = 1f;
			H0Z2a890qe6bfIwSnp8.GH743AexP9 = 1f;
			H0Z2a890qe6bfIwSnp8.WYU49Rn3A0 = 1f;
			H0Z2a890qe6bfIwSnp8.tY04s8oRwh = 5f;
			H0Z2a890qe6bfIwSnp8.Jvc4MBtB18 = 2f;
			H0Z2a890qe6bfIwSnp8.cTx47UfDbI = 5;
			H0Z2a890qe6bfIwSnp8.Hvj44SZd8e = 1f;
			H0Z2a890qe6bfIwSnp8.Nq24IYPMOx = 0.05f;
			H0Z2a890qe6bfIwSnp8.Fgr46FZNp4 = 0.65f;
			H0Z2a890qe6bfIwSnp8.VUH4tQs3Hp = 0.67f;
			H0Z2a890qe6bfIwSnp8.aw94QiNT5U = 0.75f;
			H0Z2a890qe6bfIwSnp8.qL74wxhLqu = 1f;
			H0Z2a890qe6bfIwSnp8.TEs4NpFNfa = 1f;
			H0Z2a890qe6bfIwSnp8.G7b4CwSHjR = 1f;
			H0Z2a890qe6bfIwSnp8.pe542af6Sm = 1f;
			H0Z2a890qe6bfIwSnp8.QNQ4bXX9kO = 1f;
			H0Z2a890qe6bfIwSnp8.PSW4h9yvkF = 1f;
			H0Z2a890qe6bfIwSnp8.onS4TW6IDQ = 1f;
			H0Z2a890qe6bfIwSnp8.Rvx4vFXtw5 = 1f;
			H0Z2a890qe6bfIwSnp8.fXe4aDhsy2 = 1f;
			H0Z2a890qe6bfIwSnp8.nM44gV7XlO = 1f;
			H0Z2a890qe6bfIwSnp8.E2I4WQDY1U = 1f;
			H0Z2a890qe6bfIwSnp8.oTg4uZaGFP = 0f;
			H0Z2a890qe6bfIwSnp8.MqC4S7cs2P = 0.5f;
			H0Z2a890qe6bfIwSnp8.MUa4YCesQt = 0.25f;
			H0Z2a890qe6bfIwSnp8.CFy4X72gTW = 0.9f;
			H0Z2a890qe6bfIwSnp8.RXx4O7XivG = 1f;
			H0Z2a890qe6bfIwSnp8.Lml4BNxGyJ = 0.48f;
			H0Z2a890qe6bfIwSnp8.CIF4PnxEFD = 0f;
			H0Z2a890qe6bfIwSnp8.nQL4l1pgfE = 0.17f;
			H0Z2a890qe6bfIwSnp8.ClC4jfwqCj = 0.81f;
			H0Z2a890qe6bfIwSnp8.GgO4ZgaviA = 0.36f;
			H0Z2a890qe6bfIwSnp8.zcQ4Fp7s6h = 0.09f;
			H0Z2a890qe6bfIwSnp8.BuW4iT2lEq = 0.47f;
			H0Z2a890qe6bfIwSnp8.xPT407kiQk = 1f;
			H0Z2a890qe6bfIwSnp8.rXd4RIurpH = 0.6f;
			H0Z2a890qe6bfIwSnp8.omt4pe1Gwu = 0.6f;
			H0Z2a890qe6bfIwSnp8.sUj4rfRWOE = 0.6f;
			H0Z2a890qe6bfIwSnp8.YD74nFYAEc = 0.47f;
			H0Z2a890qe6bfIwSnp8.s524eT1lGs = 0.18f;
			H0Z2a890qe6bfIwSnp8.GjW4frf9xV = 0.18f;
		}

		public H0Z2a890qe6bfIwSnp8()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.Cfk4xqE9AG = 1f;
			this.j8T41i60Ea = 1f;
			this.oYj4A1terl = 1f;
			this.Af24VrCm88 = 1f;
			this.gKl4LEFxxC = 1f;
			this.i274JHuYhv = 1f;
			this.YvJ45xWTo2 = 1f;
			this.sAK4d4EPAr = 0f;
			this.PC04o2sDuO = 0.5f;
			this.iaG4mo5vch = 0.25f;
			this.vBs4DfT6lG = 0.9f;
			this.OYF4cHvxBj = 1f;
			this.tBH4yLJnX8 = 0.48f;
			this.sU34ERs0s0 = 0f;
			this.srR4zEiooe = 0.17f;
			this.QstIqncR9B = 0.81f;
			this.HWMIkjPUYJ = 0.36f;
			this.KQjI88FXEn = 0.09f;
			this.IXLIHWuEJC = 0.47f;
			this.SWvIGXkmVW = 1f;
			this.fVdI3yGwTy = 0.6f;
			this.YApI95wrUl = 0.6f;
			this.tEPIsgrWVk = 0.6f;
			this.eXBIMfFlDB = 0.47f;
			this.oIOI7WCuqv = 0.18f;
			this.qq7I47yUV4 = 0.18f;
			base();
		}

		internal static bool mJr46WdaUbUpDkINfsF()
		{
			return H0Z2a890qe6bfIwSnp8.q8OZn1dvfJS1gpw8HJe == null;
		}

		internal static H0Z2a890qe6bfIwSnp8 OpB9nTdg1BdBH9NGApl()
		{
			return H0Z2a890qe6bfIwSnp8.q8OZn1dvfJS1gpw8HJe;
		}
	}
}