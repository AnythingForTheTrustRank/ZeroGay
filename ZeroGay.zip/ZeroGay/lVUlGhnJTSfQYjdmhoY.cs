using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using VRC;

internal delegate Il2CppReferenceArray<Player> lVUlGhnJTSfQYjdmhoY(object );