using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string caVWEB8xir6GuJF4YCM(string string_0, object object_0);