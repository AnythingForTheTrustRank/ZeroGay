using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Type eibv9kp7IvZmtNcxaO0(RuntimeTypeHandle runtimeTypeHandle_0);