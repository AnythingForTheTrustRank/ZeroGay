using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate bool EvWVoJwdHgrSdlTXCxn(Il2CppStructArray<Plane> il2CppStructArray_0, Bounds bounds_0);