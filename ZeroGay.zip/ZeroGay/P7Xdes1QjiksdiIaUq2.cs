using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate void P7Xdes1QjiksdiIaUq2(ref AsyncTaskMethodBuilder asyncTaskMethodBuilder_0);