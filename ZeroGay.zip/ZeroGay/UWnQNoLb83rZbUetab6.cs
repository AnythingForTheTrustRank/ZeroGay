using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate long UWnQNoLb83rZbUetab6(ref IntPtr );