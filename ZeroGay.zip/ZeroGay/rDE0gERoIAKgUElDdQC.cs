using b3eD5DgJPcASx0xfHYB;
using System;
using System.IO;

internal delegate void rDE0gERoIAKgUElDdQC(object , Stream , object );