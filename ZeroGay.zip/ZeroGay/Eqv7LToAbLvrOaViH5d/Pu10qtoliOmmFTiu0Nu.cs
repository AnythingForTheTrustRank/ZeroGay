using AksgHVKH9UOXlBDvRpO;
using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using X7IetPATbOXxq4U7Vmy;

namespace Eqv7LToAbLvrOaViH5d
{
	internal class Pu10qtoliOmmFTiu0Nu
	{
		internal static Pu10qtoliOmmFTiu0Nu nkiHcUmHQcBceGsVu4f;

		static Pu10qtoliOmmFTiu0Nu()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			Pu10qtoliOmmFTiu0Nu.SsHBfkWPGC = 1f;
			Pu10qtoliOmmFTiu0Nu.kUHBmaEidZ = 1f;
			Pu10qtoliOmmFTiu0Nu.UPHBDL7d9m = 1f;
			Pu10qtoliOmmFTiu0Nu.sjmBgZhQkV = 1f;
			Pu10qtoliOmmFTiu0Nu.pM2B49npuX = 5f;
			Pu10qtoliOmmFTiu0Nu.vXkBjoUYs9 = 2f;
			Pu10qtoliOmmFTiu0Nu.IriBS7bLsq = 5;
			Pu10qtoliOmmFTiu0Nu.PPYBbLqF5A = 1f;
			Pu10qtoliOmmFTiu0Nu.vDvBNafvjO = 0.05f;
			Pu10qtoliOmmFTiu0Nu.TXxBzS47m9 = 0.65f;
			Pu10qtoliOmmFTiu0Nu.xTUr51VMe3 = 0.67f;
			Pu10qtoliOmmFTiu0Nu.DxxrcwnL2T = 0.75f;
			Pu10qtoliOmmFTiu0Nu.wKurnwnGoZ = 1f;
			Pu10qtoliOmmFTiu0Nu.GZKrQe0uSI = 1f;
			Pu10qtoliOmmFTiu0Nu.tFirOHeY4a = 1f;
			Pu10qtoliOmmFTiu0Nu.iS7rIdGe0w = 1f;
			Pu10qtoliOmmFTiu0Nu.R24rocVskI = 1f;
			Pu10qtoliOmmFTiu0Nu.MXKr6KDCI9 = 1f;
			Pu10qtoliOmmFTiu0Nu.jQqrBkFYFv = 1f;
			Pu10qtoliOmmFTiu0Nu.YoXrrcxfAn = 1f;
			Pu10qtoliOmmFTiu0Nu.HObr2aow0E = 1f;
			Pu10qtoliOmmFTiu0Nu.vt1rMuNk9X = 1f;
			Pu10qtoliOmmFTiu0Nu.Rntra7KxvR = 1f;
			Pu10qtoliOmmFTiu0Nu.GXBryQO4jY = 0f;
			Pu10qtoliOmmFTiu0Nu.WIsrTa41U2 = 0.5f;
			Pu10qtoliOmmFTiu0Nu.DT7r7fMR6l = 0.25f;
			Pu10qtoliOmmFTiu0Nu.ddAreDbado = 0.9f;
			Pu10qtoliOmmFTiu0Nu.KjmrC53DdY = 1f;
			Pu10qtoliOmmFTiu0Nu.UKWrqNCbCA = 0.48f;
			Pu10qtoliOmmFTiu0Nu.JJArhupuAB = 0f;
			Pu10qtoliOmmFTiu0Nu.XtirHbKLqf = 0.17f;
			Pu10qtoliOmmFTiu0Nu.WLZrsWsvDG = 0.81f;
			Pu10qtoliOmmFTiu0Nu.n24rR2UhgE = 0.36f;
			Pu10qtoliOmmFTiu0Nu.Y00rtXoa7U = 0.09f;
			Pu10qtoliOmmFTiu0Nu.SiqrKQyfWD = 0.47f;
			Pu10qtoliOmmFTiu0Nu.bdprlDB6Rx = 1f;
			Pu10qtoliOmmFTiu0Nu.JLRrAC15Xt = 0.6f;
			Pu10qtoliOmmFTiu0Nu.Yw8rGqAaZu = 0.6f;
			Pu10qtoliOmmFTiu0Nu.tqbrdplGQh = 0.6f;
			Pu10qtoliOmmFTiu0Nu.RDkrvRDliH = 0.47f;
			Pu10qtoliOmmFTiu0Nu.U8srikRtIT = 0.18f;
			Pu10qtoliOmmFTiu0Nu.jH3r9ZI7Cq = 0.18f;
		}

		public Pu10qtoliOmmFTiu0Nu()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.qx6r0PvNvd = 1f;
			this.omjrxMG2o4 = 1f;
			this.VWZr8KGJX8 = 1f;
			this.It4rErt2ky = 1f;
			this.pvIrwVI4Jw = 1f;
			this.K30rpGcwmi = 1f;
			this.X52rWEF93y = 1f;
			this.XRerU2cHWU = 0f;
			this.ROHrP0Dfje = 0.5f;
			this.gKBruQEBfo = 0.25f;
			this.UmlrFnJutp = 0.9f;
			this.vwErXVFPlU = 1f;
			this.cvprZRxN33 = 0.48f;
			this.boNrVYNDdN = 0f;
			this.KkUrLFLoXj = 0.17f;
			this.OQwr1jlBey = 0.81f;
			this.bFQr3PU6GJ = 0.36f;
			this.WZerkKUvAO = 0.09f;
			this.CB6rfV1h54 = 0.47f;
			this.yGTrmuWkyT = 1f;
			this.uWmrDJkRkB = 0.6f;
			this.r6qrgY0ug3 = 0.6f;
			this.eJ9r4vADYQ = 0.6f;
			this.OJQrjX9yj6 = 0.47f;
			this.t1FrSZjAVV = 0.18f;
			this.jKcrbNoVVO = 0.18f;
			base();
		}

		internal static bool oyHwl1mss9hyViLbu0o()
		{
			return Pu10qtoliOmmFTiu0Nu.nkiHcUmHQcBceGsVu4f == null;
		}

		internal static Pu10qtoliOmmFTiu0Nu teYPPrmRBHyoqpZtRVr()
		{
			return Pu10qtoliOmmFTiu0Nu.nkiHcUmHQcBceGsVu4f;
		}
	}
}