using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate IntPtr QAYdL2L5mj7Oi4QBOTv(ref RuntimeMethodHandle );