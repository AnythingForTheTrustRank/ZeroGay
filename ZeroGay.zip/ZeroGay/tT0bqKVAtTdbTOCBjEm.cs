using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Core;

internal delegate ApiAvatar tT0bqKVAtTdbTOCBjEm(object object_0);