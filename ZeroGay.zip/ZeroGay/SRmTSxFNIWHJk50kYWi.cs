using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Transform SRmTSxFNIWHJk50kYWi(object , int );