using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate VRCUiCursorManager suUPqRpK0v3MagNJJop();