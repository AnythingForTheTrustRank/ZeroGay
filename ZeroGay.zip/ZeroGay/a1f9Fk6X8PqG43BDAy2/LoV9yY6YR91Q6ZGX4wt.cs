using b3eD5DgJPcASx0xfHYB;
using gpd3oZtw5qhYneWRlWY;
using Il2CppSystem.Collections.Generic;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;

namespace a1f9Fk6X8PqG43BDAy2
{
	internal class LoV9yY6YR91Q6ZGX4wt
	{
		public static bool vny6RNdxtb;

		public static bool XHG6pkxLuV;

		public static bool FcM6rQcfPr;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup> W9J6nbtuNm;

		public static Il2CppSystem.Collections.Generic.List<VRCObjectSync> r4j6e0UpVQ;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger> QUx6fi1eRR;

		public static Il2CppSystem.Collections.Generic.List<VRC_ObjectSync> r8j6xKkDXA;

		public static string hRS61IFa0Z;

		public static bool v576KTZWUu;

		public static bool Hug6AtBNHy;

		public static bool asg6VuKDgL;

		public static bool PEM6LP5tFh;

		public static bool tHj6JXg2uC;

		public static bool uJJ65Nc8WG;

		internal static LoV9yY6YR91Q6ZGX4wt tOHoa1dpL4JWjgTOulX;

		static LoV9yY6YR91Q6ZGX4wt()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			LoV9yY6YR91Q6ZGX4wt.vny6RNdxtb = false;
			LoV9yY6YR91Q6ZGX4wt.XHG6pkxLuV = false;
			LoV9yY6YR91Q6ZGX4wt.FcM6rQcfPr = false;
			LoV9yY6YR91Q6ZGX4wt.W9J6nbtuNm = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup>();
			LoV9yY6YR91Q6ZGX4wt.r4j6e0UpVQ = new Il2CppSystem.Collections.Generic.List<VRCObjectSync>();
			LoV9yY6YR91Q6ZGX4wt.QUx6fi1eRR = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger>();
			LoV9yY6YR91Q6ZGX4wt.r8j6xKkDXA = new Il2CppSystem.Collections.Generic.List<VRC_ObjectSync>();
			LoV9yY6YR91Q6ZGX4wt.hRS61IFa0Z = "wrld_858dfdfc-1b48-4e1e-8a43-f0edc611e5fe";
			LoV9yY6YR91Q6ZGX4wt.v576KTZWUu = false;
			LoV9yY6YR91Q6ZGX4wt.Hug6AtBNHy = false;
			LoV9yY6YR91Q6ZGX4wt.asg6VuKDgL = false;
			LoV9yY6YR91Q6ZGX4wt.PEM6LP5tFh = false;
			LoV9yY6YR91Q6ZGX4wt.tHj6JXg2uC = false;
			LoV9yY6YR91Q6ZGX4wt.uJJ65Nc8WG = false;
		}

		public LoV9yY6YR91Q6ZGX4wt()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static void Abort()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAbort");
			}
		}

		public static bool E6B6O0msr6()
		{
			bool flag;
			flag = (!RoomManager.Method_Internal_Static_get_String_0().Contains(LoV9yY6YR91Q6ZGX4wt.hRS61IFa0Z) ? false : true);
			return flag;
		}

		public static void eoo6lvHWT5()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "KillLocalPlayer");
			}
		}

		public static IEnumerator gBD6ZRd5A6(bool u0020)
		{
			return new LoV9yY6YR91Q6ZGX4wt.<KillAuraAlarm>d__19(0)
			{
				state = u0020
			};
		}

		internal static IEnumerator gID6jyqrEF()
		{
			return new LoV9yY6YR91Q6ZGX4wt.<smethod_3>d__17(0);
		}

		public static void Glf6FSYZpJ()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OnLocalPlayerBlinded");
			}
		}

		public static IEnumerable<WaitForSeconds> jjn6PDEW6M(bool u0020)
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (gameObject.get_name().Contains("Game Logic"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAssignM");
				}
			}
			yield return new WaitForSeconds(5f);
		}

		public static void kOB6iyFSMM()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryM");
			}
		}

		internal static bool QhPm5odr0juo14HSQjd()
		{
			return LoV9yY6YR91Q6ZGX4wt.tOHoa1dpL4JWjgTOulX == null;
		}

		internal static LoV9yY6YR91Q6ZGX4wt QunVGRdnMtxNSP26TCi()
		{
			return LoV9yY6YR91Q6ZGX4wt.tOHoa1dpL4JWjgTOulX;
		}

		public static void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_Start");
			}
		}

		internal static void WkQ6B6WaAf()
		{
			foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
			{
				vRCPickup.set_pickupable(true);
				vRCPickup.set_DisallowTheft(false);
				vRCPickup.set_proximity(99999f);
			}
		}

		public static void wsy60T6aLP()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryB");
			}
		}
	}
}