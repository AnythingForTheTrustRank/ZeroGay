﻿using MelonLoader;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Permissions;
using ZeroDayAPI;

[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("ZeroDayAPI")]
[assembly: AssemblyTitle("ZeroDayAPI")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(false)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: Guid("0d88c88f-d59d-4b28-893d-b109fe296622")]
[assembly: MelonColor(ConsoleColor.Magenta)]
[assembly: MelonGame("VRChat", "VRChat")]
[assembly: MelonInfo(typeof(ZeroDayMain), "ZeroDay V2", "2.0.0.0", "Afton, Iris, & Blaze ", null)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification=true)]
