using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using VRC.Udon;
using X7IetPATbOXxq4U7Vmy;

namespace tYy2MDMXW3ILM6p88Dk
{
	internal class YoFGyBMFcbpvHJfimuV
	{
		public static bool HuTMzt2oui;

		public static string BqNa5CSP63;

		internal static YoFGyBMFcbpvHJfimuV KPPAR6mXCJClM6a2HFA;

		static YoFGyBMFcbpvHJfimuV()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			YoFGyBMFcbpvHJfimuV.HuTMzt2oui = false;
			YoFGyBMFcbpvHJfimuV.BqNa5CSP63 = "wrld_dd036610-a246-4f52-bf01-9d7cea3405d7";
		}

		public YoFGyBMFcbpvHJfimuV()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		public static void Abort()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAbort");
			}
		}

		public static IEnumerable<WaitForSeconds> aZfM16HRLw(bool bool_0)
		{
			return new YoFGyBMFcbpvHJfimuV.<CloseDoors1>d__5(-2)
			{
				<>3__state = bool_0
			};
		}

		internal static YoFGyBMFcbpvHJfimuV BXlPr4mVfmdJpaPb8oA()
		{
			return YoFGyBMFcbpvHJfimuV.KPPAR6mXCJClM6a2HFA;
		}

		public static void cZUMfc6W3a()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageReactor");
			}
		}

		public static void dlMMLToT9C()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
			}
		}

		public static void gdfMblTnpu()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryB");
			}
		}

		public static IEnumerable<WaitForSeconds> GK4MDA6VS3(bool bool_0)
		{
			return new YoFGyBMFcbpvHJfimuV.<VoteAll>d__10(-2)
			{
				<>3__state = bool_0
			};
		}

		public static void jqVM3UJCZm()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageLights");
			}
		}

		public static void JWOMNWd8IS()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "KillLocalPlayer");
			}
		}

		public static void m60MkqZWty()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageComms");
			}
		}

		public static void NHZMVhjj4Y()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsMedbay");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsUpper");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsLower");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsSecurity");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsStorage");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsElectrical");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageDoorsCafeteria");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageLights");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageComms");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageReactor");
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageOxygen");
			}
		}

		public static void owYMSjLUGt()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncVictoryM");
			}
		}

		public static void OYmMjoVDdk()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "StartMeeting");
			}
		}

		internal static bool QGgB2KmZK8NRB84V7EX()
		{
			return YoFGyBMFcbpvHJfimuV.KPPAR6mXCJClM6a2HFA == null;
		}

		public static bool qHtMZS2g2D()
		{
			bool flag;
			flag = (!RoomManager.Method_Internal_Static_get_String_0().Contains(YoFGyBMFcbpvHJfimuV.BqNa5CSP63) ? false : true);
			return flag;
		}

		public static void s6MMghIqaL()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "OnLocalPlayerCompletedTask");
			}
		}

		public static void Start()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_Start");
			}
		}

		public static void wq4M44GQVn()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Btn_SkipVoting");
			}
		}

		public static void YKWMmogaXq()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (!gameObject.get_name().Contains("Game Logic"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncDoSabotageOxygen");
			}
		}
	}
}