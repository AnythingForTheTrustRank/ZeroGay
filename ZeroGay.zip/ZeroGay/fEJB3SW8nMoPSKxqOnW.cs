using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string fEJB3SW8nMoPSKxqOnW(ref int int_0, string string_0);