using System;

namespace q4loiAuxF6MNtBcZrh7
{
	internal class Qj2LPlufWaTAktMndvg
	{
		private static bool sufu1YBiOH;

		internal static Qj2LPlufWaTAktMndvg tCaqlAkkeoReD3nfcUPu;

		public Qj2LPlufWaTAktMndvg()
		{
		}

		internal static Qj2LPlufWaTAktMndvg CYybaUkkxxbm3AXiWQRw()
		{
			return Qj2LPlufWaTAktMndvg.tCaqlAkkeoReD3nfcUPu;
		}

		internal static void l0YkGk0xT1q()
		{
			if (!Qj2LPlufWaTAktMndvg.sufu1YBiOH)
			{
				DateTime dateTime = new DateTime(637796729716051574L);
				if (Math.Abs((DateTime.Now - dateTime).TotalDays) >= 7)
				{
					throw new Exception("This assembly is protected by an unregistered version of Eziriz's \".NET Reactor\"! This assembly won't further work.");
				}
				Qj2LPlufWaTAktMndvg.sufu1YBiOH = true;
			}
		}

		internal static bool LYjWcgkkfKT0614iRIvG()
		{
			return Qj2LPlufWaTAktMndvg.tCaqlAkkeoReD3nfcUPu == null;
		}
	}
}