using Il2CppSystem.Collections.Generic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC;
using VRC.SDKBase;

namespace DW6c39Q48fhvTF5jMI
{
	internal static class XxV353tthuCn4bdLyG
	{
		internal static XxV353tthuCn4bdLyG wskKdYJLbpwTkr3dKGa;

		internal static XxV353tthuCn4bdLyG dhj8GrJ5PG4jeTEdtaO()
		{
			return XxV353tthuCn4bdLyG.wskKdYJLbpwTkr3dKGa;
		}

		internal static QuickMenu edLT798gU()
		{
			return QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0();
		}

		internal static VRCUiManager hExv9kwWw()
		{
			return VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0();
		}

		internal static r2jawhWsJZW72NurQx hlCglFD42<r2jawhWsJZW72NurQx>(this object u0020)
		where r2jawhWsJZW72NurQx : Component
		{
			r2jawhWsJZW72NurQx _r2jawhWsJZW72NurQx;
			r2jawhWsJZW72NurQx component = u0020.GetComponent<r2jawhWsJZW72NurQx>();
			_r2jawhWsJZW72NurQx = (component != null ? component : u0020.AddComponent<r2jawhWsJZW72NurQx>());
			return _r2jawhWsJZW72NurQx;
		}

		public static string m0o2hWblO(object u0020)
		{
			string str;
			if (u0020.Contains("~private") && u0020.Contains("~canRequestInvite~nonce"))
			{
				str = "invite+";
			}
			else if (u0020.Contains("~private") && u0020.Contains("~nonce"))
			{
				str = "invite";
			}
			else if (u0020.Contains("~friend"))
			{
				str = "friends";
			}
			else
			{
				str = (!u0020.Contains("~hidden") ? "public" : "friends+");
			}
			return str;
		}

		internal static PlayerManager mLSUv9tiG()
		{
			return PlayerManager.Method_Public_Static_get_PlayerManager_0();
		}

		public static System.Collections.Generic.List<string> mZ4CQ3wLx(object u0020)
		{
			System.Collections.Generic.List<string> strs = new System.Collections.Generic.List<string>();
			Il2CppSystem.Collections.Generic.List<VRCUiContentButton>.Enumerator enumerator = u0020.get_pickers().GetEnumerator();
			while (enumerator.MoveNext())
			{
				VRCUiContentButton _current = enumerator.get_current();
				if (string.IsNullOrEmpty(_current.get_field_Public_String_0()))
				{
					continue;
				}
				strs.Add(_current.get_field_Public_String_0());
			}
			return strs;
		}

		internal static void no5btGhfN(this object u0020, object u0020, bool u0020)
		{
			u0020.Method_Public_Void_Renderer_Boolean_0(u0020, u0020);
		}

		internal static string pw9aejAQ7(object u0020)
		{
			string end = "";
			using (Stream responseStream = u0020.GetResponseStream())
			{
				using (StreamReader streamReader = new StreamReader(responseStream))
				{
					end = streamReader.ReadToEnd();
				}
			}
			u0020.Dispose();
			return end;
		}

		internal static HighlightsFX wCBhPxcnT()
		{
			return HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0();
		}

		public static string wVYwb1i4D()
		{
			string str = "wrld_4432ea9b-729c-46e3-8eaf-846aa0a37fdd:";
			int num = (new System.Random()).Next(0, 9999);
			return string.Concat(str, num.ToString());
		}

		internal static bool Xf86sMJJkho899Mydyb()
		{
			return XxV353tthuCn4bdLyG.wskKdYJLbpwTkr3dKGa == null;
		}

		internal static void XVaNFd9HW()
		{
			foreach (VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC_Pickup>())
			{
				Networking.get_LocalPlayer().TakeOwnership(vRCPickup.get_gameObject());
				vRCPickup.get_transform().set_localPosition(new Vector3(0f, -100000f, 0f));
			}
		}
	}
}