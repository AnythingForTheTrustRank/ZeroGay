using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Texture dSU0amfLwLnWO6Mukfv(object );