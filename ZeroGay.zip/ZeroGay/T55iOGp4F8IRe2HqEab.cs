using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string T55iOGp4F8IRe2HqEab(ref int , string );