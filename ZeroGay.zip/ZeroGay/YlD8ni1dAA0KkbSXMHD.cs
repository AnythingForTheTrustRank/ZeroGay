using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate TimeSpan YlD8ni1dAA0KkbSXMHD(DateTime dateTime_0, DateTime dateTime_1);