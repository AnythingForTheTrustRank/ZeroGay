using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Sprite CGQWF0iDavYvyCyBfB4(Texture2D , Rect , Vector2 , float , uint , SpriteMeshType , Vector4 , bool );