using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.UI.Elements;

internal delegate Dictionary<string, UIPage> yIpQ9KXAOj8D9BLeP4x(object object_0);