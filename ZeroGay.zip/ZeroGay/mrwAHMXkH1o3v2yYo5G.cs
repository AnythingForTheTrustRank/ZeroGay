using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void mrwAHMXkH1o3v2yYo5G(object object_0, bool bool_0);