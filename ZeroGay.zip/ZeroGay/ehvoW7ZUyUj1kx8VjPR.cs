using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate bool ehvoW7ZUyUj1kx8VjPR(object , string );