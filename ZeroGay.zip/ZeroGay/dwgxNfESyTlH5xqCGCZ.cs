using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnhollowerRuntimeLib.XrefScans;

internal delegate IEnumerable<XrefInstance> dwgxNfESyTlH5xqCGCZ(MethodBase methodBase_0);