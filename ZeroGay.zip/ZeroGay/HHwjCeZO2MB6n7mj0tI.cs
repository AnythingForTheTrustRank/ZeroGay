using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate VRCUiManager HHwjCeZO2MB6n7mj0tI();