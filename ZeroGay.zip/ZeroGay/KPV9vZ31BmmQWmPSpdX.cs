using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void KPV9vZ31BmmQWmPSpdX(IntPtr intptr_0);