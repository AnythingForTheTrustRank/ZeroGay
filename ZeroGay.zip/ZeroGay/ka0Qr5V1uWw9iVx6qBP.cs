using b3eD5DgJPcASx0xfHYB;
using System;
using System.Text;

internal delegate Encoding ka0Qr5V1uWw9iVx6qBP();