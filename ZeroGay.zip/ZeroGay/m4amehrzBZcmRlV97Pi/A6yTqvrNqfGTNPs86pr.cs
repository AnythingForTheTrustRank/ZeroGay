using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using LomkhBnIpcSlbUNcnTc;
using N6nRU8MeL8DN1kbqbkv;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Tr14UwanpaMXFeWIqTO;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;
using X7IetPATbOXxq4U7Vmy;

namespace m4amehrzBZcmRlV97Pi
{
	internal class A6yTqvrNqfGTNPs86pr
	{
		public static bool RNp2lQ4n4Y;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup> lmE2A4PEfX;

		public static Il2CppSystem.Collections.Generic.List<VRCObjectSync> jIi2GRla5o;

		public static bool rcj2dj8EtB;

		public static bool Txc2vT979T;

		public static bool xsv2iDNsje;

		public static bool nw829r8ouB;

		public static bool TPg2063ral;

		public static bool yr82xZDMri;

		private static A6yTqvrNqfGTNPs86pr PRSMZLmt9KCdHXET2ux;

		static A6yTqvrNqfGTNPs86pr()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			A6yTqvrNqfGTNPs86pr.RNp2lQ4n4Y = false;
			A6yTqvrNqfGTNPs86pr.lmE2A4PEfX = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Pickup>();
			A6yTqvrNqfGTNPs86pr.jIi2GRla5o = new Il2CppSystem.Collections.Generic.List<VRCObjectSync>();
			A6yTqvrNqfGTNPs86pr.Txc2vT979T = false;
			A6yTqvrNqfGTNPs86pr.xsv2iDNsje = false;
			A6yTqvrNqfGTNPs86pr.nw829r8ouB = false;
			A6yTqvrNqfGTNPs86pr.TPg2063ral = false;
			A6yTqvrNqfGTNPs86pr.yr82xZDMri = false;
		}

		public A6yTqvrNqfGTNPs86pr()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static void ASU2KQ5YAC()
		{
			foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
			{
				Networking.get_LocalPlayer().TakeOwnership(vRCPickup.get_gameObject());
				vRCPickup.get_transform().set_localPosition(new Vector3(0f, -100000f, 0f));
			}
		}

		internal static void BWq2I2BSar()
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					array[i].set_DisallowTheft(false);
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					vRCPickupArray[j].set_DisallowTheft(false);
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					array1[k].set_DisallowTheft(false);
				}
			}
		}

		public static void c9I27QcJbN()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((!child ? false : child.get_name() == "Shotgun (0)"))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static IEnumerator fIe2Qd6Vg3(bool bool_0)
		{
			while (true)
			{
				if (!XkOikGnOeE0y3L1iHtc.enwnwnxuIS)
				{
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
					{
						vRCPickup.set_DisallowTheft(false);
					}
					yield return new WaitForSeconds(0.1f);
				}
			}
		}

		internal static bool Ha4DHXmKhqf8JFco619()
		{
			return A6yTqvrNqfGTNPs86pr.PRSMZLmt9KCdHXET2ux == null;
		}

		public static void hAB22vRtsn()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "Shotgun (0)" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static IEnumerator HU5257EHua()
		{
			while (A6yTqvrNqfGTNPs86pr.yr82xZDMri)
			{
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (gameObject.get_name().Contains("Game Logic"))
					{
						gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "PlaySong4");
						gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "PlayContinue");
					}
				}
				yield return new WaitForSeconds(0.2f);
			}
		}

		public static void I2R2aRINo6()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "Knife (0)" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void ikx2Bc3kq5()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((!child ? false : child.get_name() == "Luger (0)"))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static GameObject[] kQr2c5Hivo()
		{
			return SceneManager.GetActiveScene().GetRootGameObjects();
		}

		public static void Muh2yovhg5()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((!child ? false : child.get_name() == "Luger (0)"))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void noR2rOFVhU()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "Frag (0)" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void Npf2ev3Igm()
		{
			while (A6yTqvrNqfGTNPs86pr.nw829r8ouB)
			{
				Thread.Sleep(70);
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					if (!gameObject.get_name().Contains("Game Logic"))
					{
						continue;
					}
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "SyncAssingB");
				}
			}
		}

		public static void pao26nrTjZ()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "Revolver" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void qMC2TwOdJf()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "Frag (0)" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void qPy2Ht8rjy()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((!child ? false : child.get_name() == "Smoke (0)"))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static void qv62RgjixG()
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array[i].get_gameObject());
					array[i].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform = array[i].get_transform();
					_transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(vRCPickupArray[j].get_gameObject());
					vRCPickupArray[j].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform transform = vRCPickupArray[j].get_transform();
					transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array1[k].get_gameObject());
					array1[k].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform1 = array1[k].get_transform();
					_transform1.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
		}

		public static void r8R2C0VPMK(bool bool_0)
		{
			foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
			{
				vRCPickup.set_pickupable(true);
				vRCPickup.set_DisallowTheft(false);
			}
		}

		public static void t3d2qVMiV4()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons/Unlockables");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((!child ? false : child.get_name() == "Smoke (0)"))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void tk12MOoQc1()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "Revolver" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void TlU2sq1snA()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((!child ? false : child.get_name() == "Bear Trap (0)"))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(j25MPyacibgF0kcPwHe.rjYaCVqqPo.get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		internal static void uE72ts55ek()
		{
			VRC.SDKBase.VRC_Pickup[] array = Resources.FindObjectsOfTypeAll<VRC.SDKBase.VRC_Pickup>().ToArray<VRC.SDKBase.VRC_Pickup>();
			for (int i = 0; i < (int)array.Length; i++)
			{
				if (array[i].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array[i].get_gameObject());
					array[i].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform = array[i].get_transform();
					_transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCSDK2.VRC_Pickup[] vRCPickupArray = Resources.FindObjectsOfTypeAll<VRCSDK2.VRC_Pickup>().ToArray<VRCSDK2.VRC_Pickup>();
			for (int j = 0; j < (int)vRCPickupArray.Length; j++)
			{
				if (vRCPickupArray[j].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(vRCPickupArray[j].get_gameObject());
					vRCPickupArray[j].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform transform = vRCPickupArray[j].get_transform();
					transform.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
			VRCPickup[] array1 = Resources.FindObjectsOfTypeAll<VRCPickup>().ToArray<VRCPickup>();
			for (int k = 0; k < (int)array1.Length; k++)
			{
				if (array1[k].get_gameObject())
				{
					Networking.get_LocalPlayer().TakeOwnership(array1[k].get_gameObject());
					array1[k].get_transform().set_localPosition(new Vector3(0f, 0.3f, 0f));
					Transform _transform1 = array1[k].get_transform();
					_transform1.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.1f, 0f));
				}
			}
		}

		public static void uZa2h4pcfv()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((!child ? false : child.get_name() == "Bear Trap (0)"))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static void VyI2op2FZa(object object_0)
		{
			foreach (Player array in PlayerManager.Method_Public_Static_get_PlayerManager_0().get_field_Private_List_1_Player_0().ToArray())
			{
				!(array.get_field_Private_APIUser_0().get_id() == object_0);
			}
		}

		public static void WN32YNvyTf()
		{
			GameObject gameObject = GameObject.Find("Game Logic/Weapons");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if ((child ? child.get_name() == "Knife (0)" : false))
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static IEnumerator y6x2n8aTdA(bool bool_0)
		{
			while (true)
			{
				if (!XkOikGnOeE0y3L1iHtc.nZ1nvTxrsi)
				{
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
					{
						vRCPickup.set_proximity(1E+08f);
					}
					yield return new WaitForSeconds(0.1f);
				}
			}
		}

		public static IEnumerator Ybt2OuU9bX(bool bool_0)
		{
			while (true)
			{
				if (XkOikGnOeE0y3L1iHtc.faWnR0F4Ys)
				{
					foreach (VRC.SDKBase.VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC.SDKBase.VRC_Pickup>())
					{
						vRCPickup.set_pickupable(true);
					}
					yield return new WaitForSeconds(0.1f);
				}
				else
				{
					yield return new WaitForSeconds(0.1f);
				}
			}
		}

		public static void yes()
		{
			if (!nBcbMnM7C7ZvL3AISZB.O7hME59iH3)
			{
				GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(true);
				GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(true);
				GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(true);
			}
			else
			{
				GameObject.Find("Game Logic/Weapons/Bear Trap (0)/Trap lethal bounds").set_active(false);
				GameObject.Find("Game Logic/Weapons/Bear Trap (1)/Trap lethal bounds").set_active(false);
				GameObject.Find("Game Logic/Weapons/Bear Trap (2)/Trap lethal bounds").set_active(false);
			}
		}

		internal static A6yTqvrNqfGTNPs86pr yRRZ4dmlO1D1XbjSJds()
		{
			return A6yTqvrNqfGTNPs86pr.PRSMZLmt9KCdHXET2ux;
		}
	}
}