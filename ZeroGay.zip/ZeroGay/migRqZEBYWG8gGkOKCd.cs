using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate bool migRqZEBYWG8gGkOKCd(string string_0, ref Color color_0);