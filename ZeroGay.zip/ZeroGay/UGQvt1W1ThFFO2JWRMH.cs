using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Material UGQvt1W1ThFFO2JWRMH(object object_0);