using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string O4S9No1jHEohi2nevQZ(object object_0, byte[] byte_0);