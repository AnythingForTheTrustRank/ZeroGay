using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;

internal delegate Il2CppStringArray ghKk5X0UUpSaQlIwWmQ(string[] );