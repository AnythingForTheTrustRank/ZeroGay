using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Vector2 lOZM7mxkrmdLT55Q03K(Vector2 , float );