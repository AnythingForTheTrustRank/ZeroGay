using b3eD5DgJPcASx0xfHYB;
using Fi2LqU99WjFHBwwkk0N;
using gpd3oZtw5qhYneWRlWY;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.Networking;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;

namespace krgLWAtP5LbLB3HiTbh
{
	internal class KarRCCtBsS2xtE1uWcw
	{
		public static List<VRCSDK2.VRC_Pickup> Fi7tnT9h4f;

		public static List<VRCSDK2.VRC_Trigger> hjDtenXZPI;

		public static VRC_EventHandler U6BtfqFa5Q;

		public static string[] VdstxWZhwA;

		public static bool YYCt1aqhOR;

		public static List<string> JcKtKY5DQH;

		public static bool V8MtAlOh9h;

		public static List<string> HmatVo0vuj;

		public static List<string> DhdtL6xVL1;

		public static int eU4tJ7bOgk;

		public static int eG4t5QqiSl;

		public static float pZltd01Gfa;

		public static bool h61toreD7j;

		public static bool KUxtmh1lQZ;

		public static System.Random zqOtDXdCE9;

		public static VRCPlayer Kv9tce9Nxm;

		public static string nKCtyg6kVO;

		private static Transform vsqtEYeVZj;

		private static VRC_AnimationController zp5tzgXotO;

		private static VRCVrIkController QetQq6cwCn;

		public static bool rYZQkdYg0h;

		public static List<string> fA6Q8dsXIK;

		public static bool uurQHFCyCn;

		public static bool jT6QG8ZwUF;

		public static bool aO6Q3R8Bfb;

		public static bool f59Q9ccWKW;

		public static bool x1OQsd8Zaj;

		public static bool HBUQM34U8B;

		public static bool kkoQ7DFYdG;

		public static bool x5uQ4xhGvA;

		public static bool vXlQIqF1gK;

		internal static KarRCCtBsS2xtE1uWcw sBNrTAd5BJUdI47Kliy;

		static KarRCCtBsS2xtE1uWcw()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			KarRCCtBsS2xtE1uWcw.Fi7tnT9h4f = new List<VRCSDK2.VRC_Pickup>();
			KarRCCtBsS2xtE1uWcw.hjDtenXZPI = new List<VRCSDK2.VRC_Trigger>();
			KarRCCtBsS2xtE1uWcw.YYCt1aqhOR = false;
			KarRCCtBsS2xtE1uWcw.V8MtAlOh9h = false;
			KarRCCtBsS2xtE1uWcw.HmatVo0vuj = new List<string>();
			KarRCCtBsS2xtE1uWcw.DhdtL6xVL1 = new List<string>();
			KarRCCtBsS2xtE1uWcw.eU4tJ7bOgk = 0;
			KarRCCtBsS2xtE1uWcw.eG4t5QqiSl = 19;
			KarRCCtBsS2xtE1uWcw.pZltd01Gfa = 0f;
			KarRCCtBsS2xtE1uWcw.h61toreD7j = true;
			KarRCCtBsS2xtE1uWcw.KUxtmh1lQZ = false;
			KarRCCtBsS2xtE1uWcw.zqOtDXdCE9 = new System.Random();
			KarRCCtBsS2xtE1uWcw.nKCtyg6kVO = "None";
			KarRCCtBsS2xtE1uWcw.rYZQkdYg0h = false;
			KarRCCtBsS2xtE1uWcw.fA6Q8dsXIK = new List<string>()
			{
				"pen",
				"marker",
				"grip"
			};
			KarRCCtBsS2xtE1uWcw.uurQHFCyCn = false;
			KarRCCtBsS2xtE1uWcw.jT6QG8ZwUF = false;
			KarRCCtBsS2xtE1uWcw.aO6Q3R8Bfb = false;
			KarRCCtBsS2xtE1uWcw.f59Q9ccWKW = false;
			KarRCCtBsS2xtE1uWcw.x1OQsd8Zaj = false;
			KarRCCtBsS2xtE1uWcw.HBUQM34U8B = false;
			KarRCCtBsS2xtE1uWcw.kkoQ7DFYdG = false;
			KarRCCtBsS2xtE1uWcw.x5uQ4xhGvA = false;
			KarRCCtBsS2xtE1uWcw.vXlQIqF1gK = false;
		}

		public KarRCCtBsS2xtE1uWcw()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static IEnumerator AGYt0H2OEn(bool u0020)
		{
			while (true)
			{
				if (KarRCCtBsS2xtE1uWcw.vXlQIqF1gK)
				{
					UdonSync component = GameObject.Find("GameManager/PlayerObjectList/Ghosts/PlayerCharacterObject_Ghost (2)").GetComponent<UdonSync>();
					component.Method_Public_get_Player_0().Method_Private_set_Void_APIUser_0(APIUser.get_CurrentUser());
					yield return new WaitForSeconds(9f);
					component = null;
				}
				yield return new WaitForSeconds(0.1f);
			}
		}

		internal static KarRCCtBsS2xtE1uWcw aRhkJcdo4OQdXPdENQT()
		{
			return KarRCCtBsS2xtE1uWcw.sBNrTAd5BJUdI47Kliy;
		}

		public static IEnumerator c3ktZFiUcv(bool u0020)
		{
			while (true)
			{
				if (KarRCCtBsS2xtE1uWcw.kkoQ7DFYdG)
				{
					Vector3 _position = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position();
					GameObject gameObject = GameObject.Find("PoliceStation/Props/KeySpawn/Keys/Key");
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/KeySpawn/Keys/Key (1)");
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/KeySpawn/Keys/Key (2)");
					gameObject.GetComponent<UdonBehaviour>().Interact();
					gameObject1.GetComponent<UdonBehaviour>().Interact();
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(_position);
					KarRCCtBsS2xtE1uWcw.kkoQ7DFYdG = false;
					_position = new Vector3();
					gameObject = null;
					gameObject1 = null;
					gameObject2 = null;
				}
				yield return new WaitForSeconds(1f);
			}
		}

		public static IEnumerator EWctrNuw31(bool u0020)
		{
			return new KarRCCtBsS2xtE1uWcw.<folderorbitstarget>d__39(0)
			{
				state = u0020
			};
		}

		public static void kPStlwNIMN()
		{
			GameObject gameObject = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107");
			if (gameObject)
			{
				for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
				{
					Transform child = gameObject.get_transform().GetChild(i);
					if (child && child.get_name() == "T4-M107")
					{
						Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), child.get_gameObject());
						child.set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.2f, 0f));
					}
				}
			}
		}

		public static IEnumerator lRetjlFiSG(bool u0020)
		{
			while (true)
			{
				if (KarRCCtBsS2xtE1uWcw.x1OQsd8Zaj)
				{
					Vector3 _position = VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position();
					GameObject gameObject = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key");
					GameObject gameObject1 = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key (1)");
					GameObject gameObject2 = GameObject.Find("PoliceStation_A/Functions/KeySpawn/Keys/Key (2)");
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					gameObject.GetComponent<UdonBehaviour>().Interact();
					yield return new WaitForSeconds(2f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject1.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject1.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(gameObject1.get_transform().get_position());
					yield return new WaitForSeconds(0.1f);
					gameObject1.GetComponent<UdonBehaviour>().Interact();
					VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().set_position(_position);
					KarRCCtBsS2xtE1uWcw.x1OQsd8Zaj = false;
					_position = new Vector3();
					gameObject = null;
					gameObject1 = null;
					gameObject2 = null;
				}
				yield return new WaitForSeconds(1f);
			}
		}

		public static IEnumerator N0KtRFZgyR(bool u0020)
		{
			while (true)
			{
				if (KarRCCtBsS2xtE1uWcw.uurQHFCyCn)
				{
					List<GameObject> gameObjects = new List<GameObject>()
					{
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (1)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (2)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (3)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (4)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (5)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (6)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (7)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (8)").get_gameObject(),
						GameObject.Find("PoliceStation").get_transform().Find("Props/NameClueSystem/NameClues/CluePickup (9)").get_gameObject()
					};
					List<GameObject> gameObjects1 = gameObjects;
					GameObject gameObject = new GameObject();
					gameObject.get_transform().set_position(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().get_position() + new Vector3(0f, 0.35f, 0f));
					gameObject.get_transform().Rotate(new Vector3(0f, 360f, 0f));
					foreach (GameObject gameObject1 in gameObjects1)
					{
						hIqOp093WTH3UTRyV8V.ynV9sdoy07(gameObject1.get_gameObject());
						gameObject1.get_transform().set_position(gameObject.get_transform().get_position() + gameObject.get_transform().get_forward());
						gameObject1.get_transform().LookAt(QdA6prtQJZNe9CGe8IK.RIbtOqTLrt.get_transform());
						gameObject.get_transform().Rotate(new Vector3(0f, (float)(360 / gameObjects1.Count), 0f));
					}
					UnityEngine.Object.Destroy(gameObject);
					gameObject = null;
					gameObjects1 = null;
					gameObject = null;
				}
				yield return new WaitForSeconds(0.01f);
			}
		}

		public static IEnumerator OQvtpwQuYj(bool u0020)
		{
			return new KarRCCtBsS2xtE1uWcw.<keysorbittarget>d__38(0)
			{
				state = u0020
			};
		}

		internal static bool oU4n7odd9CtlSycO7gP()
		{
			return KarRCCtBsS2xtE1uWcw.sBNrTAd5BJUdI47Kliy == null;
		}

		public static IEnumerator ThgtinUNrx(bool u0020)
		{
			return new KarRCCtBsS2xtE1uWcw.<keysorbit>d__34(0)
			{
				state = u0020
			};
		}

		public static IEnumerator UhVtFFbD4H(bool u0020)
		{
			return new KarRCCtBsS2xtE1uWcw.<MurderPlayerBETA>d__33(0)
			{
				state = u0020
			};
		}
	}
}