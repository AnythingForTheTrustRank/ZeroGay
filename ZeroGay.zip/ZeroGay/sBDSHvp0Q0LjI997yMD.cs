using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate NotificationManager sBDSHvp0Q0LjI997yMD();