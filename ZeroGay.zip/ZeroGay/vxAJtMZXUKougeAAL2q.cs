using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using System;
using UnhollowerRuntimeLib.XrefScans;

internal delegate Il2CppSystem.Object vxAJtMZXUKougeAAL2q(ref XrefInstance xrefInstance_0);