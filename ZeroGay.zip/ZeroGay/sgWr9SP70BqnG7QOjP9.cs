using AksgHVKH9UOXlBDvRpO;
using System;
using TMPro;

internal delegate void sgWr9SP70BqnG7QOjP9(object object_0, FontStyles fontStyles_0);