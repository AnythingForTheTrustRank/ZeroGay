using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate float eloLWDURQTwkcoHM5HN(Quaternion quaternion_0, Quaternion quaternion_1);