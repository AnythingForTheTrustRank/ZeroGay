using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.Core;

internal delegate Dictionary<int, List<ApiModel>> wQ8sMOFNNHxPn7XBx9e(object object_0);