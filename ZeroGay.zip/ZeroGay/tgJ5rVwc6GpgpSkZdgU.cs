using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate bool tgJ5rVwc6GpgpSkZdgU(MethodBase methodBase_0, MethodBase methodBase_1);