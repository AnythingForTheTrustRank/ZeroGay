using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using System;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace c149OAODXBUwu8nb6tO
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class ybBp1xOm2Jj593Sscgl
	{
		public static bool lBOO4RX5aB;

		internal static ybBp1xOm2Jj593Sscgl SF9gBsfd2ZwLPdQupOK;

		public ybBp1xOm2Jj593Sscgl()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool EBp1YbfvwnbRig9wZuY()
		{
			return ybBp1xOm2Jj593Sscgl.SF9gBsfd2ZwLPdQupOK == null;
		}

		internal static ybBp1xOm2Jj593Sscgl hPxXkGfivhWiSDwPCXk()
		{
			return ybBp1xOm2Jj593Sscgl.SF9gBsfd2ZwLPdQupOK;
		}

		public static bool ib9OgD42ul(ref string string_0, object object_0)
		{
			bool flag;
			if (!ybBp1xOm2Jj593Sscgl.lBOO4RX5aB)
			{
				flag = true;
			}
			else
			{
				flag = (string_0 != "SyncPenalty" ? true : false);
			}
			return flag;
		}
	}
}