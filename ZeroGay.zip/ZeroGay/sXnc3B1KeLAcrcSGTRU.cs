using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate Assembly sXnc3B1KeLAcrcSGTRU(object object_0);