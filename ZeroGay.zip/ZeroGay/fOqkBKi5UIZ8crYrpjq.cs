using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate bool fOqkBKi5UIZ8crYrpjq(Texture2D , Il2CppStructArray<byte> );