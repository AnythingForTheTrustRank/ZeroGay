using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using VRC.Core;
using X7IetPATbOXxq4U7Vmy;

namespace uhkve0TS4OmwX5tF83p
{
	internal class GVShf8TjTxUqjcaBuW6
	{
		protected GameObject s207Q94xLm;

		protected UiVRCList JTd7OHGRBv;

		protected Text erl7IxlK9J;

		private static GameObject uwT7ooo7bd;

		internal static GVShf8TjTxUqjcaBuW6 qJBDR145MfKZwb6IqXc;

		static GVShf8TjTxUqjcaBuW6()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			GVShf8TjTxUqjcaBuW6.uwT7ooo7bd = GameObject.Find("/UserInterface/MenuContent/Screens/Avatar/Vertical Scroll View/Viewport/Content/Public Avatar List");
		}

		public GVShf8TjTxUqjcaBuW6(Transform transform_0, string string_0, int int_0 = 0)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.RueTbETwOV(transform_0, string_0, int_0);
		}

		public UiVRCList AIU75AbvJI()
		{
			return this.JTd7OHGRBv;
		}

		public Text HeU7cxrLpj()
		{
			return this.erl7IxlK9J;
		}

		public void pKwTN8a5jT(Il2CppSystem.Collections.Generic.List<ApiAvatar> list_0)
		{
			this.JTd7OHGRBv.Method_Protected_Void_List_1_T_Int32_Boolean_VRCUiContentButton_0<ApiAvatar>(list_0, 0, true, null);
		}

		private void RueTbETwOV(Transform transform_0, string string_0, int int_0 = 0)
		{
			this.s207Q94xLm = UnityEngine.Object.Instantiate<GameObject>(GVShf8TjTxUqjcaBuW6.uwT7ooo7bd.get_gameObject(), transform_0);
			this.s207Q94xLm.GetComponent<UiAvatarList>().set_field_Public_Category_0(4);
			this.JTd7OHGRBv = this.s207Q94xLm.GetComponent<UiVRCList>();
			this.erl7IxlK9J = this.s207Q94xLm.get_transform().Find("Button").GetComponentInChildren<Text>();
			this.s207Q94xLm.get_transform().SetSiblingIndex(int_0);
			this.JTd7OHGRBv.set_clearUnseenListOnCollapse(false);
			this.JTd7OHGRBv.set_usePagination(false);
			this.JTd7OHGRBv.set_hideElementsWhenContracted(false);
			this.JTd7OHGRBv.set_hideWhenEmpty(false);
			this.JTd7OHGRBv.get_field_Protected_Dictionary_2_Int32_List_1_ApiModel_0().Clear();
			this.JTd7OHGRBv.get_pickerPrefab().get_transform().Find("TitleText").GetComponent<Text>().set_supportRichText(true);
			this.s207Q94xLm.SetActive(true);
			this.s207Q94xLm.set_name(string_0);
			this.erl7IxlK9J.set_supportRichText(true);
			this.erl7IxlK9J.set_text(string_0);
			UUyEqSykY4SKTrGkSI9.WG8yNXdKUy.Add(this);
		}

		internal static GVShf8TjTxUqjcaBuW6 rv8ITx4niRvIwyG3TXW()
		{
			return GVShf8TjTxUqjcaBuW6.qJBDR145MfKZwb6IqXc;
		}

		public GameObject UFATzQEK7J()
		{
			return this.s207Q94xLm;
		}

		public void vsl7nHHSYx()
		{
			try
			{
				UnityEngine.Object.Destroy(this.s207Q94xLm);
			}
			catch
			{
			}
		}

		internal static bool wOmTH74cam7bgA6Lslu()
		{
			return GVShf8TjTxUqjcaBuW6.qJBDR145MfKZwb6IqXc == null;
		}
	}
}