using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object yP6qJ7VmCZ4sAeOcG6N(Type , int );