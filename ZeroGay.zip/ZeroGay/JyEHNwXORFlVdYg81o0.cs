using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector2 JyEHNwXORFlVdYg81o0(Vector2 vector2_0, float float_0);