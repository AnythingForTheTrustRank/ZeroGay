using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using UnityEngine.Networking;

internal delegate AudioClip c12xJcVwCYQtsvVeml8(DownloadHandler downloadHandler_0, string string_0, bool bool_0, bool bool_1, AudioType audioType_0);