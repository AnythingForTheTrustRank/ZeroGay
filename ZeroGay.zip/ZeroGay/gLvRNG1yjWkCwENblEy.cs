using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Type gLvRNG1yjWkCwENblEy(object object_0, int int_0);