using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector2 IWssnMFWJ2QLPomOc8e(Vector2 vector2_0, Vector2 vector2_1);