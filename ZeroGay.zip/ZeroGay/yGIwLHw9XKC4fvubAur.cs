using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate bool yGIwLHw9XKC4fvubAur(GameObject gameObject_0);