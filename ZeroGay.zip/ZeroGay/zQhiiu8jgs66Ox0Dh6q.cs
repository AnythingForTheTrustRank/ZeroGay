using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void zQhiiu8jgs66Ox0Dh6q(object object_0, Sprite sprite_0);