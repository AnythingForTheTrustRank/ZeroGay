using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate USpeaker FPVi72LtmSHL14r2jms(object object_0);