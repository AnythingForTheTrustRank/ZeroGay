using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine.UI;

internal delegate Text R0LiE8ihQbDyFQSnfwO(object );