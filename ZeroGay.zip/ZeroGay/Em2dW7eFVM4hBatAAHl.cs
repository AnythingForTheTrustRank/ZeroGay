using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate float Em2dW7eFVM4hBatAAHl();