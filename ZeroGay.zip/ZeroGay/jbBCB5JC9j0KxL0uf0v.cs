using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate ScrollRectEx jbBCB5JC9j0KxL0uf0v(object object_0);