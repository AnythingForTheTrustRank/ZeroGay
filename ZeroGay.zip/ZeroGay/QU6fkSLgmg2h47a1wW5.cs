using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate TaskAwaiter QU6fkSLgmg2h47a1wW5(object object_0);