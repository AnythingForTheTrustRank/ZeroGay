using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object TWVsk4L13KSVQlK0FAD(Type );