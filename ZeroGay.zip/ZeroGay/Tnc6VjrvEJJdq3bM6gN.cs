using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.DataModel;

internal delegate IUser Tnc6VjrvEJJdq3bM6gN(object );