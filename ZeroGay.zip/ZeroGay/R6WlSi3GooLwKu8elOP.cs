using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int R6WlSi3GooLwKu8elOP(ref IntPtr intptr_0);