using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void I09r5kLsZT20RtaBqZ2(float float_0);