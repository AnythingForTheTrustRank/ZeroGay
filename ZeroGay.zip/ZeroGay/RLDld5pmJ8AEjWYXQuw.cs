using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using UnityEngine.XR;

internal delegate Vector3 RLDld5pmJ8AEjWYXQuw(XRNode xrnode_0);