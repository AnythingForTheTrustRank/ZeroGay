using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void sm7eR5WmSNZTrC8YjOP(object object_0, Shader shader_0);