using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void JxCrlN8zkDCpSeM95Eu(object object_0, Material material_0);