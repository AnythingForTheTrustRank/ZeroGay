using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate Assembly jkrd6aEaPvSSP0N7xd2();