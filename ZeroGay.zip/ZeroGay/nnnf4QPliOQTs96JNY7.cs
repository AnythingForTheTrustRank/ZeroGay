using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void nnnf4QPliOQTs96JNY7(object object_0, float float_0);