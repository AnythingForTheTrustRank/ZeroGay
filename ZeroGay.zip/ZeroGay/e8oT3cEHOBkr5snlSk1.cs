using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate byte[] e8oT3cEHOBkr5snlSk1(object object_0);