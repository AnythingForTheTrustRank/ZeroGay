using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate IntPtr ExyDoukolNaDWksxOJy(ref RuntimeMethodHandle runtimeMethodHandle_0);