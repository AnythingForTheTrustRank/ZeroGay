using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Type QX0PPu1zrY2PGtsaT3f(Type type_0);