using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Tr14UwanpaMXFeWIqTO;
using UnhollowerBaseLib;
using UnityEngine;
using UnityEngine.XR;
using VRC.SDK3.Components;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;

namespace etGHFk2gZHdbnPrtgfG
{
	internal static class MaFwvJ2DbFoFIA3BUAO
	{
		public static bool BVbMcLo7N7;

		public static bool wBbMnDkL6i;

		public static bool JJEMQj2sip;

		public static bool x6sMOa5NTs;

		public static bool l3VMIBmGwp;

		public static bool IAqMox4Tgc;

		private static InputDevice nySM6i6nYt;

		public static bool htVMY9YcPD;

		public static bool VT6MBxgnlQ;

		public static bool wwuMr7f3nj;

		public static string iitM21rNnb;

		private static MaFwvJ2DbFoFIA3BUAO jFnHiVm0SJNLlHjgmWf;

		static MaFwvJ2DbFoFIA3BUAO()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			MaFwvJ2DbFoFIA3BUAO.BVbMcLo7N7 = false;
			MaFwvJ2DbFoFIA3BUAO.wBbMnDkL6i = false;
			MaFwvJ2DbFoFIA3BUAO.JJEMQj2sip = false;
			MaFwvJ2DbFoFIA3BUAO.x6sMOa5NTs = false;
			MaFwvJ2DbFoFIA3BUAO.l3VMIBmGwp = false;
			MaFwvJ2DbFoFIA3BUAO.IAqMox4Tgc = false;
			MaFwvJ2DbFoFIA3BUAO.htVMY9YcPD = false;
			MaFwvJ2DbFoFIA3BUAO.VT6MBxgnlQ = false;
			MaFwvJ2DbFoFIA3BUAO.wwuMr7f3nj = false;
			MaFwvJ2DbFoFIA3BUAO.iitM21rNnb = "wrld_0ec97c4f-1e84-4a3a-9e3a-fa3075b6c56d";
		}

		public static IEnumerator aq024tpbDQ(bool bool_0)
		{
			// 
			// Current member / type: System.Collections.IEnumerator etGHFk2gZHdbnPrtgfG.MaFwvJ2DbFoFIA3BUAO::aq024tpbDQ(System.Boolean)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Collections.IEnumerator aq024tpbDQ(System.Boolean)
			// 
			// Invalid state value
			//    at ..( , Queue`1 , ILogicalConstruct ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 203
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 187
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 129
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 76
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\LogicalFlowBuilderStep.cs:line 126
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\LogicalFlowBuilderStep.cs:line 51
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext ,  , Func`2 , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 104
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext , & ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 139
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 134
			//    at ..Match( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 49
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 20
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public static IEnumerator CH12STXMp1(bool bool_0)
		{
			VRCPickup component;
			bool flag;
			bool flag1;
			bool flag2;
			VRCPickup vRCPickup;
			bool flag3;
			bool flag4;
			bool flag5;
			while (true)
			{
				if (MaFwvJ2DbFoFIA3BUAO.htVMY9YcPD && MaFwvJ2DbFoFIA3BUAO.qmf2jXfl9A())
				{
					List<VRCPickup> vRCPickups = new List<VRCPickup>();
					GameObject gameObject = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A -01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					if (gameObject == null)
					{
						component = null;
					}
					else
					{
						component = gameObject.GetComponent<VRCPickup>();
					}
					vRCPickups.Add(component);
					List<VRCPickup> vRCPickups1 = vRCPickups;
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A -01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					foreach (VRCPickup vRCPickup1 in vRCPickups1)
					{
						flag = (!Input.GetKey(324) ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
						flag1 = (!vRCPickup1.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag1)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
						flag2 = (!vRCPickup1.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag2)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
					}
					List<VRCPickup> vRCPickups2 = new List<VRCPickup>();
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					if (gameObject2 == null)
					{
						vRCPickup = null;
					}
					else
					{
						vRCPickup = gameObject2.GetComponent<VRCPickup>();
					}
					vRCPickups2.Add(vRCPickup);
					List<VRCPickup> vRCPickups3 = vRCPickups2;
					GameObject gameObject3 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_M107/Reward_M107/T4-M107");
					foreach (VRCPickup vRCPickup2 in vRCPickups3)
					{
						flag3 = (!Input.GetKey(324) ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag3)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
						flag4 = (!vRCPickup2.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag4)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
						flag5 = (!vRCPickup2.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag5)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
					}
					vRCPickups1 = null;
					gameObject1 = null;
					vRCPickups3 = null;
					gameObject3 = null;
				}
				yield return new WaitForSeconds(0.3f);
			}
		}

		internal static bool cSs9TxmxhskuboDZD8s()
		{
			return MaFwvJ2DbFoFIA3BUAO.jFnHiVm0SJNLlHjgmWf == null;
		}

		public static IEnumerator EPcM5F8M00(bool bool_0)
		{
			// 
			// Current member / type: System.Collections.IEnumerator etGHFk2gZHdbnPrtgfG.MaFwvJ2DbFoFIA3BUAO::EPcM5F8M00(System.Boolean)
			// File path: C:\Users\Charlie\Desktop\somewhat_cleaned_zero_gay.dll
			// 
			// Product version: 2019.1.118.0
			// Exception in: System.Collections.IEnumerator EPcM5F8M00(System.Boolean)
			// 
			// Invalid state value
			//    at ..( , Queue`1 , ILogicalConstruct ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 203
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 187
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 129
			//    at ..( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\YieldGuardedBlocksBuilder.cs:line 76
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\LogicalFlowBuilderStep.cs:line 126
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\LogicFlow\LogicalFlowBuilderStep.cs:line 51
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext ,  , Func`2 , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 104
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , DecompilationContext , & ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 139
			//    at ..() in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 134
			//    at ..Match( ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 49
			//    at ..(DecompilationContext ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Steps\RebuildYieldStatementsStep.cs:line 20
			//    at ..(MethodBody ,  , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 88
			//    at ..(MethodBody , ILanguage ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\DecompilationPipeline.cs:line 70
			//    at Telerik.JustDecompiler.Decompiler.Extensions.( , ILanguage , MethodBody , DecompilationContext& ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 95
			//    at Telerik.JustDecompiler.Decompiler.Extensions.(MethodBody , ILanguage , DecompilationContext& ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\Extensions.cs:line 58
			//    at ..(ILanguage , MethodDefinition ,  ) in C:\DeveloperTooling_JD_Agent1\_work\15\s\OpenSource\Cecil.Decompiler\Decompiler\WriterContextServices\BaseWriterContextService.cs:line 117
			// 
			// mailto: JustDecompilePublicFeedback@telerik.com

		}

		public static IEnumerator Ggt2brRtAd(bool bool_0)
		{
			VRCPickup component;
			bool flag;
			bool flag1;
			bool flag2;
			VRCPickup vRCPickup;
			bool flag3;
			bool flag4;
			bool flag5;
			while (true)
			{
				if (MaFwvJ2DbFoFIA3BUAO.VT6MBxgnlQ && MaFwvJ2DbFoFIA3BUAO.qmf2jXfl9A())
				{
					List<VRCPickup> vRCPickups = new List<VRCPickup>();
					GameObject gameObject = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward _Shotgun/RewardB_Shotgun/T3-m500");
					if (gameObject != null)
					{
						component = gameObject.GetComponent<VRCPickup>();
					}
					else
					{
						component = null;
					}
					vRCPickups.Add(component);
					List<VRCPickup> vRCPickups1 = vRCPickups;
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward _Shotgun/RewardB_Shotgun/T3-m500");
					foreach (VRCPickup vRCPickup1 in vRCPickups1)
					{
						flag = (Input.GetKey(324) ? Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()) : false);
						if (flag)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
						flag1 = (!vRCPickup1.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag1)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
						flag2 = (!vRCPickup1.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag2)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
					}
					List<VRCPickup> vRCPickups2 = new List<VRCPickup>();
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward _Shotgun/RewardB_Shotgun/T3-m500");
					if (gameObject2 != null)
					{
						vRCPickup = gameObject2.GetComponent<VRCPickup>();
					}
					else
					{
						vRCPickup = null;
					}
					vRCPickups2.Add(vRCPickup);
					List<VRCPickup> vRCPickups3 = vRCPickups2;
					GameObject gameObject3 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward _Shotgun/RewardB_Shotgun/T3-m500");
					foreach (VRCPickup vRCPickup2 in vRCPickups3)
					{
						flag3 = (!Input.GetKey(324) ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag3)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
						flag4 = (!vRCPickup2.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag4)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
						flag5 = (!vRCPickup2.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag5)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
					}
					vRCPickups1 = null;
					gameObject1 = null;
					vRCPickups3 = null;
					gameObject3 = null;
				}
				yield return new WaitForSeconds(0.2f);
			}
		}

		internal static MaFwvJ2DbFoFIA3BUAO nVup0emJKWp16Hml9jA()
		{
			return MaFwvJ2DbFoFIA3BUAO.jFnHiVm0SJNLlHjgmWf;
		}

		public static bool qmf2jXfl9A()
		{
			bool flag;
			flag = (RoomManager.Method_Internal_Static_get_String_0().Contains(MaFwvJ2DbFoFIA3BUAO.iitM21rNnb) ? true : false);
			return flag;
		}

		public static IEnumerator RaM2zb9Wsa(bool bool_0)
		{
			while (true)
			{
				if (MaFwvJ2DbFoFIA3BUAO.x6sMOa5NTs)
				{
					GameObject gameObject = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor");
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor (1)");
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Local_AddOneMoreKey", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_AddOneMoreKey", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "UnLockSound", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "UnLockSound", null, false);
					yield return new WaitForSeconds(0.5f);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Local_AddOneMoreKey", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Local_AddOneMoreKey", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Local_AddOneMoreKey", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject, "Local_AddOneMoreKey", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_AddOneMoreKey", null, false);
					yield return new WaitForSeconds(0.5f);
					MaFwvJ2DbFoFIA3BUAO.x6sMOa5NTs = false;
					gameObject = null;
					gameObject1 = null;
				}
				else if (MaFwvJ2DbFoFIA3BUAO.l3VMIBmGwp)
				{
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor/Door_Metal_Gray_mesh (1)");
					GameObject gameObject3 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor (1)/Door_Metal_Gray_mesh (1)");
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject2, "Local_OpenClockwise", null, false);
					j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_OpenClockwise", null, false);
					MaFwvJ2DbFoFIA3BUAO.l3VMIBmGwp = false;
					gameObject2 = null;
					gameObject3 = null;
				}
				else if (MaFwvJ2DbFoFIA3BUAO.IAqMox4Tgc)
				{
					GameObject gameObject4 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor/Door_Metal_Gray_mesh (1)");
					GameObject gameObject5 = GameObject.Find("PoliceStation/Props/LockDoors/LockDoor (1)/Door_Metal_Gray_mesh (1)");
					gameObject4.set_active(false);
					gameObject5.set_active(false);
					MaFwvJ2DbFoFIA3BUAO.IAqMox4Tgc = false;
					gameObject4 = null;
					gameObject5 = null;
				}
				yield return new WaitForSeconds(1f);
			}
		}

		public static IEnumerator WAV2NANpU3(bool bool_0)
		{
			VRCPickup component;
			bool flag;
			bool flag1;
			bool flag2;
			VRCPickup vRCPickup;
			bool flag3;
			bool flag4;
			bool flag5;
			while (true)
			{
				if (MaFwvJ2DbFoFIA3BUAO.wwuMr7f3nj && MaFwvJ2DbFoFIA3BUAO.qmf2jXfl9A())
				{
					List<VRCPickup> vRCPickups = new List<VRCPickup>();
					GameObject gameObject = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					if (gameObject != null)
					{
						component = gameObject.GetComponent<VRCPickup>();
					}
					else
					{
						component = null;
					}
					vRCPickups.Add(component);
					List<VRCPickup> vRCPickups1 = vRCPickups;
					GameObject gameObject1 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					foreach (VRCPickup vRCPickup1 in vRCPickups1)
					{
						flag = (!Input.GetKey(324) ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
						flag1 = (!vRCPickup1.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag1)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
						flag2 = (!vRCPickup1.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup1.get_gameObject()));
						if (flag2)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject1, "Local_FireOneShot", null, false);
						}
					}
					List<VRCPickup> vRCPickups2 = new List<VRCPickup>();
					GameObject gameObject2 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					if (gameObject2 != null)
					{
						vRCPickup = gameObject2.GetComponent<VRCPickup>();
					}
					else
					{
						vRCPickup = null;
					}
					vRCPickups2.Add(vRCPickup);
					List<VRCPickup> vRCPickups3 = vRCPickups2;
					GameObject gameObject3 = GameObject.Find("PoliceStation/Props/LootBoxes/Closet_A (1)-01/LootBoxSystem/Rewards/Reward_Vector/Reward_Vector/T3-Vector");
					foreach (VRCPickup vRCPickup2 in vRCPickups3)
					{
						flag3 = (!Input.GetKey(324) ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag3)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
						flag4 = (!vRCPickup2.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag4)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
						flag5 = (!vRCPickup2.get_IsHeld() || Input.GetAxis("Oculus_CrossPlatform_SecondaryIndexTrigger") <= 0f ? false : Networking.IsOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), vRCPickup2.get_gameObject()));
						if (flag5)
						{
							j25MPyacibgF0kcPwHe.z8OaILeQTR(gameObject3, "Local_FireOneShot", null, false);
						}
					}
					vRCPickups1 = null;
					gameObject1 = null;
					vRCPickups3 = null;
					gameObject3 = null;
				}
				yield return new WaitForSeconds(0.01f);
			}
		}
	}
}