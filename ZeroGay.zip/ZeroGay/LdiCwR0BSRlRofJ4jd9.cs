using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate bool LdiCwR0BSRlRofJ4jd9(UnityEngine.Object );