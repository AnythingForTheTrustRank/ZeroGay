using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate int NKajFoVrhgI9bNf8fxW(string string_0);