using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void Y9vLkEEuloKTYDjvf42(string string_0);