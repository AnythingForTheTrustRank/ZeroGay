using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Delegate Sd9U2ekJiKKymM3L6DH(object object_0, Type type_0);