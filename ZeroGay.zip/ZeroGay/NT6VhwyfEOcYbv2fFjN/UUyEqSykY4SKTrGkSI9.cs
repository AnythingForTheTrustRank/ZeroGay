using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using pw9US87YAVX4ooVmsJY;
using sljxub7H1ov1witsfvE;
using System;
using System.Collections.Generic;
using uhkve0TS4OmwX5tF83p;
using VqcUVtTpNQvxPM1kfeq;
using X7IetPATbOXxq4U7Vmy;
using xLewLd7b9wDrreoOTAR;

namespace NT6VhwyfEOcYbv2fFjN
{
	internal static class UUyEqSykY4SKTrGkSI9
	{
		internal static List<QMSingleButton> f2uymf0idQ;

		internal static List<QMNestedButton> UdByDTInVW;

		internal static List<QMToggleButton> vqFygGdLuS;

		internal static List<QMInfo> ahWy4JnWQS;

		internal static List<aJJj5I7S5WNQ76ULjw3> M6vyjPcRCq;

		internal static List<jd0oRo7hWTSH418pWot> ojRyS51qkx;

		internal static List<wce0YjTwoh5s2q9qAUw> PYyyb6rsCJ;

		internal static List<GVShf8TjTxUqjcaBuW6> WG8yNXdKUy;

		internal static List<Ohp8cy76CFn28WDiium> KipyzaHItX;

		internal static UUyEqSykY4SKTrGkSI9 bheaFvgURWLvktqsrlH;

		static UUyEqSykY4SKTrGkSI9()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			UUyEqSykY4SKTrGkSI9.f2uymf0idQ = new List<QMSingleButton>();
			UUyEqSykY4SKTrGkSI9.UdByDTInVW = new List<QMNestedButton>();
			UUyEqSykY4SKTrGkSI9.vqFygGdLuS = new List<QMToggleButton>();
			UUyEqSykY4SKTrGkSI9.ahWy4JnWQS = new List<QMInfo>();
			UUyEqSykY4SKTrGkSI9.M6vyjPcRCq = new List<aJJj5I7S5WNQ76ULjw3>();
			UUyEqSykY4SKTrGkSI9.ojRyS51qkx = new List<jd0oRo7hWTSH418pWot>();
			UUyEqSykY4SKTrGkSI9.PYyyb6rsCJ = new List<wce0YjTwoh5s2q9qAUw>();
			UUyEqSykY4SKTrGkSI9.WG8yNXdKUy = new List<GVShf8TjTxUqjcaBuW6>();
			UUyEqSykY4SKTrGkSI9.KipyzaHItX = new List<Ohp8cy76CFn28WDiium>();
		}

		internal static UUyEqSykY4SKTrGkSI9 AOvSHiguU4fDT1jZ4Wo()
		{
			return UUyEqSykY4SKTrGkSI9.bheaFvgURWLvktqsrlH;
		}

		internal static bool mYINLFgPGexeMayBmKG()
		{
			return UUyEqSykY4SKTrGkSI9.bheaFvgURWLvktqsrlH == null;
		}
	}
}