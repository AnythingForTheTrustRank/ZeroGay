using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string VWXdc5VvxWAraeROFVH(object object_0);