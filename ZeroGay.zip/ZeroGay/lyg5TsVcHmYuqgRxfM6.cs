using AksgHVKH9UOXlBDvRpO;
using Photon.Realtime;
using System;

internal delegate LoadBalancingClient lyg5TsVcHmYuqgRxfM6();