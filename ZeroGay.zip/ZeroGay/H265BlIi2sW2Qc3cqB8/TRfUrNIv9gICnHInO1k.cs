using AksgHVKH9UOXlBDvRpO;
using HarmonyLib;
using System;
using VRC.Networking;
using X7IetPATbOXxq4U7Vmy;

namespace H265BlIi2sW2Qc3cqB8
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class TRfUrNIv9gICnHInO1k
	{
		public static bool gPeI0EYTL8;

		internal static TRfUrNIv9gICnHInO1k iTGIJAfVIThMaPpj9Jw;

		public TRfUrNIv9gICnHInO1k()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static TRfUrNIv9gICnHInO1k bWgPFUf14i5l54XjMBQ()
		{
			return TRfUrNIv9gICnHInO1k.iTGIJAfVIThMaPpj9Jw;
		}

		internal static bool dumxxsfL73yOXbUplGb()
		{
			return TRfUrNIv9gICnHInO1k.iTGIJAfVIThMaPpj9Jw == null;
		}

		public static bool zVqI9sVmum(ref string string_0, object object_0)
		{
			bool flag;
			if (TRfUrNIv9gICnHInO1k.gPeI0EYTL8)
			{
				flag = (!string_0.Contains("HitDamage") ? true : false);
			}
			else
			{
				flag = true;
			}
			return flag;
		}
	}
}