using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate IntPtr zXB4pTJs3mC6LbMIX45(int );