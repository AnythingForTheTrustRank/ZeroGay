using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate HideFlags EdOr5LEKxg3aAgimVRE(object object_0);