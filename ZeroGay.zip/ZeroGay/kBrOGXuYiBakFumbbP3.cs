using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string kBrOGXuYiBakFumbbP3(string string_0);