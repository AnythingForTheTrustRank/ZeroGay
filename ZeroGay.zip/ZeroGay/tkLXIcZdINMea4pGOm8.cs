using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.Networking;

internal delegate UnityWebRequest tkLXIcZdINMea4pGOm8(string string_0);