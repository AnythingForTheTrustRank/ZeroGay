using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate uint Pc61GgLW5ih0rsE9AhP(ref UIntPtr );