using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string U5nuNcwYSY0tXHN4tYy(string string_0, object object_0, object object_1, object object_2);