using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.DataModel;
using VRC.SDKBase;
using VRC.UI;
using VRC.UI.Elements.Menus;
using X7IetPATbOXxq4U7Vmy;

namespace bbpWgwIfZVoArIOgl4C
{
	internal static class SYtjHrIkiLuEC8CAbH4
	{
		private static GameObject mSCo2bPHYL;

		private static int pg9oMnlaFW;

		public static string W02oakQ6vh;

		public static System.Collections.Generic.Dictionary<int, Player> Q3YoylSL7Y;

		internal static SYtjHrIkiLuEC8CAbH4 qCfXEKmTPukmwrXj8E5;

		static SYtjHrIkiLuEC8CAbH4()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			SYtjHrIkiLuEC8CAbH4.pg9oMnlaFW = 0;
			SYtjHrIkiLuEC8CAbH4.W02oakQ6vh = "";
			SYtjHrIkiLuEC8CAbH4.Q3YoylSL7Y = new System.Collections.Generic.Dictionary<int, Player>();
		}

		public static VRCPlayer b2loBSAusQ()
		{
			return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
		}

		public static string dGkoceLJM9(this object object_0)
		{
			string str;
			float single = object_0.u09IDIONCK();
			if (single <= 80f)
			{
				str = (single <= 30f ? string.Concat("<color=red>", single.ToString(), "</color>") : string.Concat("<color=yellow>", single.ToString(), "</color>"));
			}
			else
			{
				str = string.Concat("<color=green>", single.ToString(), "</color>");
			}
			return str;
		}

		public static void DxQIzsmd4b()
		{
			AssetBundleDownloadManager.get_field_Private_Static_AssetBundleDownloadManager_0().get_field_Private_Cache_0().ClearCache();
			AssetBundleDownloadManager.get_field_Private_Static_AssetBundleDownloadManager_0().get_field_Private_Queue_1_AssetBundleDownload_0().Clear();
			AssetBundleDownloadManager.get_field_Private_Static_AssetBundleDownloadManager_0().get_field_Private_Queue_1_AssetBundleDownload_1().Clear();
		}

		internal static bool g8BYEym7VLGP6DQHLeK()
		{
			return SYtjHrIkiLuEC8CAbH4.qCfXEKmTPukmwrXj8E5 == null;
		}

		public static bool H2MI4aDEpl(this object object_0)
		{
			return ((object_0.OYeIgjYkFm() > 0 || object_0.u09IDIONCK() > 0f) && object_0.u09IDIONCK() > -1f ? object_0.get_transform().get_position() == Vector3.get_zero() : true);
		}

		public static void HSJoO3MQCM(this object object_0, bool bool_0)
		{
			object_0.get__player().R5QoIQwyoF(bool_0);
		}

		public static string J7xonjeXPj(this object object_0)
		{
			string str;
			float single = object_0.u09IDIONCK();
			short num = object_0.OYeIgjYkFm();
			if (num > 665)
			{
				str = " <color=red>ClientUser</color>";
			}
			else if (num < -2)
			{
				str = " <color=red>ClientUser</color>";
			}
			else if (single > 140f)
			{
				str = " <color=red>ClientUser</color>";
			}
			else
			{
				str = (single < -2f ? " <color=red>ClientUser</color>" : "");
			}
			return str;
		}

		public static string k47o6DkAI4()
		{
			int _playerId = SYtjHrIkiLuEC8CAbH4.b2loBSAusQ().Method_Public_get_VRCPlayerApi_0().get_playerId();
			return _playerId.ToString();
		}

		internal static SYtjHrIkiLuEC8CAbH4 Lq96pOmeYwS1QCKFVX3()
		{
			return SYtjHrIkiLuEC8CAbH4.qCfXEKmTPukmwrXj8E5;
		}

		public static void NAGooaYM2Z(object object_0)
		{
			PageAvatar component = GameObject.Find("Screens").get_transform().Find("Avatar").GetComponent<PageAvatar>();
			SimpleAvatarPedestal fieldPublicSimpleAvatarPedestal0 = component.get_field_Public_SimpleAvatarPedestal_0();
			ApiAvatar apiAvatar = new ApiAvatar();
			apiAvatar.set_id(object_0);
			fieldPublicSimpleAvatarPedestal0.set_field_Internal_ApiAvatar_0(apiAvatar);
			component.ChangeToSelectedAvatar();
		}

		public static short OYeIgjYkFm(this object object_0)
		{
			return object_0.get__playerNet().get_field_Private_Int16_0();
		}

		public static void R5QoIQwyoF(this object object_0, bool bool_0)
		{
			object_0.get_transform().Find("ForwardDirection").get_gameObject().set_active(!bool_0);
		}

		public static Color RFgIN3gcBq(this object object_0)
		{
			return VRCPlayer.Method_Public_Static_Color_APIUser_0(object_0.Method_Internal_get_APIUser_0());
		}

		public static string SKxoQfnRvU(this object object_0)
		{
			string str;
			short num = object_0.OYeIgjYkFm();
			if (num > 150)
			{
				str = string.Concat("<color=red>", num.ToString(), "</color>");
			}
			else
			{
				str = (num <= 75 ? string.Concat("<color=green>", num.ToString(), "</color>") : string.Concat("<color=yellow>", num.ToString(), "</color>"));
			}
			return str;
		}

		public static float u09IDIONCK(this object object_0)
		{
			return (float)object_0.get__playerNet().Method_Public_get_Byte_0();
		}

		public static bool WAhIjRDydf(this object object_0)
		{
			return (object_0.OYeIgjYkFm() > 0 || object_0.u09IDIONCK() > 0f ? false : object_0.u09IDIONCK() <= -1f);
		}

		public static bool WLpISrHGYm(this object object_0)
		{
			return (object_0.OYeIgjYkFm() > 0 || object_0.u09IDIONCK() > 0f ? object_0.get_transform().get_position() == Vector3.get_zero() : true);
		}

		public static int wQqo5NcKcb(this object object_0)
		{
			byte fieldPrivateByte0 = object_0.get__playerNet().get_field_Private_Byte_0();
			byte fieldPrivateByte1 = object_0.get__playerNet().get_field_Private_Byte_1();
			if ((fieldPrivateByte0 != object_0.get__playerNet().get_field_Private_Byte_0() ? false : fieldPrivateByte1 == object_0.get__playerNet().get_field_Private_Byte_1()))
			{
				SYtjHrIkiLuEC8CAbH4.pg9oMnlaFW++;
			}
			else
			{
				SYtjHrIkiLuEC8CAbH4.pg9oMnlaFW = 0;
			}
			return SYtjHrIkiLuEC8CAbH4.pg9oMnlaFW;
		}

		private static VRCPlayer yQhImwqC4b()
		{
			return VRCPlayer.get_field_Internal_Static_VRCPlayer_0();
		}

		public static IUser zi6IbCsk0p(this object object_0)
		{
			return object_0.get_field_Private_IUser_0();
		}
	}
}