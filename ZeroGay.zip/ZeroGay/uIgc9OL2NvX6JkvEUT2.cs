using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using VRC.SDKBase;

internal delegate VRCPlayerApi uIgc9OL2NvX6JkvEUT2(GameObject gameObject_0);