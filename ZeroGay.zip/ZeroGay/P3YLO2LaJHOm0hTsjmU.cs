using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate ulong P3YLO2LaJHOm0hTsjmU(ref UIntPtr );