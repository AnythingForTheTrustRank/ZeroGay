using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate AssetBundle bHiKiqFyJrF0tYMNSYS(Il2CppStructArray<byte> , uint );