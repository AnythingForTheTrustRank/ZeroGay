using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC.SDKBase;
using X7IetPATbOXxq4U7Vmy;

namespace QQvuud280hKNN3PPqgR
{
	internal class bUqSA52JHZYZDdqgmrb
	{
		public static bool W342WC1UOM;

		public static bool wnd2UHr7Cq;

		public static bool ycW2Pd7rB9;

		public static bool KqZ2ucTUc7;

		public static float OJO2Fdq7TG;

		public static float Jrn2XI77rr;

		public static float v0G2ZC6FOe;

		public static float HDL2VCgmq2;

		public static bool T0d2LirjRQ;

		private static bUqSA52JHZYZDdqgmrb gQH8gMmAwEEkAS7w9Q2;

		static bUqSA52JHZYZDdqgmrb()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			bUqSA52JHZYZDdqgmrb.W342WC1UOM = false;
			bUqSA52JHZYZDdqgmrb.wnd2UHr7Cq = false;
			bUqSA52JHZYZDdqgmrb.ycW2Pd7rB9 = false;
			bUqSA52JHZYZDdqgmrb.KqZ2ucTUc7 = false;
			bUqSA52JHZYZDdqgmrb.OJO2Fdq7TG = 16f;
			bUqSA52JHZYZDdqgmrb.Jrn2XI77rr = 8f;
			bUqSA52JHZYZDdqgmrb.v0G2ZC6FOe = 8f;
			bUqSA52JHZYZDdqgmrb.HDL2VCgmq2 = 6f;
			bUqSA52JHZYZDdqgmrb.T0d2LirjRQ = false;
		}

		public bUqSA52JHZYZDdqgmrb()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static void Bgs2pbkHi1(bool bool_0)
		{
			if (!bUqSA52JHZYZDdqgmrb.KqZ2ucTUc7)
			{
				Networking.get_LocalPlayer().SetJumpImpulse(3f);
			}
			else
			{
				Networking.get_LocalPlayer().SetJumpImpulse(bUqSA52JHZYZDdqgmrb.v0G2ZC6FOe);
			}
		}

		public static IEnumerator IDi2EJsn9f(bool bool_0)
		{
			return new bUqSA52JHZYZDdqgmrb.<InfJump>d__9(0)
			{
				state = bool_0
			};
		}

		internal static bool jbwJx4mGl5TSmshdfrP()
		{
			return bUqSA52JHZYZDdqgmrb.gQH8gMmAwEEkAS7w9Q2 == null;
		}

		internal static bUqSA52JHZYZDdqgmrb N4IXHVmd8RM6ojx08B3()
		{
			return bUqSA52JHZYZDdqgmrb.gQH8gMmAwEEkAS7w9Q2;
		}

		internal static void rQ22w2KNYf(bool bool_0)
		{
			if (!bUqSA52JHZYZDdqgmrb.ycW2Pd7rB9)
			{
				Networking.get_LocalPlayer().SetWalkSpeed(2f);
				Networking.get_LocalPlayer().SetRunSpeed(4f);
				Networking.get_LocalPlayer().SetStrafeSpeed(2f);
			}
			else
			{
				Networking.get_LocalPlayer().SetWalkSpeed(bUqSA52JHZYZDdqgmrb.Jrn2XI77rr);
				Networking.get_LocalPlayer().SetRunSpeed(bUqSA52JHZYZDdqgmrb.OJO2Fdq7TG);
				Networking.get_LocalPlayer().SetStrafeSpeed(bUqSA52JHZYZDdqgmrb.Jrn2XI77rr);
			}
		}
	}
}