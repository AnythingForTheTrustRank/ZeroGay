using AksgHVKH9UOXlBDvRpO;
using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;

namespace LomkhBnIpcSlbUNcnTc
{
	internal class XkOikGnOeE0y3L1iHtc
	{
		public static string fMUn2eDMrc;

		public static string ePxnM4il7k;

		public static string CfFna0PyHO;

		public static string hPynyRFZPJ;

		public static bool vGNnTwAbnR;

		public static bool a8ln7WhW7A;

		public static bool GjOneLqfec;

		public static bool Me6nCqtKVb;

		public static bool hDtnqx4169;

		public static bool A1qnhCEhHo;

		public static bool VV4nHgcChi;

		public static bool Tcxnswutrj;

		public static bool faWnR0F4Ys;

		public static bool DSTntvaeYk;

		public static bool eTTnKxE6pR;

		public static bool iUunlypqYJ;

		public static bool mbAnAyHyQq;

		public static bool LS1nGU2U1X;

		public static bool qv2ndc4fmr;

		public static bool nZ1nvTxrsi;

		public static bool HMxnikRYTJ;

		public static string VBRn9qy5Wm;

		public static string H8Wn09GN85;

		public static Color gCwnxePVx0;

		public static Color ggKnJsAqk7;

		public static bool q2En8fxw1g;

		public static bool dxtnEwb3u0;

		public static bool enwnwnxuIS;

		public static bool flYnp664Oi;

		public static bool Q0BnW5LntK;

		public static bool IL0nUPtsW0;

		public static bool OYAnP6tvrM;

		public static bool vqJnu5EHWF;

		public static bool kQunFp8SpQ;

		public static bool SmVnXcxjBH;

		public static bool vvlnZJ4m9r;

		public static bool sPrnVwUiDx;

		public static int SCxnLRLO9E;

		public static bool uqJn1o5IY7;

		public static bool DWln3KDagW;

		public static bool A94nkASCbh;

		public static bool iZlnfB5qaK;

		public static bool ws2nmnEnBr;

		public static bool HpwnDwnlE7;

		public static bool reRngSQPet;

		public static bool PWvn4Feqef;

		public static bool NQSnjYG2gb;

		public static bool qQ9nS55jfl;

		public static bool ELynbVDjj3;

		public static bool jjsnNEB4bC;

		public static bool mDynzCgyjG;

		public static bool LcPQ5wqRks;

		public static bool O81QcwGIX4;

		public static bool MSBQntxIoe;

		public static bool IjAQQ0ospr;

		public static bool u2mQOPQiy8;

		public static bool lKVQIF9fld;

		public static bool a7kQoXQJQc;

		public static bool IsNQ6mPpKY;

		public static bool Vp0QYDYS6c;

		public static bool LiQQBwK1M8;

		public static bool mqtQrpuUJ1;

		public static float M7tQ2XTuwZ;

		public static bool YOwQMDjJxD;

		public static bool sQeQaLYX2B;

		public static bool ym5QySxEZ2;

		public static bool Kk3QTeBC8L;

		public static bool tUHQ7YGKvT;

		public static bool wqYQeg9xe9;

		public static bool cJWQCIwpBX;

		public static bool wsyQqU7Wh8;

		public static float GwGQhnEtIr;

		public static bool PrJQHrwy00;

		public static bool JLJQsHqJba;

		public static bool s00QRmgCSX;

		public static bool YnmQt8hyTu;

		public static bool yirQKiTxUH;

		public static bool UqBQlnf7Lp;

		public static bool bVhQATe8AF;

		public static bool r3HQGmFWHV;

		public static bool BwVQdiQnmZ;

		public static bool DeNQvSYUVZ;

		public static bool v3mQi7PODg;

		public static bool NUBQ9ycafn;

		public static bool pKYQ0IUrO7;

		public static bool lMOQxtFjaC;

		public static bool kd3QJ6dADu;

		public static bool pTcQ8yCETi;

		public static bool qxXQEg81TM;

		public static bool G8BQwLG3as;

		public static bool YYQQpmKGrf;

		public static bool wsJQWdobEE;

		public static bool zUjQU5jmq8;

		public static bool fZpQPVNFpk;

		public static bool bqmQujswK7;

		public static bool GHSQFLPSqN;

		public static bool ctVQXyyUfw;

		public static bool jYaQZWehCj;

		public static bool at9QVkR4IV;

		public static bool IaYQLnt0mM;

		public static bool uZWQ1D9Yx9;

		public static bool GrJQ31IgMd;

		public static bool lTMQkLjcv8;

		public static bool uP3QfAKD3V;

		public static bool rYVQmlybj4;

		public static bool AydQDOIkYS;

		public static bool gwIQgwevVU;

		public static bool o9tQ426MNU;

		public static bool cfnQjBNfrS;

		public static bool C29QS1BwvM;

		public static bool Ry0Qbha3dD;

		public static bool gcUQNhVfBd;

		public static bool xyRQzArlmY;

		public static bool i3EO54IObt;

		public static bool TwuOc5C1yg;

		public static bool QhIOn5UZpM;

		public static bool uY0OQko6ZH;

		public static bool nMxOOlTRXv;

		public static bool r6iOIYdxQ3;

		public static bool YJVOotA5JS;

		public static bool UBwO61NoTG;

		public static bool UqpOYVBVUA;

		public static bool LHmOBMxYuk;

		public static bool JEsOrqd23T;

		public static bool oC3O2UtQga;

		public static bool mrmOMIqGQt;

		public static bool blHOakvSa1;

		public static bool EsyOyQ59cw;

		public static bool YTtOTH20Yn;

		public static bool TTOO7MgTrh;

		public static bool GbOOeyv4KD;

		public static bool B8FOC7w0ly;

		public static bool TVrOqb957r;

		public static bool M8nOhS1OY1;

		public static bool FkHOH6mw0V;

		public static bool Vj7OsbtpFA;

		public static float jv5ORiCgcx;

		public static bool HX3OtXlIZP;

		public static float hItOKvesOG;

		public static float dxROlKuaiM;

		public static bool DiCOA94P80;

		public static bool nkAOGor8JR;

		public static bool z9gOdc0WPh;

		public static bool WqcOvRfffw;

		public static bool Ix0OiKbdXr;

		public static bool XY4O9ryYDN;

		public static bool PM2O0ir6VM;

		public static bool abdOxYcHVS;

		public static bool g42OJSiAye;

		public static bool oEEO81RjSf;

		public static float cC5OEu03ty;

		public static float AhcOwr3N7h;

		public static bool S8EOps6ZZS;

		public static bool SMMOWnR8l2;

		public static bool faZOUWlMl2;

		public static bool avSOPCGFiQ;

		public static bool mfBOu4lYyS;

		public static Vector3 QqdOFAVf1Y;

		public static Dictionary<string, XkOikGnOeE0y3L1iHtc.nMhMWZe8qAeWKVdeYDE> j7rOXVxiFb;

		private static XkOikGnOeE0y3L1iHtc zYdexOfRnYCT5GOfCpU;

		static XkOikGnOeE0y3L1iHtc()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			XkOikGnOeE0y3L1iHtc.fMUn2eDMrc = "avtr_999";
			XkOikGnOeE0y3L1iHtc.ePxnM4il7k = "avtr_999";
			XkOikGnOeE0y3L1iHtc.CfFna0PyHO = "avtr_999";
			XkOikGnOeE0y3L1iHtc.hPynyRFZPJ = "avtr_999";
			XkOikGnOeE0y3L1iHtc.vGNnTwAbnR = false;
			XkOikGnOeE0y3L1iHtc.a8ln7WhW7A = false;
			XkOikGnOeE0y3L1iHtc.GjOneLqfec = false;
			XkOikGnOeE0y3L1iHtc.Me6nCqtKVb = false;
			XkOikGnOeE0y3L1iHtc.hDtnqx4169 = false;
			XkOikGnOeE0y3L1iHtc.A1qnhCEhHo = false;
			XkOikGnOeE0y3L1iHtc.VV4nHgcChi = false;
			XkOikGnOeE0y3L1iHtc.Tcxnswutrj = false;
			XkOikGnOeE0y3L1iHtc.faWnR0F4Ys = false;
			XkOikGnOeE0y3L1iHtc.DSTntvaeYk = false;
			XkOikGnOeE0y3L1iHtc.eTTnKxE6pR = false;
			XkOikGnOeE0y3L1iHtc.iUunlypqYJ = false;
			XkOikGnOeE0y3L1iHtc.mbAnAyHyQq = false;
			XkOikGnOeE0y3L1iHtc.LS1nGU2U1X = false;
			XkOikGnOeE0y3L1iHtc.qv2ndc4fmr = false;
			XkOikGnOeE0y3L1iHtc.nZ1nvTxrsi = false;
			XkOikGnOeE0y3L1iHtc.HMxnikRYTJ = false;
			XkOikGnOeE0y3L1iHtc.VBRn9qy5Wm = "#6a00ff";
			XkOikGnOeE0y3L1iHtc.H8Wn09GN85 = "#ff0055";
			XkOikGnOeE0y3L1iHtc.q2En8fxw1g = false;
			XkOikGnOeE0y3L1iHtc.dxtnEwb3u0 = false;
			XkOikGnOeE0y3L1iHtc.enwnwnxuIS = false;
			XkOikGnOeE0y3L1iHtc.flYnp664Oi = false;
			XkOikGnOeE0y3L1iHtc.Q0BnW5LntK = false;
			XkOikGnOeE0y3L1iHtc.IL0nUPtsW0 = false;
			XkOikGnOeE0y3L1iHtc.OYAnP6tvrM = false;
			XkOikGnOeE0y3L1iHtc.vqJnu5EHWF = false;
			XkOikGnOeE0y3L1iHtc.kQunFp8SpQ = false;
			XkOikGnOeE0y3L1iHtc.SmVnXcxjBH = false;
			XkOikGnOeE0y3L1iHtc.vvlnZJ4m9r = false;
			XkOikGnOeE0y3L1iHtc.sPrnVwUiDx = false;
			XkOikGnOeE0y3L1iHtc.SCxnLRLO9E = 0;
			XkOikGnOeE0y3L1iHtc.uqJn1o5IY7 = false;
			XkOikGnOeE0y3L1iHtc.DWln3KDagW = false;
			XkOikGnOeE0y3L1iHtc.A94nkASCbh = false;
			XkOikGnOeE0y3L1iHtc.iZlnfB5qaK = false;
			XkOikGnOeE0y3L1iHtc.ws2nmnEnBr = false;
			XkOikGnOeE0y3L1iHtc.HpwnDwnlE7 = false;
			XkOikGnOeE0y3L1iHtc.reRngSQPet = false;
			XkOikGnOeE0y3L1iHtc.PWvn4Feqef = false;
			XkOikGnOeE0y3L1iHtc.NQSnjYG2gb = false;
			XkOikGnOeE0y3L1iHtc.qQ9nS55jfl = false;
			XkOikGnOeE0y3L1iHtc.ELynbVDjj3 = false;
			XkOikGnOeE0y3L1iHtc.jjsnNEB4bC = false;
			XkOikGnOeE0y3L1iHtc.mDynzCgyjG = false;
			XkOikGnOeE0y3L1iHtc.LcPQ5wqRks = false;
			XkOikGnOeE0y3L1iHtc.O81QcwGIX4 = false;
			XkOikGnOeE0y3L1iHtc.MSBQntxIoe = false;
			XkOikGnOeE0y3L1iHtc.IjAQQ0ospr = false;
			XkOikGnOeE0y3L1iHtc.u2mQOPQiy8 = false;
			XkOikGnOeE0y3L1iHtc.lKVQIF9fld = false;
			XkOikGnOeE0y3L1iHtc.a7kQoXQJQc = false;
			XkOikGnOeE0y3L1iHtc.IsNQ6mPpKY = false;
			XkOikGnOeE0y3L1iHtc.Vp0QYDYS6c = false;
			XkOikGnOeE0y3L1iHtc.LiQQBwK1M8 = false;
			XkOikGnOeE0y3L1iHtc.mqtQrpuUJ1 = false;
			XkOikGnOeE0y3L1iHtc.M7tQ2XTuwZ = 0f;
			XkOikGnOeE0y3L1iHtc.YOwQMDjJxD = false;
			XkOikGnOeE0y3L1iHtc.sQeQaLYX2B = false;
			XkOikGnOeE0y3L1iHtc.ym5QySxEZ2 = false;
			XkOikGnOeE0y3L1iHtc.Kk3QTeBC8L = false;
			XkOikGnOeE0y3L1iHtc.tUHQ7YGKvT = false;
			XkOikGnOeE0y3L1iHtc.wqYQeg9xe9 = false;
			XkOikGnOeE0y3L1iHtc.cJWQCIwpBX = true;
			XkOikGnOeE0y3L1iHtc.wsyQqU7Wh8 = false;
			XkOikGnOeE0y3L1iHtc.GwGQhnEtIr = 7f;
			XkOikGnOeE0y3L1iHtc.PrJQHrwy00 = false;
			XkOikGnOeE0y3L1iHtc.JLJQsHqJba = false;
			XkOikGnOeE0y3L1iHtc.s00QRmgCSX = false;
			XkOikGnOeE0y3L1iHtc.YnmQt8hyTu = false;
			XkOikGnOeE0y3L1iHtc.yirQKiTxUH = false;
			XkOikGnOeE0y3L1iHtc.UqBQlnf7Lp = false;
			XkOikGnOeE0y3L1iHtc.bVhQATe8AF = false;
			XkOikGnOeE0y3L1iHtc.r3HQGmFWHV = false;
			XkOikGnOeE0y3L1iHtc.BwVQdiQnmZ = false;
			XkOikGnOeE0y3L1iHtc.DeNQvSYUVZ = false;
			XkOikGnOeE0y3L1iHtc.v3mQi7PODg = false;
			XkOikGnOeE0y3L1iHtc.NUBQ9ycafn = false;
			XkOikGnOeE0y3L1iHtc.pKYQ0IUrO7 = false;
			XkOikGnOeE0y3L1iHtc.lMOQxtFjaC = false;
			XkOikGnOeE0y3L1iHtc.kd3QJ6dADu = false;
			XkOikGnOeE0y3L1iHtc.pTcQ8yCETi = false;
			XkOikGnOeE0y3L1iHtc.qxXQEg81TM = false;
			XkOikGnOeE0y3L1iHtc.G8BQwLG3as = true;
			XkOikGnOeE0y3L1iHtc.YYQQpmKGrf = false;
			XkOikGnOeE0y3L1iHtc.wsJQWdobEE = false;
			XkOikGnOeE0y3L1iHtc.zUjQU5jmq8 = true;
			XkOikGnOeE0y3L1iHtc.fZpQPVNFpk = false;
			XkOikGnOeE0y3L1iHtc.bqmQujswK7 = false;
			XkOikGnOeE0y3L1iHtc.GHSQFLPSqN = false;
			XkOikGnOeE0y3L1iHtc.ctVQXyyUfw = false;
			XkOikGnOeE0y3L1iHtc.jYaQZWehCj = false;
			XkOikGnOeE0y3L1iHtc.at9QVkR4IV = false;
			XkOikGnOeE0y3L1iHtc.IaYQLnt0mM = false;
			XkOikGnOeE0y3L1iHtc.uZWQ1D9Yx9 = false;
			XkOikGnOeE0y3L1iHtc.GrJQ31IgMd = false;
			XkOikGnOeE0y3L1iHtc.lTMQkLjcv8 = false;
			XkOikGnOeE0y3L1iHtc.uP3QfAKD3V = false;
			XkOikGnOeE0y3L1iHtc.rYVQmlybj4 = true;
			XkOikGnOeE0y3L1iHtc.AydQDOIkYS = true;
			XkOikGnOeE0y3L1iHtc.gwIQgwevVU = true;
			XkOikGnOeE0y3L1iHtc.o9tQ426MNU = true;
			XkOikGnOeE0y3L1iHtc.cfnQjBNfrS = true;
			XkOikGnOeE0y3L1iHtc.C29QS1BwvM = false;
			XkOikGnOeE0y3L1iHtc.Ry0Qbha3dD = false;
			XkOikGnOeE0y3L1iHtc.gcUQNhVfBd = true;
			XkOikGnOeE0y3L1iHtc.xyRQzArlmY = true;
			XkOikGnOeE0y3L1iHtc.i3EO54IObt = false;
			XkOikGnOeE0y3L1iHtc.TwuOc5C1yg = true;
			XkOikGnOeE0y3L1iHtc.QhIOn5UZpM = false;
			XkOikGnOeE0y3L1iHtc.uY0OQko6ZH = true;
			XkOikGnOeE0y3L1iHtc.nMxOOlTRXv = false;
			XkOikGnOeE0y3L1iHtc.r6iOIYdxQ3 = true;
			XkOikGnOeE0y3L1iHtc.YJVOotA5JS = false;
			XkOikGnOeE0y3L1iHtc.UBwO61NoTG = true;
			XkOikGnOeE0y3L1iHtc.UqpOYVBVUA = false;
			XkOikGnOeE0y3L1iHtc.LHmOBMxYuk = false;
			XkOikGnOeE0y3L1iHtc.JEsOrqd23T = true;
			XkOikGnOeE0y3L1iHtc.oC3O2UtQga = false;
			XkOikGnOeE0y3L1iHtc.mrmOMIqGQt = false;
			XkOikGnOeE0y3L1iHtc.blHOakvSa1 = false;
			XkOikGnOeE0y3L1iHtc.EsyOyQ59cw = false;
			XkOikGnOeE0y3L1iHtc.YTtOTH20Yn = false;
			XkOikGnOeE0y3L1iHtc.TTOO7MgTrh = false;
			XkOikGnOeE0y3L1iHtc.GbOOeyv4KD = false;
			XkOikGnOeE0y3L1iHtc.B8FOC7w0ly = false;
			XkOikGnOeE0y3L1iHtc.TVrOqb957r = true;
			XkOikGnOeE0y3L1iHtc.M8nOhS1OY1 = false;
			XkOikGnOeE0y3L1iHtc.FkHOH6mw0V = false;
			XkOikGnOeE0y3L1iHtc.Vj7OsbtpFA = true;
			XkOikGnOeE0y3L1iHtc.jv5ORiCgcx = 5f;
			XkOikGnOeE0y3L1iHtc.HX3OtXlIZP = false;
			XkOikGnOeE0y3L1iHtc.hItOKvesOG = 5f;
			XkOikGnOeE0y3L1iHtc.dxROlKuaiM = 4f;
			XkOikGnOeE0y3L1iHtc.DiCOA94P80 = false;
			XkOikGnOeE0y3L1iHtc.nkAOGor8JR = false;
			XkOikGnOeE0y3L1iHtc.z9gOdc0WPh = false;
			XkOikGnOeE0y3L1iHtc.WqcOvRfffw = false;
			XkOikGnOeE0y3L1iHtc.Ix0OiKbdXr = false;
			XkOikGnOeE0y3L1iHtc.XY4O9ryYDN = false;
			XkOikGnOeE0y3L1iHtc.PM2O0ir6VM = false;
			XkOikGnOeE0y3L1iHtc.abdOxYcHVS = true;
			XkOikGnOeE0y3L1iHtc.g42OJSiAye = false;
			XkOikGnOeE0y3L1iHtc.oEEO81RjSf = false;
			XkOikGnOeE0y3L1iHtc.faZOUWlMl2 = false;
			XkOikGnOeE0y3L1iHtc.avSOPCGFiQ = false;
			XkOikGnOeE0y3L1iHtc.mfBOu4lYyS = false;
		}

		public XkOikGnOeE0y3L1iHtc()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static bool dBmM44ftLs3YI9F7HD1()
		{
			return XkOikGnOeE0y3L1iHtc.zYdexOfRnYCT5GOfCpU == null;
		}

		public static Color IEEnBBTpT0()
		{
			return XkOikGnOeE0y3L1iHtc.LZwn6cDKIK(XkOikGnOeE0y3L1iHtc.VBRn9qy5Wm);
		}

		internal static XkOikGnOeE0y3L1iHtc kBwF5OfKLx8pI2TdRKT()
		{
			return XkOikGnOeE0y3L1iHtc.zYdexOfRnYCT5GOfCpU;
		}

		public static Color LZwn6cDKIK(object object_0)
		{
			if (object_0.IndexOf('#') != -1)
			{
				object_0 = object_0.Replace("#", "");
			}
			float single = (float)int.Parse(object_0.Substring(0, 2), NumberStyles.AllowHexSpecifier) / 255f;
			float single1 = (float)int.Parse(object_0.Substring(2, 2), NumberStyles.AllowHexSpecifier) / 255f;
			float single2 = (float)int.Parse(object_0.Substring(4, 2), NumberStyles.AllowHexSpecifier) / 255f;
			return new Color(single, single1, single2);
		}

		public static Color NRInrJhDhQ()
		{
			return XkOikGnOeE0y3L1iHtc.LZwn6cDKIK(XkOikGnOeE0y3L1iHtc.H8Wn09GN85);
		}

		public static string P4unYOuCog(Color color_0, bool bool_0 = false)
		{
			int num = Convert.ToInt32(color_0.r * 255f);
			int num1 = Convert.ToInt32(color_0.g * 255f);
			int num2 = Convert.ToInt32(color_0.b * 255f);
			string str = num2.ToString("X2");
			string str1 = string.Concat(num.ToString("X2"), num1.ToString("X2"), str);
			if (bool_0)
			{
				str1 = string.Concat("#", str1);
			}
			return str1;
		}

		public static void W0Xno5nkpn()
		{
			XkOikGnOeE0y3L1iHtc.QqdOFAVf1Y = Physics.get_gravity();
		}

		public class nMhMWZe8qAeWKVdeYDE
		{
			public KeyValuePair<Vector3, Quaternion> P8PeE42CBU;

			public KeyValuePair<Vector3, Quaternion> l6sewkZkjq;

			public KeyValuePair<Vector3, Quaternion> Na0epM740T;

			internal static XkOikGnOeE0y3L1iHtc.nMhMWZe8qAeWKVdeYDE yM1whE4NwJCrbHKA5FL;

			public nMhMWZe8qAeWKVdeYDE()
			{
				CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
				ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
				base();
			}

			internal static bool NJJY9K4z0eV7Y5yYlZO()
			{
				return XkOikGnOeE0y3L1iHtc.nMhMWZe8qAeWKVdeYDE.yM1whE4NwJCrbHKA5FL == null;
			}

			internal static XkOikGnOeE0y3L1iHtc.nMhMWZe8qAeWKVdeYDE UiAGGZj5ESD0rlnOcsr()
			{
				return XkOikGnOeE0y3L1iHtc.nMhMWZe8qAeWKVdeYDE.yM1whE4NwJCrbHKA5FL;
			}
		}
	}
}