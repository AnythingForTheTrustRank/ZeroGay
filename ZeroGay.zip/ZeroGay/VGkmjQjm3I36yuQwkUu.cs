using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate bool VGkmjQjm3I36yuQwkUu(UnityEngine.Object , UnityEngine.Object );