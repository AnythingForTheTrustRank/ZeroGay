using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;
using VRC.SDKBase;

internal delegate bool GwFlyWrz1IvhB9deGp6(VRCPlayerApi , GameObject );