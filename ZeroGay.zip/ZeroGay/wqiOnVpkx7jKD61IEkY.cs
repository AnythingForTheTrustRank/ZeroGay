using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector3 wqiOnVpkx7jKD61IEkY();