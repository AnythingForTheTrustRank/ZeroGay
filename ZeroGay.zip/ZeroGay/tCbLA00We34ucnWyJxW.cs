using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;

internal delegate Dictionary<string, List<uint>> tCbLA00We34ucnWyJxW(object );