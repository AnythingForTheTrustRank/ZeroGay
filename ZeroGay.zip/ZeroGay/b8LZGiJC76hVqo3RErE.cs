using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection.Emit;

internal delegate LocalBuilder b8LZGiJC76hVqo3RErE(object , Type );