using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate object lBpDy7VcPMVA3EPjGif(Type , uint );