using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string yR8CUKrRM3T3oEDEIH3(ref short );