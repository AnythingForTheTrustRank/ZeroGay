using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void BBSM2OpuJnHYYvla5f8(object , Shader );