using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Sprite t2XfUOwHYwFbg4HXTfk(Texture2D texture2D_0, Rect rect_0, Vector2 vector2_0, float float_0, uint uint_0, SpriteMeshType spriteMeshType_0, Vector4 vector4_0, bool bool_0);