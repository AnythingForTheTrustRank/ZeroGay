using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate bool ApwfIBrO2vDuyoRhhH4(ref Cache );