using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Color gYhNiLEI6YNUxxM4jX6(Color32 color32_0);