using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate VRCUiPopupManager ryyfbX0m5T7xpLelS3a();