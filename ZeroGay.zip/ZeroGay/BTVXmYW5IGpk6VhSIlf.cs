using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.UserCamera;

internal delegate UserCameraController BTVXmYW5IGpk6VhSIlf();