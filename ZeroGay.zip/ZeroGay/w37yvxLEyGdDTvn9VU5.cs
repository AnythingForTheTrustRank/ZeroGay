using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Transform w37yvxLEyGdDTvn9VU5(object object_0, HumanBodyBones humanBodyBones_0);