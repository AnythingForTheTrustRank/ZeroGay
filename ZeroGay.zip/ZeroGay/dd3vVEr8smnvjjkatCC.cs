using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Quaternion dd3vVEr8smnvjjkatCC(Quaternion , Quaternion , float );