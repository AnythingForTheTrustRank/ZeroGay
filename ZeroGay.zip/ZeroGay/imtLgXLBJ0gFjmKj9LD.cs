using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void imtLgXLBJ0gFjmKj9LD(object , object , int );