using Il2CppSystem.Collections.Generic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using UnityEngine;
using VRC;
using VRC.SDKBase;

namespace DI1Ec8yA4vBbNqCqHF
{
	internal static class ScwDo7aJqt0Ery0psC
	{
		internal static ScwDo7aJqt0Ery0psC A72IdTkSfSItCHbZuQK;

		internal static HighlightsFX aTIhC6fBS()
		{
			return HighlightsFX.Method_Public_Static_get_HighlightsFX_PDM_0();
		}

		internal static QuickMenu bT1sIp0Lv()
		{
			return QuickMenu.Method_Public_Static_get_QuickMenu_PDM_0();
		}

		internal static bool cLDDaTkbacE5ZYiJr6u()
		{
			return ScwDo7aJqt0Ery0psC.A72IdTkSfSItCHbZuQK == null;
		}

		internal static d6LVLLlxgyJJ2qJ7dC cZRK1kpdT<d6LVLLlxgyJJ2qJ7dC>(this object object_0)
		where d6LVLLlxgyJJ2qJ7dC : Component
		{
			d6LVLLlxgyJJ2qJ7dC _d6LVLLlxgyJJ2qJ7dC;
			d6LVLLlxgyJJ2qJ7dC component = object_0.GetComponent<d6LVLLlxgyJJ2qJ7dC>();
			_d6LVLLlxgyJJ2qJ7dC = (component != null ? component : object_0.AddComponent<d6LVLLlxgyJJ2qJ7dC>());
			return _d6LVLLlxgyJJ2qJ7dC;
		}

		public static string ES2CWMFs6(object object_0)
		{
			string str;
			if ((!object_0.Contains("~private") ? false : object_0.Contains("~canRequestInvite~nonce")))
			{
				str = "invite+";
			}
			else if ((object_0.Contains("~private") ? object_0.Contains("~nonce") : false))
			{
				str = "invite";
			}
			else if (object_0.Contains("~friend"))
			{
				str = "friends";
			}
			else
			{
				str = (object_0.Contains("~hidden") ? "friends+" : "public");
			}
			return str;
		}

		internal static VRCUiManager eTuRgh8XQ()
		{
			return VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0();
		}

		internal static void j7g7Va7Un()
		{
			foreach (VRC_Pickup vRCPickup in UnityEngine.Object.FindObjectsOfType<VRC_Pickup>())
			{
				Networking.get_LocalPlayer().TakeOwnership(vRCPickup.get_gameObject());
				vRCPickup.get_transform().set_localPosition(new Vector3(0f, -100000f, 0f));
			}
		}

		internal static void Kf8qda7GR(this object object_0, object object_1, bool bool_0)
		{
			object_0.Method_Public_Void_Renderer_Boolean_0(object_1, bool_0);
		}

		internal static string SaFtoNxfr(object object_0)
		{
			string end = "";
			using (Stream responseStream = object_0.GetResponseStream())
			{
				using (StreamReader streamReader = new StreamReader(responseStream))
				{
					end = streamReader.ReadToEnd();
				}
			}
			object_0.Dispose();
			return end;
		}

		public static System.Collections.Generic.List<string> tgFe3HAUh(object object_0)
		{
			System.Collections.Generic.List<string> strs = new System.Collections.Generic.List<string>();
			Il2CppSystem.Collections.Generic.List<VRCUiContentButton>.Enumerator enumerator = object_0.get_pickers().GetEnumerator();
			while (enumerator.MoveNext())
			{
				VRCUiContentButton _current = enumerator.get_current();
				if (string.IsNullOrEmpty(_current.get_field_Public_String_0()))
				{
					continue;
				}
				strs.Add(_current.get_field_Public_String_0());
			}
			return strs;
		}

		public static string twaTD9RnG()
		{
			string str = "wrld_4432ea9b-729c-46e3-8eaf-846aa0a37fdd:";
			int num = (new System.Random()).Next(0, 9999);
			return string.Concat(str, num.ToString());
		}

		internal static ScwDo7aJqt0Ery0psC UnBW8mkNVhXnb7n2iJK()
		{
			return ScwDo7aJqt0Ery0psC.A72IdTkSfSItCHbZuQK;
		}

		internal static PlayerManager zPiH6vW2x()
		{
			return PlayerManager.Method_Public_Static_get_PlayerManager_0();
		}
	}
}