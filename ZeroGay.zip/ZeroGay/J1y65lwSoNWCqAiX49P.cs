using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate bool J1y65lwSoNWCqAiX49P(UnityEngine.Object object_0);