using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Udon.Common.Interfaces;

internal delegate void Qy7O2MPR8CXV5DpGRFH(object object_0, NetworkEventTarget networkEventTarget_0, string string_0);