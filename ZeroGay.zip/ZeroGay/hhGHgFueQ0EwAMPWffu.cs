using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void hhGHgFueQ0EwAMPWffu(object object_0, FontStyle fontStyle_0);