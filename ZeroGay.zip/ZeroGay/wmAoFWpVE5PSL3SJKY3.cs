using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector3 wmAoFWpVE5PSL3SJKY3(object object_0, Vector3 vector3_0);