using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Reflection;

namespace FXNTuNgKhKAHO3yaZxU
{
	internal class sgkp9bg13SZsPQe7aiR
	{
		internal static Module KqJgAnlXdr;

		internal static sgkp9bg13SZsPQe7aiR p8VxpDkkvFk1AaLj71tb;

		static sgkp9bg13SZsPQe7aiR()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			sgkp9bg13SZsPQe7aiR.KqJgAnlXdr = typeof(sgkp9bg13SZsPQe7aiR).Assembly.ManifestModule;
		}

		public sgkp9bg13SZsPQe7aiR()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static void cYgkHzGPqD8(int typemdt)
		{
			Type type = sgkp9bg13SZsPQe7aiR.KqJgAnlXdr.ResolveType(33554432 + typemdt);
			FieldInfo[] fields = type.GetFields();
			for (int i = 0; i < (int)fields.Length; i++)
			{
				FieldInfo fieldInfo = fields[i];
				MethodInfo methodInfo = (MethodInfo)sgkp9bg13SZsPQe7aiR.KqJgAnlXdr.ResolveMethod(fieldInfo.MetadataToken + 100663296);
				fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, methodInfo));
			}
		}

		internal static bool fcOOKykkaHCgIgm1QUU1()
		{
			return sgkp9bg13SZsPQe7aiR.p8VxpDkkvFk1AaLj71tb == null;
		}

		internal static sgkp9bg13SZsPQe7aiR MAjqxlkkgU6xR1l0YJtn()
		{
			return sgkp9bg13SZsPQe7aiR.p8VxpDkkvFk1AaLj71tb;
		}

		internal delegate void IhafOsgVx2LaAq9A3ga(object o);
	}
}