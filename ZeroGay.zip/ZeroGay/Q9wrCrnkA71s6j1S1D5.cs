using b3eD5DgJPcASx0xfHYB;
using ExitGames.Client.Photon;
using Il2CppSystem;
using Photon.Realtime;
using System;

internal delegate bool Q9wrCrnkA71s6j1S1D5(byte , Il2CppSystem.Object , RaiseEventOptions , SendOptions );