using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using TMPro;
using UnityEngine;
using UyW1FlOl3XL1EHOVRF;
using VRC;

namespace ugKGEZQEKvXWM2iGnlX
{
	internal class dyKBHKQyJEgyti4quiU : MonoBehaviour
	{
		public Player cGEwkR3tay;

		private TextMeshProUGUI WF0w88fItq;

		private ImageThreeSlice FZrwHjqSJQ;

		private byte yyHwG7XFq8;

		private byte sbdw3SlrhA;

		private int Agfw9LEstg;

		private string eXkwsN2PnT;

		internal static dyKBHKQyJEgyti4quiU BfCSaxouYWJnkpQZLhv;

		public dyKBHKQyJEgyti4quiU(IntPtr u0020)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			this.Agfw9LEstg = 0;
			this.eXkwsN2PnT = "";
			base(u0020);
		}

		private string DY5wqFaLxH(string u0020)
		{
			string str;
			if (u0020 == "usr_6f71bbac-1a26-4d6d-b75d-376050db3c57")
			{
				str = " [<color=green>Monkey</color>]";
			}
			else if (u0020 == "usr_8fa49306-0283-47c9-9d5d-8d095c3818f7")
			{
				str = " [<color=yellow>Chickens</color>]";
			}
			else if (u0020 == "usr_81e172f3-7439-4ce1-9971-cd0bfd532725")
			{
				str = " [<color=red>Ur Mom!</color>]";
			}
			else if (u0020 == "usr_3085603a-4343-46e2-afa4-c06951c56ed0")
			{
				str = " [<color=black>:P</color>]";
			}
			else
			{
				str = (u0020 == "usr_5225280e-886a-4327-bec1-3719985e94ec" ? "" : " [<color=#00FF00>Area 51</color>]");
			}
			return str;
		}

		internal static bool SFUIXdoSPiuOJq9uKdW()
		{
			return dyKBHKQyJEgyti4quiU.BfCSaxouYWJnkpQZLhv == null;
		}

		private void Start()
		{
			Transform transform = UnityEngine.Object.Instantiate<Transform>(base.get_gameObject().get_transform().Find("Contents/Quick Stats"), base.get_gameObject().get_transform().Find("Contents"));
			transform.set_parent(base.get_gameObject().get_transform().Find("Contents"));
			transform.set_name("Area51_nameplate");
			transform.set_localPosition(new Vector3(0f, 62f, 0f));
			transform.set_localScale(new Vector3(1f, 1f, 2f));
			transform.get_gameObject().SetActive(true);
			this.WF0w88fItq = transform.Find("Trust Text").GetComponent<TextMeshProUGUI>();
			this.WF0w88fItq.set_color(Color.get_white());
			this.WF0w88fItq.set_fontStyle(2);
			transform.Find("Trust Icon").get_gameObject().SetActive(false);
			transform.Find("Performance Icon").get_gameObject().SetActive(false);
			transform.Find("Performance Text").get_gameObject().SetActive(false);
			transform.Find("Friend Anchor Stats").get_gameObject().SetActive(false);
			this.FZrwHjqSJQ = base.get_gameObject().get_transform().Find("Contents/Main/Background").GetComponent<ImageThreeSlice>();
			this.yyHwG7XFq8 = this.cGEwkR3tay.Method_Internal_get_PlayerNet_0().get_field_Private_Byte_0();
			this.sbdw3SlrhA = this.cGEwkR3tay.Method_Internal_get_PlayerNet_0().get_field_Private_Byte_1();
		}

		private void Update()
		{
			if (this.yyHwG7XFq8 != this.cGEwkR3tay.Method_Internal_get_PlayerNet_0().get_field_Private_Byte_0() || this.sbdw3SlrhA != this.cGEwkR3tay.Method_Internal_get_PlayerNet_0().get_field_Private_Byte_1())
			{
				this.Agfw9LEstg = 0;
			}
			else
			{
				this.Agfw9LEstg++;
			}
			this.yyHwG7XFq8 = this.cGEwkR3tay.Method_Internal_get_PlayerNet_0().Method_Public_get_Byte_0();
			this.sbdw3SlrhA = this.cGEwkR3tay.Method_Internal_get_PlayerNet_0().get_field_Private_Byte_1();
			string str = "<color=green>Stable</color>";
			if (this.Agfw9LEstg > 35)
			{
				str = "<color=yellow>Lagging</color>";
			}
			if (this.Agfw9LEstg > 375)
			{
				str = "<color=red>Crashed</color>";
			}
			string str1 = this.DY5wqFaLxH(this.eXkwsN2PnT);
			this.WF0w88fItq.set_text(string.Concat(new string[] { "[", str, "] |<color=white>Ping:</color> ", this.cGEwkR3tay.get__vrcplayer().OwNFSv9R4(), " |<color=white>FPS</color>: ", this.cGEwkR3tay.get__vrcplayer().OwNFSv9R4(), " |", str1 }));
		}

		internal static dyKBHKQyJEgyti4quiU vgli8AoYOOJ2VhJCRL5()
		{
			return dyKBHKQyJEgyti4quiU.BfCSaxouYWJnkpQZLhv;
		}

		public Vector3 wmwQzAmteD()
		{
			Vector3 vector3;
			vector3 = (!GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/").get_activeSelf() ? new Vector3(0f, 42f, 0f) : new Vector3(0f, 62f, 0f));
			return vector3;
		}
	}
}