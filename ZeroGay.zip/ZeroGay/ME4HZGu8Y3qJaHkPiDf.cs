using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void ME4HZGu8Y3qJaHkPiDf(object object_0, ParticleSystemTrailMode particleSystemTrailMode_0);