using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string WKIkYMJufsY3BgIIo08(object object_0);