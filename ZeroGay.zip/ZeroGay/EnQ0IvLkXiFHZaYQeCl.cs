using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem;
using System;

internal delegate void EnQ0IvLkXiFHZaYQeCl(object object_0, string string_0, WorldTransitionInfo worldTransitionInfo_0, Il2CppSystem.Action<string> action_0, bool bool_0);