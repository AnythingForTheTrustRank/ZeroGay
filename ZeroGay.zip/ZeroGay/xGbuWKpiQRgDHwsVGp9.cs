using AksgHVKH9UOXlBDvRpO;
using Photon.Realtime;
using System;

internal delegate LoadBalancingClient xGbuWKpiQRgDHwsVGp9(object object_0);