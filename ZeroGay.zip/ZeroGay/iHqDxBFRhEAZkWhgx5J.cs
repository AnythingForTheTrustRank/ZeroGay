using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using UnityEngine.UI;

internal delegate Color iHqDxBFRhEAZkWhgx5J(ref ColorBlock colorBlock_0);