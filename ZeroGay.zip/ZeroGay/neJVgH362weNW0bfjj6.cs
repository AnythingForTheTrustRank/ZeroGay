using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object neJVgH362weNW0bfjj6(Type type_0, ushort ushort_0);