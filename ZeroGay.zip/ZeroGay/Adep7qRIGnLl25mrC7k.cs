using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate NetworkManager Adep7qRIGnLl25mrC7k();