using System;

namespace X7IetPATbOXxq4U7Vmy
{
	internal class ddXDFDAyjuXuTapZR07
	{
		private static bool YmJA7JKI6t;

		private static ddXDFDAyjuXuTapZR07 zaWoKAc5TQAjVxn3NcNx;

		public ddXDFDAyjuXuTapZR07()
		{
		}

		internal static void cAWcnx1a8ek()
		{
			if (!ddXDFDAyjuXuTapZR07.YmJA7JKI6t)
			{
				DateTime dateTime = new DateTime(637793435790162533L);
				if (Math.Abs((DateTime.Now - dateTime).TotalDays) >= 7)
				{
					throw new Exception("This assembly is protected by an unregistered version of Eziriz's \".NET Reactor\"! This assembly won't further work.");
				}
				ddXDFDAyjuXuTapZR07.YmJA7JKI6t = true;
			}
		}

		internal static bool k9I052c57BsRJpmgKdw8()
		{
			return ddXDFDAyjuXuTapZR07.zaWoKAc5TQAjVxn3NcNx == null;
		}

		internal static ddXDFDAyjuXuTapZR07 pTAsasc5e61unOr9Dq26()
		{
			return ddXDFDAyjuXuTapZR07.zaWoKAc5TQAjVxn3NcNx;
		}
	}
}