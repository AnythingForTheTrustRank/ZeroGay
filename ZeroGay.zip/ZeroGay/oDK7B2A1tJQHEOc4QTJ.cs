using b3eD5DgJPcASx0xfHYB;
using System;
using System.Runtime.CompilerServices;

internal delegate TaskAwaiter oDK7B2A1tJQHEOc4QTJ(object );