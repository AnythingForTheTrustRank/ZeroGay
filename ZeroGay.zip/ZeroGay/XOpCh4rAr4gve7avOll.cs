using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;

internal delegate Il2CppStructArray<int> XOpCh4rAr4gve7avOll(object , int );