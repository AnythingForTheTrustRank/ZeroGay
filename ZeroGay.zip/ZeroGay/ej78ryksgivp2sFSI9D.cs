using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate bool ej78ryksgivp2sFSI9D(MethodInfo methodInfo_0, MethodInfo methodInfo_1);