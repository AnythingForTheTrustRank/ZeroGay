using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate ActionMenuOpener GClpd9WOg2DZXIRw6e8(object object_0);