using b3eD5DgJPcASx0xfHYB;
using Photon.Realtime;
using System;

internal delegate void wG0XhOK8CqXMl10bnCc(object , ReceiverGroup );