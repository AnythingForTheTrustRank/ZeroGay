using AksgHVKH9UOXlBDvRpO;
using System;
using System.Windows.Forms;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using VRC.UI;
using X7IetPATbOXxq4U7Vmy;

namespace WrcIXrcwhnWSCvhNdmR
{
	internal class kgKUrIcEPBwAPoxP1pT
	{
		internal static kgKUrIcEPBwAPoxP1pT quS7Gjf2GNjBrTUEyQs;

		public kgKUrIcEPBwAPoxP1pT()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
		}

		internal static void dd6cPeiylZ(object object_0)
		{
			if (Clipboard.ContainsText())
			{
				Clipboard.Clear();
				Clipboard.SetText(object_0);
			}
			else
			{
				Clipboard.SetText(object_0);
			}
		}

		public static bool dZUcpTwEmM(object object_0)
		{
			bool flag;
			if (!Networking.GoToRoom(object_0))
			{
				string[] strArrays = object_0.Split(new char[] { ':' });
				if ((int)strArrays.Length == 2)
				{
					(new PortalInternal()).Method_Private_Void_String_String_PDM_0(strArrays[0], strArrays[1]);
					flag = true;
					return flag;
				}
				flag = false;
				return flag;
			}
			flag = true;
			return flag;
		}

		internal static string HrycUelPOq()
		{
			string text;
			if (!Clipboard.ContainsText())
			{
				text = null;
			}
			else
			{
				text = Clipboard.GetText();
			}
			return text;
		}

		internal static bool nLbXqSfMS7AZW9PUnZG()
		{
			return kgKUrIcEPBwAPoxP1pT.quS7Gjf2GNjBrTUEyQs == null;
		}

		internal static void TnGcWa5fMd(object object_0)
		{
			PageAvatar component = GameObject.Find("Screens").get_transform().Find("Avatar").GetComponent<PageAvatar>();
			SimpleAvatarPedestal fieldPublicSimpleAvatarPedestal0 = component.get_field_Public_SimpleAvatarPedestal_0();
			ApiAvatar apiAvatar = new ApiAvatar();
			apiAvatar.set_id(object_0);
			fieldPublicSimpleAvatarPedestal0.set_field_Internal_ApiAvatar_0(apiAvatar);
			component.ChangeToSelectedAvatar();
		}

		internal static kgKUrIcEPBwAPoxP1pT vvfWRFfaAGrapZitr2S()
		{
			return kgKUrIcEPBwAPoxP1pT.quS7Gjf2GNjBrTUEyQs;
		}
	}
}