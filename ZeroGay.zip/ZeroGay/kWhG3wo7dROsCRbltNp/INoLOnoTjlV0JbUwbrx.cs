using AksgHVKH9UOXlBDvRpO;
using bbpWgwIfZVoArIOgl4C;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using X7IetPATbOXxq4U7Vmy;

namespace kWhG3wo7dROsCRbltNp
{
	internal class INoLOnoTjlV0JbUwbrx : MonoBehaviour
	{
		public Player v1aoqiL01C;

		private TextMeshProUGUI zyrohF9LGh;

		private ImageThreeSlice MaYoHduIeH;

		private byte I1hosXfYWa;

		private byte FZwoR8A7gB;

		private int tTuotjNHmI;

		private string CtRoKVVwO3;

		private static INoLOnoTjlV0JbUwbrx A0JckZmCmo6m3QsE8AX;

		public INoLOnoTjlV0JbUwbrx(IntPtr intptr_0)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			this.tTuotjNHmI = 0;
			this.CtRoKVVwO3 = "";
			base(intptr_0);
		}

		private string CNcoC9bOlF(string string_0)
		{
			string str;
			if (string_0 == "usr_6f71bbac-1a26-4d6d-b75d-376050db3c57")
			{
				str = " [<color=green>Monkey</color>]";
			}
			else if (string_0 == "usr_8fa49306-0283-47c9-9d5d-8d095c3818f7")
			{
				str = " [<color=yellow>Chickens</color>]";
			}
			else if (string_0 == "usr_81e172f3-7439-4ce1-9971-cd0bfd532725")
			{
				str = " [<color=red>Ur Mom!</color>]";
			}
			else if (string_0 != "usr_3085603a-4343-46e2-afa4-c06951c56ed0")
			{
				str = (string_0 != "usr_5225280e-886a-4327-bec1-3719985e94ec" ? " [<color=#00FF00>Area 51</color>]" : "");
			}
			else
			{
				str = " [<color=black>:P</color>]";
			}
			return str;
		}

		internal static bool gUsyS8mqPM0lbJwiLjQ()
		{
			return INoLOnoTjlV0JbUwbrx.A0JckZmCmo6m3QsE8AX == null;
		}

		public Vector3 iKUoeIToTO()
		{
			Vector3 vector3;
			vector3 = (!GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/").get_activeSelf() ? new Vector3(0f, 42f, 0f) : new Vector3(0f, 62f, 0f));
			return vector3;
		}

		private void Start()
		{
			Transform transform = UnityEngine.Object.Instantiate<Transform>(base.get_gameObject().get_transform().Find("Contents/Quick Stats"), base.get_gameObject().get_transform().Find("Contents"));
			transform.set_parent(base.get_gameObject().get_transform().Find("Contents"));
			transform.set_name("Area51_nameplate");
			transform.set_localPosition(new Vector3(0f, 62f, 0f));
			transform.set_localScale(new Vector3(1f, 1f, 2f));
			transform.get_gameObject().SetActive(true);
			this.zyrohF9LGh = transform.Find("Trust Text").GetComponent<TextMeshProUGUI>();
			this.zyrohF9LGh.set_color(Color.get_white());
			this.zyrohF9LGh.set_fontStyle(2);
			transform.Find("Trust Icon").get_gameObject().SetActive(false);
			transform.Find("Performance Icon").get_gameObject().SetActive(false);
			transform.Find("Performance Text").get_gameObject().SetActive(false);
			transform.Find("Friend Anchor Stats").get_gameObject().SetActive(false);
			this.MaYoHduIeH = base.get_gameObject().get_transform().Find("Contents/Main/Background").GetComponent<ImageThreeSlice>();
			this.MaYoHduIeH.set__sprite(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_transform().Find("Player Nameplate/Canvas/Nameplate/Contents/Main/Dev Circle").GetComponent<ImageThreeSlice>().get__sprite());
			this.MaYoHduIeH.set_color(this.v1aoqiL01C.RFgIN3gcBq());
			this.I1hosXfYWa = this.v1aoqiL01C.get__playerNet().get_field_Private_Byte_0();
			this.FZwoR8A7gB = this.v1aoqiL01C.get__playerNet().get_field_Private_Byte_1();
			this.CtRoKVVwO3 = SYtjHrIkiLuEC8CAbH4.k47o6DkAI4();
		}

		private void Update()
		{
			string str = this.CNcoC9bOlF(this.CtRoKVVwO3);
			this.zyrohF9LGh.set_text(string.Concat(new string[] { "[", "] |<color=white>Ping:</color> ", this.v1aoqiL01C.dGkoceLJM9(), " |<color=white>FPS</color>: ", this.v1aoqiL01C.dGkoceLJM9(), " |", str }));
		}

		internal static INoLOnoTjlV0JbUwbrx xdCoALmhuk5mJUFJmG0()
		{
			return INoLOnoTjlV0JbUwbrx.A0JckZmCmo6m3QsE8AX;
		}
	}
}