using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void JcYDRLZjXAAKhrdiUOf(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0);