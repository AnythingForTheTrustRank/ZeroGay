using b3eD5DgJPcASx0xfHYB;
using HarmonyLib;
using MelonLoader;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC.Networking;

namespace o9VpcU9W8wCrH1JE2ep
{
	[HarmonyPatch(typeof(UdonSync), "UdonSyncRunProgramAsRPC")]
	internal class mcnOUk9gTMRJFI9PhbD
	{
		public static bool Psb9utx9D6;

		internal static mcnOUk9gTMRJFI9PhbD aCgYdYd8yysZ6pleVQk;

		public mcnOUk9gTMRJFI9PhbD()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		public static void UdonLogShit(ref string __0, object __1)
		{
			string str;
			if (!mcnOUk9gTMRJFI9PhbD.Psb9utx9D6)
			{
				MelonLogger.Log("Started Udon Logger");
				mcnOUk9gTMRJFI9PhbD.Psb9utx9D6 = true;
			}
			if (__0.Contains(""))
			{
				string _0 = __0;
				object _1 = __1;
				if (_1 == null)
				{
					str = null;
				}
				else
				{
					str = _1.ToString();
				}
				MelonLogger.Log(string.Concat(_0, "From : ", str));
			}
		}

		internal static bool X8LXcRdH29kfwhR6c8M()
		{
			return mcnOUk9gTMRJFI9PhbD.aCgYdYd8yysZ6pleVQk == null;
		}

		internal static mcnOUk9gTMRJFI9PhbD y6pykPdGJ2i8KRunAvV()
		{
			return mcnOUk9gTMRJFI9PhbD.aCgYdYd8yysZ6pleVQk;
		}
	}
}