using AksgHVKH9UOXlBDvRpO;
using System;
using System.IO;

internal delegate Stream B2L8LSET2hufNJa3jTy(object object_0, string string_0);