using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate MethodBase vyH5Ff1qN3apVGTHhFD(object object_0, int int_0);