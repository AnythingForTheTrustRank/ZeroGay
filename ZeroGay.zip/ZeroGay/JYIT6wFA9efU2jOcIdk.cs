using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;

internal delegate Assembly JYIT6wFA9efU2jOcIdk();