using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;
using UnhollowerRuntimeLib.XrefScans;

internal delegate MethodBase xie6HkijQn6TW7LK9oq(ref XrefInstance );