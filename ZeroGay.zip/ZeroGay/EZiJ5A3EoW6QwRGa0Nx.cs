using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string EZiJ5A3EoW6QwRGa0Nx(ref char char_0);