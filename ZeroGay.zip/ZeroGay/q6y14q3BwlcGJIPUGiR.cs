using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate object q6y14q3BwlcGJIPUGiR(Type type_0, byte byte_0);