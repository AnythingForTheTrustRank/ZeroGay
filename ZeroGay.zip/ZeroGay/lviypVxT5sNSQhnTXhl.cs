using b3eD5DgJPcASx0xfHYB;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.UI.Elements;

internal delegate List<UIPage> lviypVxT5sNSQhnTXhl(object );