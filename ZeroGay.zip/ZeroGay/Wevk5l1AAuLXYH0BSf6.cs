using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate float Wevk5l1AAuLXYH0BSf6(string );