using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void kjkNqwJ1CqiVG7RuGLf(object object_0, Renderer renderer_0, bool bool_0);