using b3eD5DgJPcASx0xfHYB;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnhollowerRuntimeLib.XrefScans;

internal delegate IEnumerable<XrefInstance> pPIYOLiBPs3uAaglGgV(MethodBase );