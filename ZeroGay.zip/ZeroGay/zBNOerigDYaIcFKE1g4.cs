using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void zBNOerigDYaIcFKE1g4(object , string , string );