using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;
using VRC.Core;

internal delegate Color s100vLUgHFRKFIDWI8B(APIUser apiuser_0);