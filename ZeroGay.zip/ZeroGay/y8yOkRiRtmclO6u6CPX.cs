using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate int y8yOkRiRtmclO6u6CPX(object , string , StringComparison );