using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine.UI;

internal delegate void QKIQQ1F8rduDguCIChF(object object_0, ColorBlock colorBlock_0);