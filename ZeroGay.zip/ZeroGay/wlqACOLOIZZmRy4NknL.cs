using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.SDKBase;

internal delegate void wlqACOLOIZZmRy4NknL(object object_0, VRC_Pickup vrc_Pickup_0);