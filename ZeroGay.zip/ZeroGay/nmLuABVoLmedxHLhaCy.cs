using AksgHVKH9UOXlBDvRpO;
using Photon.Realtime;
using System;

internal delegate void nmLuABVoLmedxHLhaCy(object object_0, ReceiverGroup receiverGroup_0);