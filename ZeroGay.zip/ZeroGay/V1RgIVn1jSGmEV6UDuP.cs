using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void V1RgIVn1jSGmEV6UDuP(object , string , Color );