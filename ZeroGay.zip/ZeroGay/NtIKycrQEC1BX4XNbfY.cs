using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate string NtIKycrQEC1BX4XNbfY(ref Vector3 );