using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate RectTransform S0jrT1XPXVK5K8eStcA(object object_0);