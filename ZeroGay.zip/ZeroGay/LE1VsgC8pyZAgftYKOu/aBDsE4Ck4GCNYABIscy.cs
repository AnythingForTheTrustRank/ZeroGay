using b3eD5DgJPcASx0xfHYB;
using eW8HpLwDaJje18l6kCc;
using iJ73DQwxRI3caDhkmDO;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace LE1VsgC8pyZAgftYKOu
{
	internal class aBDsE4Ck4GCNYABIscy
	{
		protected GameObject LtJCIaQw6U;

		protected Text FG1C6ImoYn;

		internal static aBDsE4Ck4GCNYABIscy yVHErqDhD8Ib9Rjkxfh;

		public aBDsE4Ck4GCNYABIscy(yLWOmZwmRqSychwym35.S17b6ogswY7KLvgkjg8 u0020, float u0020, float u0020, float u0020, float u0020, string u0020, Color? u0020 = null)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.fp7CHusb2P(yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find(u0020.ToString()), u0020, u0020, u0020, u0020, u0020, u0020);
		}

		public aBDsE4Ck4GCNYABIscy(Transform u0020, float u0020, float u0020, float u0020, float u0020, string u0020, Color? u0020 = null)
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
			this.fp7CHusb2P(u0020, u0020, u0020, u0020, u0020, u0020, u0020);
		}

		internal static bool e17dM5DUh1Jpvp5RNQY()
		{
			return aBDsE4Ck4GCNYABIscy.yVHErqDhD8Ib9Rjkxfh == null;
		}

		public void E1HC9iOU0R(Color u0020)
		{
			this.FG1C6ImoYn.set_color(u0020);
		}

		private void fp7CHusb2P(Transform u0020, float u0020, float u0020, float u0020, float u0020, string u0020, Color? u0020 = null)
		{
			this.LtJCIaQw6U = UnityEngine.Object.Instantiate<GameObject>(yLWOmZwmRqSychwym35.urjwyqmP5S().get_transform().Find("Settings/AudioDevicePanel/MicDeviceText").get_gameObject(), u0020, false);
			this.FG1C6ImoYn = this.LtJCIaQw6U.GetComponent<Text>();
			this.LtJCIaQw6U.set_name(string.Format("{0}-SMText-{1}", "WTFBlaze", yLWOmZwmRqSychwym35.Fn2N9KXqf1()));
			this.R7qCG0Y6hT(new Vector2(u0020, u0020));
			this.rEOC3dO3S9(new Vector2(u0020, u0020));
			this.Jr1CsneDwT(u0020);
			if (u0020.HasValue)
			{
				this.E1HC9iOU0R(u0020.Value);
			}
			vBMVdGwfepiujjMKYNt.KARwoKKj3D.Add(this);
		}

		public GameObject hj5C4uurtN()
		{
			return this.LtJCIaQw6U;
		}

		public void Jr1CsneDwT(string u0020)
		{
			this.FG1C6ImoYn.set_supportRichText(true);
			this.FG1C6ImoYn.set_text(u0020);
		}

		public void lYnC72qMjx(int u0020)
		{
			this.FG1C6ImoYn.set_fontSize(u0020);
		}

		internal static aBDsE4Ck4GCNYABIscy pNt180DTqSbSP8k0w8w()
		{
			return aBDsE4Ck4GCNYABIscy.yVHErqDhD8Ib9Rjkxfh;
		}

		public void R7qCG0Y6hT(Vector2 u0020)
		{
			this.LtJCIaQw6U.GetComponent<RectTransform>().set_anchoredPosition(u0020);
		}

		public void rEOC3dO3S9(Vector2 u0020)
		{
			this.LtJCIaQw6U.GetComponent<RectTransform>().set_sizeDelta(u0020);
		}

		public void xfPCMeDUPS(TextAnchor u0020)
		{
			this.FG1C6ImoYn.set_alignment(u0020);
		}
	}
}