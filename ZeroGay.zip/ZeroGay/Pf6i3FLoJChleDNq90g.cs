using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void Pf6i3FLoJChleDNq90g(object object_0, Rigidbody rigidbody_0);