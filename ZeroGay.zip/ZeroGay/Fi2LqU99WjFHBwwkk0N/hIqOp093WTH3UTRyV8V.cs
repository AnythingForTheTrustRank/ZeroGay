using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using VRC.SDKBase;

namespace Fi2LqU99WjFHBwwkk0N
{
	internal class hIqOp093WTH3UTRyV8V
	{
		internal static hIqOp093WTH3UTRyV8V I7mZDZ5AtlUEdLhtM6b;

		public hIqOp093WTH3UTRyV8V()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static hIqOp093WTH3UTRyV8V NKVUQZ5Lno4x1cnGIT3()
		{
			return hIqOp093WTH3UTRyV8V.I7mZDZ5AtlUEdLhtM6b;
		}

		internal static bool vAC42C5VtGUUGlYHNOf()
		{
			return hIqOp093WTH3UTRyV8V.I7mZDZ5AtlUEdLhtM6b == null;
		}

		public static void ynV9sdoy07(object u0020)
		{
			Networking.SetOwner(VRCPlayer.get_field_Internal_Static_VRCPlayer_0().get_field_Private_VRCPlayerApi_0(), u0020);
		}
	}
}