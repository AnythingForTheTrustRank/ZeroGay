using b3eD5DgJPcASx0xfHYB;
using System;
using System.IO;

internal delegate FileStream DVA5AZnUC8X4cgJm8Vn(string );