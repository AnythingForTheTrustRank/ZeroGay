using System;

namespace dummy_ptr
{
	internal abstract class {7053eaf9-9154-4412-83b5-10d5fce79c11}
	{
		public abstract void m0007AE();
	}
}