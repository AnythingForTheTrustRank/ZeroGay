using System;

namespace dummy_ptr
{
	internal abstract class {65a36f69-db2a-4adf-894a-ccbe3a324de9}
	{
		public abstract void m00003E();

		public abstract void m0000A2();

		public abstract void m0000A8();

		public abstract void m0000AC();

		public abstract void m0000AE();
	}
}