using System;

namespace dummy_ptr
{
	internal abstract class {cc6ad93c-38ed-4340-8ddc-395646e88e26}
	{
		public abstract void m000020();

		public abstract void m000022();

		public abstract void m00003A();

		public abstract void m00003B();

		public abstract void m00003C();

		public abstract void m000066();

		public abstract void m000067();

		public abstract void m0000A4();

		public abstract void m0000A5();

		public abstract void m0000AB();

		public abstract void m0000C5();

		public abstract void m00010A();

		public abstract void m00010B();

		public abstract void m00010D();

		public abstract void m000119();

		public abstract void m000133();

		public abstract void m000134();

		public abstract void m0003AB();

		public abstract void m0003CD();

		public abstract void m00041B();

		public abstract void m00041E();

		public abstract void m000424();

		public abstract void m000432();

		public abstract void m00045D();

		public abstract void m0004AF();

		public abstract void m00078C();

		public abstract void m000790();

		public abstract void m000793();

		public abstract void m0007AA();

		public abstract void m000AA7();

		public abstract void mp000012();

		public abstract void mp000031();

		public abstract void mp000032();

		public abstract void mp000033();

		public abstract void mp000089();

		public abstract void mp0000BB();

		public abstract void mp0000BD();

		public abstract void mp0000C9();

		public abstract void mp0000CA();

		public abstract void mp0000D7();

		public abstract void mp000180();

		public abstract void mp000189();

		public abstract void mp0001A5();

		public abstract void mp000323();

		public abstract void mp000324();

		public abstract void mp000325();

		public abstract void mp000326();

		public abstract void mp00034C();
	}
}