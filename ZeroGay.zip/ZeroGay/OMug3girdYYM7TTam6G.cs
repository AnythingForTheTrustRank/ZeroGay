using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate Type OMug3girdYYM7TTam6G(object );