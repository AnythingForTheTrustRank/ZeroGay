using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using VRC.UI.Elements;

internal delegate Il2CppReferenceArray<UIPage> Rhc3pNxWTuJRIKCu8e1(object );