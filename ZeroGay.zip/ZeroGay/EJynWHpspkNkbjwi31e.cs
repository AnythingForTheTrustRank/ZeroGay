using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;

internal delegate Delegate EJynWHpspkNkbjwi31e(Type type_0, object object_0, MethodInfo methodInfo_0);