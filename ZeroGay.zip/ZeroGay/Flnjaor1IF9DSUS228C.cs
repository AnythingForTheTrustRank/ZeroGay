using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void Flnjaor1IF9DSUS228C(UnityEngine.Object , bool );