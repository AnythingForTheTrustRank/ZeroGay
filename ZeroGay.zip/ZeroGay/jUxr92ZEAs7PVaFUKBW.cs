using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate PlayerNet jUxr92ZEAs7PVaFUKBW(object );