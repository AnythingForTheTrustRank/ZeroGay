using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool SUsCx9JXeyDp5hWeegF(string string_0);