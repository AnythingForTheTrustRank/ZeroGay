using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate double STTFJA1iE6Cl0uvN5J8(ref TimeSpan timeSpan_0);