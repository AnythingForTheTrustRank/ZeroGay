using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate void cj4c2SnGo294LqBImPd(int );