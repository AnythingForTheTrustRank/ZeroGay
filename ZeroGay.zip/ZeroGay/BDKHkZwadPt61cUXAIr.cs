using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate bool BDKHkZwadPt61cUXAIr(Type type_0, Type type_1);