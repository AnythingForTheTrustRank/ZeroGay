using b3eD5DgJPcASx0xfHYB;
using System;
using System.Runtime.CompilerServices;

internal delegate AsyncVoidMethodBuilder NJBnItfnugpVr7i6rpE();