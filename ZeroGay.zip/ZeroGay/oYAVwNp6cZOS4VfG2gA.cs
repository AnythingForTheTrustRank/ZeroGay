using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Core;

internal delegate void oYAVwNp6cZOS4VfG2gA(object object_0, ApiAvatar apiAvatar_0);