using AksgHVKH9UOXlBDvRpO;
using Newtonsoft.Json;
using System;

internal delegate string G4S8rEuOKDJN71Z6Qid(object object_0, Formatting formatting_0);