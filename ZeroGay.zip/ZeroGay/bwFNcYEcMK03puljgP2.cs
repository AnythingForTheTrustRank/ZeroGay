using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Color bwFNcYEcMK03puljgP2(object object_0);