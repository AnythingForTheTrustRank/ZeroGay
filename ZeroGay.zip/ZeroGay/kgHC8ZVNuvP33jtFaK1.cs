using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using VRC.SDKBase;

internal delegate void kgHC8ZVNuvP33jtFaK1(object object_0, List<VRC_Interactable> list_0);