using AksgHVKH9UOXlBDvRpO;
using System;
using UnhollowerBaseLib;
using UnityEngine;

internal delegate bool XT2Pk4weXjPlGJHU7wL(Texture2D texture2D_0, Il2CppStructArray<byte> il2CppStructArray_0);