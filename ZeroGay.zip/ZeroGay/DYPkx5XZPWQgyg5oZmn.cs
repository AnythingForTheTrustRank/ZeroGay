using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Color32 DYPkx5XZPWQgyg5oZmn(Color color_0);