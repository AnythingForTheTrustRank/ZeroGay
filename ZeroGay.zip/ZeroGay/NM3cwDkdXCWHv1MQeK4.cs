using AksgHVKH9UOXlBDvRpO;
using System;
using System.Reflection;
using System.Reflection.Emit;

internal delegate void NM3cwDkdXCWHv1MQeK4(object object_0, OpCode opCode_0, MethodInfo methodInfo_0, Type[] type_0);