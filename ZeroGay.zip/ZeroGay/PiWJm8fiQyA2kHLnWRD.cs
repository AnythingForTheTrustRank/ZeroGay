using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Vector2 PiWJm8fiQyA2kHLnWRD(Vector2 , Vector2 );