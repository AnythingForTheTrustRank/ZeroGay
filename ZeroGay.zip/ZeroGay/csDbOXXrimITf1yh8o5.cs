using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector2 csDbOXXrimITf1yh8o5(Vector3 vector3_0);