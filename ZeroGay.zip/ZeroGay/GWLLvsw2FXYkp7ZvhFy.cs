using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate Type GWLLvsw2FXYkp7ZvhFy(object object_0, string string_0);