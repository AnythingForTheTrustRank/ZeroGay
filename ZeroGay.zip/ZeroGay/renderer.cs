using Il2CppSystem.Collections.Generic;
using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;
using VRC.Core;

public static class renderer
{
	public static void StartRenderElementsCoroutine(this UiVRCList instance, List<ApiAvatar> avatarList, int offset = 0, bool endOfPickers = true, VRCUiContentButton contentHeaderElement = null)
	{
		if ((!instance.get_gameObject().get_activeInHierarchy() || !instance.get_isActiveAndEnabled() || instance.get_isOffScreen() ? 1 : (int)(!instance.get_enabled())) == 0)
		{
			if (instance.get_scrollRect() != null)
			{
				instance.get_scrollRect().set_normalizedPosition(new Vector2(0f, 0f));
			}
			instance.Method_Protected_Void_List_1_T_Int32_Boolean_VRCUiContentButton_0<ApiAvatar>(avatarList, offset, endOfPickers, contentHeaderElement);
		}
	}
}