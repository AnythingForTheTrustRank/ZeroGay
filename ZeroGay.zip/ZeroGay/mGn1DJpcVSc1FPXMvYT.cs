using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Vector3 mGn1DJpcVSc1FPXMvYT(ref Quaternion );