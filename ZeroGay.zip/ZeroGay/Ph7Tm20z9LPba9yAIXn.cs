using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate VRCUiCursorManager Ph7Tm20z9LPba9yAIXn();