using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate HighlightsFX XXuE5kZgfEdBMTZA5pj();