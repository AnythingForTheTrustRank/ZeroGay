using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate VRCInput L07jDFKKmjxF2w2gWrC(object );