using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Bounds GDkBoR0kLcwOiyjI8ey(object );