using b3eD5DgJPcASx0xfHYB;
using System;
using System.Threading.Tasks;

internal delegate Task OgOhx2AfCV63Ebp9ZH8(int );