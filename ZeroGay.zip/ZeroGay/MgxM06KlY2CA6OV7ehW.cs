using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate void MgxM06KlY2CA6OV7ehW(object , AudioClip );