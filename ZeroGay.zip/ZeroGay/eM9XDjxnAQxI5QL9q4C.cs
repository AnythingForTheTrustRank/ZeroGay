using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Color32 eM9XDjxnAQxI5QL9q4C(Color );