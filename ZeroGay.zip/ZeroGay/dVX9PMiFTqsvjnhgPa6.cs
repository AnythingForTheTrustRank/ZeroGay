using b3eD5DgJPcASx0xfHYB;
using System;
using System.Reflection;

internal delegate bool dVX9PMiFTqsvjnhgPa6(MethodBase , MethodBase );