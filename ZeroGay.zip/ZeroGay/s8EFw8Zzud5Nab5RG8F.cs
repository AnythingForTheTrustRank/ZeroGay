using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void s8EFw8Zzud5Nab5RG8F(Array array_0, int int_0, Array array_1, int int_1, int int_2);