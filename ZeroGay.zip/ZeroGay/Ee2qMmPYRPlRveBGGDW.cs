using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string Ee2qMmPYRPlRveBGGDW(ref short short_0);