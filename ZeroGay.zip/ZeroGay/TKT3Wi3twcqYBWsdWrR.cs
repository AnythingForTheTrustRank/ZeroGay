using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void* TKT3Wi3twcqYBWsdWrR(IntPtr intptr_0);