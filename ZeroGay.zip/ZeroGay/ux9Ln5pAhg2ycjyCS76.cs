using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.Management;

internal delegate ModerationManager ux9Ln5pAhg2ycjyCS76();