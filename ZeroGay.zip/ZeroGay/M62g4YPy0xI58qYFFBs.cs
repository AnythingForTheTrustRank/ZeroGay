using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void M62g4YPy0xI58qYFFBs(object object_0, Transform transform_0);