using b3eD5DgJPcASx0xfHYB;
using q4loiAuxF6MNtBcZrh7;
using System;
using System.Collections.Generic;
using UnityEngine;
using VRC.Udon;

namespace EdLd516WygEAkf8W1hR
{
	internal class FZELGv6gCVvl9Qf4uhb
	{
		private static FZELGv6gCVvl9Qf4uhb WyQu4ddixYdWihYvoHi;

		public FZELGv6gCVvl9Qf4uhb()
		{
			i3ecBpgLeKWg8s1k4bW.ta2W4MZeBP();
			Qj2LPlufWaTAktMndvg.l0YkGk0xT1q();
			base();
		}

		internal static bool myCpgld0PmLPZ091gRp()
		{
			return FZELGv6gCVvl9Qf4uhb.WyQu4ddixYdWihYvoHi == null;
		}

		internal static void pVw6S0EYZx()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (1)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (2)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (3)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (4)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (5)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (6)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (7)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (8)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (9)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (10)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (11)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (12)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (13)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (14)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (15)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
				}
				if (!gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (16)"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Local_DamageHit");
			}
		}

		internal static void tRy6uJSPvb()
		{
			foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
			{
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (1)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (2)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (3)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (4)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (5)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (6)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (7)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (8)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (9)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (10)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (11)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (12)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (13)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (14)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (15)"))
				{
					gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
				}
				if (!gameObject.get_name().Contains("GameManager/PlayerObjectList/Humans/PlayerCharacterObject (16)"))
				{
					continue;
				}
				gameObject.GetComponent<UdonBehaviour>().SendCustomNetworkEvent(0, "Net_DamageHit");
			}
		}

		internal static FZELGv6gCVvl9Qf4uhb Tvrh7SdRAtbM4opL4sF()
		{
			return FZELGv6gCVvl9Qf4uhb.WyQu4ddixYdWihYvoHi;
		}
	}
}