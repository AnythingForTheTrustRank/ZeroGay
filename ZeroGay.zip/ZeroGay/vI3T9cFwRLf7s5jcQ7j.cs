using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate Vector2 vI3T9cFwRLf7s5jcQ7j(object object_0);