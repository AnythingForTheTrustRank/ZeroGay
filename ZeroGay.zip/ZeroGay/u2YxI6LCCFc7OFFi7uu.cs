using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Diagnostics;
using System;

internal delegate Process u2YxI6LCCFc7OFFi7uu();