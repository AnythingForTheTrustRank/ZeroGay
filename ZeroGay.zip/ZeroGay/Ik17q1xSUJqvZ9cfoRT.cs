using b3eD5DgJPcASx0xfHYB;
using System;
using UnhollowerBaseLib;
using VRC.UI.Elements;

internal delegate void Ik17q1xSUJqvZ9cfoRT(object , Il2CppReferenceArray<UIPage> );