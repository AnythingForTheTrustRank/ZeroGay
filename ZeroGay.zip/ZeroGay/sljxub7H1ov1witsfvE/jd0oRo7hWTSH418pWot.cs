using AksgHVKH9UOXlBDvRpO;
using Blaze.API.QM;
using NT6VhwyfEOcYbv2fFjN;
using System;
using System.Collections.Generic;
using tj5E7kTcTdevpjQ41CC;
using TMPro;
using UnityEngine;
using X7IetPATbOXxq4U7Vmy;

namespace sljxub7H1ov1witsfvE
{
	internal class jd0oRo7hWTSH418pWot
	{
		protected GameObject EcB7dbnbFX;

		protected TextMeshProUGUI EaG7vRjcCw;

		internal static jd0oRo7hWTSH418pWot OYqgnu4M46cWKIcALVk;

		public jd0oRo7hWTSH418pWot(QMNestedButton qmnestedButton_0, float float_0, float float_1, string string_0, Color? nullable_0)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.ris7sxCnv1(qmnestedButton_0.GetMenuObject().get_transform().get_parent(), float_0, float_1, string_0, nullable_0);
		}

		public jd0oRo7hWTSH418pWot(Transform transform_0, float float_0, float float_1, string string_0, Color? nullable_0)
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			base();
			this.ris7sxCnv1(transform_0, float_0, float_1, string_0, nullable_0);
		}

		public void AFq7GkR1Du()
		{
			try
			{
				UnityEngine.Object.Destroy(this.EcB7dbnbFX);
				UUyEqSykY4SKTrGkSI9.ojRyS51qkx.Remove(this);
			}
			catch
			{
			}
		}

		public GameObject jtF7RPbQPu()
		{
			return this.EcB7dbnbFX;
		}

		public void nKL7KbJQmU(string string_0)
		{
			this.EaG7vRjcCw.set_text(string_0);
		}

		internal static jd0oRo7hWTSH418pWot oCt36u4ygvcf9SZCMMv()
		{
			return jd0oRo7hWTSH418pWot.OYqgnu4M46cWKIcALVk;
		}

		public TextMeshProUGUI p1B7tB0khi()
		{
			return this.EaG7vRjcCw;
		}

		private void ris7sxCnv1(Transform transform_0, float float_0, float float_1, string string_0, Color? nullable_0)
		{
			this.EcB7dbnbFX = UnityEngine.Object.Instantiate<GameObject>(GameObject.Find("UserInterface/Canvas_QuickMenu(Clone)/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickLinks/LeftItemContainer/Text_Title"), transform_0, false);
			this.EcB7dbnbFX.set_name(string.Format("{0}-QMLabel-{1}", "WTFBlaze", x5iKdsT53msph4ugL7v.accTMUKvyj()));
			this.EaG7vRjcCw = this.EcB7dbnbFX.GetComponent<TextMeshProUGUI>();
			this.EaG7vRjcCw.set_alignment(514);
			this.EaG7vRjcCw.set_autoSizeTextContainer(true);
			this.EaG7vRjcCw.set_enableWordWrapping(false);
			this.EaG7vRjcCw.set_fontSize(32f);
			this.EaG7vRjcCw.set_richText(true);
			this.XXu7AyKkRA(new Vector2(float_0, float_1));
			this.nKL7KbJQmU(string_0);
			if (nullable_0.HasValue)
			{
				this.W3p7l5gHMN(nullable_0.Value);
			}
			UUyEqSykY4SKTrGkSI9.ojRyS51qkx.Add(this);
		}

		internal static bool tyByPn4aFDOqLGDum7H()
		{
			return jd0oRo7hWTSH418pWot.OYqgnu4M46cWKIcALVk == null;
		}

		public void W3p7l5gHMN(Color color_0)
		{
			this.EaG7vRjcCw.set_color(color_0);
		}

		public void XXu7AyKkRA(Vector2 vector2_0)
		{
			this.EcB7dbnbFX.GetComponent<RectTransform>().set_anchoredPosition(vector2_0);
		}
	}
}