using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate double uAaFYlVvuQBVI5rbiO2(ref TimeSpan );