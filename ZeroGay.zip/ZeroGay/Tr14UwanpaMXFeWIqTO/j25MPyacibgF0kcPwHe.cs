using AksgHVKH9UOXlBDvRpO;
using Il2CppSystem.Collections.Generic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnhollowerBaseLib;
using UnityEngine;
using VRC;
using VRC.Core;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;
using VRCSDK2;
using X7IetPATbOXxq4U7Vmy;

namespace Tr14UwanpaMXFeWIqTO
{
	internal static class j25MPyacibgF0kcPwHe
	{
		public static bool sTnao7LHoV;

		public static bool ejoa6CXDtQ;

		public static System.Collections.Generic.List<VRC.SDKBase.VRC_Pickup> WV7aYUot6J;

		public static Il2CppSystem.Collections.Generic.List<VRCPickup> Xu9aBOO5VT;

		public static Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger> Hk7arFmc1N;

		public static Il2CppSystem.Collections.Generic.List<VRC_ObjectSync> egNa2TtGso;

		public static VRC_EventHandler tvVaMBFGBa;

		public static Il2CppArrayBase<UdonBehaviour> ovXaawbpui;

		public static VRC_SyncVideoPlayer HRGayjbvI6;

		public static string[] L2haTSx3N3;

		public static bool Riua718qij;

		public static bool NpxaefMu5c;

		public static Player rjYaCVqqPo;

		private static j25MPyacibgF0kcPwHe eLTEf6mL3RMnSble4cW;

		static j25MPyacibgF0kcPwHe()
		{
			CjlfmMKhfV8QPfhHT9P.WQRKUO5a9D();
			ddXDFDAyjuXuTapZR07.cAWcnx1a8ek();
			j25MPyacibgF0kcPwHe.sTnao7LHoV = false;
			j25MPyacibgF0kcPwHe.ejoa6CXDtQ = false;
			j25MPyacibgF0kcPwHe.WV7aYUot6J = new System.Collections.Generic.List<VRC.SDKBase.VRC_Pickup>();
			j25MPyacibgF0kcPwHe.Xu9aBOO5VT = new Il2CppSystem.Collections.Generic.List<VRCPickup>();
			j25MPyacibgF0kcPwHe.Hk7arFmc1N = new Il2CppSystem.Collections.Generic.List<VRC.SDKBase.VRC_Trigger>();
			j25MPyacibgF0kcPwHe.egNa2TtGso = new Il2CppSystem.Collections.Generic.List<VRC_ObjectSync>();
			j25MPyacibgF0kcPwHe.Riua718qij = false;
			j25MPyacibgF0kcPwHe.NpxaefMu5c = true;
		}

		internal static j25MPyacibgF0kcPwHe LMZy72m3jEVdGmHykSX()
		{
			return j25MPyacibgF0kcPwHe.eLTEf6mL3RMnSble4cW;
		}

		internal static bool p9cEARm1fbsAxh2d8F1()
		{
			return j25MPyacibgF0kcPwHe.eLTEf6mL3RMnSble4cW == null;
		}

		internal static IEnumerator tAHaObGavo()
		{
			return new j25MPyacibgF0kcPwHe.<smethod_4>d__14(0);
		}

		public static void wxlaQSaVUP(object object_0)
		{
			foreach (Player array in PlayerManager.Method_Public_Static_get_PlayerManager_0().get_field_Private_List_1_Player_0().ToArray())
			{
				if (array.get_field_Private_APIUser_0().get_id() != object_0)
				{
					continue;
				}
				j25MPyacibgF0kcPwHe.rjYaCVqqPo = array;
			}
		}

		public static void z8OaILeQTR(object object_0, object object_1, Player player_0 = null, bool bool_0 = false)
		{
			if (object_0 != null)
			{
				UdonBehaviour component = object_0.GetComponent<UdonBehaviour>();
				if (player_0 != null)
				{
					Networking.SetOwner(player_0.get_field_Private_VRCPlayerApi_0(), object_0);
					component.SendCustomNetworkEvent(1, object_1);
				}
				else if (!bool_0)
				{
					component.SendCustomNetworkEvent(0, object_1);
				}
				else
				{
					component.SendCustomEvent(object_1);
				}
			}
			else
			{
				foreach (UdonBehaviour udonBehaviour in j25MPyacibgF0kcPwHe.ovXaawbpui)
				{
					if (!udonBehaviour.get__eventTable().ContainsKey(object_1))
					{
						continue;
					}
					udonBehaviour.SendCustomNetworkEvent(0, object_1);
				}
			}
		}
	}
}