using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate string PSxVa8p8ir2cnIsaCDp(object , string , string );