using b3eD5DgJPcASx0xfHYB;
using System;
using UnityEngine;

internal delegate Color wyUiWAFp9R7EGP10Cf0(Color32 );