using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate VRCWebSocketsManager t0HfDTR7aAHrC7jGZJD();