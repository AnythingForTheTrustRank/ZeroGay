using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void JN31X7XWFLyWC6TQSyW(object object_0);