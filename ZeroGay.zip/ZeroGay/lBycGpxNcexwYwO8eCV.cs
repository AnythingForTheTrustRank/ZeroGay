using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.UI.Elements;

internal delegate MenuStateController lBycGpxNcexwYwO8eCV(object );