using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate byte[] NA4YIDFDc5NAa9COGUD(object );