using AksgHVKH9UOXlBDvRpO;
using System;
using UnityEngine;

internal delegate void fJZrIC8fdORsjUkD578(object object_0, Color color_0);