using AksgHVKH9UOXlBDvRpO;
using System;
using System.Runtime.CompilerServices;

internal delegate bool JCb7cSLjJxvhM9pISkI(ref TaskAwaiter taskAwaiter_0);