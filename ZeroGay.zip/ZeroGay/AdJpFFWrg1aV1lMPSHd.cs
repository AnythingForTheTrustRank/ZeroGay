using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void AdJpFFWrg1aV1lMPSHd(object object_0, Array array_0, int int_0);