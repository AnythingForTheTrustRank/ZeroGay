using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void WHTmqRuKK0aETqFQ1WL(object object_0, int int_0);