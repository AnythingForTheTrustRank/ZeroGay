using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate string CZuRQC3C8D7PQI5hkFR(ref uint uint_0);