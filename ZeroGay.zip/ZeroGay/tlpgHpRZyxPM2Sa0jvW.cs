using b3eD5DgJPcASx0xfHYB;
using System;
using VRC.UserCamera;

internal delegate UserCameraController tlpgHpRZyxPM2Sa0jvW();