using b3eD5DgJPcASx0xfHYB;
using System;

internal delegate Exception adse27Lei3QfX7OfYsj(object );