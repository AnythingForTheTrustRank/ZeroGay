using AksgHVKH9UOXlBDvRpO;
using System;

internal delegate void d8Yvee1pkKl0sgPSoWj(object object_0, long long_0);