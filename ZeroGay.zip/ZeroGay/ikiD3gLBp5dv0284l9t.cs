using AksgHVKH9UOXlBDvRpO;
using System;
using VRC.SDKBase;

internal delegate VRC_Pickup ikiD3gLBp5dv0284l9t(object object_0);